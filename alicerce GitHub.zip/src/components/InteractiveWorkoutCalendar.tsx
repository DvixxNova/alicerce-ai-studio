import React, { useState, useMemo } from 'react';
import { Workout } from '../types';
import { fmtDayMonth, genId } from '../utils/constants';
import {
  CalendarIcon,
  CheckCircle2Icon,
  MoonIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  RotateCcwIcon,
  SparklesIcon,
} from './Icons';

interface InteractiveWorkoutCalendarProps {
  workouts: Workout[];
  setWorkouts: React.Dispatch<React.SetStateAction<Workout[]>>;
  todayIso: string;
  onFeedback: (msg: string) => void;
}

const MONTH_NAMES = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
];

const WEEKDAY_LABELS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

export const InteractiveWorkoutCalendar: React.FC<InteractiveWorkoutCalendarProps> = ({
  workouts,
  setWorkouts,
  todayIso,
  onFeedback,
}) => {
  // Calendar mode: 'week' | 'month'
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week');

  // Base navigation date (year & month or current week)
  const [navDate, setNavDate] = useState<Date>(() => new Date());

  // Check today's status
  const todayWorkout = useMemo(() => {
    return workouts.find((w) => w.date === todayIso);
  }, [workouts, todayIso]);

  const statusToday: 'Pendente' | 'Concluído' | 'Descanso' = todayWorkout
    ? todayWorkout.isRestDay
      ? 'Descanso'
      : 'Concluído'
    : 'Pendente';

  // Toggle day status
  const handleToggleDay = (isoDate: string) => {
    const existing = workouts.find((w) => w.date === isoDate);
    const dayDisplay = fmtDayMonth(isoDate);

    if (!existing) {
      // 1. Pending -> Completed
      const newWorkout: Workout = {
        id: genId(),
        name: 'Treino Concluído',
        date: isoDate,
        durationMinutes: 45,
        focus: 'Treino Realizado',
        isRestDay: false,
      };
      setWorkouts((prev) => [newWorkout, ...prev]);
      onFeedback(`🎉 Dia ${dayDisplay} marcado como Concluído!`);
    } else if (!existing.isRestDay) {
      // 2. Completed -> Rest
      setWorkouts((prev) =>
        prev.map((w) =>
          w.date === isoDate
            ? {
                ...w,
                name: 'Dia de Descanso & Recuperação',
                durationMinutes: 0,
                focus: 'Recuperação Muscular',
                isRestDay: true,
              }
            : w
        )
      );
      onFeedback(`💤 Dia ${dayDisplay} alterado para Dia de Descanso.`);
    } else {
      // 3. Rest -> Pending (remove entry)
      setWorkouts((prev) => prev.filter((w) => w.date !== isoDate));
      onFeedback(`⚪ Registro do dia ${dayDisplay} removido (Pendente).`);
    }
  };

  // --- WEEK DATA CALCULATION ---
  const weekData = useMemo(() => {
    const current = new Date(navDate);
    const dayOfWeek = current.getDay(); // 0 is Sunday
    const distanceToMonday = (dayOfWeek + 6) % 7;
    const monday = new Date(current);
    monday.setDate(current.getDate() - distanceToMonday);

    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      const iso = d.toISOString().slice(0, 10);
      const isToday = iso === todayIso;
      const workoutOnDay = workouts.find((w) => w.date === iso);
      const isCompleted = Boolean(workoutOnDay && !workoutOnDay.isRestDay);
      const isRest = Boolean(workoutOnDay && workoutOnDay.isRestDay);

      days.push({
        label: WEEKDAY_LABELS[i],
        dayNum: d.getDate(),
        iso,
        isToday,
        isCompleted,
        isRest,
        workout: workoutOnDay,
      });
    }

    const startLabel = fmtDayMonth(days[0].iso);
    const endLabel = fmtDayMonth(days[6].iso);

    return { days, rangeLabel: `${startLabel} a ${endLabel}` };
  }, [navDate, workouts, todayIso]);

  // --- MONTH DATA CALCULATION ---
  const monthData = useMemo(() => {
    const year = navDate.getFullYear();
    const month = navDate.getMonth();

    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const totalDays = lastDay.getDate();

    // Monday as start (0: Mon, ..., 6: Sun)
    const firstDayOfWeek = (firstDay.getDay() + 6) % 7;

    // Previous month filler days
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    const prevDays = [];
    for (let i = firstDayOfWeek - 1; i >= 0; i--) {
      const dayNum = prevMonthLastDay - i;
      const d = new Date(year, month - 1, dayNum);
      const iso = d.toISOString().slice(0, 10);
      const workoutOnDay = workouts.find((w) => w.date === iso);
      prevDays.push({
        dayNum,
        iso,
        isCurrentMonth: false,
        isToday: iso === todayIso,
        isCompleted: Boolean(workoutOnDay && !workoutOnDay.isRestDay),
        isRest: Boolean(workoutOnDay && workoutOnDay.isRestDay),
      });
    }

    // Current month days
    const currentDays = [];
    for (let i = 1; i <= totalDays; i++) {
      const d = new Date(year, month, i);
      const iso = d.toISOString().slice(0, 10);
      const workoutOnDay = workouts.find((w) => w.date === iso);
      currentDays.push({
        dayNum: i,
        iso,
        isCurrentMonth: true,
        isToday: iso === todayIso,
        isCompleted: Boolean(workoutOnDay && !workoutOnDay.isRestDay),
        isRest: Boolean(workoutOnDay && workoutOnDay.isRestDay),
      });
    }

    // Next month filler days to complete grid to 35 or 42 cells
    const combinedLength = prevDays.length + currentDays.length;
    const totalSlots = combinedLength > 35 ? 42 : 35;
    const nextDays = [];
    for (let i = 1; i <= totalSlots - combinedLength; i++) {
      const d = new Date(year, month + 1, i);
      const iso = d.toISOString().slice(0, 10);
      const workoutOnDay = workouts.find((w) => w.date === iso);
      nextDays.push({
        dayNum: i,
        iso,
        isCurrentMonth: false,
        isToday: iso === todayIso,
        isCompleted: Boolean(workoutOnDay && !workoutOnDay.isRestDay),
        isRest: Boolean(workoutOnDay && workoutOnDay.isRestDay),
      });
    }

    return {
      title: `${MONTH_NAMES[month]} de ${year}`,
      cells: [...prevDays, ...currentDays, ...nextDays],
    };
  }, [navDate, workouts, todayIso]);

  // Navigation handlers
  const handlePrev = () => {
    setNavDate((prev) => {
      const next = new Date(prev);
      if (viewMode === 'week') {
        next.setDate(next.getDate() - 7);
      } else {
        next.setMonth(next.getMonth() - 1);
      }
      return next;
    });
  };

  const handleNext = () => {
    setNavDate((prev) => {
      const next = new Date(prev);
      if (viewMode === 'week') {
        next.setDate(next.getDate() + 7);
      } else {
        next.setMonth(next.getMonth() + 1);
      }
      return next;
    });
  };

  const handleGoToday = () => {
    setNavDate(new Date());
  };

  return (
    <div
      style={{
        background: 'var(--panel-strong, rgba(255, 255, 255, 0.04))',
        border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
        borderRadius: '1.05rem',
        padding: '1rem 1.1rem',
        marginBottom: '1.2rem',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      {/* Header bar: Title, View mode switcher, and Today's status */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '0.85rem',
          flexWrap: 'wrap',
          gap: '0.6rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: '0.55rem',
              background: 'linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(139, 92, 246, 0.2))',
              border: '1px solid rgba(236, 72, 153, 0.35)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <CalendarIcon size={17} color="#EC4899" />
          </div>
          <div>
            <div
              style={{
                fontSize: '0.82rem',
                fontWeight: 800,
                color: 'var(--ink)',
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
              }}
            >
              <span>Calendário Interativo de Treinos</span>
            </div>
            <div style={{ fontSize: '0.68rem', color: 'var(--ink-soft)' }}>
              Clique em qualquer dia para alternar:{' '}
              <strong style={{ color: '#16A34A' }}>Concluído ✓</strong> →{' '}
              <strong style={{ color: '#8B5CF6' }}>Descanso 💤</strong> →{' '}
              <strong style={{ color: 'var(--ink-soft)' }}>Pendente</strong>
            </div>
          </div>
        </div>

        {/* Switcher & Today badge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
          {/* View Mode Switcher (Semanal / Mensal) */}
          <div
            style={{
              display: 'inline-flex',
              background: 'rgba(255, 255, 255, 0.06)',
              borderRadius: '0.55rem',
              padding: '2px',
              border: '1px solid var(--line)',
            }}
          >
            <button
              type="button"
              id="calendar-mode-week-btn"
              onClick={() => setViewMode('week')}
              style={{
                background: viewMode === 'week' ? 'linear-gradient(135deg, #EC4899, #F97316)' : 'transparent',
                color: viewMode === 'week' ? '#fff' : 'var(--ink-soft)',
                border: 'none',
                borderRadius: '0.45rem',
                fontSize: '0.7rem',
                fontWeight: 700,
                padding: '0.3rem 0.65rem',
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
            >
              Semanal
            </button>
            <button
              type="button"
              id="calendar-mode-month-btn"
              onClick={() => setViewMode('month')}
              style={{
                background: viewMode === 'month' ? 'linear-gradient(135deg, #8B5CF6, #3B82F6)' : 'transparent',
                color: viewMode === 'month' ? '#fff' : 'var(--ink-soft)',
                border: 'none',
                borderRadius: '0.45rem',
                fontSize: '0.7rem',
                fontWeight: 700,
                padding: '0.3rem 0.65rem',
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
            >
              Mensal
            </button>
          </div>

          {/* Today Status Pill */}
          <span
            style={{
              fontSize: '0.7rem',
              fontWeight: 700,
              padding: '0.25rem 0.65rem',
              borderRadius: '9999px',
              border: '1px solid',
              borderColor:
                statusToday === 'Concluído'
                  ? 'rgba(34, 197, 94, 0.4)'
                  : statusToday === 'Descanso'
                  ? 'rgba(139, 92, 246, 0.4)'
                  : 'var(--line)',
              background:
                statusToday === 'Concluído'
                  ? 'rgba(34, 197, 94, 0.14)'
                  : statusToday === 'Descanso'
                  ? 'rgba(139, 92, 246, 0.14)'
                  : 'rgba(255, 255, 255, 0.05)',
              color:
                statusToday === 'Concluído'
                  ? '#16A34A'
                  : statusToday === 'Descanso'
                  ? '#8B5CF6'
                  : 'var(--ink-soft)',
            }}
          >
            Hoje: {statusToday}
          </span>
        </div>
      </div>

      {/* Navigation Sub-Bar: Prev / Range or Month Title / Next / Go to Today */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '0.75rem',
          paddingBottom: '0.5rem',
          borderBottom: '1px solid var(--line)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <button
            type="button"
            title="Anterior"
            onClick={handlePrev}
            style={{
              background: 'rgba(255, 255, 255, 0.06)',
              border: '1px solid var(--line)',
              color: 'var(--ink)',
              borderRadius: '0.45rem',
              width: 28,
              height: 28,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            <ChevronLeftIcon size={14} />
          </button>

          <span
            style={{
              fontSize: '0.78rem',
              fontWeight: 800,
              fontFamily: 'var(--font-mono)',
              color: 'var(--ink)',
              padding: '0 0.35rem',
            }}
          >
            {viewMode === 'week' ? `Semana: ${weekData.rangeLabel}` : monthData.title}
          </span>

          <button
            type="button"
            title="Próximo"
            onClick={handleNext}
            style={{
              background: 'rgba(255, 255, 255, 0.06)',
              border: '1px solid var(--line)',
              color: 'var(--ink)',
              borderRadius: '0.45rem',
              width: 28,
              height: 28,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            <ChevronRightIcon size={14} />
          </button>
        </div>

        <button
          type="button"
          onClick={handleGoToday}
          style={{
            background: 'transparent',
            border: '1px solid var(--line)',
            color: 'var(--ink-soft)',
            borderRadius: '0.45rem',
            fontSize: '0.68rem',
            fontWeight: 700,
            padding: '0.25rem 0.55rem',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '0.3rem',
          }}
        >
          <RotateCcwIcon size={11} />
          <span>Voltar p/ Hoje</span>
        </button>
      </div>

      {/* --- MODO SEMANAL (Faixa de 7 dias) --- */}
      {viewMode === 'week' && (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(7, 1fr)',
            gap: '0.45rem',
          }}
        >
          {weekData.days.map((d) => {
            let bg = 'rgba(255, 255, 255, 0.03)';
            let borderColor = 'var(--line)';
            let textColor = 'var(--ink-soft)';
            let badgeText = '';

            if (d.isCompleted) {
              bg = 'rgba(34, 197, 94, 0.18)';
              borderColor = '#22C55E';
              textColor = 'var(--ink)';
              badgeText = 'Treino ✓';
            } else if (d.isRest) {
              bg = 'rgba(139, 92, 246, 0.18)';
              borderColor = '#8B5CF6';
              textColor = 'var(--ink)';
              badgeText = 'Descanso 💤';
            } else if (d.isToday) {
              borderColor = '#EC4899';
              bg = 'rgba(236, 72, 153, 0.09)';
              textColor = 'var(--ink)';
            }

            return (
              <button
                key={d.iso}
                type="button"
                onClick={() => handleToggleDay(d.iso)}
                title={`Clique para alternar o status do dia ${fmtDayMonth(d.iso)}`}
                style={{
                  background: bg,
                  border: `1.5px solid ${borderColor}`,
                  borderRadius: '0.75rem',
                  padding: '0.65rem 0.2rem',
                  textAlign: 'center',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.25rem',
                  position: 'relative',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  userSelect: 'none',
                  minHeight: 88,
                  justifyContent: 'space-between',
                }}
              >
                {d.isToday && (
                  <span
                    style={{
                      fontSize: '0.54rem',
                      fontWeight: 800,
                      background: '#EC4899',
                      color: '#fff',
                      borderRadius: '9999px',
                      padding: '0.05rem 0.4rem',
                      lineHeight: 1.2,
                    }}
                  >
                    Hoje
                  </span>
                )}

                <span
                  style={{
                    fontSize: '0.65rem',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    color: textColor,
                  }}
                >
                  {d.label}
                </span>

                <span
                  style={{
                    fontSize: '1.05rem',
                    fontWeight: 800,
                    fontFamily: 'var(--font-mono)',
                    color: textColor,
                  }}
                >
                  {d.dayNum}
                </span>

                {/* Status Indicator Icon or Badge */}
                <div style={{ minHeight: 20, display: 'flex', alignItems: 'center' }}>
                  {d.isCompleted ? (
                    <span
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.2rem',
                        fontSize: '0.6rem',
                        fontWeight: 800,
                        color: '#16A34A',
                        background: 'rgba(34, 197, 94, 0.22)',
                        padding: '0.1rem 0.4rem',
                        borderRadius: '0.35rem',
                      }}
                    >
                      <CheckCircle2Icon size={12} />
                      <span>Feito</span>
                    </span>
                  ) : d.isRest ? (
                    <span
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.2rem',
                        fontSize: '0.6rem',
                        fontWeight: 800,
                        color: '#8B5CF6',
                        background: 'rgba(139, 92, 246, 0.22)',
                        padding: '0.1rem 0.4rem',
                        borderRadius: '0.35rem',
                      }}
                    >
                      <MoonIcon size={12} />
                      <span>Off</span>
                    </span>
                  ) : (
                    <span
                      style={{
                        width: 7,
                        height: 7,
                        borderRadius: '50%',
                        background: d.isToday ? '#EC4899' : 'var(--line)',
                      }}
                    />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* --- MODO MENSAL (Grade Completa com 7 colunas) --- */}
      {viewMode === 'month' && (
        <div>
          {/* Weekday headers */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(7, 1fr)',
              gap: '0.35rem',
              marginBottom: '0.35rem',
              textAlign: 'center',
            }}
          >
            {WEEKDAY_LABELS.map((w) => (
              <span
                key={w}
                style={{
                  fontSize: '0.65rem',
                  fontWeight: 700,
                  textTransform: 'uppercase',
                  color: 'var(--ink-soft)',
                  padding: '0.2rem 0',
                }}
              >
                {w}
              </span>
            ))}
          </div>

          {/* Month Cells */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(7, 1fr)',
              gap: '0.35rem',
            }}
          >
            {monthData.cells.map((cell, idx) => {
              let bg = cell.isCurrentMonth
                ? 'rgba(255, 255, 255, 0.03)'
                : 'rgba(255, 255, 255, 0.01)';
              let borderColor = cell.isCurrentMonth ? 'var(--line)' : 'transparent';
              let opacity = cell.isCurrentMonth ? 1 : 0.45;
              let textColor = 'var(--ink)';

              if (cell.isCompleted) {
                bg = 'rgba(34, 197, 94, 0.2)';
                borderColor = '#22C55E';
              } else if (cell.isRest) {
                bg = 'rgba(139, 92, 246, 0.2)';
                borderColor = '#8B5CF6';
              } else if (cell.isToday) {
                borderColor = '#EC4899';
                bg = 'rgba(236, 72, 153, 0.12)';
              }

              return (
                <button
                  key={cell.iso + idx}
                  type="button"
                  onClick={() => handleToggleDay(cell.iso)}
                  title={`${fmtDayMonth(cell.iso)}: Clique para alternar status`}
                  style={{
                    background: bg,
                    border: `1.5px solid ${borderColor}`,
                    borderRadius: '0.55rem',
                    padding: '0.45rem 0.2rem',
                    textAlign: 'center',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    minHeight: 52,
                    cursor: 'pointer',
                    opacity,
                    transition: 'all 0.12s ease',
                    position: 'relative',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      width: '100%',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '0.78rem',
                        fontWeight: cell.isToday ? 800 : 700,
                        fontFamily: 'var(--font-mono)',
                        color: cell.isToday ? '#EC4899' : textColor,
                      }}
                    >
                      {cell.dayNum}
                    </span>
                  </div>

                  <div style={{ height: 16, display: 'flex', alignItems: 'center' }}>
                    {cell.isCompleted ? (
                      <CheckCircle2Icon size={13} color="#16A34A" />
                    ) : cell.isRest ? (
                      <MoonIcon size={13} color="#8B5CF6" />
                    ) : cell.isToday ? (
                      <span
                        style={{
                          width: 5,
                          height: 5,
                          borderRadius: '50%',
                          background: '#EC4899',
                        }}
                      />
                    ) : null}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Footer Legend */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          gap: '1rem',
          marginTop: '0.75rem',
          paddingTop: '0.5rem',
          borderTop: '1px solid var(--line)',
          fontSize: '0.67rem',
          color: 'var(--ink-soft)',
          flexWrap: 'wrap',
        }}
      >
        <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
          <span
            style={{
              width: 9,
              height: 9,
              borderRadius: '50%',
              background: '#22C55E',
              boxShadow: '0 0 6px rgba(34, 197, 94, 0.4)',
            }}
          />
          <strong>Concluído (✓)</strong>
        </span>

        <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
          <span
            style={{
              width: 9,
              height: 9,
              borderRadius: '50%',
              background: '#8B5CF6',
              boxShadow: '0 0 6px rgba(139, 92, 246, 0.4)',
            }}
          />
          <strong>Descanso (💤)</strong>
        </span>

        <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
          <span
            style={{
              width: 9,
              height: 9,
              borderRadius: '50%',
              background: 'var(--line)',
            }}
          />
          <span>Pendente</span>
        </span>
      </div>
    </div>
  );
};
