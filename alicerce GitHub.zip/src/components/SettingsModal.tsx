import React, { useState, useRef, useEffect } from 'react';
import {
  SettingsGearIcon,
  XIcon,
  CheckIcon,
  CameraIcon,
  UserIcon,
  MailIcon,
  TargetIcon,
  SunIcon,
  MoonIcon,
  MonitorIcon,
  DumbbellIcon,
  WalletIcon,
  LightbulbIcon,
  BookOpenIcon,
  TrashIcon,
} from './Icons';
import { Zap, Sparkles, Waves, Crown, Smartphone, LogIn } from 'lucide-react';
import { ThemeMode, UserProfile } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onSaveProfile: (profile: UserProfile) => void;
  theme: ThemeMode;
  onSelectTheme: (theme: ThemeMode) => void;
  onOpenIPhoneDownload?: () => void;
  onOpenLogin?: () => void;
}

const PRESET_AVATARS = [
  {
    id: 'fitness',
    label: 'Atleta',
    gradient: 'linear-gradient(135deg, #F43F5E, #FB923C)',
    icon: DumbbellIcon,
  },
  {
    id: 'finance',
    label: 'Finanças',
    gradient: 'linear-gradient(135deg, #10B981, #059669)',
    icon: WalletIcon,
  },
  {
    id: 'mind',
    label: 'Foco & Mente',
    gradient: 'linear-gradient(135deg, #6366F1, #8B5CF6)',
    icon: LightbulbIcon,
  },
  {
    id: 'wisdom',
    label: 'Propósito',
    gradient: 'linear-gradient(135deg, #EC4899, #8B5CF6)',
    icon: BookOpenIcon,
  },
];

const MAIN_GOALS = [
  'Hipertrofia & Rendimento Físico',
  'Saúde Financeira & Investimentos',
  'Qualidade de Vida & Longevidade',
  'Equilíbrio, Foco & Produtividade',
  'Constância Espiritual & Propósito',
  'Organização & Rotina Diária',
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onSaveProfile,
  theme,
  onSelectTheme,
  onOpenIPhoneDownload,
  onOpenLogin,
}) => {
  const [name, setName] = useState(userProfile.name || '');
  const [email, setEmail] = useState(userProfile.email || '');
  const [mainGoal, setMainGoal] = useState(
    userProfile.mainGoal || MAIN_GOALS[0]
  );
  const [avatarUrl, setAvatarUrl] = useState(userProfile.avatarUrl || '');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync state if userProfile changes
  useEffect(() => {
    if (isOpen) {
      setName(userProfile.name || '');
      setEmail(userProfile.email || '');
      setMainGoal(userProfile.mainGoal || MAIN_GOALS[0]);
      setAvatarUrl(userProfile.avatarUrl || '');
      setSavedSuccess(false);
    }
  }, [isOpen, userProfile]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Por favor selecione uma imagem menor que 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile({
      name: name.trim(),
      email: email.trim(),
      mainGoal,
      avatarUrl,
    });
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
    }, 1800);
  };

  const handleExportData = () => {
    try {
      const data = localStorage.getItem('alicerce_data') || '{}';
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `alicerce-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      // Ignore
    }
  };

  // Determine avatar representation
  const isPresetAvatar = avatarUrl.startsWith('preset:');
  const activePreset = isPresetAvatar
    ? PRESET_AVATARS.find((p) => `preset:${p.id}` === avatarUrl)
    : null;

  return (
    <div
      id="settings-overlay"
      className="settings-backdrop"
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        background: 'rgba(5, 8, 26, 0.68)',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        display: 'flex',
        justifyContent: 'flex-end',
        animation: 'fadeIn 0.2s ease-out',
      }}
    >
      <style>{`
        @keyframes slideInRight {
          from { transform: translateX(100%); opacity: 0.7; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .settings-drawer {
          width: 100%;
          max-width: 440px;
          height: 100vh;
          overflow-y: auto;
          background: var(--settings-panel-bg, #0F1433);
          border-left: 1px solid var(--settings-border, rgba(255, 255, 255, 0.12));
          box-shadow: -10px 0 40px rgba(0, 0, 0, 0.55);
          animation: slideInRight 0.28s cubic-bezier(0.16, 1, 0.3, 1);
          display: flex;
          flex-direction: column;
          box-sizing: border-box;
          color: var(--ink, #F3F5FF);
        }
        .settings-drawer::-webkit-scrollbar {
          width: 5px;
        }
        .settings-drawer::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.15);
          border-radius: 9999px;
        }
        .settings-section-card {
          background: var(--settings-card-bg, rgba(255, 255, 255, 0.045));
          border: 1px solid var(--settings-border, rgba(255, 255, 255, 0.1));
          border-radius: 1.1rem;
          padding: 1.1rem;
          margin-bottom: 1.25rem;
          transition: border-color 0.2s ease;
        }
        .settings-input-group {
          margin-bottom: 0.95rem;
        }
        .settings-label {
          display: flex;
          align-items: center;
          gap: 0.4rem;
          font-size: 0.78rem;
          font-weight: 600;
          margin-bottom: 0.4rem;
          color: var(--settings-label-color, #CBD5E1);
          text-transform: uppercase;
          letter-spacing: 0.03em;
        }
        .settings-input-wrap {
          position: relative;
          display: flex;
          align-items: center;
        }
        .settings-input-wrap svg {
          position: absolute;
          left: 0.8rem;
          color: var(--ink-soft, #94A3B8);
          pointer-events: none;
        }
        .settings-input {
          width: 100%;
          background: var(--settings-input-bg, rgba(255, 255, 255, 0.07)) !important;
          border: 1px solid var(--settings-border, rgba(255, 255, 255, 0.12)) !important;
          border-radius: 0.75rem !important;
          padding: 0.65rem 0.8rem 0.65rem 2.4rem !important;
          font-size: 0.88rem !important;
          color: var(--ink, #FFFFFF) !important;
          outline: none;
          transition: all 0.2s ease;
          box-sizing: border-box;
        }
        .settings-input:focus {
          border-color: var(--active, #6366F1) !important;
          box-shadow: 0 0 0 3px var(--settings-focus-glow, rgba(99, 102, 241, 0.25)) !important;
        }
        .settings-select {
          width: 100%;
          background: var(--settings-input-bg, rgba(255, 255, 255, 0.07)) !important;
          border: 1px solid var(--settings-border, rgba(255, 255, 255, 0.12)) !important;
          border-radius: 0.75rem !important;
          padding: 0.65rem 0.8rem 0.65rem 2.4rem !important;
          font-size: 0.85rem !important;
          color: var(--ink, #FFFFFF) !important;
          outline: none;
          cursor: pointer;
          transition: all 0.2s ease;
          box-sizing: border-box;
        }
        .settings-select option {
          background: #111638;
          color: #FFFFFF;
        }
        .theme-choice-card {
          border: 1.5px solid var(--settings-border, rgba(255, 255, 255, 0.1));
          border-radius: 0.9rem;
          padding: 0.85rem 0.95rem;
          background: var(--settings-card-bg, rgba(255, 255, 255, 0.035));
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 0.85rem;
          transition: all 0.2s ease;
          position: relative;
          text-align: left;
          width: 100%;
        }
        .theme-choice-card:hover {
          border-color: var(--settings-border-hover, rgba(255, 255, 255, 0.25));
          transform: translateY(-1px);
        }
        .theme-choice-card.active {
          border-color: var(--active, #6366F1);
          background: var(--settings-active-card, rgba(99, 102, 241, 0.12));
          box-shadow: 0 4px 18px var(--settings-glow, rgba(99, 102, 241, 0.2));
        }
        .theme-preview-box {
          width: 44px;
          height: 44px;
          border-radius: 0.65rem;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          box-shadow: 0 4px 10px rgba(0,0,0,0.25);
        }
        .theme-radio-circle {
          width: 18px;
          height: 18px;
          border-radius: 50%;
          border: 2px solid var(--settings-border, rgba(255, 255, 255, 0.25));
          display: flex;
          align-items: center;
          justify-content: center;
          margin-left: auto;
          flex-shrink: 0;
        }
        .theme-choice-card.active .theme-radio-circle {
          border-color: var(--active, #6366F1);
          background: var(--active, #6366F1);
        }
        .theme-choice-card.active .theme-radio-circle::after {
          content: '';
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #FFFFFF;
        }
      `}</style>

      <div
        id="settings-drawer-panel"
        className="settings-drawer"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label="Painel de Configurações"
      >
        {/* Top Header with Close 'X' */}
        <div
          style={{
            padding: '1.25rem 1.4rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderBottom: '1px solid var(--settings-border, rgba(255, 255, 255, 0.08))',
            position: 'sticky',
            top: 0,
            zIndex: 10,
            background: 'var(--settings-header-bg, rgba(15, 20, 51, 0.95))',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '0.65rem',
                background: 'linear-gradient(135deg, #6366F1, #8B5CF6)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fff',
                boxShadow: '0 4px 12px rgba(99, 102, 241, 0.35)',
              }}
            >
              <SettingsGearIcon size={20} />
            </div>
            <div>
              <h2
                style={{
                  margin: 0,
                  fontSize: '1.15rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-display, sans-serif)',
                  letterSpacing: '-0.01em',
                  color: 'var(--ink, #FFFFFF)',
                }}
              >
                Configurações
              </h2>
              <p
                style={{
                  margin: 0,
                  fontSize: '0.72rem',
                  color: 'var(--ink-soft, #94A3B8)',
                }}
              >
                Perfil & Preferências do Alicerce
              </p>
            </div>
          </div>

          <button
            id="settings-close-btn"
            type="button"
            onClick={onClose}
            aria-label="Fechar painel"
            title="Fechar (Esc)"
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.06)',
              border: '1px solid var(--settings-border, rgba(255, 255, 255, 0.12))',
              color: 'var(--ink-soft, #94A3B8)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.15s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = 'var(--ink, #FFFFFF)';
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.12)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = 'var(--ink-soft, #94A3B8)';
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.06)';
            }}
          >
            <XIcon size={18} />
          </button>
        </div>

        {/* Drawer Scrollable Content */}
        <div style={{ padding: '1.25rem 1.4rem', flex: 1 }}>
          {/* SEÇÃO 1: CADASTRO DO USUÁRIO (PERFIL) */}
          <form onSubmit={handleSave}>
            <div className="settings-section-card">
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '1rem',
                  paddingBottom: '0.6rem',
                  borderBottom: '1px solid var(--settings-border, rgba(255, 255, 255, 0.08))',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                  <UserIcon size={17} color="var(--active, #6366F1)" />
                  <span
                    style={{
                      fontFamily: 'var(--font-display, sans-serif)',
                      fontWeight: 700,
                      fontSize: '0.95rem',
                      color: 'var(--ink, #FFFFFF)',
                    }}
                  >
                    Perfil do Usuário
                  </span>
                </div>
                <span
                  style={{
                    fontSize: '0.65rem',
                    padding: '0.2rem 0.5rem',
                    borderRadius: '9999px',
                    background: 'rgba(99, 102, 241, 0.15)',
                    color: '#A5B4FC',
                    fontWeight: 600,
                  }}
                >
                  Identidade
                </span>
              </div>

              {/* Avatar circular com opção de alterar imagem */}
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  marginBottom: '1.3rem',
                }}
              >
                <div
                  style={{
                    position: 'relative',
                    width: '84px',
                    height: '84px',
                    borderRadius: '50%',
                    padding: '3px',
                    background: 'linear-gradient(135deg, var(--active, #6366F1), #A855F7)',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
                    cursor: 'pointer',
                  }}
                  onClick={() => fileInputRef.current?.click()}
                  title="Clique para alterar foto"
                >
                  <div
                    style={{
                      width: '100%',
                      height: '100%',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      background: activePreset
                        ? activePreset.gradient
                        : 'linear-gradient(135deg, #1E2552, #0D112B)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                    }}
                  >
                    {avatarUrl && !isPresetAvatar ? (
                      <img
                        src={avatarUrl}
                        alt="Foto de perfil"
                        referrerPolicy="no-referrer"
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      />
                    ) : activePreset ? (
                      <activePreset.icon size={36} color="#FFFFFF" />
                    ) : name ? (
                      <span
                        style={{
                          fontSize: '1.9rem',
                          fontWeight: 700,
                          fontFamily: 'var(--font-display, sans-serif)',
                          color: '#FFFFFF',
                        }}
                      >
                        {name.trim().charAt(0).toUpperCase()}
                      </span>
                    ) : (
                      <UserIcon size={34} color="#94A3B8" />
                    )}

                    {/* Camera overlay button */}
                    <div
                      style={{
                        position: 'absolute',
                        inset: 0,
                        background: 'rgba(0, 0, 0, 0.42)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: 0,
                        transition: 'opacity 0.2s ease',
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.opacity = '1')}
                      onMouseLeave={(e) => (e.currentTarget.style.opacity = '0')}
                    >
                      <CameraIcon size={22} color="#FFFFFF" />
                    </div>
                  </div>

                  {/* Badge floating camera */}
                  <div
                    style={{
                      position: 'absolute',
                      bottom: '-2px',
                      right: '-2px',
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      background: 'var(--active, #6366F1)',
                      border: '2px solid #0F1433',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: '#fff',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
                    }}
                  >
                    <CameraIcon size={14} />
                  </div>
                </div>

                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleImageUpload}
                  style={{ display: 'none' }}
                />

                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    marginTop: '0.65rem',
                  }}
                >
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: 'var(--active, #6366F1)',
                      fontSize: '0.78rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                      padding: '0.2rem 0.4rem',
                      borderRadius: '0.4rem',
                    }}
                  >
                    Carregar foto
                  </button>
                  {avatarUrl && (
                    <>
                      <span style={{ color: 'var(--ink-soft, #94A3B8)', fontSize: '0.75rem' }}>
                        •
                      </span>
                      <button
                        type="button"
                        onClick={() => setAvatarUrl('')}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: '#EF4444',
                          fontSize: '0.75rem',
                          cursor: 'pointer',
                          padding: '0.2rem 0.4rem',
                        }}
                      >
                        Remover
                      </button>
                    </>
                  )}
                </div>

                {/* Preset Avatars Quick Row */}
                <div style={{ marginTop: '0.75rem', width: '100%', textAlign: 'center' }}>
                  <div
                    style={{
                      fontSize: '0.68rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginBottom: '0.4rem',
                    }}
                  >
                    Ou escolha um avatar temático:
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'center',
                      gap: '0.55rem',
                    }}
                  >
                    {PRESET_AVATARS.map((p) => {
                      const isSelected = avatarUrl === `preset:${p.id}`;
                      const IconComp = p.icon;
                      return (
                        <button
                          key={p.id}
                          type="button"
                          title={p.label}
                          onClick={() => setAvatarUrl(`preset:${p.id}`)}
                          style={{
                            width: '36px',
                            height: '36px',
                            borderRadius: '50%',
                            background: p.gradient,
                            border: isSelected
                              ? '2px solid #FFFFFF'
                              : '2px solid transparent',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#FFFFFF',
                            cursor: 'pointer',
                            transform: isSelected ? 'scale(1.15)' : 'scale(1)',
                            transition: 'all 0.15s ease',
                            boxShadow: isSelected
                              ? '0 0 12px rgba(255,255,255,0.4)'
                              : '0 2px 6px rgba(0,0,0,0.2)',
                          }}
                        >
                          <IconComp size={16} />
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Input: Nome Completo */}
              <div className="settings-input-group">
                <label className="settings-label" htmlFor="user-full-name">
                  <span>Nome Completo</span>
                </label>
                <div className="settings-input-wrap">
                  <UserIcon size={16} />
                  <input
                    id="user-full-name"
                    type="text"
                    className="settings-input"
                    placeholder="Ex: Davi Oliveira"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Input: E-mail */}
              <div className="settings-input-group">
                <label className="settings-label" htmlFor="user-email">
                  <span>E-mail</span>
                </label>
                <div className="settings-input-wrap">
                  <MailIcon size={16} />
                  <input
                    id="user-email"
                    type="email"
                    className="settings-input"
                    placeholder="Ex: davi.oliveira@exemplo.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              {/* Dropdown: Objetivo Principal */}
              <div className="settings-input-group" style={{ marginBottom: '1.2rem' }}>
                <label className="settings-label" htmlFor="user-main-goal">
                  <span>Objetivo Principal</span>
                </label>
                <div className="settings-input-wrap">
                  <TargetIcon size={16} />
                  <select
                    id="user-main-goal"
                    className="settings-select"
                    value={mainGoal}
                    onChange={(e) => setMainGoal(e.target.value)}
                  >
                    {MAIN_GOALS.map((goal) => (
                      <option key={goal} value={goal}>
                        {goal}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Botão de Salvar Alterações */}
              <button
                id="save-profile-btn"
                type="submit"
                style={{
                  width: '100%',
                  background: savedSuccess
                    ? 'linear-gradient(135deg, #10B981, #059669)'
                    : 'linear-gradient(135deg, var(--active, #6366F1), var(--active2, #8B5CF6))',
                  border: 'none',
                  borderRadius: '0.85rem',
                  padding: '0.75rem 1rem',
                  color: '#FFFFFF',
                  fontWeight: 600,
                  fontSize: '0.9rem',
                  fontFamily: 'var(--font-display, sans-serif)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.5rem',
                  cursor: 'pointer',
                  boxShadow: savedSuccess
                    ? '0 6px 20px rgba(16, 185, 129, 0.4)'
                    : '0 6px 20px var(--active-glow, rgba(99, 102, 241, 0.35))',
                  transition: 'all 0.2s ease',
                }}
              >
                {savedSuccess ? (
                  <>
                    <CheckIcon size={18} />
                    <span>Alterações Salvas com Sucesso!</span>
                  </>
                ) : (
                  <span>Salvar Alterações</span>
                )}
              </button>
            </div>
          </form>

          {/* SEÇÃO 2: APARÊNCIA E TEMAS */}
          <div className="settings-section-card">
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '1rem',
                paddingBottom: '0.6rem',
                borderBottom: '1px solid var(--settings-border, rgba(255, 255, 255, 0.08))',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                <SunIcon size={17} color="#F59E0B" />
                <span
                  style={{
                    fontFamily: 'var(--font-display, sans-serif)',
                    fontWeight: 700,
                    fontSize: '0.95rem',
                    color: 'var(--ink, #FFFFFF)',
                  }}
                >
                  Aparência & Temas
                </span>
              </div>
              <span
                style={{
                  fontSize: '0.65rem',
                  padding: '0.2rem 0.5rem',
                  borderRadius: '9999px',
                  background: 'rgba(245, 158, 11, 0.15)',
                  color: '#FCD34D',
                  fontWeight: 600,
                }}
              >
                Visual
              </span>
            </div>

            <p
              style={{
                margin: '0 0 0.9rem',
                fontSize: '0.78rem',
                color: 'var(--ink-soft, #94A3B8)',
                lineHeight: 1.45,
              }}
            >
              Selecione o tema visual de sua preferência. A mudança reflete
              imediatamente em todo o aplicativo.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              {/* Opção 1: Verde Neon & Preto (Cyberpunk) */}
              <button
                type="button"
                id="theme-option-cyberpunk"
                className={`theme-choice-card ${theme === 'cyberpunk' ? 'active' : ''}`}
                onClick={() => onSelectTheme('cyberpunk')}
              >
                <div
                  className="theme-preview-box"
                  style={{
                    background: '#050505',
                    border: '1.5px solid #00FF66',
                    color: '#00FF66',
                    boxShadow: '0 0 12px rgba(0, 255, 102, 0.35)',
                  }}
                >
                  <Zap size={22} color="#00FF66" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: '0.88rem',
                      color: 'var(--ink, #FFFFFF)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span>Verde Neon & Preto</span>
                    <span
                      style={{
                        fontSize: '0.62rem',
                        fontWeight: 700,
                        padding: '0.1rem 0.45rem',
                        borderRadius: '0.35rem',
                        background: 'rgba(0, 255, 102, 0.15)',
                        border: '1px solid rgba(0, 255, 102, 0.35)',
                        color: '#00FF66',
                        letterSpacing: '0.03em',
                      }}
                    >
                      ⚡ CYBERPUNK
                    </span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.72rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginTop: '0.15rem',
                      lineHeight: 1.35,
                    }}
                  >
                    Fundo preto puro (#050505) com destaques em Verde Neon (#00FF66) e glow sutil
                  </div>
                </div>
                <div className="theme-radio-circle" />
              </button>

              {/* Opção 2: Roxo Cósmico (Cosmic Violet) */}
              <button
                type="button"
                id="theme-option-cosmic"
                className={`theme-choice-card ${theme === 'cosmic' ? 'active' : ''}`}
                onClick={() => onSelectTheme('cosmic')}
              >
                <div
                  className="theme-preview-box"
                  style={{
                    background: '#090414',
                    border: '1.5px solid #A855F7',
                    color: '#C084FC',
                    boxShadow: '0 0 12px rgba(168, 85, 247, 0.35)',
                  }}
                >
                  <Sparkles size={22} color="#C084FC" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: '0.88rem',
                      color: 'var(--ink, #FFFFFF)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span>Roxo Cósmico</span>
                    <span
                      style={{
                        fontSize: '0.62rem',
                        fontWeight: 700,
                        padding: '0.1rem 0.45rem',
                        borderRadius: '0.35rem',
                        background: 'rgba(168, 85, 247, 0.18)',
                        border: '1px solid rgba(168, 85, 247, 0.35)',
                        color: '#D8B4FE',
                        letterSpacing: '0.03em',
                      }}
                    >
                      🌌 COSMIC
                    </span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.72rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginTop: '0.15rem',
                      lineHeight: 1.35,
                    }}
                  >
                    Fundo escuro profundo com contrastes em Violeta/Neon Magenta (#A855F7)
                  </div>
                </div>
                <div className="theme-radio-circle" />
              </button>

              {/* Opção 3: Azul Oceano (Ocean Deep) */}
              <button
                type="button"
                id="theme-option-ocean"
                className={`theme-choice-card ${theme === 'ocean' ? 'active' : ''}`}
                onClick={() => onSelectTheme('ocean')}
              >
                <div
                  className="theme-preview-box"
                  style={{
                    background: '#040D1A',
                    border: '1.5px solid #06B6D4',
                    color: '#22D3EE',
                    boxShadow: '0 0 12px rgba(6, 182, 212, 0.35)',
                  }}
                >
                  <Waves size={22} color="#22D3EE" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: '0.88rem',
                      color: 'var(--ink, #FFFFFF)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span>Azul Oceano</span>
                    <span
                      style={{
                        fontSize: '0.62rem',
                        fontWeight: 700,
                        padding: '0.1rem 0.45rem',
                        borderRadius: '0.35rem',
                        background: 'rgba(6, 182, 212, 0.18)',
                        border: '1px solid rgba(6, 182, 212, 0.35)',
                        color: '#67E8F9',
                        letterSpacing: '0.03em',
                      }}
                    >
                      🌊 OCEAN DEEP
                    </span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.72rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginTop: '0.15rem',
                      lineHeight: 1.35,
                    }}
                  >
                    Tons de azul marinho com detalhes em Azul Turquesa (#06B6D4)
                  </div>
                </div>
                <div className="theme-radio-circle" />
              </button>

              {/* Opção 4: Ouro & Marfim (Luxury Light) */}
              <button
                type="button"
                id="theme-option-luxury"
                className={`theme-choice-card ${theme === 'luxury' ? 'active' : ''}`}
                onClick={() => onSelectTheme('luxury')}
              >
                <div
                  className="theme-preview-box"
                  style={{
                    background: '#FAF8F5',
                    border: '1.5px solid #D97706',
                    color: '#D97706',
                    boxShadow: '0 0 12px rgba(217, 119, 6, 0.25)',
                  }}
                >
                  <Crown size={22} color="#D97706" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: '0.88rem',
                      color: 'var(--ink, #FFFFFF)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span>Ouro & Marfim</span>
                    <span
                      style={{
                        fontSize: '0.62rem',
                        fontWeight: 700,
                        padding: '0.1rem 0.45rem',
                        borderRadius: '0.35rem',
                        background: 'rgba(217, 119, 6, 0.15)',
                        border: '1px solid rgba(217, 119, 6, 0.35)',
                        color: '#D97706',
                        letterSpacing: '0.03em',
                      }}
                    >
                      👑 LUXURY LIGHT
                    </span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.72rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginTop: '0.15rem',
                      lineHeight: 1.35,
                    }}
                  >
                    Tema claro premium com tons marfim, carvão e acentos em dourado/âmbar
                  </div>
                </div>
                <div className="theme-radio-circle" />
              </button>

              {/* Opção 5: Modo Escuro (Padrão) */}
              <button
                type="button"
                id="theme-option-dark"
                className={`theme-choice-card ${theme === 'dark' ? 'active' : ''}`}
                onClick={() => onSelectTheme('dark')}
              >
                <div
                  className="theme-preview-box"
                  style={{
                    background: '#0A0E27',
                    border: '1px solid rgba(255, 255, 255, 0.15)',
                    color: '#818CF8',
                  }}
                >
                  <MoonIcon size={22} color="#A5B4FC" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: '0.88rem',
                      color: 'var(--ink, #FFFFFF)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                    }}
                  >
                    <span>Modo Escuro</span>
                    <span style={{ fontSize: '0.75rem' }}>🌙</span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.72rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginTop: '0.15rem',
                      lineHeight: 1.35,
                    }}
                  >
                    Tons profundos e noturnos para descanso visual (Padrão Alicerce)
                  </div>
                </div>
                <div className="theme-radio-circle" />
              </button>

              {/* Opção 6: Modo Claro (Padrão) */}
              <button
                type="button"
                id="theme-option-light"
                className={`theme-choice-card ${theme === 'light' ? 'active' : ''}`}
                onClick={() => onSelectTheme('light')}
              >
                <div
                  className="theme-preview-box"
                  style={{
                    background: '#F8FAFC',
                    border: '1px solid #CBD5E1',
                    color: '#F59E0B',
                  }}
                >
                  <SunIcon size={22} color="#D97706" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: '0.88rem',
                      color: 'var(--ink, #FFFFFF)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                    }}
                  >
                    <span>Modo Claro</span>
                    <span style={{ fontSize: '0.75rem' }}>☀️</span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.72rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginTop: '0.15rem',
                      lineHeight: 1.35,
                    }}
                  >
                    Fundo limpo e alta luminosidade para o dia a dia
                  </div>
                </div>
                <div className="theme-radio-circle" />
              </button>

              {/* Opção 7: Tema do Sistema */}
              <button
                type="button"
                id="theme-option-system"
                className={`theme-choice-card ${theme === 'system' ? 'active' : ''}`}
                onClick={() => onSelectTheme('system')}
              >
                <div
                  className="theme-preview-box"
                  style={{
                    background: 'linear-gradient(135deg, #0A0E27 50%, #F8FAFC 50%)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    color: '#38BDF8',
                  }}
                >
                  <MonitorIcon size={20} color="#38BDF8" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: '0.88rem',
                      color: 'var(--ink, #FFFFFF)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                    }}
                  >
                    <span>Tema do Sistema</span>
                    <span style={{ fontSize: '0.75rem' }}>⚙️</span>
                  </div>
                  <div
                    style={{
                      fontSize: '0.72rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      marginTop: '0.15rem',
                      lineHeight: 1.35,
                    }}
                  >
                    Adapta-se automaticamente às preferências do dispositivo
                  </div>
                </div>
                <div className="theme-radio-circle" />
              </button>
            </div>
          </div>

          {/* SEÇÃO 3: DADOS & BACKUP */}
          <div className="settings-section-card" style={{ marginBottom: '1.5rem' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '0.75rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                <WalletIcon size={16} color="#38BDF8" />
                <span
                  style={{
                    fontFamily: 'var(--font-display, sans-serif)',
                    fontWeight: 700,
                    fontSize: '0.92rem',
                    color: 'var(--ink, #FFFFFF)',
                  }}
                >
                  Segurança & Backup
                </span>
              </div>
            </div>
            <p
              style={{
                margin: '0 0 0.85rem',
                fontSize: '0.75rem',
                color: 'var(--ink-soft, #94A3B8)',
                lineHeight: 1.45,
              }}
            >
              Seus registros e configurações são salvos de forma segura e privada
              no navegador.
            </p>
            <button
              type="button"
              onClick={handleExportData}
              style={{
                width: '100%',
                background: 'rgba(255, 255, 255, 0.06)',
                border: '1px solid var(--settings-border, rgba(255, 255, 255, 0.12))',
                borderRadius: '0.75rem',
                padding: '0.65rem 0.9rem',
                fontSize: '0.8rem',
                fontWeight: 600,
                color: 'var(--ink, #FFFFFF)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.45rem',
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.1)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.06)';
              }}
            >
              <span>Exportar Cópia de Segurança (JSON)</span>
            </button>
          </div>

          {/* SEÇÃO 4: APLICATIVO & ACESSO */}
          <div className="settings-section-card">
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '0.85rem',
                paddingBottom: '0.6rem',
                borderBottom: '1px solid var(--settings-border, rgba(255, 255, 255, 0.08))',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                <Smartphone size={17} color="#38BDF8" />
                <span
                  style={{
                    fontFamily: 'var(--font-display, sans-serif)',
                    fontWeight: 700,
                    fontSize: '0.92rem',
                    color: 'var(--ink, #FFFFFF)',
                  }}
                >
                  Aplicativo & Atalhos
                </span>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.55rem' }}>
              {onOpenIPhoneDownload && (
                <button
                  type="button"
                  onClick={onOpenIPhoneDownload}
                  style={{
                    width: '100%',
                    background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.12), rgba(139, 92, 246, 0.08))',
                    border: '1px solid rgba(56, 189, 248, 0.3)',
                    borderRadius: '0.75rem',
                    padding: '0.7rem 0.9rem',
                    fontSize: '0.82rem',
                    fontWeight: 700,
                    color: '#38BDF8',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <Smartphone size={16} />
                    <span>Baixar / Instalar no iPhone </span>
                  </div>
                  <span style={{ fontSize: '0.7rem', opacity: 0.8 }}>Instruções →</span>
                </button>
              )}

              {onOpenLogin && (
                <button
                  type="button"
                  onClick={onOpenLogin}
                  style={{
                    width: '100%',
                    background: 'rgba(255, 255, 255, 0.06)',
                    border: '1px solid var(--settings-border, rgba(255, 255, 255, 0.12))',
                    borderRadius: '0.75rem',
                    padding: '0.7rem 0.9rem',
                    fontSize: '0.82rem',
                    fontWeight: 700,
                    color: 'var(--ink, #FFFFFF)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <LogIn size={16} color="var(--active, #6366F1)" />
                    <span>Painel de Login & Avatares</span>
                  </div>
                  <span style={{ fontSize: '0.7rem', opacity: 0.8 }}>Abrir →</span>
                </button>
              )}
            </div>
          </div>

          {/* Footer note */}
          <div
            style={{
              textAlign: 'center',
              padding: '0.5rem 0 1rem',
              fontSize: '0.7rem',
              color: 'var(--ink-soft, #94A3B8)',
              opacity: 0.8,
            }}
          >
            Alicerce v2.0 • Edificando sobre a Rocha
          </div>
        </div>
      </div>
    </div>
  );
};
