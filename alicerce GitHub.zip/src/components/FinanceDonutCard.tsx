import React, { useState, useMemo } from 'react';
import {
  PieChart,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Layers,
  Sparkles,
  ChevronRight,
  RotateCcw,
} from 'lucide-react';
import { Investment } from '../types';
import { FINANCE_CATEGORIES } from '../utils/constants';

export type DonutViewMode = 'despesas' | 'fluxo' | 'investimentos';

interface FinanceDonutCardProps {
  periodEntradas: number;
  periodSaidas: number;
  periodSaldo: number;
  categoryBreakdown: {
    list: Array<{
      category: string;
      total: number;
      count: number;
      percent: number;
    }>;
    max: number;
  };
  investments: Investment[];
  totalInvestido: number;
  hideValues: boolean;
  formatMoney: (val: number) => string;
  isDeficit: boolean;
  savingsRate: number;
}

// Fallback color palette for dynamic slices
const PALETTE = [
  '#F59E0B', // Amber
  '#3B82F6', // Blue
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#10B981', // Emerald
  '#06B6D4', // Cyan
  '#F43F5E', // Rose
  '#14B8A6', // Teal
  '#6366F1', // Indigo
  '#EAB308', // Yellow
  '#64748B', // Slate
];

const INVESTMENT_TYPE_COLORS: Record<string, string> = {
  'Renda Fixa': '#06B6D4',
  'Fundos Imobiliários': '#8B5CF6',
  Cripto: '#F59E0B',
  Ações: '#3B82F6',
  'Tesouro Direto': '#10B981',
  Fundos: '#EC4899',
  Outro: '#64748B',
};

export const FinanceDonutCard: React.FC<FinanceDonutCardProps> = ({
  periodEntradas,
  periodSaidas,
  periodSaldo,
  categoryBreakdown,
  investments,
  totalInvestido,
  hideValues,
  formatMoney,
  isDeficit,
  savingsRate,
}) => {
  const [viewMode, setViewMode] = useState<DonutViewMode>('despesas');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // 1. Prepare Investment Type Breakdown
  const investmentBreakdown = useMemo(() => {
    const map: Record<string, { total: number; count: number }> = {};
    investments.forEach((inv) => {
      const t = inv.type || 'Outro';
      if (!map[t]) map[t] = { total: 0, count: 0 };
      map[t].total += inv.value;
      map[t].count += 1;
    });

    const total = Object.values(map).reduce((acc, cur) => acc + cur.total, 0);

    return Object.entries(map)
      .map(([type, data], idx) => ({
        name: type,
        total: data.total,
        count: data.count,
        percent: total > 0 ? Math.round((data.total / total) * 100) : 0,
        color: INVESTMENT_TYPE_COLORS[type] || PALETTE[idx % PALETTE.length],
      }))
      .sort((a, b) => b.total - a.total);
  }, [investments]);

  // 2. Active Slices according to current view mode
  const currentSlices = useMemo(() => {
    if (viewMode === 'despesas') {
      const total = periodSaidas;
      return categoryBreakdown.list.map((item, idx) => {
        const catConfig = FINANCE_CATEGORIES[item.category];
        const color = catConfig ? catConfig.color : PALETTE[idx % PALETTE.length];
        return {
          id: `cat-${item.category}`,
          name: item.category,
          value: item.total,
          count: item.count,
          percent: item.percent,
          color,
          icon: catConfig?.icon,
        };
      });
    }

    if (viewMode === 'fluxo') {
      const total = periodEntradas + periodSaidas;
      const list = [];
      if (periodEntradas > 0 || total === 0) {
        list.push({
          id: 'fluxo-entradas',
          name: 'Receitas (Entradas)',
          value: periodEntradas,
          count: 0,
          percent: total > 0 ? Math.round((periodEntradas / total) * 100) : 0,
          color: '#22C55E',
        });
      }
      if (periodSaidas > 0 || total === 0) {
        list.push({
          id: 'fluxo-saidas',
          name: 'Despesas (Saídas)',
          value: periodSaidas,
          count: 0,
          percent: total > 0 ? Math.round((periodSaidas / total) * 100) : 0,
          color: '#EF4444',
        });
      }
      return list;
    }

    // viewMode === 'investimentos'
    return investmentBreakdown.map((item) => ({
      id: `inv-${item.name}`,
      name: item.name,
      value: item.total,
      count: item.count,
      percent: item.percent,
      color: item.color,
    }));
  }, [viewMode, periodEntradas, periodSaidas, categoryBreakdown.list, investmentBreakdown]);

  // Total value for the current donut
  const totalSliceValue = useMemo(() => {
    if (viewMode === 'despesas') return periodSaidas;
    if (viewMode === 'fluxo') return periodEntradas + periodSaidas;
    return totalInvestido;
  }, [viewMode, periodSaidas, periodEntradas, totalInvestido]);

  // SVG parameters
  const svgSize = 240;
  const cx = 120;
  const cy = 120;
  const radius = 82;
  const circumference = 2 * Math.PI * radius; // ~515.22
  const gap = currentSlices.length > 1 ? 3 : 0;

  // Center display data (hovered slice vs default overall state)
  const centerDisplay = useMemo(() => {
    if (hoveredIndex !== null && currentSlices[hoveredIndex]) {
      const hovered = currentSlices[hoveredIndex];
      return {
        isHovered: true,
        label: hovered.name,
        amount: formatMoney(hovered.value),
        badge: `${hovered.percent}% do total`,
        color: hovered.color,
        countText:
          hovered.count > 0
            ? `${hovered.count} ${hovered.count === 1 ? 'item' : 'itens'}`
            : undefined,
      };
    }

    if (viewMode === 'despesas') {
      return {
        isHovered: false,
        label: 'GASTOS TOTAIS',
        amount: formatMoney(periodSaidas),
        badge:
          categoryBreakdown.list.length > 0
            ? `${categoryBreakdown.list.length} ${
                categoryBreakdown.list.length === 1 ? 'categoria' : 'categorias'
              }`
            : 'Sem despesas',
        color: 'var(--red, #EF4444)',
        countText: undefined,
      };
    }

    if (viewMode === 'fluxo') {
      return {
        isHovered: false,
        label: 'SALDO DO PERÍODO',
        amount: `${periodSaldo >= 0 ? '+' : ''}${formatMoney(periodSaldo)}`,
        badge: isDeficit ? 'Déficit no Período' : `${savingsRate}% Economizado`,
        color: periodSaldo >= 0 ? 'var(--green, #22C55E)' : 'var(--red, #EF4444)',
        countText: undefined,
      };
    }

    // viewMode === 'investimentos'
    return {
      isHovered: false,
      label: 'TOTAL INVESTIDO',
      amount: formatMoney(totalInvestido),
      badge: `${investments.length} ${
        investments.length === 1 ? 'ativo' : 'ativos'
      }`,
      color: '#06B6D4',
      countText: undefined,
    };
  }, [
    hoveredIndex,
    currentSlices,
    viewMode,
    periodSaidas,
    periodSaldo,
    totalInvestido,
    categoryBreakdown.list.length,
    isDeficit,
    savingsRate,
    formatMoney,
  ]);

  // Slices SVG arc offsets calculation
  let accumulatedLength = 0;
  const sliceRenderData = currentSlices.map((slice) => {
    const fraction = totalSliceValue > 0 ? slice.value / totalSliceValue : 0;
    const rawLength = fraction * circumference;
    const strokeDash = Math.max(0, rawLength - gap);
    const strokeOffset = -accumulatedLength;
    accumulatedLength += rawLength;

    return {
      ...slice,
      strokeDash,
      strokeOffset,
      fraction,
    };
  });

  const selectedSlice = hoveredIndex !== null ? currentSlices[hoveredIndex] : null;

  return (
    <div
      className="donut-card-highlight"
      style={{
        background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
        border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
        borderRadius: '1.25rem',
        padding: '1.1rem 1rem 1.25rem',
        boxShadow: 'var(--card-shadow, 0 14px 34px rgba(0, 0, 0, 0.4))',
        position: 'relative',
        overflow: 'hidden',
        transition: 'all 0.25s ease',
      }}
    >
      <style>{`
        /* Tema Cyberpunk Neon */
        .theme-cyberpunk .donut-card-highlight {
          background: #050505 !important;
          border-color: rgba(0, 255, 102, 0.38) !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.9), 0 0 20px rgba(0, 255, 102, 0.2), inset 0 1px 0 rgba(0, 255, 102, 0.25) !important;
        }
        .theme-cyberpunk .donut-slice {
          filter: drop-shadow(0 0 4px rgba(0, 255, 102, 0.45));
        }
        .theme-cyberpunk .donut-slice:hover,
        .theme-cyberpunk .donut-slice.active {
          filter: drop-shadow(0 0 14px #00FF66) !important;
        }
        .theme-cyberpunk .donut-center-label {
          color: #00FF66 !important;
        }
        .theme-cyberpunk .donut-center-val {
          color: #FFFFFF !important;
          text-shadow: 0 0 14px rgba(0, 255, 102, 0.65);
        }
        .theme-cyberpunk .donut-mode-active {
          background: #00FF66 !important;
          color: #050505 !important;
          box-shadow: 0 0 14px rgba(0, 255, 102, 0.5) !important;
          border-color: #00FF66 !important;
        }

        /* Tema Claro (Light Mode) */
        .theme-light .donut-card-highlight {
          background: #FFFFFF !important;
          border-color: #E2E8F0 !important;
          box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04) !important;
        }
        .theme-light .donut-center-label {
          color: #475569 !important; /* slate-600 */
        }
        .theme-light .donut-center-val {
          color: #0F172A !important; /* slate-900 */
        }
        .theme-light .donut-legend-label {
          color: #0F172A !important; /* slate-900 */
        }
        .theme-light .donut-legend-value {
          color: #1E293B !important; /* slate-800 */
        }
        .theme-light .donut-legend-pct {
          color: #334155 !important; /* slate-700 */
          background: #F1F5F9 !important; /* slate-100 */
          border: 1px solid #E2E8F0 !important;
        }
        .theme-light .donut-bg-ring {
          stroke: #E2E8F0 !important;
        }
        .theme-light .donut-detail-box {
          background: #F8FAFC !important;
          border-color: #E2E8F0 !important;
        }
        .theme-light .donut-detail-label {
          color: #0F172A !important;
        }
        .theme-light .donut-detail-sub {
          color: #475569 !important;
        }
      `}</style>

      {/* Card Header: Title & Quick View Selector */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '0.65rem',
          marginBottom: '0.85rem',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <div
              style={{
                width: '30px',
                height: '30px',
                borderRadius: '0.65rem',
                background:
                  'linear-gradient(135deg, var(--active, #06B6D4), var(--active2, #3B82F6))',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#FFFFFF',
                boxShadow: '0 4px 10px rgba(6, 182, 212, 0.3)',
              }}
            >
              <PieChart size={16} />
            </div>
            <div>
              <h3
                style={{
                  margin: 0,
                  fontFamily: 'var(--font-display)',
                  fontWeight: 800,
                  fontSize: '0.98rem',
                  letterSpacing: '-0.01em',
                  color: 'var(--ink, #FFFFFF)',
                }}
              >
                Distribuição Financeira
              </h3>
              <p
                style={{
                  margin: 0,
                  fontSize: '0.66rem',
                  color: 'var(--ink-soft, #94A3B8)',
                  fontFamily: 'var(--font-mono)',
                }}
              >
                Gráfico de Rosca Dinâmico & Interativo
              </p>
            </div>
          </div>

          {hoveredIndex !== null && (
            <button
              type="button"
              onClick={() => setHoveredIndex(null)}
              title="Limpar seleção"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.25rem',
                padding: '0.25rem 0.55rem',
                borderRadius: '0.5rem',
                border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                background: 'rgba(255, 255, 255, 0.06)',
                color: 'var(--ink-soft, #94A3B8)',
                fontSize: '0.65rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              <RotateCcw size={11} />
              <span>Resetar</span>
            </button>
          )}
        </div>

        {/* 2. Seletor de Visualização Rápido */}
        <div
          role="tablist"
          aria-label="Seletor de Modo do Gráfico"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '0.35rem',
            background: 'var(--panel, rgba(255, 255, 255, 0.04))',
            padding: '0.25rem',
            borderRadius: '0.75rem',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
          }}
        >
          <button
            id="donut-tab-despesas"
            type="button"
            role="tab"
            aria-selected={viewMode === 'despesas'}
            className={viewMode === 'despesas' ? 'donut-mode-active' : ''}
            onClick={() => {
              setViewMode('despesas');
              setHoveredIndex(null);
            }}
            title="Despesas por Categoria"
            style={{
              padding: '0.45rem 0.2rem',
              borderRadius: '0.55rem',
              border: 'none',
              background:
                viewMode === 'despesas'
                  ? 'var(--active, #06B6D4)'
                  : 'transparent',
              color: viewMode === 'despesas' ? '#FFFFFF' : 'var(--ink-soft, #94A3B8)',
              fontFamily: 'var(--font-body)',
              fontSize: '0.65rem',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.25rem',
              transition: 'all 0.18s ease',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              overflow: 'hidden',
            }}
          >
            <PieChart size={12} style={{ flexShrink: 0 }} />
            <span>Despesas por Categoria</span>
          </button>

          <button
            id="donut-tab-fluxo"
            type="button"
            role="tab"
            aria-selected={viewMode === 'fluxo'}
            className={viewMode === 'fluxo' ? 'donut-mode-active' : ''}
            onClick={() => {
              setViewMode('fluxo');
              setHoveredIndex(null);
            }}
            title="Entradas vs Saídas"
            style={{
              padding: '0.45rem 0.2rem',
              borderRadius: '0.55rem',
              border: 'none',
              background:
                viewMode === 'fluxo'
                  ? 'var(--active, #06B6D4)'
                  : 'transparent',
              color: viewMode === 'fluxo' ? '#FFFFFF' : 'var(--ink-soft, #94A3B8)',
              fontFamily: 'var(--font-body)',
              fontSize: '0.65rem',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.25rem',
              transition: 'all 0.18s ease',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              overflow: 'hidden',
            }}
          >
            <ArrowUpRight size={12} style={{ flexShrink: 0 }} />
            <span>Entradas vs Saídas</span>
          </button>

          <button
            id="donut-tab-investimentos"
            type="button"
            role="tab"
            aria-selected={viewMode === 'investimentos'}
            className={viewMode === 'investimentos' ? 'donut-mode-active' : ''}
            onClick={() => {
              setViewMode('investimentos');
              setHoveredIndex(null);
            }}
            title="Investimentos"
            style={{
              padding: '0.45rem 0.2rem',
              borderRadius: '0.55rem',
              border: 'none',
              background:
                viewMode === 'investimentos'
                  ? 'var(--active, #06B6D4)'
                  : 'transparent',
              color:
                viewMode === 'investimentos'
                  ? '#FFFFFF'
                  : 'var(--ink-soft, #94A3B8)',
              fontFamily: 'var(--font-body)',
              fontSize: '0.65rem',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.25rem',
              transition: 'all 0.18s ease',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              overflow: 'hidden',
            }}
          >
            <TrendingUp size={12} style={{ flexShrink: 0 }} />
            <span>Investimentos</span>
          </button>
        </div>
      </div>

      {/* Main Centerpiece: The Large Donut with Center Label */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          padding: '0.4rem 0 0.8rem',
        }}
      >
        <div
          style={{
            position: 'relative',
            width: `${svgSize}px`,
            height: `${svgSize}px`,
            maxWidth: '100%',
          }}
        >
          <svg
            width="100%"
            height="100%"
            viewBox={`0 0 ${svgSize} ${svgSize}`}
            style={{ overflow: 'visible' }}
          >
            <defs>
              {/* Neon glow filter for Cyberpunk theme */}
              <filter id="neon-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="5" result="glow" />
                <feMerge>
                  <feMergeNode in="glow" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Background ring */}
            <circle
              className="donut-bg-ring"
              cx={cx}
              cy={cy}
              r={radius}
              fill="none"
              stroke="rgba(255, 255, 255, 0.08)"
              strokeWidth="20"
            />

            {/* Empty state single ring if total value is 0 */}
            {totalSliceValue <= 0 && (
              <circle
                cx={cx}
                cy={cy}
                r={radius}
                fill="none"
                stroke="rgba(255, 255, 255, 0.15)"
                strokeWidth="20"
                strokeDasharray="6 6"
              />
            )}

            {/* Donut Slices */}
            {totalSliceValue > 0 &&
              sliceRenderData.map((slice, idx) => {
                const isHovered = hoveredIndex === idx;
                const hasHover = hoveredIndex !== null;
                const opacity = hasHover ? (isHovered ? 1 : 0.35) : 1;
                const strokeWidth = isHovered ? 28 : 22;

                return (
                  <circle
                    key={slice.id}
                    className={`donut-slice ${isHovered ? 'active' : ''}`}
                    cx={cx}
                    cy={cy}
                    r={radius}
                    fill="none"
                    stroke={slice.color}
                    strokeWidth={strokeWidth}
                    strokeDasharray={`${slice.strokeDash} ${circumference}`}
                    strokeDashoffset={slice.strokeOffset}
                    transform={`rotate(-90 ${cx} ${cy})`}
                    style={{
                      cursor: 'pointer',
                      opacity,
                      transition:
                        'stroke-width 0.25s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s ease, filter 0.2s ease',
                      filter: isHovered
                        ? `drop-shadow(0 0 10px ${slice.color})`
                        : undefined,
                    }}
                    onMouseEnter={() => setHoveredIndex(idx)}
                    onClick={() =>
                      setHoveredIndex(hoveredIndex === idx ? null : idx)
                    }
                    onTouchStart={() => setHoveredIndex(idx)}
                  />
                );
              })}
          </svg>

          {/* Center Label (Inside Donut) */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              textAlign: 'center',
              padding: '1.2rem',
              pointerEvents: 'none',
            }}
          >
            {/* Center Header / Category Title */}
            <span
              className="donut-center-label"
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.62rem',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                color: centerDisplay.isHovered
                  ? centerDisplay.color
                  : 'var(--ink-soft, #94A3B8)',
                marginBottom: '0.15rem',
                maxWidth: '140px',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                transition: 'color 0.2s ease',
              }}
            >
              {centerDisplay.label}
            </span>

            {/* Center Value */}
            <span
              className="donut-center-val"
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '1.35rem',
                fontWeight: 800,
                lineHeight: 1.15,
                letterSpacing: '-0.02em',
                color: 'var(--ink, #FFFFFF)',
                transition: 'all 0.2s ease',
              }}
            >
              {centerDisplay.amount}
            </span>

            {/* Subtitle / Percentage Badge */}
            <div
              style={{
                marginTop: '0.35rem',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.25rem',
                padding: '0.15rem 0.5rem',
                borderRadius: '9999px',
                fontSize: '0.62rem',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                backgroundColor: centerDisplay.isHovered
                  ? `${centerDisplay.color}22`
                  : 'rgba(255, 255, 255, 0.08)',
                color: centerDisplay.isHovered
                  ? centerDisplay.color
                  : 'var(--ink-soft, #94A3B8)',
                border: `1px solid ${
                  centerDisplay.isHovered
                    ? `${centerDisplay.color}40`
                    : 'transparent'
                }`,
                transition: 'all 0.2s ease',
              }}
            >
              <span>{centerDisplay.badge}</span>
            </div>

            {centerDisplay.countText && (
              <span
                style={{
                  fontSize: '0.58rem',
                  color: 'var(--ink-soft, #94A3B8)',
                  marginTop: '0.15rem',
                  fontFamily: 'var(--font-mono)',
                }}
              >
                {centerDisplay.countText}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Selected Item Detailed Callout on Hover / Tap */}
      {selectedSlice && (
        <div
          className="donut-detail-box"
          style={{
            marginBottom: '0.85rem',
            padding: '0.6rem 0.8rem',
            borderRadius: '0.75rem',
            backgroundColor: `${selectedSlice.color}14`,
            border: `1px solid ${selectedSlice.color}45`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            animation: 'fadeIn 0.2s ease',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
            <span
              style={{
                width: '12px',
                height: '12px',
                borderRadius: '50%',
                backgroundColor: selectedSlice.color,
                boxShadow: `0 0 8px ${selectedSlice.color}80`,
                flexShrink: 0,
              }}
            />
            <div>
              <div
                className="donut-detail-label"
                style={{
                  fontSize: '0.78rem',
                  fontWeight: 700,
                  color: 'var(--ink, #FFFFFF)',
                  lineHeight: 1.2,
                }}
              >
                {selectedSlice.name}
              </div>
              <div
                className="donut-detail-sub"
                style={{
                  fontSize: '0.66rem',
                  color: 'var(--ink-soft, #94A3B8)',
                  fontFamily: 'var(--font-mono)',
                }}
              >
                {selectedSlice.count > 0 ? `${selectedSlice.count} lançamentos • ` : ''}
                {selectedSlice.percent}% do montante total
              </div>
            </div>
          </div>

          <div style={{ textAlign: 'right' }}>
            <div
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.92rem',
                fontWeight: 800,
                color: selectedSlice.color,
              }}
            >
              {formatMoney(selectedSlice.value)}
            </div>
          </div>
        </div>
      )}

      {/* Responsive Legend Grid with Interactive Slices */}
      {currentSlices.length > 0 ? (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '0.45rem',
          }}
        >
          {currentSlices.map((slice, idx) => {
            const isHovered = hoveredIndex === idx;

            return (
              <button
                key={slice.id}
                type="button"
                onClick={() =>
                  setHoveredIndex(hoveredIndex === idx ? null : idx)
                }
                onMouseEnter={() => setHoveredIndex(idx)}
                style={{
                  background: isHovered
                    ? `${slice.color}1A`
                    : 'var(--panel, rgba(255, 255, 255, 0.035))',
                  border: `1px solid ${
                    isHovered
                      ? slice.color
                      : 'var(--line, rgba(255, 255, 255, 0.1))'
                  }`,
                  borderRadius: '0.75rem',
                  padding: '0.55rem 0.65rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '0.4rem',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.18s ease',
                  boxShadow: isHovered
                    ? `0 3px 12px ${slice.color}35`
                    : 'none',
                  transform: isHovered ? 'scale(1.02)' : 'scale(1)',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.45rem',
                    minWidth: 0,
                  }}
                >
                  <span
                    style={{
                      width: '10px',
                      height: '10px',
                      borderRadius: '50%',
                      backgroundColor: slice.color,
                      flexShrink: 0,
                      boxShadow: isHovered ? `0 0 8px ${slice.color}` : 'none',
                    }}
                  />
                  <div style={{ minWidth: 0 }}>
                    <div
                      className="donut-legend-label"
                      style={{
                        fontSize: '0.72rem',
                        fontWeight: 700,
                        color: 'var(--ink, #FFFFFF)',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {slice.name}
                    </div>
                    <div
                      className="donut-legend-value"
                      style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.7rem',
                        fontWeight: 600,
                        color: isHovered
                          ? slice.color
                          : 'var(--ink-soft, #94A3B8)',
                      }}
                    >
                      {formatMoney(slice.value)}
                    </div>
                  </div>
                </div>

                {/* Percentage Chip */}
                <span
                  className="donut-legend-pct"
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.65rem',
                    fontWeight: 800,
                    padding: '0.15rem 0.35rem',
                    borderRadius: '0.45rem',
                    backgroundColor: `${slice.color}25`,
                    color: slice.color,
                    flexShrink: 0,
                  }}
                >
                  {slice.percent}%
                </span>
              </button>
            );
          })}
        </div>
      ) : (
        <div
          style={{
            textAlign: 'center',
            padding: '1.2rem 0.5rem',
            color: 'var(--ink-soft, #94A3B8)',
            fontSize: '0.75rem',
            fontFamily: 'var(--font-mono)',
          }}
        >
          Nenhum dado registrado para este modo no período selecionado.
        </div>
      )}
    </div>
  );
};
