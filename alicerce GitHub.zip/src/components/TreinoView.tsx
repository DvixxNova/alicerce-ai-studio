import React, { useState, useMemo } from 'react';
import {
  Dumbbell,
  Activity,
  Check,
  Plus,
  X,
  Droplets,
  Moon,
  Apple,
  SlidersHorizontal,
  Flame,
  Timer,
  Play,
  RotateCcw,
  Sparkles,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Circle,
  Calendar,
  Zap,
  Award,
  TrendingUp,
  Trash2,
  Layers,
  Clock,
  Target,
  Info,
  History,
} from 'lucide-react';
import { Workout } from '../types';
import { genId, getTodayISO, fmtVolumeKg, fmtDayMonth } from '../utils/constants';

interface TreinoViewProps {
  workouts: Workout[];
  setWorkouts: React.Dispatch<React.SetStateAction<Workout[]>>;
  userName?: string;
}

// Formatação humanizada da data para o histórico recente
function formatRecentWorkoutDate(isoDate?: string): string {
  if (!isoDate) return '';
  const today = getTodayISO();
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const yesterday = d.toISOString().slice(0, 10);

  if (isoDate === today) return 'Hoje';
  if (isoDate === yesterday) return 'Ontem';

  try {
    const parts = isoDate.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}`;
    }
  } catch {
    // fallback
  }
  return fmtDayMonth(isoDate);
}

interface ExerciseDetail {
  id: string;
  name: string;
  sets: string;
  weight?: string;
  reps?: string;
  notes?: string;
  isDone?: boolean;
}

interface ScheduledSession {
  id: string;
  title: string;
  duration: string;
  level: string;
  exercisesCount: number;
  badge?: string;
  badgeType?: 'purple' | 'green' | 'amber' | 'coral';
  isCompleted: boolean;
  type: 'strength' | 'mobility' | 'cardio' | 'rest';
  exercises: ExerciseDetail[];
  muscleGroup?: string;
  restBetweenSets?: string;
  caloriesBurn?: number;
  warmup?: string;
  notes?: string;
}

export const TreinoView: React.FC<TreinoViewProps> = ({
  workouts,
  setWorkouts,
  userName = 'dvixx',
}) => {
  // 1. Selected Weekday (0 = Seg, 1 = Ter, 2 = Qua, 3 = Qui, 4 = Sex, 5 = Sáb, 6 = Dom)
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0);

  // 2. Active Chart Time Range: 7 dias | Mês | Ano
  const [chartRange, setChartRange] = useState<'7d' | 'mes' | 'ano'>('7d');

  // 3. Expanded session ID to view inline Bento exercise cards
  const [expandedSessionId, setExpandedSessionId] = useState<string | null>('sess-seg-1');

  // 4. Habits tracking state with interactive increment
  const [habitsData, setHabitsData] = useState({
    waterDays: 6,
    waterPct: 82,
    sleepAvg: '7h 24m',
    sleepPct: 91,
    nutritionDays: 4,
    nutritionPct: 76,
  });

  // 5. Interactive Sessions state per day of the week
  const [weeklySessions, setWeeklySessions] = useState<Record<number, ScheduledSession[]>>({
    0: [
      {
        id: 'sess-seg-1',
        title: 'Força total do corpo',
        duration: '45 min',
        level: 'Intermediário',
        exercisesCount: 6,
        badge: 'Hoje',
        badgeType: 'purple',
        isCompleted: true,
        type: 'strength',
        exercises: [
          { id: 'ex-seg-1', name: 'Supino Reto com Barra', sets: '4 séries × 10 reps', weight: '60kg', isDone: true },
          { id: 'ex-seg-2', name: 'Puxada Aberta no Pulley', sets: '4 séries × 10 reps', weight: '55kg', isDone: true },
          { id: 'ex-seg-3', name: 'Desenvolvimento com Halteres', sets: '3 séries × 12 reps', weight: '18kg', isDone: true },
          { id: 'ex-seg-4', name: 'Agachamento Livre com Barra', sets: '4 séries × 8 reps', weight: '70kg', isDone: false },
          { id: 'ex-seg-5', name: 'Elevação Lateral na Polia', sets: '3 séries × 15 reps', weight: '10kg', isDone: false },
          { id: 'ex-seg-6', name: 'Prancha Isométrica com Peso', sets: '3 séries × 45s', weight: '10kg', isDone: false },
        ],
      },
      {
        id: 'sess-seg-2',
        title: 'Mobilidade de quadril',
        duration: '18 min',
        level: 'Recuperação ativa',
        exercisesCount: 4,
        badge: 'Opcional',
        badgeType: 'green',
        isCompleted: false,
        type: 'mobility',
        exercises: [
          { id: 'ex-seg-7', name: 'Alongamento 90/90 no Solo', sets: '3 séries × 60s cada lado', isDone: false },
          { id: 'ex-seg-8', name: 'Pigeon Pose (Postura do Pombo)', sets: '3 séries × 45s', isDone: false },
          { id: 'ex-seg-9', name: 'Cócoras Profundas Ativas', sets: '3 séries × 1 min', isDone: false },
          { id: 'ex-seg-10', name: 'Ponte de Glúteos Dinâmica', sets: '2 séries × 15 reps', isDone: false },
        ],
      },
    ],
    1: [
      {
        id: 'sess-ter-1',
        title: 'Puxar (Pull) & Costas Pesadas',
        duration: '50 min',
        level: 'Avançado',
        exercisesCount: 5,
        badge: 'Programado',
        badgeType: 'purple',
        isCompleted: false,
        type: 'strength',
        exercises: [
          { id: 'ex-ter-1', name: 'Levantamento Terra Clássico', sets: '4 séries × 6 reps', weight: '100kg', isDone: false },
          { id: 'ex-ter-2', name: 'Remada Curvada com Barra', sets: '4 séries × 8 reps', weight: '60kg', isDone: false },
          { id: 'ex-ter-3', name: 'Remada Baixa no Triângulo', sets: '3 séries × 10 reps', weight: '50kg', isDone: false },
          { id: 'ex-ter-4', name: 'Rosca Direta na Barra W', sets: '3 séries × 10 reps', weight: '26kg', isDone: false },
          { id: 'ex-ter-5', name: 'Rosca Martelo com Halteres', sets: '3 séries × 12 reps', weight: '14kg', isDone: false },
        ],
      },
    ],
    2: [
      {
        id: 'sess-qua-1',
        title: 'Pernas & Core Intenso',
        duration: '55 min',
        level: 'Avançado',
        exercisesCount: 6,
        badge: 'Programado',
        badgeType: 'purple',
        isCompleted: false,
        type: 'strength',
        exercises: [
          { id: 'ex-qua-1', name: 'Agachamento com Barra Livre', sets: '4 séries × 8 reps', weight: '80kg', isDone: false },
          { id: 'ex-qua-2', name: 'Leg Press 45°', sets: '4 séries × 12 reps', weight: '180kg', isDone: false },
          { id: 'ex-qua-3', name: 'Cadeira Extensora', sets: '3 séries × 15 reps', weight: '45kg', isDone: false },
          { id: 'ex-qua-4', name: 'Mesa Flexora', sets: '3 séries × 12 reps', weight: '40kg', isDone: false },
          { id: 'ex-qua-5', name: 'Panturrilha no Smith', sets: '4 séries × 15 reps', weight: '70kg', isDone: false },
          { id: 'ex-qua-6', name: 'Abdominal na Polia Alta', sets: '4 séries × 15 reps', weight: '30kg', isDone: false },
        ],
      },
    ],
    3: [
      {
        id: 'sess-qui-1',
        title: 'Ombros, Peito & Tríceps',
        duration: '45 min',
        level: 'Intermediário',
        exercisesCount: 5,
        badge: 'Programado',
        badgeType: 'purple',
        isCompleted: false,
        type: 'strength',
        exercises: [
          { id: 'ex-qui-1', name: 'Supino Inclinado com Halteres', sets: '4 séries × 10 reps', weight: '24kg', isDone: false },
          { id: 'ex-qui-2', name: 'Crucifixo na Polia (Crossover)', sets: '3 séries × 12 reps', weight: '15kg', isDone: false },
          { id: 'ex-qui-3', name: 'Desenvolvimento Militar', sets: '4 séries × 8 reps', weight: '20kg', isDone: false },
          { id: 'ex-qui-4', name: 'Tríceps Corda no Pulley', sets: '3 séries × 12 reps', weight: '25kg', isDone: false },
          { id: 'ex-qui-5', name: 'Tríceps Francês Unilateral', sets: '3 séries × 10 reps', weight: '12kg', isDone: false },
        ],
      },
    ],
    4: [
      {
        id: 'sess-sex-1',
        title: 'Full Body Funcional & HIIT',
        duration: '40 min',
        level: 'Intermediário',
        exercisesCount: 5,
        badge: 'Programado',
        badgeType: 'purple',
        isCompleted: false,
        type: 'cardio',
        exercises: [
          { id: 'ex-sex-1', name: 'Kettlebell Swing Russo', sets: '4 séries × 20 reps', weight: '16kg', isDone: false },
          { id: 'ex-sex-2', name: 'Burpees com Salto', sets: '3 séries × 12 reps', isDone: false },
          { id: 'ex-sex-3', name: 'Remo Seco (Ergômetro)', sets: '4 tiros × 500m', isDone: false },
          { id: 'ex-sex-4', name: 'Box Jumps no Caixote', sets: '3 séries × 10 reps', isDone: false },
          { id: 'ex-sex-5', name: 'Mountain Climbers', sets: '3 séries × 45s', isDone: false },
        ],
      },
    ],
    5: [
      {
        id: 'sess-sab-1',
        title: 'Corrida ao Ar Livre & Cardio',
        duration: '35 min',
        level: 'Resistência aeróbica',
        exercisesCount: 1,
        badge: 'Opcional',
        badgeType: 'green',
        isCompleted: false,
        type: 'cardio',
        exercises: [{ id: 'ex-sab-1', name: 'Corrida Contínua Z2 (135-145 bpm)', sets: '5 km em ritmo constante', isDone: false }],
      },
    ],
    6: [
      {
        id: 'sess-dom-1',
        title: 'Descanso Total & Recuperação',
        duration: '0 min',
        level: 'Regeneração muscular',
        exercisesCount: 0,
        badge: 'Descanso',
        badgeType: 'green',
        isCompleted: true,
        type: 'rest',
        exercises: [{ id: 'ex-dom-1', name: 'Hidratação reforçada, sono reparador e caminhada leve', sets: 'Dia livre', isDone: true }],
      },
    ],
  });

  // 6. Modal states & Montar Treino form fields
  const [activeSessionForModal, setActiveSessionForModal] = useState<ScheduledSession | null>(null);
  const [isNewWorkoutOpen, setIsNewWorkoutOpen] = useState(false);

  // Campos completos de montagem de treino
  const [newTitle, setNewTitle] = useState('');
  const [newDayIndex, setNewDayIndex] = useState<number>(0);
  const [newType, setNewType] = useState<'strength' | 'cardio' | 'mobility' | 'rest'>('strength');
  const [newMuscleGroup, setNewMuscleGroup] = useState<string>('Peito & Tríceps');
  const [newLevel, setNewLevel] = useState<string>('Intermediário');
  const [newDuration, setNewDuration] = useState('50 min');
  const [newRestBetweenSets, setNewRestBetweenSets] = useState('60s');
  const [newCalories, setNewCalories] = useState('360');
  const [newWarmup, setNewWarmup] = useState('5 min esteira leve + mobilidade articular');
  const [newNotes, setNewNotes] = useState('');
  const [newExercises, setNewExercises] = useState<Array<{
    id: string;
    name: string;
    sets: string;
    reps: string;
    weight: string;
    notes: string;
  }>>([
    { id: '1', name: 'Supino Reto com Barra', sets: '4', reps: '10-12', weight: '60kg', notes: 'Cadência controlada 3-0-1' },
    { id: '2', name: 'Crucifixo Inclinado com Halteres', sets: '3', reps: '12-15', weight: '16kg', notes: 'Pico de contração' },
    { id: '3', name: 'Tríceps na Polia / Corda', sets: '4', reps: '12', weight: '25kg', notes: 'Cotovelos estáveis' },
  ]);

  // 7-day Bento selector cards
  const weekDays = useMemo(
    () => [
      { index: 0, label: 'SEG', dayNum: 21, dotColor: '#F87171' }, // Coral dot
      { index: 1, label: 'TER', dayNum: 22, dotColor: '#10B981' }, // Green dot
      { index: 2, label: 'QUA', dayNum: 23, dotColor: '#10B981' }, // Green dot
      { index: 3, label: 'QUI', dayNum: 24, dotColor: '#F87171' }, // Coral dot
      { index: 4, label: 'SEX', dayNum: 25, dotColor: '#F87171' }, // Coral dot
      { index: 5, label: 'SÁB', dayNum: 26, dotColor: '#F87171' }, // Coral dot
      { index: 6, label: 'DOM', dayNum: 27, dotColor: null }, // Rest day (no dot)
    ],
    []
  );

  // Active workout load data
  const chartData = useMemo(() => {
    if (chartRange === 'mes') {
      return [
        { label: 'Sem 1', minutes: 180, active: false },
        { label: 'Sem 2', minutes: 240, active: false },
        { label: 'Sem 3', minutes: 215, active: true },
        { label: 'Sem 4', minutes: 190, active: false },
      ];
    }
    if (chartRange === 'ano') {
      return [
        { label: 'Jan', minutes: 45, active: false },
        { label: 'Fev', minutes: 50, active: false },
        { label: 'Mar', minutes: 55, active: false },
        { label: 'Abr', minutes: 60, active: false },
        { label: 'Mai', minutes: 65, active: false },
        { label: 'Jun', minutes: 50, active: false },
        { label: 'Jul', minutes: 58, active: false },
        { label: 'Ago', minutes: 62, active: false },
        { label: 'Set', minutes: 68, active: true },
      ];
    }
    // 7 dias default (exact from model)
    return [
      { label: 'Seg', minutes: 45, active: true },
      { label: 'Ter', minutes: 55, active: false },
      { label: 'Qua', minutes: 40, active: false },
      { label: 'Qui', minutes: 50, active: false },
      { label: 'Sex', minutes: 45, active: false },
      { label: 'Sáb', minutes: 30, active: false },
      { label: 'Dom', minutes: 0, active: false },
    ];
  }, [chartRange]);

  // Estado para expandir detalhes de um treino no Histórico Recente
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);

  // Resumo dos últimos 3 treinos concluídos pelo usuário utilizando os dados salvos no localStorage
  const recentCompletedWorkouts = useMemo(() => {
    let list: Workout[] = Array.isArray(workouts) ? workouts : [];

    // Fallback garantido lendo diretamente do localStorage caso a prop ainda esteja sendo hidratada
    if (list.length === 0 && typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('alicerce_data') || localStorage.getItem('alicerce_app_data_v2');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed.workouts)) {
            list = parsed.workouts;
          }
        }
      } catch {
        // fallback silencioso
      }
    }

    // Filtrar apenas treinos concluídos e que não sejam dias de descanso
    const valid = list.filter((w) => !w.isRestDay);

    // Ordenar decrescente pela data mais recente (newest first)
    const sorted = [...valid].sort((a, b) => {
      const dateA = a.date || '';
      const dateB = b.date || '';
      return dateB.localeCompare(dateA);
    });

    // Retorna os últimos 3 treinos
    return sorted.slice(0, 3);
  }, [workouts]);

  // Toggle completion of a session
  const handleToggleSession = (sessionId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setWeeklySessions((prev) => {
      const updated = { ...prev };
      const currentList = updated[selectedDayIndex] || [];
      updated[selectedDayIndex] = currentList.map((s) => {
        if (s.id !== sessionId) return s;
        const nextState = !s.isCompleted;

        // Sincronizar com os workouts globais salvos no localStorage
        if (nextState) {
          const newWorkoutRecord: Workout = {
            id: genId(),
            name: s.title,
            focus: s.level,
            durationMinutes: parseInt(s.duration, 10) || 45,
            date: getTodayISO(),
            loadNote: `${s.exercises.length} exercícios`,
            totalVolumeKg: 2400,
          };
          setWorkouts((prevWorkouts) => [newWorkoutRecord, ...prevWorkouts]);
        } else {
          // Se desmarcar, sincroniza removendo do histórico
          setWorkouts((prevWorkouts) =>
            prevWorkouts.filter((w) => !(w.name === s.title && w.date === getTodayISO()))
          );
        }
        return { ...s, isCompleted: nextState };
      });
      return updated;
    });
  };

  // Toggle individual exercise completion
  const handleToggleExerciseDone = (sessionId: string, exerciseId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setWeeklySessions((prev) => {
      const updated = { ...prev };
      const currentList = updated[selectedDayIndex] || [];
      updated[selectedDayIndex] = currentList.map((session) => {
        if (session.id !== sessionId) return session;
        const updatedExercises = session.exercises.map((ex) =>
          ex.id === exerciseId ? { ...ex, isDone: !ex.isDone } : ex
        );
        const allDone = updatedExercises.length > 0 && updatedExercises.every((ex) => ex.isDone);
        return {
          ...session,
          exercises: updatedExercises,
          isCompleted: allDone ? true : session.isCompleted,
        };
      });
      return updated;
    });
  };

  // Manipulação de exercícios no Montar Treino
  const handleAddExerciseRow = () => {
    setNewExercises((prev) => [
      ...prev,
      { id: genId(), name: '', sets: '3', reps: '10-12', weight: '', notes: '' },
    ]);
  };

  const handleRemoveExerciseRow = (id: string) => {
    setNewExercises((prev) => (prev.length > 1 ? prev.filter((ex) => ex.id !== id) : prev));
  };

  const handleUpdateExerciseRow = (id: string, field: 'name' | 'sets' | 'reps' | 'weight' | 'notes', value: string) => {
    setNewExercises((prev) =>
      prev.map((ex) => (ex.id === id ? { ...ex, [field]: value } : ex))
    );
  };

  const handleApplyWorkoutTemplate = (templateName: string) => {
    if (templateName === 'peito_triceps') {
      setNewTitle('Hipertrofia Peitoral & Tríceps');
      setNewMuscleGroup('Peito & Tríceps');
      setNewType('strength');
      setNewDuration('55 min');
      setNewCalories('380');
      setNewRestBetweenSets('60s');
      setNewWarmup('5 min esteira + rotação de manguito rotador');
      setNewExercises([
        { id: genId(), name: 'Supino Reto com Barra', sets: '4', reps: '8-10', weight: '60kg', notes: 'Cadência 3-0-1' },
        { id: genId(), name: 'Supino Inclinado com Halteres', sets: '4', reps: '10-12', weight: '22kg', notes: 'Alongamento profundo' },
        { id: genId(), name: 'Crucifixo no Crossover', sets: '3', reps: '12-15', weight: '15kg', notes: 'Pico de contração 1s' },
        { id: genId(), name: 'Tríceps Corda no Pulley', sets: '4', reps: '12', weight: '25kg', notes: 'Abrir no final' },
        { id: genId(), name: 'Tríceps Francês / Testa', sets: '3', reps: '10-12', weight: '18kg', notes: 'Cotovelos fechados' },
      ]);
    } else if (templateName === 'costas_biceps') {
      setNewTitle('Dorsal & Bíceps Densidade');
      setNewMuscleGroup('Costas & Bíceps');
      setNewType('strength');
      setNewDuration('50 min');
      setNewCalories('400');
      setNewRestBetweenSets('75s');
      setNewWarmup('5 min simulador de remo + mobilidade escapular');
      setNewExercises([
        { id: genId(), name: 'Puxada Alta Aberta (Pulley)', sets: '4', reps: '10-12', weight: '55kg', notes: 'Puxar com as escápulas' },
        { id: genId(), name: 'Remada Curvada com Barra', sets: '4', reps: '8-10', weight: '50kg', notes: 'Coluna alinhada' },
        { id: genId(), name: 'Remada Baixa Triângulo', sets: '3', reps: '12', weight: '60kg', notes: 'Segurar 1s atrás' },
        { id: genId(), name: 'Rosca Direta Barra W', sets: '4', reps: '10-12', weight: '14kg', notes: 'Sem balançar o tronco' },
        { id: genId(), name: 'Rosca Martelo Halteres', sets: '3', reps: '12', weight: '14kg', notes: 'Foco no braquial' },
      ]);
    } else if (templateName === 'pernas_completo') {
      setNewTitle('Membros Inferiores & Glúteos');
      setNewMuscleGroup('Pernas Completo');
      setNewType('strength');
      setNewDuration('60 min');
      setNewCalories('450');
      setNewRestBetweenSets('90s');
      setNewWarmup('8 min esteira com inclinação + mobilidade de tornozelo/quadril');
      setNewExercises([
        { id: genId(), name: 'Agachamento Livre com Barra', sets: '4', reps: '8-10', weight: '70kg', notes: 'Profundidade máxima segura' },
        { id: genId(), name: 'Leg Press 45°', sets: '4', reps: '10-12', weight: '160kg', notes: 'Sem travar o joelho' },
        { id: genId(), name: 'Cadeira Extensora', sets: '3', reps: '15', weight: '45kg', notes: 'Pausa no topo' },
        { id: genId(), name: 'Mesa Flexora (Posterior)', sets: '4', reps: '12', weight: '40kg', notes: 'Quadril colado no banco' },
        { id: genId(), name: 'Elevação de Panturrilhas em Pé', sets: '4', reps: '15-20', weight: '60kg', notes: 'Alongar bem embaixo' },
      ]);
    } else if (templateName === 'cardio_funcional') {
      setNewTitle('Cardio HIIT & Abdômen');
      setNewMuscleGroup('Cardio & Core');
      setNewType('cardio');
      setNewDuration('40 min');
      setNewCalories('420');
      setNewRestBetweenSets('45s');
      setNewWarmup('3 min caminhada progressiva');
      setNewExercises([
        { id: genId(), name: 'Tiro na Esteira (Intervalado)', sets: '8 tiros', reps: '1 min tiro / 1 min leve', weight: '14km/h', notes: 'Frequência alta' },
        { id: genId(), name: 'Prancha Isométrica', sets: '4 séries', reps: '45s', weight: 'Peso corporal', notes: 'Abdômen contraído' },
        { id: genId(), name: 'Abdominal Infra na Barra', sets: '3 séries', reps: '15 reps', weight: 'Peso corporal', notes: 'Sem balançar' },
        { id: genId(), name: 'Bicicleta Ergométrica Moderada', sets: '1 bloco', reps: '10 min contínuo', weight: 'Carga média', notes: 'Recuperação aeróbica' },
      ]);
    }
  };

  // Add new session handler
  const handleCreateNewWorkout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const formattedExercises: ExerciseDetail[] = newExercises
      .filter((ex) => ex.name.trim().length > 0)
      .map((ex) => ({
        id: ex.id || genId(),
        name: ex.name.trim(),
        sets: `${ex.sets || 3} séries × ${ex.reps || 10} reps`,
        weight: ex.weight ? ex.weight.trim() : undefined,
        reps: ex.reps,
        notes: ex.notes ? ex.notes.trim() : undefined,
        isDone: false,
      }));

    const finalExercises =
      formattedExercises.length > 0
        ? formattedExercises
        : [
            {
              id: genId(),
              name: 'Exercício Principal',
              sets: '4 séries × 10 reps',
              weight: '20kg',
              isDone: false,
            },
          ];

    const targetDay =
      newDayIndex >= 0 && newDayIndex <= 6 ? newDayIndex : selectedDayIndex;

    const newSession: ScheduledSession = {
      id: genId(),
      title: newTitle.trim(),
      duration: newDuration || '45 min',
      level: newLevel,
      exercisesCount: finalExercises.length,
      badge: 'Novo',
      badgeType: newType === 'cardio' ? 'amber' : newType === 'mobility' ? 'green' : 'purple',
      isCompleted: false,
      type: newType,
      exercises: finalExercises,
      muscleGroup: newMuscleGroup,
      restBetweenSets: newRestBetweenSets,
      caloriesBurn: parseInt(newCalories, 10) || 350,
      warmup: newWarmup,
      notes: newNotes,
    };

    setWeeklySessions((prev) => ({
      ...prev,
      [targetDay]: [newSession, ...(prev[targetDay] || [])],
    }));

    // Sincronizar com o array global workouts para persistência
    setWorkouts((prev) => [
      {
        id: newSession.id,
        name: newSession.title,
        date: new Date().toISOString().slice(0, 10),
        dayOfWeek: weekDays[targetDay]?.label || 'SEG',
        category: newMuscleGroup || 'Musculação',
        exercises: finalExercises.map((e) => ({
          id: e.id,
          name: e.name,
          sets: parseInt(e.sets, 10) || 3,
          reps: 10,
          weight: e.weight || '0kg',
          isDone: false,
        })),
        durationMinutes: parseInt(newDuration, 10) || 45,
      },
      ...prev,
    ]);

    // Limpar e fechar modal
    setNewTitle('');
    setNewNotes('');
    setIsNewWorkoutOpen(false);
  };

  // Log habit increment
  const handleLogHabit = (type: 'water' | 'sleep' | 'nutrition') => {
    setHabitsData((prev) => {
      if (type === 'water') {
        const nextDays = Math.min(7, prev.waterDays + 1);
        return { ...prev, waterDays: nextDays, waterPct: Math.min(100, prev.waterPct + 5) };
      }
      if (type === 'nutrition') {
        const nextDays = Math.min(7, prev.nutritionDays + 1);
        return { ...prev, nutritionDays: nextDays, nutritionPct: Math.min(100, prev.nutritionPct + 6) };
      }
      return prev;
    });
  };

  // Current day's sessions
  const currentSessions = weeklySessions[selectedDayIndex] || [];

  return (
    <div className="w-full bg-[#F8F9FD] text-[#0F172A] rounded-3xl p-4 sm:p-7 transition-all">
      <div className="w-full max-w-5xl mx-auto flex flex-col gap-6">
        {/* ========================================================= */}
        {/* BENTO HEADER: Saudação, Avatar DN e Ações Rápidas         */}
        {/* ========================================================= */}
        <header className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            {/* Avatar Bento Squircle */}
            <div className="w-11 h-11 bg-[#EDE9FE] text-[#6D28D9] font-bold text-sm flex items-center justify-center rounded-2xl shrink-0 shadow-[0_2px_8px_rgba(109,40,217,0.12)] border border-[#DDD6FE] transition-transform hover:scale-105">
              DN
            </div>
            <div>
              <div className="font-mono text-xs text-slate-400 capitalize flex items-center gap-1.5">
                <Calendar className="w-3 h-3 text-slate-400" />
                <span>segunda-feira, 21 de setembro</span>
              </div>
              <h1 className="font-bold text-xl text-slate-900 tracking-tight leading-snug">
                Bom treino, {userName}.
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setNewDayIndex(selectedDayIndex);
                setIsNewWorkoutOpen(true);
              }}
              className="bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-2.5 rounded-xl border border-slate-200/90 shadow-[0_2px_6px_rgba(0,0,0,0.03)] hover:shadow-md cursor-pointer transition-all active:scale-95 whitespace-nowrap flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5 text-slate-500" />
              <span>Montar Treino</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setNewDayIndex(selectedDayIndex);
                setIsNewWorkoutOpen(true);
              }}
              className="w-10 h-10 bg-white hover:bg-slate-50 border border-slate-200/90 rounded-xl flex items-center justify-center text-slate-500 shadow-[0_2px_6px_rgba(0,0,0,0.03)] hover:shadow-md cursor-pointer transition-all active:scale-95 shrink-0"
              title="Montar Treino Personalizado"
            >
              <SlidersHorizontal className="w-4 h-4 text-slate-600" />
            </button>
          </div>
        </header>

        {/* ========================================================= */}
        {/* BENTO GRID: LAYOUT DUPLO INTEGRADO                         */}
        {/* ========================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* ======================================================= */}
          {/* COLUNA ESQUERDA: HERO, MÉTRICAS, CARGA, LISTA SEMANAL   */}
          {/* ======================================================= */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            {/* 1. Bento Hero Card: FOCO DE HOJE */}
            <div className="bg-gradient-to-r from-[#6366F1] via-[#7C3AED] to-[#8B5CF6] text-white rounded-3xl p-6 sm:p-7 relative overflow-hidden shadow-[0_4px_20px_rgba(99,102,241,0.22)] border border-white/20 transition-all hover:shadow-[0_8px_30px_rgba(99,102,241,0.28)]">
              {/* Arcos orgânicos de fundo característicos */}
              <div className="absolute -right-12 -top-12 w-64 h-64 rounded-full border-[28px] border-white/10 pointer-events-none" />
              <div className="absolute right-6 -bottom-20 w-56 h-56 rounded-full border-[20px] border-white/10 pointer-events-none" />

              <div className="relative z-10 max-w-lg">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-mono font-bold text-[11px] text-purple-200 tracking-wider uppercase bg-white/10 px-2.5 py-0.5 rounded-full backdrop-blur-xs">
                    FOCO DE HOJE
                  </span>
                  <span className="text-[11px] text-purple-200 font-mono flex items-center gap-1">
                    <Zap className="w-3 h-3 text-amber-300 fill-amber-300" />
                    <span>Semana 38</span>
                  </span>
                </div>

                <h2 className="font-extrabold text-2xl sm:text-3xl text-white tracking-tight leading-tight">
                  Força e mobilidade,<br />sem pressa.
                </h2>
                <p className="text-xs sm:text-sm text-purple-100/90 leading-relaxed mt-2.5 max-w-md">
                  Você está no ritmo certo. Complete a sessão de hoje para fechar a semana com consistência.
                </p>

                <div className="flex items-center gap-3 mt-5 flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      const firstSession = currentSessions[0];
                      if (firstSession) {
                        setActiveSessionForModal(firstSession);
                      }
                    }}
                    className="bg-[#F87171] hover:bg-[#EF4444] text-white font-semibold text-xs sm:text-sm px-6 py-2.5 rounded-xl shadow-[0_2px_10px_rgba(248,113,113,0.35)] transition-all active:scale-95 cursor-pointer inline-flex items-center gap-2"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Começar sessão</span>
                  </button>

                  {currentSessions[0] && (
                    <button
                      type="button"
                      onClick={() => setExpandedSessionId(expandedSessionId === currentSessions[0].id ? null : currentSessions[0].id)}
                      className="bg-white/15 hover:bg-white/20 text-white font-medium text-xs px-4 py-2.5 rounded-xl backdrop-blur-xs transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <span>Ver {currentSessions[0].exercises.length} exercícios</span>
                      {expandedSessionId === currentSessions[0].id ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* 2. Bento Quick Stats: 3 Métricas em Estilo Bento */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-[0_2px_8px_rgba(0,0,0,0.02)] hover:shadow-md transition-all duration-200">
                <div className="text-3xl sm:text-4xl font-extrabold text-slate-800 font-mono tracking-tight">
                  04
                </div>
                <div className="text-[11px] sm:text-xs text-slate-400 font-mono mt-0.5">
                  sessões na semana
                </div>
                <div className="text-[11px] sm:text-xs text-emerald-600 font-semibold font-mono mt-1 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  <span>+1 vs. semana passada</span>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-[0_2px_8px_rgba(0,0,0,0.02)] hover:shadow-md transition-all duration-200">
                <div className="text-3xl sm:text-4xl font-extrabold text-slate-800 font-mono tracking-tight">
                  2.840
                </div>
                <div className="text-[11px] sm:text-xs text-slate-400 font-mono mt-0.5">
                  calorias estimadas
                </div>
                <div className="text-[11px] sm:text-xs text-emerald-600 font-semibold font-mono mt-1 flex items-center gap-1">
                  <Flame className="w-3 h-3 text-orange-500 fill-orange-500" />
                  <span>+12% no mês</span>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-[0_2px_8px_rgba(0,0,0,0.02)] hover:shadow-md transition-all duration-200">
                <div className="text-3xl sm:text-4xl font-extrabold text-slate-800 font-mono tracking-tight">
                  86%
                </div>
                <div className="text-[11px] sm:text-xs text-slate-400 font-mono mt-0.5">
                  consistência
                </div>
                <div className="text-[11px] sm:text-xs text-emerald-600 font-semibold font-mono mt-1 flex items-center gap-1">
                  <Award className="w-3 h-3 text-emerald-600" />
                  <span>melhor marca</span>
                </div>
              </div>
            </div>

            {/* 3. Bento Card: Carga de Treino (Rastreador Gráfico de Progresso) */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.05)] transition-all duration-300">
              <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
                <div>
                  <h3 className="font-bold text-base text-slate-800 flex items-center gap-2">
                    <span>Carga de treino</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-purple-50 text-purple-700 rounded-full font-semibold">
                      48 min média
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    Minutos ativos por sessão
                  </p>
                </div>

                <div className="bg-slate-100 p-1 flex gap-1 rounded-xl">
                  {(['7d', 'mes', 'ano'] as const).map((r) => {
                    const label = r === '7d' ? '7 dias' : r === 'mes' ? 'Mês' : 'Ano';
                    const active = chartRange === r;
                    return (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setChartRange(r)}
                        className={`text-xs px-3 py-1 rounded-lg transition-all cursor-pointer font-medium ${
                          active
                            ? 'bg-white text-slate-800 font-semibold shadow-xs'
                            : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Bar Chart Area Bento */}
              <div className="h-44 w-full flex items-end justify-between gap-2 pt-4 px-2">
                {chartData.map((d, i) => {
                  const maxMinutes = 70;
                  const heightPct = Math.max(8, Math.min(100, (d.minutes / maxMinutes) * 100));
                  const isCurrentDay = d.active;
                  return (
                    <div
                      key={i}
                      className="flex-1 flex flex-col items-center gap-2 h-full justify-end group cursor-pointer"
                    >
                      <div className="relative w-full flex flex-col items-center justify-end h-32">
                        {/* Tooltip on hover */}
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 bg-slate-800 text-white text-[10px] font-mono py-1 px-2 rounded-md shadow-md pointer-events-none whitespace-nowrap z-20">
                          {d.minutes} min ativos
                        </div>

                        {/* Bar com visual Bento refinado */}
                        <div
                          style={{ height: `${heightPct}%` }}
                          className={`w-full max-w-[28px] rounded-xl transition-all duration-300 group-hover:scale-y-105 ${
                            isCurrentDay
                              ? 'bg-gradient-to-t from-[#6366F1] to-[#8B5CF6] shadow-[0_2px_10px_rgba(99,102,241,0.3)]'
                              : 'bg-slate-200/90 hover:bg-purple-200'
                          }`}
                        />
                      </div>
                      <span
                        className={`text-[11px] font-mono capitalize ${
                          isCurrentDay ? 'text-[#6D28D9] font-bold' : 'text-slate-400'
                        }`}
                      >
                        {d.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 4. Bento Card: Agenda da Semana & Lista de Exercícios */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.05)] transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-slate-800 font-mono">
                    Agenda da semana
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-100 text-slate-600 rounded-full">
                    {currentSessions.length} sessões
                  </span>
                </div>
                <span className="text-xs text-slate-400 font-mono">
                  21 a 27 set
                </span>
              </div>

              {/* Seletor Bento de 7 Dias da Semana */}
              <div className="grid grid-cols-7 gap-1.5 sm:gap-2 mb-6">
                {weekDays.map((d) => {
                  const isSelected = selectedDayIndex === d.index;
                  return (
                    <button
                      key={d.index}
                      type="button"
                      onClick={() => setSelectedDayIndex(d.index)}
                      className={`flex flex-col items-center justify-center py-2.5 rounded-2xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#EDE9FE] border-[#C4B5FD] shadow-[0_2px_10px_rgba(109,40,217,0.15)] scale-[1.02]'
                          : 'bg-white border-slate-200/90 hover:border-slate-300 hover:shadow-xs'
                      }`}
                    >
                      <span
                        className={`text-[10px] font-mono font-semibold ${
                          isSelected ? 'text-[#6D28D9]' : 'text-slate-500'
                        }`}
                      >
                        {d.label}
                      </span>
                      <span
                        className={`text-sm sm:text-base font-bold font-mono mt-0.5 ${
                          isSelected ? 'text-[#0F172A]' : 'text-slate-700'
                        }`}
                      >
                        {d.dayNum}
                      </span>
                      <div className="h-2 flex items-center justify-center mt-1">
                        {d.dotColor && (
                          <div
                            style={{ backgroundColor: d.dotColor }}
                            className="w-1.5 h-1.5 rounded-full"
                          />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Lista Semanal de Sessões com Cards Bento de Exercícios */}
              <div className="flex flex-col gap-4">
                {currentSessions.map((session) => {
                  const isExpanded = expandedSessionId === session.id;
                  const completedExercisesCount = session.exercises.filter((e) => e.isDone).length;

                  return (
                    <div
                      key={session.id}
                      className={`rounded-2xl border transition-all ${
                        isExpanded
                          ? 'bg-slate-50/70 border-purple-200 shadow-xs'
                          : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50/40 shadow-xs'
                      }`}
                    >
                      {/* Cabeçalho do Card da Sessão */}
                      <div
                        onClick={() => setExpandedSessionId(isExpanded ? null : session.id)}
                        className="flex items-center justify-between p-3.5 sm:p-4 cursor-pointer"
                      >
                        <div className="flex items-center gap-3.5">
                          {/* Squircle com ícone da sessão */}
                          <div
                            className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
                              session.type === 'mobility'
                                ? 'bg-[#D1FAE5] text-[#065F46]'
                                : session.type === 'cardio'
                                ? 'bg-[#FEE2E2] text-[#B91C1C]'
                                : 'bg-[#EDE9FE] text-[#6D28D9]'
                            }`}
                          >
                            {session.type === 'mobility' ? (
                              <Activity className="w-5 h-5" />
                            ) : session.type === 'cardio' ? (
                              <Flame className="w-5 h-5" />
                            ) : (
                              <Dumbbell className="w-5 h-5" />
                            )}
                          </div>

                          {/* Título & metadados */}
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-sm text-slate-800 hover:text-purple-900 transition-colors">
                                {session.title}
                              </h4>
                              {session.exercises.length > 0 && (
                                <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-200/70 text-slate-700 rounded-full font-medium">
                                  {completedExercisesCount}/{session.exercises.length} feitos
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-400 font-mono mt-0.5">
                              {session.duration} • {session.level}
                              {session.exercisesCount > 0 && ` • ${session.exercisesCount} exercícios`}
                            </p>
                          </div>
                        </div>

                        {/* Badges e Ação de Conclusão */}
                        <div className="flex items-center gap-3">
                          {session.badge && (
                            <span
                              className={`text-[10px] font-semibold px-2.5 py-0.5 rounded-full font-mono ${
                                session.badgeType === 'green'
                                  ? 'bg-[#D1FAE5] text-[#065F46]'
                                  : 'bg-[#EDE9FE] text-[#6D28D9]'
                              }`}
                            >
                              {session.badge}
                            </span>
                          )}

                          <button
                            type="button"
                            onClick={(e) => handleToggleSession(session.id, e)}
                            title={session.isCompleted ? 'Desmarcar treino' : 'Marcar como concluído'}
                            className={`w-7 h-7 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer ${
                              session.isCompleted
                                ? 'bg-[#6366F1] border-[#6366F1] text-white shadow-xs'
                                : 'border-slate-300 hover:border-purple-600 bg-white'
                            }`}
                          >
                            {session.isCompleted && <Check className="w-4 h-4 stroke-[3]" />}
                          </button>

                          <div className="text-slate-400 hover:text-slate-600 p-1">
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </div>
                        </div>
                      </div>

                      {/* Gaveta Bento Expansível de Exercícios Detalhados */}
                      {isExpanded && session.exercises.length > 0 && (
                        <div className="px-3.5 sm:px-4 pb-4 pt-1 border-t border-slate-200/60 flex flex-col gap-2">
                          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-1 py-1">
                            <span>Exercícios da sessão</span>
                            <span>Clique para marcar série</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {session.exercises.map((exercise, idx) => (
                              <div
                                key={exercise.id}
                                onClick={(e) => handleToggleExerciseDone(session.id, exercise.id, e)}
                                className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-2.5 ${
                                  exercise.isDone
                                    ? 'bg-purple-50/60 border-purple-200/80'
                                    : 'bg-white border-slate-200/70 hover:border-slate-300 shadow-xs'
                                }`}
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div
                                    className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                                      exercise.isDone
                                        ? 'bg-purple-600 text-white'
                                        : 'bg-slate-100 text-slate-600'
                                    }`}
                                  >
                                    {exercise.isDone ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : idx + 1}
                                  </div>
                                  <div className="min-w-0">
                                    <h5
                                      className={`text-xs font-semibold truncate ${
                                        exercise.isDone ? 'line-through text-slate-400' : 'text-slate-800'
                                      }`}
                                    >
                                      {exercise.name}
                                    </h5>
                                    <p className="text-[11px] text-slate-400 font-mono truncate">
                                      {exercise.sets}
                                    </p>
                                  </div>
                                </div>

                                {exercise.weight && (
                                  <span className="shrink-0 px-2 py-0.5 rounded-md bg-purple-100/70 text-purple-800 text-[10px] font-mono font-bold">
                                    {exercise.weight}
                                  </span>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}

                {currentSessions.length === 0 && (
                  <div className="py-8 text-center text-xs text-slate-400 font-mono bg-slate-50/60 rounded-2xl border border-dashed border-slate-200">
                    Nenhum treino agendado para este dia.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ======================================================= */}
          {/* COLUNA DIREITA: META MENSAL, HÁBITOS, INSIGHT (~35%)    */}
          {/* ======================================================= */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            {/* 1. Bento Card: Meta Mensal */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.05)] transition-all duration-300">
              <div className="mb-4">
                <h3 className="font-bold text-sm text-slate-800 font-mono flex items-center justify-between">
                  <span>Meta mensal</span>
                  <span className="text-[10px] px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full font-semibold">
                    Em dia
                  </span>
                </h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Construir força até 30 de setembro
                </p>
              </div>

              {/* Gauge radial circular Bento */}
              <div className="flex items-center gap-4 my-3 p-2 bg-slate-50/50 rounded-2xl border border-slate-100">
                <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 80 80">
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      className="text-slate-100"
                      strokeWidth="7"
                      stroke="currentColor"
                      fill="transparent"
                    />
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      className="text-[#6366F1] transition-all duration-700 ease-out"
                      strokeWidth="7"
                      strokeDasharray={201}
                      strokeDashoffset={201 * (1 - 0.72)}
                      strokeLinecap="round"
                      stroke="currentColor"
                      fill="transparent"
                    />
                  </svg>
                  <span className="absolute font-bold text-sm text-slate-800 font-mono">
                    72%
                  </span>
                </div>

                <div>
                  <div className="font-semibold text-xs text-slate-800 font-mono">
                    18 de 25 sessões
                  </div>
                  <p className="text-[11px] text-slate-400 leading-tight mt-1 font-mono">
                    Faltam 7 sessões para bater sua meta.
                  </p>
                </div>
              </div>

              {/* Linear Progress */}
              <div className="mt-4 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-1.5">
                  <span>Progresso acumulado</span>
                  <span className="text-slate-700 font-semibold">18 / 25</span>
                </div>
                <div className="w-full bg-purple-100/70 rounded-full h-2 overflow-hidden">
                  <div className="bg-[#6366F1] h-2 rounded-full w-[72%] transition-all" />
                </div>
              </div>
            </div>

            {/* 2. Bento Card: Hábitos em Alta com Ações Rápidas */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.05)] transition-all duration-300">
              <div className="mb-4">
                <h3 className="font-bold text-sm text-slate-800">
                  Hábitos em alta
                </h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Pequenas vitórias, resultado grande
                </p>
              </div>

              <div className="flex flex-col gap-3.5">
                {/* Hábito 1: Hidratação */}
                <div
                  onClick={() => handleLogHabit('water')}
                  className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-[#D1FAE5] rounded-xl flex items-center justify-center text-emerald-600 shrink-0 group-hover:scale-105 transition-transform">
                      <Droplets className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-semibold text-xs text-slate-800 flex items-center gap-1.5">
                        <span>Hidratação</span>
                        <span className="text-[10px] text-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity font-mono">
                          +1 copo
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {habitsData.waterDays} dias seguidos
                      </div>
                    </div>
                  </div>
                  <span className="font-bold text-xs text-slate-700 font-mono">
                    {habitsData.waterPct}%
                  </span>
                </div>

                {/* Hábito 2: Sono */}
                <div className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-[#FEF08A] rounded-xl flex items-center justify-center text-amber-600 shrink-0">
                      <Moon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-semibold text-xs text-slate-800">
                        Sono
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {habitsData.sleepAvg} em média
                      </div>
                    </div>
                  </div>
                  <span className="font-bold text-xs text-slate-700 font-mono">
                    {habitsData.sleepPct}%
                  </span>
                </div>

                {/* Hábito 3: Nutrição */}
                <div
                  onClick={() => handleLogHabit('nutrition')}
                  className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-[#FEE2E2] rounded-xl flex items-center justify-center text-rose-600 shrink-0 group-hover:scale-105 transition-transform">
                      <Apple className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-semibold text-xs text-slate-800 flex items-center gap-1.5">
                        <span>Nutrição</span>
                        <span className="text-[10px] text-rose-600 opacity-0 group-hover:opacity-100 transition-opacity font-mono">
                          +1 dia
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {habitsData.nutritionDays} dias registrados
                      </div>
                    </div>
                  </div>
                  <span className="font-bold text-xs text-slate-700 font-mono">
                    {habitsData.nutritionPct}%
                  </span>
                </div>
              </div>
            </div>

            {/* 3. Bento Card: Histórico Recente (Últimos 3 treinos concluídos pelo usuário) */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.05)] transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-[#EDE9FE] text-[#6D28D9] flex items-center justify-center shadow-xs">
                    <History className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-800">
                      Histórico Recente
                    </h3>
                    <p className="text-[11px] text-slate-400 font-mono">
                      Últimos 3 treinos concluídos
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full font-semibold border border-emerald-200/50 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>{recentCompletedWorkouts.length} salvos</span>
                </span>
              </div>

              {recentCompletedWorkouts.length > 0 ? (
                <div className="flex flex-col gap-2.5">
                  {recentCompletedWorkouts.map((workout, index) => {
                    const isExpanded = expandedHistoryId === workout.id;
                    const displayDate = formatRecentWorkoutDate(workout.date);
                    const volumeStr = workout.totalVolumeKg
                      ? fmtVolumeKg(workout.totalVolumeKg)
                      : null;

                    return (
                      <div
                        key={workout.id || index}
                        onClick={() => setExpandedHistoryId(isExpanded ? null : workout.id)}
                        className={`rounded-2xl border transition-all cursor-pointer p-3.5 ${
                          isExpanded
                            ? 'bg-purple-50/50 border-purple-200 shadow-xs'
                            : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50/60 shadow-xs'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2.5">
                          <div className="flex items-start gap-3 min-w-0">
                            {/* Número de ordem 1, 2 ou 3 */}
                            <div className="w-8 h-8 rounded-xl bg-purple-100/70 text-purple-700 flex items-center justify-center shrink-0 font-mono font-bold text-xs">
                              {index + 1}
                            </div>
                            <div className="min-w-0">
                              <h4 className="font-bold text-xs sm:text-sm text-slate-800 truncate">
                                {workout.name}
                              </h4>
                              <div className="flex items-center gap-1.5 flex-wrap mt-1">
                                <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                                  {displayDate}
                                </span>
                                {workout.durationMinutes && (
                                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 flex items-center gap-1">
                                    <Clock className="w-2.5 h-2.5 text-slate-400" />
                                    <span>{workout.durationMinutes} min</span>
                                  </span>
                                )}
                                {volumeStr && (
                                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 font-medium flex items-center gap-1">
                                    <Flame className="w-2.5 h-2.5 text-orange-500 fill-orange-500" />
                                    <span>{volumeStr}</span>
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/50 flex items-center gap-1">
                              <Check className="w-3 h-3 stroke-[3]" />
                              <span>Feito</span>
                            </span>
                            <div className="text-slate-400 hover:text-slate-600 p-0.5">
                              {isExpanded ? (
                                <ChevronUp className="w-3.5 h-3.5" />
                              ) : (
                                <ChevronDown className="w-3.5 h-3.5" />
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Detalhes expansíveis ao clicar */}
                        {isExpanded && (
                          <div className="mt-3 pt-2.5 border-t border-purple-100 flex flex-col gap-2 text-xs">
                            {workout.focus && (
                              <div className="flex items-center justify-between text-slate-600 font-mono text-[11px]">
                                <span className="text-slate-400">Foco do treino:</span>
                                <span className="font-semibold text-slate-800">{workout.focus}</span>
                              </div>
                            )}
                            {workout.loadNote && (
                              <div className="bg-white/90 p-2.5 rounded-xl border border-slate-200/70 text-[11px] font-mono text-slate-600 leading-relaxed">
                                <span className="text-slate-400 block mb-1">Cargas registradas:</span>
                                <span className="text-slate-700 font-medium">{workout.loadNote}</span>
                              </div>
                            )}
                            {workout.exercises && workout.exercises.length > 0 && (
                              <div className="flex flex-col gap-1 mt-1">
                                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                                  Exercícios ({workout.exercises.length}):
                                </span>
                                <div className="grid grid-cols-1 gap-1">
                                  {workout.exercises.map((ex, exIdx) => (
                                    <div
                                      key={ex.id || exIdx}
                                      className="flex items-center justify-between px-2.5 py-1 rounded-lg bg-white/70 border border-slate-100 text-[11px]"
                                    >
                                      <span className="font-medium text-slate-700 truncate">{ex.name}</span>
                                      <span className="text-slate-500 font-mono text-[10px]">
                                        {ex.sets} séries • {ex.weight}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            <div className="text-[10px] text-slate-400 font-mono text-right mt-0.5">
                              Salvo no localStorage
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-6 text-center text-xs text-slate-400 font-mono bg-slate-50/60 rounded-2xl border border-dashed border-slate-200 p-4">
                  <p>Nenhum treino concluído ainda.</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Marque um treino como concluído na agenda para exibi-lo aqui.
                  </p>
                </div>
              )}
            </div>

            {/* 4. Bento Card: Insight da Semana */}
            <div className="bg-[#FFF1F2] border border-[#FFE4E6] rounded-3xl p-5 shadow-[0_2px_8px_rgba(255,228,230,0.4)] hover:shadow-md transition-all">
              <div className="flex items-center gap-1.5 mb-1.5">
                <Sparkles className="w-4 h-4 text-rose-500" />
                <h4 className="font-bold text-xs text-slate-800 font-mono">
                  Insight da semana
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Suas sessões de terça têm 18% mais volume. Esse é seu melhor dia para treinos de força.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* MODAL BENTO: SESSÃO / COMEÇAR SESSÃO                      */}
      {/* ========================================================= */}
      {activeSessionForModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <span className="inline-block text-[10px] font-mono uppercase tracking-wider text-purple-600 bg-purple-50 px-2 py-0.5 rounded-md font-semibold mb-1">
                  {activeSessionForModal.level}
                </span>
                <h3 className="font-bold text-xl text-slate-900">
                  {activeSessionForModal.title}
                </h3>
                <p className="text-xs text-slate-500 font-mono mt-0.5">
                  Duração estimada: {activeSessionForModal.duration}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setActiveSessionForModal(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="my-4">
              <h4 className="font-bold text-xs text-slate-700 font-mono uppercase tracking-wider mb-2.5">
                Exercícios da Sessão
              </h4>
              <div className="flex flex-col gap-2 max-h-64 overflow-y-auto pr-1">
                {activeSessionForModal.exercises.map((ex, i) => (
                  <div
                    key={ex.id || i}
                    onClick={() => handleToggleExerciseDone(activeSessionForModal.id, ex.id)}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-purple-50/50 border border-slate-100 transition-colors text-xs cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-5 h-5 rounded-md bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-[10px]">
                        {i + 1}
                      </div>
                      <span className={`font-semibold ${ex.isDone ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                        {ex.name}
                      </span>
                    </div>
                    <div className="text-right font-mono text-slate-500 flex items-center gap-2">
                      <span>{ex.sets}</span>
                      {ex.weight && <span className="font-bold text-purple-600">• {ex.weight}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 mt-6 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setActiveSessionForModal(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Fechar
              </button>
              <button
                type="button"
                onClick={() => {
                  handleToggleSession(activeSessionForModal.id);
                  setActiveSessionForModal(null);
                }}
                className={`px-5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all shadow-xs ${
                  activeSessionForModal.isCompleted
                    ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    : 'bg-[#6366F1] hover:bg-[#4F46E5] text-white'
                }`}
              >
                {activeSessionForModal.isCompleted ? 'Desmarcar' : 'Concluir Treino'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL BENTO: MONTAR TREINO COMPLETO                       */}
      {/* ========================================================= */}
      {isNewWorkoutOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateNewWorkout}
            className="bg-white rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 my-8 max-h-[90vh] flex flex-col"
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shadow-xs">
                  <Dumbbell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-slate-900 leading-tight">
                    Montar Treino Personalizado
                  </h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    Preencha todos os parâmetros, grupamentos e lista de exercícios
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsNewWorkoutOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Form Body */}
            <div className="overflow-y-auto pr-1 flex-1 py-4 flex flex-col gap-5 text-xs">
              {/* Sugestões Rápidas de Treino (Templates 1-Click) */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-slate-700 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                    Modelos Rápidos (Preencher com 1 clique)
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => handleApplyWorkoutTemplate('peito_triceps')}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-400 bg-slate-50 hover:bg-indigo-50/50 text-left transition-all cursor-pointer"
                  >
                    <p className="font-bold text-slate-800 text-[11px]">Peito & Tríceps</p>
                    <p className="text-[10px] text-slate-500">5 exercícios • 55 min</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplyWorkoutTemplate('costas_biceps')}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-400 bg-slate-50 hover:bg-indigo-50/50 text-left transition-all cursor-pointer"
                  >
                    <p className="font-bold text-slate-800 text-[11px]">Costas & Bíceps</p>
                    <p className="text-[10px] text-slate-500">5 exercícios • 50 min</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplyWorkoutTemplate('pernas_completo')}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-400 bg-slate-50 hover:bg-indigo-50/50 text-left transition-all cursor-pointer"
                  >
                    <p className="font-bold text-slate-800 text-[11px]">Pernas Completo</p>
                    <p className="text-[10px] text-slate-500">5 exercícios • 60 min</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplyWorkoutTemplate('cardio_funcional')}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-400 bg-slate-50 hover:bg-indigo-50/50 text-left transition-all cursor-pointer"
                  >
                    <p className="font-bold text-slate-800 text-[11px]">Cardio HIIT & Core</p>
                    <p className="text-[10px] text-slate-500">4 blocos • 40 min</p>
                  </button>
                </div>
              </div>

              {/* Seção 1: Agendamento & Informações Principais */}
              <div className="bg-slate-50/70 border border-slate-200/80 rounded-2xl p-4 flex flex-col gap-3.5">
                <span className="font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                  <Calendar className="w-3.5 h-3.5 text-slate-600" />
                  1. Agendamento & Foco do Treino
                </span>

                {/* Seleção do dia da semana */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                    Dia da semana para agendar
                  </label>
                  <div className="grid grid-cols-7 gap-1.5">
                    {weekDays.map((d) => (
                      <button
                        key={d.index}
                        type="button"
                        onClick={() => setNewDayIndex(d.index)}
                        className={`py-2 px-1 rounded-xl text-center font-bold text-[11px] border transition-all cursor-pointer ${
                          newDayIndex === d.index
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Título & Grupamento */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Título do Treino *
                    </label>
                    <input
                      type="text"
                      required
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="Ex: Treino de Força Peitoral & Tríceps"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Grupo Muscular Principal
                    </label>
                    <input
                      type="text"
                      value={newMuscleGroup}
                      onChange={(e) => setNewMuscleGroup(e.target.value)}
                      placeholder="Ex: Peito, Costas, Pernas, Ombros..."
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs"
                    />
                  </div>
                </div>

                {/* Tipo de Treino & Nível */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Modalidade / Tipo
                    </label>
                    <select
                      value={newType}
                      onChange={(e) => setNewType(e.target.value as any)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs cursor-pointer"
                    >
                      <option value="strength">Musculação / Força Hipertrófica</option>
                      <option value="cardio">Cardio / Resistência Aeróbica</option>
                      <option value="mobility">Mobilidade / Alongamento / Yoga</option>
                      <option value="rest">Recuperação Ativa</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Nível de Intensidade
                    </label>
                    <select
                      value={newLevel}
                      onChange={(e) => setNewLevel(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs cursor-pointer"
                    >
                      <option value="Iniciante">Iniciante (Adaptação anatômica)</option>
                      <option value="Intermediário">Intermediário (Cargas médias)</option>
                      <option value="Avançado">Avançado (Cargas progressivas / RPE 8-9)</option>
                      <option value="Alta Intensidade">Alta Intensidade / Hardcore</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Seção 2: Parâmetros de Tempo, Descanso e Energia */}
              <div className="bg-slate-50/70 border border-slate-200/80 rounded-2xl p-4 flex flex-col gap-3.5">
                <span className="font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                  <Timer className="w-3.5 h-3.5 text-slate-600" />
                  2. Parâmetros de Duração, Descanso & Calorias
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Duração Estimada
                    </label>
                    <input
                      type="text"
                      value={newDuration}
                      onChange={(e) => setNewDuration(e.target.value)}
                      placeholder="Ex: 50 min"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Descanso entre Séries
                    </label>
                    <input
                      type="text"
                      value={newRestBetweenSets}
                      onChange={(e) => setNewRestBetweenSets(e.target.value)}
                      placeholder="Ex: 60s ou 90s"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Estimativa de Kcal
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        value={newCalories}
                        onChange={(e) => setNewCalories(e.target.value)}
                        placeholder="350"
                        className="w-full bg-white border border-slate-200 rounded-xl pl-3 pr-10 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs"
                      />
                      <span className="absolute right-3 top-2 text-[10px] text-slate-400 font-bold">
                        kcal
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Aquecimento & Mobilidade Pré-Treino
                  </label>
                  <input
                    type="text"
                    value={newWarmup}
                    onChange={(e) => setNewWarmup(e.target.value)}
                    placeholder="Ex: 5 min esteira leve + rotação de ombros com elástico"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 shadow-2xs"
                  />
                </div>
              </div>

              {/* Seção 3: Lista Detalhada de Exercícios */}
              <div className="bg-slate-50/70 border border-slate-200/80 rounded-2xl p-4 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                    <Layers className="w-3.5 h-3.5 text-slate-600" />
                    3. Lista de Exercícios ({newExercises.length})
                  </span>

                  <button
                    type="button"
                    onClick={handleAddExerciseRow}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg text-[11px] border border-indigo-200/80 cursor-pointer transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                    Adicionar Exercício
                  </button>
                </div>

                <div className="flex flex-col gap-2.5">
                  {newExercises.map((ex, index) => (
                    <div
                      key={ex.id}
                      className="bg-white border border-slate-200/90 rounded-xl p-3 shadow-2xs flex flex-col gap-2 transition-all hover:border-slate-300"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                          #{index + 1}
                        </span>

                        <div className="flex-1">
                          <input
                            type="text"
                            value={ex.name}
                            onChange={(e) => handleUpdateExerciseRow(ex.id, 'name', e.target.value)}
                            placeholder="Nome do Exercício (Ex: Supino Reto)"
                            className="w-full font-semibold text-xs text-slate-800 border-b border-slate-200 pb-1 focus:outline-none focus:border-indigo-600"
                          />
                        </div>

                        {newExercises.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveExerciseRow(ex.id)}
                            className="text-slate-400 hover:text-red-500 p-1 rounded-md transition-colors cursor-pointer"
                            title="Remover exercício"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {/* Campos numéricos do exercício */}
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <label className="text-[10px] text-slate-500 font-medium block">
                            Séries
                          </label>
                          <input
                            type="text"
                            value={ex.sets}
                            onChange={(e) => handleUpdateExerciseRow(ex.id, 'sets', e.target.value)}
                            placeholder="4"
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-[11px] text-slate-800 focus:outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-medium block">
                            Repetições
                          </label>
                          <input
                            type="text"
                            value={ex.reps}
                            onChange={(e) => handleUpdateExerciseRow(ex.id, 'reps', e.target.value)}
                            placeholder="10-12"
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-[11px] text-slate-800 focus:outline-none focus:border-indigo-500"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-medium block">
                            Carga Inicial
                          </label>
                          <input
                            type="text"
                            value={ex.weight}
                            onChange={(e) => handleUpdateExerciseRow(ex.id, 'weight', e.target.value)}
                            placeholder="Ex: 50kg"
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-[11px] text-slate-800 focus:outline-none focus:border-indigo-500"
                          />
                        </div>
                      </div>

                      {/* Campo de notas técnicas do exercício */}
                      <div>
                        <input
                          type="text"
                          value={ex.notes}
                          onChange={(e) => handleUpdateExerciseRow(ex.id, 'notes', e.target.value)}
                          placeholder="Observação técnica (Ex: pausa 1s no ponto zero, cadência lenta...)"
                          className="w-full bg-slate-50 border border-slate-100 rounded-lg px-2.5 py-1 text-[10px] text-slate-600 focus:outline-none focus:border-indigo-400"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Seção 4: Recomendações e Anotações Gerais */}
              <div className="bg-slate-50/70 border border-slate-200/80 rounded-2xl p-4 flex flex-col gap-2">
                <span className="font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                  <Info className="w-3.5 h-3.5 text-slate-600" />
                  4. Recomendações & Anotações Gerais
                </span>
                <textarea
                  rows={2}
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Orientações de hidratação, suplementação pré-treino, cuidados com postura ou metas da sessão..."
                  className="w-full bg-white border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-600 shadow-2xs resize-none"
                />
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-between gap-3 pt-4 border-t border-slate-100 shrink-0">
              <span className="text-[11px] text-slate-400">
                {newExercises.filter((e) => e.name.trim()).length} exercício(s) configurado(s)
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewWorkoutOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-[#6366F1] hover:bg-[#4F46E5] text-white px-5 py-2.5 rounded-xl text-xs font-bold cursor-pointer shadow-md hover:shadow-indigo-500/25 active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Salvar Treino Completo
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
