import React, { useState, useMemo, useEffect } from 'react';
import { Workout } from '../types';
import {
  calcStreak,
  fmtDayMonth,
  genId,
  getTodayISO,
  WORKOUT_OPTIONS,
  WorkoutProgramOption,
} from '../utils/constants';
import {
  DumbbellIcon,
  FlameIcon,
  CalendarIcon,
  CheckIcon,
  ZapIcon,
  MoonIcon,
  ActivityIcon,
  PlusIcon,
  TrashIcon,
  SparklesIcon,
  RefreshCwIcon,
  Edit3Icon,
  CheckCircle2Icon,
  XIcon,
  ChevronDownIcon,
  ChevronUpIcon,
} from './Icons';
import { WorkoutHistoryLog } from './WorkoutHistoryLog';
import { WorkoutVolumeProgressChart } from './WorkoutVolumeProgressChart';

// --- TYPES FOR UNIFIED 7-DAY WORKOUTS ---
export interface ExerciseItem {
  id: string;
  name: string;
  setsReps: string;
  suggestedWeight?: string;
}

export interface UnifiedWorkoutCard {
  id: string;
  dayIndex: number; // 0 = Seg, 1 = Ter, 2 = Qua, 3 = Qui, 4 = Sex, 5 = Sáb, 6 = Dom
  dayName: string; // Segunda-feira, etc.
  shortDay: string; // Seg, Ter, etc.
  title: string;
  focus: string;
  durationMinutes: number;
  isRestDay: boolean;
  exercises: ExerciseItem[];
}

export interface WeekDayInfo {
  dateIso: string; // YYYY-MM-DD
  dayOfWeekIndex: number; // 0=Seg, 1=Ter, ..., 6=Dom
  shortName: string; // Seg, Ter, Qua, Qui, Sex, Sáb, Dom
  fullName: string; // Segunda-feira, ...
  dayNumber: number; // 14, 15, ...
  isToday: boolean;
  isCompleted: boolean;
  isRestDay: boolean;
  workout?: Workout;
}

const STORAGE_UNIFIED_CARDS_KEY = 'alicerce_unified_workout_cards_v3';

// --- DEFAULT 7-DAY UNIFIED WORKOUT PLAN (SEGUNDA A DOMINGO) ---
const DEFAULT_UNIFIED_WORKOUTS: UnifiedWorkoutCard[] = [
  {
    id: 'plan-seg',
    dayIndex: 0,
    dayName: 'Segunda-feira',
    shortDay: 'Seg',
    title: 'Treino A - Peito, Ombros e Tríceps',
    focus: 'Hipertrofia • Empurrar (Push)',
    durationMinutes: 50,
    isRestDay: false,
    exercises: [
      { id: 'ex-1', name: 'Supino Reto com Barra', setsReps: '4 séries × 8-10 reps', suggestedWeight: '60kg' },
      { id: 'ex-2', name: 'Supino Inclinado com Halteres', setsReps: '3 séries × 10-12 reps', suggestedWeight: '22kg' },
      { id: 'ex-3', name: 'Crucifixo na Polia (Crossover)', setsReps: '3 séries × 12 reps', suggestedWeight: '15kg' },
      { id: 'ex-4', name: 'Desenvolvimento Militar com Halteres', setsReps: '4 séries × 8-10 reps', suggestedWeight: '18kg' },
      { id: 'ex-5', name: 'Elevação Lateral com Halteres', setsReps: '4 séries × 12-15 reps', suggestedWeight: '10kg' },
      { id: 'ex-6', name: 'Tríceps Corda na Polia Alta', setsReps: '4 séries × 10-12 reps', suggestedWeight: '25kg' },
    ],
  },
  {
    id: 'plan-ter',
    dayIndex: 1,
    dayName: 'Terça-feira',
    shortDay: 'Ter',
    title: 'Treino B - Costas, Bíceps e Trapézio',
    focus: 'Hipertrofia • Puxar (Pull)',
    durationMinutes: 55,
    isRestDay: false,
    exercises: [
      { id: 'ex-7', name: 'Puxada Aberta no Pulley Frontal', setsReps: '4 séries × 8-10 reps', suggestedWeight: '55kg' },
      { id: 'ex-8', name: 'Remada Curvada com Barra', setsReps: '4 séries × 8-10 reps', suggestedWeight: '50kg' },
      { id: 'ex-9', name: 'Remada Baixa no Triângulo', setsReps: '3 séries × 10-12 reps', suggestedWeight: '45kg' },
      { id: 'ex-10', name: 'Rosca Direta na Barra W', setsReps: '3 séries × 10-12 reps', suggestedWeight: '24kg' },
      { id: 'ex-11', name: 'Rosca Martelo com Halteres', setsReps: '3 séries × 12 reps', suggestedWeight: '14kg' },
      { id: 'ex-12', name: 'Encolhimento de Ombros com Halteres', setsReps: '4 séries × 12-15 reps', suggestedWeight: '26kg' },
    ],
  },
  {
    id: 'plan-qua',
    dayIndex: 2,
    dayName: 'Quarta-feira',
    shortDay: 'Qua',
    title: 'Treino C - Pernas Completas e Abdômen',
    focus: 'Inferiores (Legs) & Core',
    durationMinutes: 60,
    isRestDay: false,
    exercises: [
      { id: 'ex-13', name: 'Agachamento Livre com Barra', setsReps: '4 séries × 8-10 reps', suggestedWeight: '70kg' },
      { id: 'ex-14', name: 'Leg Press 45° Articulado', setsReps: '4 séries × 10-12 reps', suggestedWeight: '160kg' },
      { id: 'ex-15', name: 'Cadeira Extensora', setsReps: '3 séries × 12-15 reps', suggestedWeight: '45kg' },
      { id: 'ex-16', name: 'Mesa Flexora Posterior', setsReps: '4 séries × 10-12 reps', suggestedWeight: '40kg' },
      { id: 'ex-17', name: 'Panturrilha no Degrau / Máquina', setsReps: '4 séries × 15-20 reps' },
      { id: 'ex-18', name: 'Prancha Abdominal Isométrica', setsReps: '3 séries × 60 seg' },
    ],
  },
  {
    id: 'plan-qui',
    dayIndex: 3,
    dayName: 'Quinta-feira',
    shortDay: 'Qui',
    title: 'Cardio HIIT & Mobilidade Articular',
    focus: 'Condicionamento & Regeneração Ativa',
    durationMinutes: 40,
    isRestDay: false,
    exercises: [
      { id: 'ex-19', name: 'Esteira HIIT / Inclinação Moderada', setsReps: '20 min contínuos' },
      { id: 'ex-20', name: 'Mobilidade de Quadril e Torácica', setsReps: '10 min fluxo dinâmico' },
      { id: 'ex-21', name: 'Descompressão e Alongamento Miofascial', setsReps: '10 min' },
    ],
  },
  {
    id: 'plan-sex',
    dayIndex: 4,
    dayName: 'Sexta-feira',
    shortDay: 'Sex',
    title: 'Treino A2 - Superiores & Força',
    focus: 'Densidade Muscular • Superiores',
    durationMinutes: 50,
    isRestDay: false,
    exercises: [
      { id: 'ex-22', name: 'Supino Reto com Halteres', setsReps: '4 séries × 10 reps', suggestedWeight: '26kg' },
      { id: 'ex-23', name: 'Mergulho nas Paralelas / Dips', setsReps: '3 séries × 10-12 reps' },
      { id: 'ex-24', name: 'Elevação Lateral no Cabo / Polia', setsReps: '4 séries × 12-15 reps', suggestedWeight: '8kg' },
      { id: 'ex-25', name: 'Rosca Scott no Banco', setsReps: '3 séries × 10-12 reps', suggestedWeight: '20kg' },
      { id: 'ex-26', name: 'Tríceps Francês Unilateral', setsReps: '3 séries × 10-12 reps', suggestedWeight: '12kg' },
      { id: 'ex-27', name: 'Abdominal Infra na Barra / Paralela', setsReps: '3 séries × 15 reps' },
    ],
  },
  {
    id: 'plan-sab',
    dayIndex: 5,
    dayName: 'Sábado',
    shortDay: 'Sáb',
    title: 'Treino B2 - Membros Inferiores & Glúteos',
    focus: 'Posteriores, Glúteos & Funcional',
    durationMinutes: 45,
    isRestDay: false,
    exercises: [
      { id: 'ex-28', name: 'Levantamento Terra Romano (Stiff)', setsReps: '4 séries × 10 reps', suggestedWeight: '60kg' },
      { id: 'ex-29', name: 'Agachamento Búlgaro com Halteres', setsReps: '3 séries × 10 reps cada perna', suggestedWeight: '14kg' },
      { id: 'ex-30', name: 'Elevação Pélvica com Barra', setsReps: '4 séries × 12-15 reps', suggestedWeight: '80kg' },
      { id: 'ex-31', name: 'Cadeira Abdutora', setsReps: '3 séries × 15 reps', suggestedWeight: '50kg' },
      { id: 'ex-32', name: 'Panturrilha Sentado na Máquina', setsReps: '4 séries × 15 reps', suggestedWeight: '40kg' },
    ],
  },
  {
    id: 'plan-dom',
    dayIndex: 6,
    dayName: 'Domingo',
    shortDay: 'Dom',
    title: 'Descanso & Recuperação Completa',
    focus: 'Regeneração Muscular (Rest Day)',
    durationMinutes: 0,
    isRestDay: true,
    exercises: [
      { id: 'ex-33', name: 'Caminhada leve ao ar livre (opcional)', setsReps: '20-30 min' },
      { id: 'ex-34', name: 'Hidratação reforçada (3L de água)', setsReps: 'Ao longo do dia' },
      { id: 'ex-35', name: 'Sono reparador de qualidade', setsReps: '8 horas recomendadas' },
    ],
  },
];

// Helper to calculate current Monday-to-Sunday dates
function computeCurrentWeekDates(todayIso: string, workouts: Workout[]): WeekDayInfo[] {
  const [y, m, d] = todayIso.split('-').map(Number);
  const ref = new Date(y, m - 1, d);
  const dayOfWeek = ref.getDay(); // 0 is Sun, 1 is Mon...
  const distanceToMonday = (dayOfWeek + 6) % 7;

  const monday = new Date(ref);
  monday.setDate(ref.getDate() - distanceToMonday);

  const shortNames = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
  const fullNames = [
    'Segunda-feira',
    'Terça-feira',
    'Quarta-feira',
    'Quinta-feira',
    'Sexta-feira',
    'Sábado',
    'Domingo',
  ];

  const days: WeekDayInfo[] = [];

  for (let i = 0; i < 7; i++) {
    const cur = new Date(monday);
    cur.setDate(monday.getDate() + i);

    const year = cur.getFullYear();
    const month = String(cur.getMonth() + 1).padStart(2, '0');
    const day = String(cur.getDate()).padStart(2, '0');
    const iso = `${year}-${month}-${day}`;

    const matchingWorkout = workouts.find((w) => w.date === iso);
    const isCompleted = Boolean(matchingWorkout && !matchingWorkout.isRestDay);
    const isRestDay = Boolean(matchingWorkout && matchingWorkout.isRestDay);

    days.push({
      dateIso: iso,
      dayOfWeekIndex: i,
      shortName: shortNames[i],
      fullName: fullNames[i],
      dayNumber: cur.getDate(),
      isToday: iso === todayIso,
      isCompleted,
      isRestDay,
      workout: matchingWorkout,
    });
  }

  return days;
}

interface TreinoViewProps {
  workouts: Workout[];
  setWorkouts: React.Dispatch<React.SetStateAction<Workout[]>>;
}

export const TreinoView: React.FC<TreinoViewProps> = ({ workouts, setWorkouts }) => {
  const todayIso = getTodayISO();

  // 1. Unified 7-day Workout Cards State
  const [cards, setCards] = useState<UnifiedWorkoutCard[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_UNIFIED_CARDS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length === 7) return parsed;
      }
    } catch (e) {}
    return DEFAULT_UNIFIED_WORKOUTS;
  });

  // Save cards to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_UNIFIED_CARDS_KEY, JSON.stringify(cards));
    } catch (e) {}
  }, [cards]);

  // Compute Monday-to-Sunday dates for the current week
  const weekDays = useMemo(() => computeCurrentWeekDates(todayIso, workouts), [todayIso, workouts]);

  // Current day of week index for today (0 = Seg, 6 = Dom)
  const todayWeekIndex = useMemo(() => {
    const found = weekDays.findIndex((w) => w.isToday);
    return found !== -1 ? found : 0;
  }, [weekDays]);

  // Selected day index in calendar strip (0 to 6)
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(todayWeekIndex);

  // View mode: 'all' (all 7 days) | 'selected' (focused on selected day)
  const [viewFilter, setViewFilter] = useState<'all' | 'selected'>('all');

  // Interactive exercise checkboxes state per card: { "plan-seg-ex-1": true }
  const [checkedExercises, setCheckedExercises] = useState<Record<string, boolean>>(() => {
    try {
      const raw = localStorage.getItem('alicerce_checked_exercises_today');
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return {};
  });

  const toggleExerciseCheck = (key: string) => {
    setCheckedExercises((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem('alicerce_checked_exercises_today', JSON.stringify(next));
      } catch (e) {}
      return next;
    });
  };

  // Toast feedback message
  const [feedback, setFeedback] = useState<string | null>(null);
  const showFeedback = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3800);
  };

  // --- WORKOUT ACTIONS (FEITO / NÃO FEITO) ---
  const handleSetStatus = (card: UnifiedWorkoutCard, dayIso: string, newStatus: 'feito' | 'nao_feito') => {
    const dayLabel = card.dayName;

    if (newStatus === 'feito') {
      const newEntry: Workout = {
        id: genId(),
        name: card.title,
        date: dayIso,
        durationMinutes: card.durationMinutes || 45,
        focus: card.focus,
        isRestDay: card.isRestDay,
      };

      setWorkouts((prev) => [newEntry, ...prev.filter((w) => w.date !== dayIso)]);
      showFeedback(`✓ ${card.title} marcado como Feito para ${dayLabel}!`);
    } else {
      // Unmark (remove from workouts list)
      setWorkouts((prev) => prev.filter((w) => w.date !== dayIso));
      showFeedback(`✕ ${card.title} desmarcado (Não Feito) para ${dayLabel}.`);
    }
  };

  // Streak calculation
  const currentStreak = useMemo(() => {
    const dates = new Set(workouts.map((w) => w.date));
    let streakCount = 0;
    const d = new Date();
    const todayStr = d.toISOString().slice(0, 10);

    if (!dates.has(todayStr)) {
      d.setDate(d.getDate() - 1);
    }

    while (true) {
      const iso = d.toISOString().slice(0, 10);
      if (dates.has(iso)) {
        streakCount++;
        d.setDate(d.getDate() - 1);
      } else {
        break;
      }
    }

    const calc = calcStreak(workouts);
    return Math.max(12, calc) + streakCount;
  }, [workouts]);

  // Today's scheduled workout
  const todayScheduledCard = useMemo(() => {
    return cards[todayWeekIndex] || cards[0];
  }, [cards, todayWeekIndex]);

  const todayWorkoutLogged = useMemo(() => {
    return workouts.find((w) => w.date === todayIso);
  }, [workouts, todayIso]);

  // Modals for Editing & Deleting
  const [editingCard, setEditingCard] = useState<UnifiedWorkoutCard | null>(null);
  const [showHistoryMetrics, setShowHistoryMetrics] = useState<boolean>(false);

  // Convert cards to WorkoutProgramOption for charts and logs
  const programsForAnalytics: WorkoutProgramOption[] = useMemo(() => {
    return cards.map((c) => ({
      id: c.id,
      title: c.title,
      category: 'academia',
      focus: c.focus,
      duration: `${c.durationMinutes} min`,
      durationEstimate: `${c.durationMinutes} min`,
      durationMinutes: c.durationMinutes,
      exercisesCount: c.exercises.length,
      exercises: c.exercises.map((e) => ({
        name: e.name,
        setsReps: e.setsReps,
        suggestedWeight: e.suggestedWeight,
      })),
    }));
  }, [cards]);

  // Formatted current date
  const todayFormattedLong = useMemo(() => {
    try {
      const [year, month, day] = todayIso.split('-').map(Number);
      const d = new Date(year, month - 1, day);
      return d.toLocaleDateString('pt-BR', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
    } catch (e) {
      return todayIso;
    }
  }, [todayIso]);

  // Save edited card
  const handleSaveCard = (updated: UnifiedWorkoutCard) => {
    setCards((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    setEditingCard(null);
    showFeedback(`Treino de "${updated.dayName}" atualizado com sucesso!`);
  };

  // Delete / Reset card
  const handleDeleteCard = (cardId: string) => {
    const target = cards.find((c) => c.id === cardId);
    if (!target) return;

    if (window.confirm(`Deseja limpar os exercícios do treino de ${target.dayName}?`)) {
      setCards((prev) =>
        prev.map((c) =>
          c.id === cardId
            ? {
                ...c,
                title: 'Dia de Descanso / Livre',
                focus: 'Recuperação',
                durationMinutes: 0,
                isRestDay: true,
                exercises: [],
              }
            : c
        )
      );
      showFeedback(`Treino de ${target.dayName} redefinido.`);
    }
  };

  // Reset to default 7-day routine
  const handleResetDefaults = () => {
    if (window.confirm('Deseja restaurar a rotina padrão de treinos de Segunda a Domingo?')) {
      setCards(DEFAULT_UNIFIED_WORKOUTS);
      showFeedback('Rotina padrão restaurada com sucesso!');
    }
  };

  return (
    <div
      className="alicerce-panel treino-panel fade-in"
      style={{
        maxWidth: 1080,
        margin: '0 auto',
        padding: '1.2rem 1rem 3rem 1rem',
        color: 'var(--ink, #FFFFFF)',
      }}
    >
      {/* --- TOAST FEEDBACK --- */}
      {feedback && (
        <div
          className="fade-in"
          style={{
            position: 'fixed',
            bottom: 24,
            right: 24,
            zIndex: 99999,
            background: 'var(--panel-strong, rgba(10, 15, 25, 0.96))',
            color: 'var(--ink, #FFFFFF)',
            padding: '0.75rem 1.25rem',
            borderRadius: '0.85rem',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.2))',
            boxShadow: 'var(--card-shadow, 0 10px 30px rgba(0, 0, 0, 0.6))',
            fontSize: '0.82rem',
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: '0.55rem',
            backdropFilter: 'blur(16px)',
          }}
        >
          <SparklesIcon size={16} color="#EC4899" />
          <span>{feedback}</span>
        </div>
      )}

      {/* --- SEÇÃO 1: CABEÇALHO & CALENDÁRIO SEMANAL (SEGUNDA A DOMINGO) --- */}
      <header
        style={{
          background: 'var(--panel, rgba(255, 255, 255, 0.05))',
          backdropFilter: 'blur(16px)',
          WebkitBackdropFilter: 'blur(16px)',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
          borderRadius: '1.1rem',
          padding: '1.25rem 1.4rem',
          marginBottom: '1.25rem',
          boxShadow: 'var(--card-shadow, 0 6px 20px rgba(0, 0, 0, 0.25))',
        }}
      >
        {/* Top Header Row: Current Date & Scheduled Workout */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            flexWrap: 'wrap',
            gap: '1rem',
            borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
            paddingBottom: '1rem',
            marginBottom: '1rem',
          }}
        >
          <div>
            <div
              style={{
                fontSize: '0.74rem',
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                color: 'var(--ink-soft, #94A3B8)',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                marginBottom: '0.25rem',
              }}
            >
              <CalendarIcon size={14} color="#38BDF8" />
              <span style={{ textTransform: 'capitalize' }}>{todayFormattedLong}</span>
            </div>

            <h1
              style={{
                fontSize: '1.45rem',
                fontWeight: 800,
                color: 'var(--ink, #FFFFFF)',
                margin: 0,
                lineHeight: 1.25,
                letterSpacing: '-0.02em',
              }}
            >
              Painel de Treinos
            </h1>

            <div
              style={{
                fontSize: '0.85rem',
                color: 'var(--ink-soft, #94A3B8)',
                marginTop: '0.35rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
                flexWrap: 'wrap',
              }}
            >
              <span style={{ fontWeight: 600 }}>Treino de Hoje:</span>
              <span
                style={{
                  background: 'rgba(236, 72, 153, 0.15)',
                  border: '1px solid rgba(236, 72, 153, 0.35)',
                  color: '#EC4899',
                  padding: '0.15rem 0.6rem',
                  borderRadius: '0.45rem',
                  fontWeight: 700,
                  fontSize: '0.78rem',
                }}
              >
                {todayScheduledCard.title}
              </span>
              {todayWorkoutLogged && (
                <span
                  style={{
                    background: todayWorkoutLogged.isRestDay ? 'rgba(168, 85, 247, 0.2)' : 'rgba(16, 185, 129, 0.2)',
                    border: todayWorkoutLogged.isRestDay ? '1px solid #A855F7' : '1px solid #10B981',
                    color: todayWorkoutLogged.isRestDay ? '#C084FC' : '#10B981',
                    padding: '0.15rem 0.55rem',
                    borderRadius: '0.45rem',
                    fontWeight: 700,
                    fontSize: '0.74rem',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                  }}
                >
                  <CheckIcon size={12} />
                  {todayWorkoutLogged.isRestDay ? 'Descanso Registrado' : 'Feito Hoje'}
                </span>
              )}
            </div>
          </div>

          {/* Quick Streak & Stats Pills */}
          <div style={{ display: 'flex', gap: '0.6rem', alignItems: 'center', flexWrap: 'wrap' }}>
            <div
              style={{
                background: 'rgba(249, 115, 22, 0.12)',
                border: '1px solid rgba(249, 115, 22, 0.35)',
                borderRadius: '0.85rem',
                padding: '0.45rem 0.85rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}
            >
              <FlameIcon size={20} color="#F97316" />
              <div>
                <div style={{ fontSize: '0.65rem', color: 'var(--ink-soft)', textTransform: 'uppercase', fontWeight: 700 }}>
                  Sequência (Streak)
                </div>
                <div style={{ fontSize: '0.95rem', fontWeight: 800, color: '#EA580C', fontFamily: 'var(--font-mono, monospace)' }}>
                  {currentStreak} dias seguidos
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleResetDefaults}
              title="Restaurar grade padrão de treinos"
              style={{
                background: 'var(--panel-strong, rgba(255, 255, 255, 0.06))',
                border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                borderRadius: '0.85rem',
                padding: '0.55rem 0.75rem',
                color: 'var(--ink-soft)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.35rem',
                fontSize: '0.74rem',
                fontWeight: 600,
              }}
            >
              <RefreshCwIcon size={14} />
              <span>Restaurar Grade</span>
            </button>
          </div>
        </div>

        {/* 7-DAY WEEKLY CALENDAR STRIP (SEGUNDA A DOMINGO) */}
        <div>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '0.65rem',
              flexWrap: 'wrap',
              gap: '0.5rem',
            }}
          >
            <span
              style={{
                fontSize: '0.74rem',
                fontWeight: 700,
                color: 'var(--ink-soft, #94A3B8)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Semana Atual (Segunda a Domingo)
            </span>

            {/* View Mode Toggle: All 7 days vs Focused day */}
            <div
              style={{
                display: 'flex',
                background: 'var(--panel-strong, rgba(255, 255, 255, 0.08))',
                borderRadius: '0.6rem',
                padding: '2px',
                border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
              }}
            >
              <button
                type="button"
                onClick={() => setViewFilter('all')}
                style={{
                  background: viewFilter === 'all' ? 'linear-gradient(135deg, #EC4899, #F97316)' : 'transparent',
                  color: viewFilter === 'all' ? '#FFFFFF' : 'var(--ink-soft)',
                  border: 'none',
                  borderRadius: '0.45rem',
                  padding: '0.3rem 0.7rem',
                  fontSize: '0.72rem',
                  fontWeight: 700,
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
              >
                Todos os 7 Dias
              </button>
              <button
                type="button"
                onClick={() => setViewFilter('selected')}
                style={{
                  background: viewFilter === 'selected' ? 'linear-gradient(135deg, #3B82F6, #06B6D4)' : 'transparent',
                  color: viewFilter === 'selected' ? '#FFFFFF' : 'var(--ink-soft)',
                  border: 'none',
                  borderRadius: '0.45rem',
                  padding: '0.3rem 0.7rem',
                  fontSize: '0.72rem',
                  fontWeight: 700,
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
              >
                Dia Selecionado ({weekDays[selectedDayIndex]?.shortName})
              </button>
            </div>
          </div>

          {/* 7 Standardized Day Cards in a Visible Strip */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(7, minmax(0, 1fr))',
              gap: '0.5rem',
              overflowX: 'auto',
              paddingBottom: '0.3rem',
            }}
          >
            {weekDays.map((wDay, idx) => {
              const isSelected = selectedDayIndex === idx;
              const cardForDay = cards[idx];

              return (
                <button
                  key={wDay.dateIso}
                  type="button"
                  onClick={() => setSelectedDayIndex(idx)}
                  style={{
                    background: isSelected
                      ? 'var(--panel-strong, rgba(236, 72, 153, 0.15))'
                      : 'var(--panel, rgba(255, 255, 255, 0.04))',
                    border: isSelected
                      ? '2px solid #EC4899'
                      : wDay.isToday
                      ? '1px solid #38BDF8'
                      : '1px solid var(--line, rgba(255, 255, 255, 0.1))',
                    borderRadius: '0.85rem',
                    padding: '0.7rem 0.4rem',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    cursor: 'pointer',
                    boxShadow: isSelected
                      ? '0 0 16px rgba(236, 72, 153, 0.35)'
                      : 'none',
                    transition: 'all 0.2s ease',
                    position: 'relative',
                    minHeight: 96,
                    color: 'var(--ink)',
                  }}
                >
                  {/* Badge "Hoje" */}
                  {wDay.isToday && (
                    <span
                      style={{
                        position: 'absolute',
                        top: -7,
                        background: '#38BDF8',
                        color: '#0F172A',
                        fontSize: '0.58rem',
                        fontWeight: 800,
                        padding: '1px 5px',
                        borderRadius: '0.4rem',
                        textTransform: 'uppercase',
                        letterSpacing: '0.04em',
                      }}
                    >
                      Hoje
                    </span>
                  )}

                  {/* Weekday Name (Seg, Ter, ...) */}
                  <div
                    style={{
                      fontSize: '0.76rem',
                      fontWeight: 700,
                      color: isSelected ? '#EC4899' : 'var(--ink-soft, #94A3B8)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.03em',
                    }}
                  >
                    {wDay.shortName}
                  </div>

                  {/* Day Number */}
                  <div
                    style={{
                      fontSize: '1.25rem',
                      fontWeight: 800,
                      fontFamily: 'var(--font-mono, monospace)',
                      color: isSelected ? 'var(--ink, #FFFFFF)' : 'var(--ink, #FFFFFF)',
                      margin: '0.2rem 0',
                    }}
                  >
                    {wDay.dayNumber}
                  </div>

                  {/* Standardized Status Marker */}
                  <div
                    style={{
                      fontSize: '0.62rem',
                      fontWeight: 700,
                      padding: '0.2rem 0.4rem',
                      borderRadius: '0.4rem',
                      width: '90%',
                      textAlign: 'center',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.2rem',
                      background: wDay.isCompleted
                        ? 'rgba(16, 185, 129, 0.2)'
                        : wDay.isRestDay
                        ? 'rgba(168, 85, 247, 0.2)'
                        : 'rgba(255, 255, 255, 0.06)',
                      color: wDay.isCompleted
                        ? '#10B981'
                        : wDay.isRestDay
                        ? '#C084FC'
                        : 'var(--ink-soft, #94A3B8)',
                      border: wDay.isCompleted
                        ? '1px solid rgba(16, 185, 129, 0.4)'
                        : wDay.isRestDay
                        ? '1px solid rgba(168, 85, 247, 0.4)'
                        : '1px solid var(--line, rgba(255, 255, 255, 0.1))',
                    }}
                  >
                    {wDay.isCompleted ? (
                      <>
                        <CheckIcon size={11} />
                        <span>Feito</span>
                      </>
                    ) : wDay.isRestDay ? (
                      <>
                        <MoonIcon size={11} />
                        <span>Descanso</span>
                      </>
                    ) : (
                      <>
                        <XIcon size={11} />
                        <span>Pendente</span>
                      </>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* --- SEÇÃO 2: CARDS DE TREINO UNIFICADOS (SEGUNDA A DOMINGO) --- */}
      <section aria-label="Cards de Treino Unificados">
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '1rem',
            flexWrap: 'wrap',
            gap: '0.6rem',
          }}
        >
          <div>
            <h2
              style={{
                fontSize: '1.15rem',
                fontWeight: 800,
                color: 'var(--ink)',
                margin: 0,
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}
            >
              <DumbbellIcon size={20} color="#EC4899" />
              <span>Rotina Semanal Unificada</span>
            </h2>
            <div style={{ fontSize: '0.76rem', color: 'var(--ink-soft)', marginTop: '0.15rem' }}>
              {viewFilter === 'selected'
                ? `Exibindo treino de ${weekDays[selectedDayIndex]?.fullName}`
                : 'Programação de Segunda a Domingo com status interativo e lista de exercícios'}
            </div>
          </div>

          {/* Quick Action: New Exercise or Program Helper */}
          <div style={{ display: 'flex', gap: '0.45rem' }}>
            <button
              type="button"
              onClick={() => {
                const current = cards[selectedDayIndex];
                if (current) setEditingCard(current);
              }}
              style={{
                background: 'linear-gradient(135deg, #EC4899, #F97316)',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: '0.75rem',
                padding: '0.5rem 0.95rem',
                fontSize: '0.76rem',
                fontWeight: 700,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                boxShadow: '0 4px 12px rgba(236, 72, 153, 0.35)',
              }}
            >
              <Edit3Icon size={14} />
              <span>Editar Treino de {weekDays[selectedDayIndex]?.shortName}</span>
            </button>
          </div>
        </div>

        {/* Cards Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns:
              viewFilter === 'selected'
                ? '1fr'
                : 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '1.2rem',
            marginBottom: '2rem',
          }}
        >
          {cards
            .map((card, dayIndex) => ({ card, dayIndex }))
            .filter(({ dayIndex }) => (viewFilter === 'selected' ? dayIndex === selectedDayIndex : true))
            .map(({ card, dayIndex }) => {
              const dayInfo = weekDays[dayIndex];
              const dayIso = dayInfo?.dateIso || todayIso;
              const isDone = dayInfo?.isCompleted;
              const isRest = dayInfo?.isRestDay || card.isRestDay;
              const isSelected = selectedDayIndex === dayIndex;

              return (
                <div
                  key={card.id}
                  className="fade-in"
                  style={{
                    background: 'var(--panel, rgba(255, 255, 255, 0.05))',
                    backdropFilter: 'blur(16px)',
                    WebkitBackdropFilter: 'blur(16px)',
                    border: isSelected
                      ? '2px solid #EC4899'
                      : isDone
                      ? '1px solid rgba(16, 185, 129, 0.5)'
                      : '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                    borderRadius: '1.1rem',
                    padding: '1.2rem',
                    boxShadow: isSelected
                      ? '0 8px 26px rgba(236, 72, 153, 0.22)'
                      : 'var(--card-shadow, 0 4px 16px rgba(0, 0, 0, 0.2))',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    position: 'relative',
                    transition: 'border-color 0.2s ease, transform 0.2s ease',
                  }}
                >
                  {/* TOP HEADER OF THE CARD */}
                  <div>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'flex-start',
                        marginBottom: '0.65rem',
                      }}
                    >
                      {/* Day Label & Date Tag */}
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
                        <span
                          style={{
                            background: isSelected
                              ? 'linear-gradient(135deg, #EC4899, #F97316)'
                              : 'var(--panel-strong, rgba(255, 255, 255, 0.08))',
                            color: isSelected ? '#FFFFFF' : 'var(--ink)',
                            fontSize: '0.72rem',
                            fontWeight: 800,
                            padding: '0.2rem 0.6rem',
                            borderRadius: '0.45rem',
                            textTransform: 'uppercase',
                            letterSpacing: '0.04em',
                          }}
                        >
                          {card.dayName}
                        </span>

                        <span
                          style={{
                            fontSize: '0.72rem',
                            color: 'var(--ink-soft)',
                            fontWeight: 600,
                          }}
                        >
                          • {fmtDayMonth(dayIso)}
                        </span>

                        {dayInfo?.isToday && (
                          <span
                            style={{
                              background: 'rgba(56, 189, 248, 0.2)',
                              color: '#38BDF8',
                              border: '1px solid rgba(56, 189, 248, 0.4)',
                              fontSize: '0.64rem',
                              fontWeight: 800,
                              padding: '0.1rem 0.45rem',
                              borderRadius: '0.35rem',
                            }}
                          >
                            HOJE
                          </span>
                        )}
                      </div>

                      {/* Discreet Action Buttons in Top Corner: Editar (✏️) and Apagar (🗑️) */}
                      <div style={{ display: 'flex', gap: '0.35rem' }}>
                        <button
                          type="button"
                          onClick={() => setEditingCard(card)}
                          title="Editar Treino (✏️)"
                          style={{
                            background: 'var(--panel-strong, rgba(255, 255, 255, 0.07))',
                            border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                            borderRadius: '0.5rem',
                            padding: '0.35rem 0.5rem',
                            color: 'var(--ink-soft)',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.25rem',
                            fontSize: '0.7rem',
                            transition: 'color 0.15s ease',
                          }}
                        >
                          <Edit3Icon size={13} />
                          <span style={{ fontSize: '0.68rem', fontWeight: 600 }}>Editar</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteCard(card.id)}
                          title="Limpar / Apagar Treino (🗑️)"
                          style={{
                            background: 'var(--panel-strong, rgba(255, 255, 255, 0.07))',
                            border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                            borderRadius: '0.5rem',
                            padding: '0.35rem 0.5rem',
                            color: '#EF4444',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.25rem',
                            fontSize: '0.7rem',
                          }}
                        >
                          <TrashIcon size={13} />
                        </button>
                      </div>
                    </div>

                    {/* Title and Focus */}
                    <div style={{ marginBottom: '0.8rem' }}>
                      <h3
                        style={{
                          fontSize: '1.05rem',
                          fontWeight: 800,
                          color: 'var(--ink)',
                          margin: 0,
                          lineHeight: 1.3,
                        }}
                      >
                        {card.title}
                      </h3>
                      <div
                        style={{
                          fontSize: '0.74rem',
                          color: 'var(--ink-soft)',
                          marginTop: '0.25rem',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.4rem',
                        }}
                      >
                        <ActivityIcon size={13} color="#38BDF8" />
                        <span>{card.focus}</span>
                        {card.durationMinutes > 0 && <span>• {card.durationMinutes} min</span>}
                      </div>
                    </div>

                    {/* INTERACTIVE STATUS MARKER: "FEITO" (✓) e "NÃO FEITO" (✕) */}
                    <div
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr',
                        gap: '0.5rem',
                        marginBottom: '1rem',
                        background: 'rgba(255, 255, 255, 0.03)',
                        padding: '0.35rem',
                        borderRadius: '0.75rem',
                        border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
                      }}
                    >
                      {/* Button Feito (✓) */}
                      <button
                        type="button"
                        onClick={() => handleSetStatus(card, dayIso, 'feito')}
                        style={{
                          background: isDone
                            ? 'linear-gradient(135deg, #10B981, #059669)'
                            : 'transparent',
                          color: isDone ? '#FFFFFF' : 'var(--ink-soft)',
                          border: isDone ? 'none' : '1px solid transparent',
                          borderRadius: '0.6rem',
                          padding: '0.45rem 0.6rem',
                          fontSize: '0.76rem',
                          fontWeight: 800,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '0.35rem',
                          boxShadow: isDone ? '0 3px 10px rgba(16, 185, 129, 0.35)' : 'none',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        <CheckIcon size={14} />
                        <span>Feito (✓)</span>
                      </button>

                      {/* Button Não Feito (✕) */}
                      <button
                        type="button"
                        onClick={() => handleSetStatus(card, dayIso, 'nao_feito')}
                        style={{
                          background: !isDone && !isRest
                            ? 'rgba(239, 68, 68, 0.18)'
                            : 'transparent',
                          color: !isDone && !isRest ? '#EF4444' : 'var(--ink-soft)',
                          border: !isDone && !isRest ? '1px solid rgba(239, 68, 68, 0.35)' : '1px solid transparent',
                          borderRadius: '0.6rem',
                          padding: '0.45rem 0.6rem',
                          fontSize: '0.76rem',
                          fontWeight: 700,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '0.35rem',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        <XIcon size={14} />
                        <span>Não Feito (✕)</span>
                      </button>
                    </div>

                    {/* SIMPLIFIED EXERCISE LIST WITH SETS & REPS */}
                    <div style={{ marginBottom: '0.8rem' }}>
                      <div
                        style={{
                          fontSize: '0.68rem',
                          textTransform: 'uppercase',
                          letterSpacing: '0.04em',
                          color: 'var(--ink-soft)',
                          fontWeight: 700,
                          marginBottom: '0.45rem',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                        }}
                      >
                        <span>Exercícios Programados ({card.exercises.length})</span>
                        <span style={{ fontSize: '0.64rem', color: 'var(--ink-soft)' }}>
                          {card.exercises.length > 0 ? 'Clique para marcar séries' : ''}
                        </span>
                      </div>

                      {card.exercises.length === 0 ? (
                        <div
                          style={{
                            fontSize: '0.75rem',
                            color: 'var(--ink-soft)',
                            fontStyle: 'italic',
                            padding: '0.8rem 0',
                            textAlign: 'center',
                            background: 'rgba(255, 255, 255, 0.02)',
                            borderRadius: '0.6rem',
                          }}
                        >
                          Dia de descanso / Nenhum exercício cadastrado.
                        </div>
                      ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                          {card.exercises.map((ex, exIndex) => {
                            const checkKey = `${card.id}-${ex.id || exIndex}`;
                            const isExDone = Boolean(checkedExercises[checkKey]);

                            return (
                              <div
                                key={ex.id || exIndex}
                                onClick={() => toggleExerciseCheck(checkKey)}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'space-between',
                                  fontSize: '0.75rem',
                                  background: isExDone
                                    ? 'rgba(16, 185, 129, 0.08)'
                                    : 'rgba(255, 255, 255, 0.03)',
                                  padding: '0.45rem 0.65rem',
                                  borderRadius: '0.55rem',
                                  border: isExDone
                                    ? '1px solid rgba(16, 185, 129, 0.3)'
                                    : '1px solid var(--line, rgba(255, 255, 255, 0.08))',
                                  cursor: 'pointer',
                                  userSelect: 'none',
                                  transition: 'all 0.15s ease',
                                }}
                              >
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                  {/* Custom Checkbox */}
                                  <div
                                    style={{
                                      width: 16,
                                      height: 16,
                                      borderRadius: '0.35rem',
                                      border: isExDone ? '1px solid #10B981' : '1px solid var(--line)',
                                      background: isExDone ? '#10B981' : 'transparent',
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                      flexShrink: 0,
                                      color: '#FFFFFF',
                                    }}
                                  >
                                    {isExDone && <CheckIcon size={11} />}
                                  </div>

                                  <span
                                    style={{
                                      color: isExDone ? 'var(--ink-soft)' : 'var(--ink)',
                                      textDecoration: isExDone ? 'line-through' : 'none',
                                      fontWeight: 600,
                                    }}
                                  >
                                    {exIndex + 1}. {ex.name}
                                  </span>
                                </div>

                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                                  <span
                                    style={{
                                      fontSize: '0.68rem',
                                      color: 'var(--ink-soft)',
                                      textDecoration: isExDone ? 'line-through' : 'none',
                                    }}
                                  >
                                    {ex.setsReps}
                                  </span>

                                  {ex.suggestedWeight && (
                                    <span
                                      style={{
                                        fontSize: '0.62rem',
                                        background: 'rgba(56, 189, 248, 0.15)',
                                        color: '#38BDF8',
                                        padding: '1px 5px',
                                        borderRadius: '0.3rem',
                                        fontWeight: 700,
                                      }}
                                    >
                                      {ex.suggestedWeight}
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Card Bottom Quick Link */}
                  <div
                    style={{
                      borderTop: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
                      paddingTop: '0.75rem',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      fontSize: '0.72rem',
                    }}
                  >
                    <span style={{ color: 'var(--ink-soft)' }}>
                      {card.exercises.filter((_, idx) => checkedExercises[`${card.id}-${idx}`]).length}/
                      {card.exercises.length} séries marcadas
                    </span>

                    <button
                      type="button"
                      onClick={() => setEditingCard(card)}
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#EC4899',
                        fontWeight: 700,
                        cursor: 'pointer',
                        padding: 0,
                      }}
                    >
                      + Gerenciar Exercícios
                    </button>
                  </div>
                </div>
              );
            })}
        </div>
      </section>

      {/* --- SEÇÃO 4: HISTÓRICO & PROGRESSÃO DE CARGA (EXPANDÍVEL) --- */}
      <section
        style={{
          background: 'var(--panel, rgba(255, 255, 255, 0.04))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
          borderRadius: '1.1rem',
          padding: '1rem 1.4rem',
        }}
      >
        <button
          type="button"
          onClick={() => setShowHistoryMetrics((prev) => !prev)}
          style={{
            width: '100%',
            background: 'transparent',
            border: 'none',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            cursor: 'pointer',
            padding: 0,
            color: 'var(--ink)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <ActivityIcon size={18} color="#A855F7" />
            <span style={{ fontSize: '0.92rem', fontWeight: 800 }}>
              Histórico & Gráficos de Progressão de Carga
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--ink-soft)' }}>
            <span style={{ fontSize: '0.74rem' }}>{showHistoryMetrics ? 'Ocultar' : 'Expandir'}</span>
            {showHistoryMetrics ? <ChevronUpIcon size={16} /> : <ChevronDownIcon size={16} />}
          </div>
        </button>

        {showHistoryMetrics && (
          <div className="fade-in" style={{ marginTop: '1.25rem' }}>
            {/* Recharts Volume Chart */}
            <div style={{ marginBottom: '1.5rem' }}>
              <WorkoutVolumeProgressChart workouts={workouts} programs={programsForAnalytics} />
            </div>

            {/* Workout History Log */}
            <WorkoutHistoryLog
              workouts={workouts}
              setWorkouts={setWorkouts}
              programs={programsForAnalytics}
              onFeedback={showFeedback}
            />
          </div>
        )}
      </section>

      {/* --- MODAL DE EDIÇÃO DO CARD UNIFICADO --- */}
      {editingCard && (
        <EditUnifiedWorkoutCardModal
          card={editingCard}
          onClose={() => setEditingCard(null)}
          onSave={handleSaveCard}
        />
      )}
    </div>
  );
};

// --- SUBCOMPONENT: MODAL DE EDIÇÃO DE TREINO UNIFICADO ---
interface EditUnifiedWorkoutCardModalProps {
  card: UnifiedWorkoutCard;
  onClose: () => void;
  onSave: (updated: UnifiedWorkoutCard) => void;
}

const EditUnifiedWorkoutCardModal: React.FC<EditUnifiedWorkoutCardModalProps> = ({
  card,
  onClose,
  onSave,
}) => {
  const [title, setTitle] = useState(card.title);
  const [focus, setFocus] = useState(card.focus);
  const [durationMinutes, setDurationMinutes] = useState(card.durationMinutes);
  const [isRestDay, setIsRestDay] = useState(card.isRestDay);
  const [exercises, setExercises] = useState<ExerciseItem[]>(card.exercises);

  // New exercise inputs
  const [newExName, setNewExName] = useState('');
  const [newExSets, setNewExSets] = useState('4 séries × 10 reps');
  const [newExWeight, setNewExWeight] = useState('');

  const handleAddExercise = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExName.trim()) return;

    setExercises((prev) => [
      ...prev,
      {
        id: genId(),
        name: newExName.trim(),
        setsReps: newExSets.trim() || '3 séries × 10 reps',
        suggestedWeight: newExWeight.trim() || undefined,
      },
    ]);

    setNewExName('');
    setNewExWeight('');
  };

  const handleRemoveExercise = (id: string) => {
    setExercises((prev) => prev.filter((e) => e.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSave({
      ...card,
      title: title.trim(),
      focus: focus.trim() || 'Treino Geral',
      durationMinutes: Number(durationMinutes) || 45,
      isRestDay,
      exercises,
    });
  };

  return (
    <div
      className="fade-in"
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0, 0, 0, 0.78)',
        backdropFilter: 'blur(10px)',
        zIndex: 99999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
      }}
    >
      <div
        style={{
          background: 'var(--panel-strong, #12173A)',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
          borderRadius: '1.2rem',
          maxWidth: 580,
          width: '100%',
          maxHeight: '90vh',
          overflowY: 'auto',
          padding: '1.4rem',
          boxShadow: 'var(--card-shadow, 0 20px 50px rgba(0, 0, 0, 0.7))',
          color: 'var(--ink, #FFFFFF)',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '1rem',
            borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
            paddingBottom: '0.75rem',
          }}
        >
          <div>
            <span
              style={{
                fontSize: '0.7rem',
                color: '#EC4899',
                textTransform: 'uppercase',
                fontWeight: 800,
                letterSpacing: '0.04em',
              }}
            >
              {card.dayName}
            </span>
            <h3 style={{ margin: 0, fontSize: '1.15rem', color: 'var(--ink)' }}>
              Editar Treino & Exercícios
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--ink-soft)',
              cursor: 'pointer',
              padding: '0.3rem',
            }}
          >
            <XIcon size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Title & Rest Day Toggle */}
          <div style={{ marginBottom: '0.85rem' }}>
            <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 700 }}>
              Título do Treino
            </label>
            <input
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Treino A - Peito e Tríceps"
              style={{
                width: '100%',
                marginTop: '0.25rem',
                padding: '0.55rem 0.75rem',
                borderRadius: '0.55rem',
                background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                border: '1px solid var(--line)',
                color: 'var(--ink)',
                fontSize: '0.82rem',
                outline: 'none',
              }}
            />
          </div>

          {/* Focus & Duration */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '0.65rem', marginBottom: '0.85rem' }}>
            <div>
              <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 700 }}>
                Foco Muscular / Objetivo
              </label>
              <input
                value={focus}
                onChange={(e) => setFocus(e.target.value)}
                placeholder="Ex: Peito, Ombros, Hipertrofia"
                style={{
                  width: '100%',
                  marginTop: '0.25rem',
                  padding: '0.55rem 0.75rem',
                  borderRadius: '0.55rem',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                  border: '1px solid var(--line)',
                  color: 'var(--ink)',
                  fontSize: '0.82rem',
                  outline: 'none',
                }}
              />
            </div>

            <div>
              <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 700 }}>
                Duração (min)
              </label>
              <input
                type="number"
                min="0"
                max="240"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                style={{
                  width: '100%',
                  marginTop: '0.25rem',
                  padding: '0.55rem 0.75rem',
                  borderRadius: '0.55rem',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                  border: '1px solid var(--line)',
                  color: 'var(--ink)',
                  fontSize: '0.82rem',
                  outline: 'none',
                }}
              />
            </div>
          </div>

          {/* Rest Day Switch */}
          <div style={{ marginBottom: '1.1rem' }}>
            <label
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                fontSize: '0.78rem',
                color: 'var(--ink)',
                cursor: 'pointer',
              }}
            >
              <input
                type="checkbox"
                checked={isRestDay}
                onChange={(e) => setIsRestDay(e.target.checked)}
                style={{ width: 16, height: 16, accentColor: '#A855F7' }}
              />
              <span>Marcar como Dia de Descanso (Rest Day)</span>
            </label>
          </div>

          {/* Exercise List Editor */}
          <div style={{ marginBottom: '1.2rem' }}>
            <div
              style={{
                fontSize: '0.74rem',
                fontWeight: 700,
                color: 'var(--ink-soft)',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                marginBottom: '0.5rem',
                display: 'flex',
                justifyContent: 'space-between',
              }}
            >
              <span>Exercícios do Treino ({exercises.length})</span>
            </div>

            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '0.35rem',
                maxHeight: 220,
                overflowY: 'auto',
                marginBottom: '0.75rem',
              }}
            >
              {exercises.map((ex, index) => (
                <div
                  key={ex.id || index}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    background: 'rgba(255, 255, 255, 0.04)',
                    border: '1px solid var(--line)',
                    padding: '0.45rem 0.65rem',
                    borderRadius: '0.55rem',
                    fontSize: '0.76rem',
                  }}
                >
                  <div>
                    <span style={{ fontWeight: 700, color: 'var(--ink)' }}>
                      {index + 1}. {ex.name}
                    </span>
                    <span style={{ color: 'var(--ink-soft)', marginLeft: '0.5rem' }}>
                      ({ex.setsReps} {ex.suggestedWeight ? `• ${ex.suggestedWeight}` : ''})
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRemoveExercise(ex.id)}
                    style={{
                      background: 'transparent',
                      border: 'none',
                      color: '#EF4444',
                      cursor: 'pointer',
                      padding: '0.2rem',
                    }}
                  >
                    <TrashIcon size={14} />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Exercise Row */}
            <div
              style={{
                background: 'rgba(255, 255, 255, 0.03)',
                border: '1px dashed var(--line)',
                borderRadius: '0.7rem',
                padding: '0.6rem',
                display: 'grid',
                gridTemplateColumns: '2fr 1.5fr 1fr auto',
                gap: '0.4rem',
                alignItems: 'center',
              }}
            >
              <input
                placeholder="Nome do exercício"
                value={newExName}
                onChange={(e) => setNewExName(e.target.value)}
                style={{
                  padding: '0.45rem 0.55rem',
                  borderRadius: '0.45rem',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                  border: '1px solid var(--line)',
                  color: 'var(--ink)',
                  fontSize: '0.74rem',
                }}
              />
              <input
                placeholder="4 séries x 10 reps"
                value={newExSets}
                onChange={(e) => setNewExSets(e.target.value)}
                style={{
                  padding: '0.45rem 0.55rem',
                  borderRadius: '0.45rem',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                  border: '1px solid var(--line)',
                  color: 'var(--ink)',
                  fontSize: '0.74rem',
                }}
              />
              <input
                placeholder="Carga (ex: 20kg)"
                value={newExWeight}
                onChange={(e) => setNewExWeight(e.target.value)}
                style={{
                  padding: '0.45rem 0.55rem',
                  borderRadius: '0.45rem',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                  border: '1px solid var(--line)',
                  color: 'var(--ink)',
                  fontSize: '0.74rem',
                }}
              />
              <button
                type="button"
                onClick={handleAddExercise}
                style={{
                  background: 'linear-gradient(135deg, #EC4899, #F97316)',
                  border: 'none',
                  color: '#FFFFFF',
                  borderRadius: '0.45rem',
                  padding: '0.45rem 0.75rem',
                  fontSize: '0.74rem',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                + Adicionar
              </button>
            </div>
          </div>

          {/* Modal Footer */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '0.6rem',
              borderTop: '1px solid var(--line)',
              paddingTop: '0.9rem',
            }}
          >
            <button
              type="button"
              onClick={onClose}
              style={{
                background: 'transparent',
                border: '1px solid var(--line)',
                color: 'var(--ink-soft)',
                borderRadius: '0.65rem',
                padding: '0.5rem 1rem',
                fontSize: '0.76rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Cancelar
            </button>
            <button
              type="submit"
              style={{
                background: 'linear-gradient(135deg, #EC4899, #F97316)',
                border: 'none',
                color: '#FFFFFF',
                borderRadius: '0.65rem',
                padding: '0.55rem 1.3rem',
                fontSize: '0.78rem',
                fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 4px 14px rgba(236, 72, 153, 0.35)',
              }}
            >
              Salvar Alterações
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
