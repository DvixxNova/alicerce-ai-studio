import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Lock,
  Mail,
  User,
  Eye,
  EyeOff,
  LogIn,
  UserPlus,
  LogOut,
  ShieldCheck,
  Zap,
  Check,
  Flame,
  Smile,
  Target,
} from 'lucide-react';
import { UserProfile } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onLoginSuccess: (profile: UserProfile) => void;
  onLogout: () => void;
}

const PLAYFUL_AVATARS = [
  { id: 'rocket', emoji: '🚀', name: 'Explorador', tag: 'Rumo ao Topo', gradient: 'linear-gradient(135deg, #38BDF8, #818CF8)' },
  { id: 'lion', emoji: '🦁', name: 'Leão Focado', tag: 'Rei da Disciplina', gradient: 'linear-gradient(135deg, #F59E0B, #EF4444)' },
  { id: 'flash', emoji: '⚡', name: '220 Volts', tag: 'Produtividade Pura', gradient: 'linear-gradient(135deg, #FBBF24, #10B981)' },
  { id: 'zen', emoji: '🧘', name: 'Mente Zen', tag: 'Paz & Constância', gradient: 'linear-gradient(135deg, #10B981, #06B6D4)' },
  { id: 'cyborg', emoji: '🦾', name: 'Modo Cyborg', tag: 'Shape Blindado', gradient: 'linear-gradient(135deg, #EC4899, #8B5CF6)' },
  { id: 'diamond', emoji: '💎', name: 'Investidor Alfa', tag: 'Foco no Futuro', gradient: 'linear-gradient(135deg, #6366F1, #3B82F6)' },
  { id: 'coffee', emoji: '☕', name: 'Café & Ação', tag: 'Sem Enrolação', gradient: 'linear-gradient(135deg, #D97706, #78350F)' },
  { id: 'ninja', emoji: '🥷', name: 'Ninja da Rotina', tag: 'Execução Silenciosa', gradient: 'linear-gradient(135deg, #475569, #0F172A)' },
];

const MAIN_GOALS = [
  'Hipertrofia & Rendimento Físico',
  'Saúde Financeira & Investimentos',
  'Qualidade de Vida & Longevidade',
  'Equilíbrio, Foco & Produtividade',
  'Constância Espiritual & Propósito',
];

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onLoginSuccess,
  onLogout,
}) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(PLAYFUL_AVATARS[0]);
  const [selectedGoal, setSelectedGoal] = useState(MAIN_GOALS[0]);
  const [errorMessage, setErrorMessage] = useState('');
  const [successAnimation, setSuccessAnimation] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Pre-fill email or name if already exists
  useEffect(() => {
    if (isOpen) {
      if (userProfile.email) setLoginEmail(userProfile.email);
      setErrorMessage('');
      setSuccessAnimation(false);
    }
  }, [isOpen, userProfile]);

  if (!isOpen) return null;

  const handleQuickDemoLogin = () => {
    setSuccessAnimation(true);
    setTimeout(() => {
      const demoUser: UserProfile = {
        name: 'Convidado VIP',
        email: 'vip@alicerce.app',
        mainGoal: 'Equilíbrio, Foco & Produtividade',
        avatarUrl: '',
        avatarEmoji: '🚀',
        customStatus: 'Acesso VIP Ativado',
        isLoggedIn: true,
      };
      onLoginSuccess(demoUser);
      setSuccessAnimation(false);
      onClose();
    }, 450);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim()) {
      setErrorMessage('Digite seu nome de usuário ou e-mail.');
      return;
    }

    setSuccessAnimation(true);
    setTimeout(() => {
      // Find suitable avatar if user already has one
      const existingEmoji = userProfile.avatarEmoji || '⚡';
      const cleanName = loginEmail.includes('@')
        ? loginEmail.split('@')[0].replace('.', ' ')
        : loginEmail;
      const formattedName =
        cleanName.charAt(0).toUpperCase() + cleanName.slice(1);

      const loggedUser: UserProfile = {
        ...userProfile,
        name: userProfile.name || formattedName,
        email: loginEmail,
        avatarEmoji: existingEmoji,
        isLoggedIn: true,
        customStatus: 'Foco Ativado',
      };
      onLoginSuccess(loggedUser);
      setSuccessAnimation(false);
      onClose();
    }, 400);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim()) {
      setErrorMessage('Por favor, informe como quer ser chamado(a).');
      return;
    }

    setSuccessAnimation(true);
    setTimeout(() => {
      const newUser: UserProfile = {
        name: regName.trim(),
        email: regEmail.trim() || `${regName.toLowerCase().replace(/\s+/g, '')}@alicerce.app`,
        mainGoal: selectedGoal,
        avatarUrl: '',
        avatarEmoji: selectedAvatar.emoji,
        customStatus: selectedAvatar.tag,
        isLoggedIn: true,
      };
      onLoginSuccess(newUser);
      setSuccessAnimation(false);
      onClose();
    }, 400);
  };

  const handleDoLogout = () => {
    onLogout();
    onClose();
  };

  const currentAvatarConfig =
    PLAYFUL_AVATARS.find((a) => a.emoji === userProfile.avatarEmoji) ||
    PLAYFUL_AVATARS[0];

  return (
    <div
      className="login-modal-backdrop"
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        background: 'rgba(0, 0, 0, 0.75)',
        backdropFilter: 'blur(18px)',
        WebkitBackdropFilter: 'blur(18px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        animation: 'fadeIn 0.2s ease',
      }}
    >
      <div
        className="login-modal-card"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '460px',
          maxHeight: '92vh',
          background: 'var(--panel-strong)',
          border: '1px solid var(--line)',
          borderRadius: '1.4rem',
          boxShadow: '0 25px 60px rgba(0, 0, 0, 0.65), 0 0 35px var(--active-glow)',
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
        }}
      >
        {/* Header do Painel */}
        <div
          style={{
            padding: '1.2rem 1.3rem 0.9rem',
            borderBottom: '1px solid var(--line)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'sticky',
            top: 0,
            background: 'var(--panel-strong)',
            zIndex: 10,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: '40px',
                height: '40px',
                borderRadius: '0.8rem',
                background: 'linear-gradient(135deg, var(--active), var(--active2))',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 6px 16px var(--active-glow)',
                color: '#FFFFFF',
                fontSize: '1.2rem',
              }}
            >
              {userProfile.isLoggedIn ? userProfile.avatarEmoji || '👑' : '✨'}
            </div>
            <div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.68rem',
                  textTransform: 'uppercase',
                  letterSpacing: '0.06em',
                  color: 'var(--active)',
                  fontWeight: 700,
                }}
              >
                <Sparkles size={12} />
                <span>{userProfile.isLoggedIn ? 'Sessão Ativa' : 'Painel de Acesso'}</span>
              </div>
              <h2
                style={{
                  margin: 0,
                  fontSize: '1.2rem',
                  fontWeight: 800,
                  color: 'var(--ink)',
                  fontFamily: 'var(--font-display)',
                  letterSpacing: '-0.02em',
                }}
              >
                {userProfile.isLoggedIn
                  ? `E aí, ${userProfile.name || 'Mestre'}!`
                  : 'Bora pro Jogo! 🚀'}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid var(--line)',
              color: 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.18s ease',
            }}
            title="Fechar"
          >
            <X size={16} />
          </button>
        </div>

        {/* Corpo do Painel */}
        <div style={{ padding: '1.2rem 1.3rem', flex: 1 }}>
          {userProfile.isLoggedIn ? (
            /* =================== TELA DE PERFIL CONECTADO =================== */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
              <div
                style={{
                  background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.12), rgba(56, 189, 248, 0.08))',
                  border: '1px solid rgba(34, 197, 94, 0.3)',
                  borderRadius: '1.1rem',
                  padding: '1.1rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem',
                }}
              >
                <div
                  style={{
                    width: '62px',
                    height: '62px',
                    borderRadius: '1rem',
                    background: currentAvatarConfig.gradient,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '2rem',
                    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.35)',
                    flexShrink: 0,
                  }}
                >
                  {userProfile.avatarEmoji || '🚀'}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.3rem',
                      background: 'rgba(34, 197, 94, 0.2)',
                      color: '#22C55E',
                      fontSize: '0.66rem',
                      fontWeight: 700,
                      padding: '0.15rem 0.5rem',
                      borderRadius: '1rem',
                      marginBottom: '0.25rem',
                    }}
                  >
                    <ShieldCheck size={12} />
                    <span>Conectado com Sucesso</span>
                  </div>
                  <h3
                    style={{
                      margin: 0,
                      fontSize: '1.15rem',
                      fontWeight: 800,
                      color: 'var(--ink)',
                      fontFamily: 'var(--font-display)',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {userProfile.name}
                  </h3>
                  <div
                    style={{
                      fontSize: '0.76rem',
                      color: 'var(--ink-soft)',
                      marginTop: '0.15rem',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {userProfile.email || 'Conta Alicerce Pessoal'}
                  </div>
                </div>
              </div>

              {/* Status Descontraído & Meta */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '0.6rem',
                }}
              >
                <div
                  style={{
                    background: 'var(--panel)',
                    border: '1px solid var(--line)',
                    borderRadius: '0.85rem',
                    padding: '0.75rem',
                  }}
                >
                  <div
                    style={{
                      fontSize: '0.65rem',
                      fontFamily: 'var(--font-mono)',
                      color: 'var(--ink-soft)',
                      textTransform: 'uppercase',
                      marginBottom: '0.2rem',
                    }}
                  >
                    Vibe do Dia
                  </div>
                  <div
                    style={{
                      fontSize: '0.85rem',
                      fontWeight: 700,
                      color: 'var(--active)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.3rem',
                    }}
                  >
                    <Flame size={14} />
                    <span>{userProfile.customStatus || 'Foco Total 🔥'}</span>
                  </div>
                </div>

                <div
                  style={{
                    background: 'var(--panel)',
                    border: '1px solid var(--line)',
                    borderRadius: '0.85rem',
                    padding: '0.75rem',
                  }}
                >
                  <div
                    style={{
                      fontSize: '0.65rem',
                      fontFamily: 'var(--font-mono)',
                      color: 'var(--ink-soft)',
                      textTransform: 'uppercase',
                      marginBottom: '0.2rem',
                    }}
                  >
                    Objetivo
                  </div>
                  <div
                    style={{
                      fontSize: '0.8rem',
                      fontWeight: 700,
                      color: 'var(--ink)',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                    title={userProfile.mainGoal}
                  >
                    {userProfile.mainGoal || 'Evolução Diária'}
                  </div>
                </div>
              </div>

              {/* Frase motivacional descontraída */}
              <div
                style={{
                  padding: '0.85rem 1rem',
                  background: 'var(--panel)',
                  border: '1px dashed var(--line)',
                  borderRadius: '0.9rem',
                  fontSize: '0.8rem',
                  color: 'var(--ink-soft)',
                  lineHeight: 1.45,
                  textAlign: 'center',
                  fontStyle: 'italic',
                }}
              >
                "Disciplina é escolher entre o que você quer agora e o que você mais quer na vida."
              </div>

              {/* Ações de Conta */}
              <div style={{ display: 'flex', gap: '0.6rem', marginTop: '0.5rem' }}>
                <button
                  type="button"
                  onClick={onClose}
                  style={{
                    flex: 1,
                    padding: '0.75rem',
                    borderRadius: '0.75rem',
                    background: 'linear-gradient(135deg, var(--active), var(--active2))',
                    border: 'none',
                    color: '#FFFFFF',
                    fontSize: '0.85rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    boxShadow: '0 6px 18px var(--active-glow)',
                    transition: 'all 0.18s ease',
                  }}
                >
                  Continuar no App ✨
                </button>

                <button
                  type="button"
                  onClick={handleDoLogout}
                  style={{
                    padding: '0.75rem 1rem',
                    borderRadius: '0.75rem',
                    background: 'rgba(239, 68, 68, 0.12)',
                    border: '1px solid rgba(239, 68, 68, 0.3)',
                    color: '#EF4444',
                    fontSize: '0.85rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    transition: 'all 0.18s ease',
                  }}
                  title="Sair da sessão"
                >
                  <LogOut size={16} />
                  <span>Sair</span>
                </button>
              </div>
            </div>
          ) : (
            /* =================== FORMULÁRIO DE LOGIN / CADASTRO =================== */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {/* Botão de Acesso Instantâneo Convidado VIP */}
              <div
                style={{
                  background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.14), rgba(239, 68, 68, 0.08))',
                  border: '1px solid rgba(245, 158, 11, 0.35)',
                  borderRadius: '1rem',
                  padding: '0.85rem 1rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '0.75rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                  <div
                    style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: '#FFFFFF',
                      fontSize: '1.1rem',
                      boxShadow: '0 4px 12px rgba(245, 158, 11, 0.4)',
                    }}
                  >
                    🔥
                  </div>
                  <div>
                    <div style={{ fontSize: '0.84rem', fontWeight: 800, color: 'var(--ink)' }}>
                      Quer testar na hora?
                    </div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--ink-soft)' }}>
                      Acesse com 1 toque sem preencher nada
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleQuickDemoLogin}
                  style={{
                    padding: '0.45rem 0.85rem',
                    borderRadius: '0.65rem',
                    background: '#F59E0B',
                    border: 'none',
                    color: '#000000',
                    fontSize: '0.76rem',
                    fontWeight: 800,
                    cursor: 'pointer',
                    boxShadow: '0 4px 12px rgba(245, 158, 11, 0.3)',
                    whiteSpace: 'nowrap',
                    transition: 'all 0.15s ease',
                  }}
                >
                  Entrar Rápido ⚡
                </button>
              </div>

              {/* Seletor de Abas: Entrar vs Criar Conta */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  background: 'rgba(0, 0, 0, 0.15)',
                  border: '1px solid var(--line)',
                  borderRadius: '0.85rem',
                  padding: '0.22rem',
                  gap: '0.3rem',
                }}
              >
                <button
                  type="button"
                  onClick={() => {
                    setTab('login');
                    setErrorMessage('');
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.4rem',
                    padding: '0.55rem 0.6rem',
                    borderRadius: '0.65rem',
                    border: 'none',
                    background: tab === 'login' ? 'var(--active)' : 'transparent',
                    color: tab === 'login' ? '#FFFFFF' : 'var(--ink-soft)',
                    fontWeight: 700,
                    fontSize: '0.8rem',
                    cursor: 'pointer',
                    transition: 'all 0.18s ease',
                  }}
                >
                  <LogIn size={15} />
                  Já Tenho Conta
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTab('register');
                    setErrorMessage('');
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.4rem',
                    padding: '0.55rem 0.6rem',
                    borderRadius: '0.65rem',
                    border: 'none',
                    background: tab === 'register' ? 'var(--active)' : 'transparent',
                    color: tab === 'register' ? '#FFFFFF' : 'var(--ink-soft)',
                    fontWeight: 700,
                    fontSize: '0.8rem',
                    cursor: 'pointer',
                    transition: 'all 0.18s ease',
                  }}
                >
                  <UserPlus size={15} />
                  Criar Conta
                </button>
              </div>

              {errorMessage && (
                <div
                  style={{
                    background: 'rgba(239, 68, 68, 0.12)',
                    border: '1px solid rgba(239, 68, 68, 0.3)',
                    color: '#EF4444',
                    padding: '0.6rem 0.8rem',
                    borderRadius: '0.7rem',
                    fontSize: '0.78rem',
                    fontWeight: 600,
                  }}
                >
                  {errorMessage}
                </div>
              )}

              {tab === 'login' ? (
                /* Formulário: Login */
                <form onSubmit={handleLoginSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
                  <div>
                    <label
                      style={{
                        display: 'block',
                        fontSize: '0.74rem',
                        fontWeight: 700,
                        color: 'var(--ink-soft)',
                        marginBottom: '0.35rem',
                      }}
                    >
                      Usuário ou E-mail
                    </label>
                    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                      <span style={{ position: 'absolute', left: '0.85rem', color: 'var(--ink-soft)' }}>
                        <User size={16} />
                      </span>
                      <input
                        type="text"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        placeholder="Ex: Pedro, Sarah, ou seu e-mail"
                        style={{
                          width: '100%',
                          padding: '0.7rem 0.85rem 0.7rem 2.4rem',
                          borderRadius: '0.75rem',
                          background: 'var(--input-bg, var(--panel))',
                          border: '1px solid var(--line)',
                          color: 'var(--ink)',
                          fontSize: '0.85rem',
                          outline: 'none',
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.35rem' }}>
                      <label
                        style={{
                          fontSize: '0.74rem',
                          fontWeight: 700,
                          color: 'var(--ink-soft)',
                        }}
                      >
                        Senha
                      </label>
                      <span
                        style={{
                          fontSize: '0.68rem',
                          color: 'var(--active)',
                          cursor: 'pointer',
                        }}
                        onClick={() => alert('Dica: Esta é uma autenticação simplificada local. Digite qualquer senha memorável ou use o botão "Entrar Rápido"!')}
                      >
                        Esqueceu?
                      </span>
                    </div>
                    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                      <span style={{ position: 'absolute', left: '0.85rem', color: 'var(--ink-soft)' }}>
                        <Lock size={16} />
                      </span>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="••••••••"
                        style={{
                          width: '100%',
                          padding: '0.7rem 2.4rem 0.7rem 2.4rem',
                          borderRadius: '0.75rem',
                          background: 'var(--input-bg, var(--panel))',
                          border: '1px solid var(--line)',
                          color: 'var(--ink)',
                          fontSize: '0.85rem',
                          outline: 'none',
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        style={{
                          position: 'absolute',
                          right: '0.75rem',
                          background: 'none',
                          border: 'none',
                          color: 'var(--ink-soft)',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                        }}
                      >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '0.2rem 0' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', cursor: 'pointer', fontSize: '0.75rem', color: 'var(--ink-soft)' }}>
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        style={{ accentColor: 'var(--active)', cursor: 'pointer' }}
                      />
                      <span>Manter conectado neste aparelho</span>
                    </label>
                  </div>

                  <button
                    type="submit"
                    style={{
                      width: '100%',
                      padding: '0.78rem',
                      borderRadius: '0.8rem',
                      background: 'linear-gradient(135deg, var(--active), var(--active2))',
                      border: 'none',
                      color: '#FFFFFF',
                      fontSize: '0.9rem',
                      fontWeight: 800,
                      cursor: 'pointer',
                      boxShadow: '0 8px 22px var(--active-glow)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.5rem',
                      transition: 'all 0.18s ease',
                      marginTop: '0.4rem',
                    }}
                  >
                    {successAnimation ? <Check size={18} /> : <LogIn size={18} />}
                    <span>{successAnimation ? 'Entrando com Estilo...' : 'Entrar no Alicerce ✨'}</span>
                  </button>
                </form>
              ) : (
                /* Formulário: Cadastro Descontraído */
                <form onSubmit={handleRegisterSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                  <div>
                    <label
                      style={{
                        display: 'block',
                        fontSize: '0.74rem',
                        fontWeight: 700,
                        color: 'var(--ink-soft)',
                        marginBottom: '0.35rem',
                      }}
                    >
                      Como devemos te chamar?
                    </label>
                    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                      <span style={{ position: 'absolute', left: '0.85rem', color: 'var(--ink-soft)' }}>
                        <Smile size={16} />
                      </span>
                      <input
                        type="text"
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder="Ex: Carlos, Marina, Vini..."
                        style={{
                          width: '100%',
                          padding: '0.7rem 0.85rem 0.7rem 2.4rem',
                          borderRadius: '0.75rem',
                          background: 'var(--input-bg, var(--panel))',
                          border: '1px solid var(--line)',
                          color: 'var(--ink)',
                          fontSize: '0.85rem',
                          outline: 'none',
                        }}
                      />
                    </div>
                  </div>

                  {/* Escolha de Avatar Descontraído */}
                  <div>
                    <label
                      style={{
                        display: 'block',
                        fontSize: '0.74rem',
                        fontWeight: 700,
                        color: 'var(--ink-soft)',
                        marginBottom: '0.45rem',
                      }}
                    >
                      Escolha seu Avatar de Entrada:
                    </label>
                    <div
                      style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(4, 1fr)',
                        gap: '0.45rem',
                      }}
                    >
                      {PLAYFUL_AVATARS.map((av) => {
                        const isSelected = selectedAvatar.id === av.id;
                        return (
                          <button
                            key={av.id}
                            type="button"
                            onClick={() => setSelectedAvatar(av)}
                            style={{
                              background: isSelected ? 'var(--panel-strong)' : 'var(--panel)',
                              border: isSelected ? '2px solid var(--active)' : '1px solid var(--line)',
                              borderRadius: '0.75rem',
                              padding: '0.5rem 0.3rem',
                              display: 'flex',
                              flexDirection: 'column',
                              alignItems: 'center',
                              gap: '0.2rem',
                              cursor: 'pointer',
                              transform: isSelected ? 'scale(1.04)' : 'scale(1)',
                              boxShadow: isSelected ? '0 6px 16px var(--active-glow)' : 'none',
                              transition: 'all 0.15s ease',
                            }}
                          >
                            <span style={{ fontSize: '1.45rem' }}>{av.emoji}</span>
                            <span
                              style={{
                                fontSize: '0.62rem',
                                fontWeight: 700,
                                color: isSelected ? 'var(--active)' : 'var(--ink-soft)',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                maxWidth: '100%',
                              }}
                            >
                              {av.name}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Meta Principal */}
                  <div>
                    <label
                      style={{
                        display: 'block',
                        fontSize: '0.74rem',
                        fontWeight: 700,
                        color: 'var(--ink-soft)',
                        marginBottom: '0.35rem',
                      }}
                    >
                      Foco Prioritário Atual:
                    </label>
                    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                      <span style={{ position: 'absolute', left: '0.85rem', color: 'var(--ink-soft)' }}>
                        <Target size={16} />
                      </span>
                      <select
                        value={selectedGoal}
                        onChange={(e) => setSelectedGoal(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '0.7rem 0.85rem 0.7rem 2.4rem',
                          borderRadius: '0.75rem',
                          background: 'var(--input-bg, var(--panel))',
                          border: '1px solid var(--line)',
                          color: 'var(--ink)',
                          fontSize: '0.82rem',
                          outline: 'none',
                        }}
                      >
                        {MAIN_GOALS.map((goal) => (
                          <option key={goal} value={goal} style={{ background: 'var(--panel-strong)', color: 'var(--ink)' }}>
                            {goal}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      style={{
                        display: 'block',
                        fontSize: '0.74rem',
                        fontWeight: 700,
                        color: 'var(--ink-soft)',
                        marginBottom: '0.35rem',
                      }}
                    >
                      E-mail (opcional)
                    </label>
                    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                      <span style={{ position: 'absolute', left: '0.85rem', color: 'var(--ink-soft)' }}>
                        <Mail size={16} />
                      </span>
                      <input
                        type="email"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        placeholder="seuemail@exemplo.com"
                        style={{
                          width: '100%',
                          padding: '0.7rem 0.85rem 0.7rem 2.4rem',
                          borderRadius: '0.75rem',
                          background: 'var(--input-bg, var(--panel))',
                          border: '1px solid var(--line)',
                          color: 'var(--ink)',
                          fontSize: '0.85rem',
                          outline: 'none',
                        }}
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    style={{
                      width: '100%',
                      padding: '0.78rem',
                      borderRadius: '0.8rem',
                      background: 'linear-gradient(135deg, var(--active), var(--active2))',
                      border: 'none',
                      color: '#FFFFFF',
                      fontSize: '0.9rem',
                      fontWeight: 800,
                      cursor: 'pointer',
                      boxShadow: '0 8px 22px var(--active-glow)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.5rem',
                      transition: 'all 0.18s ease',
                      marginTop: '0.3rem',
                    }}
                  >
                    {successAnimation ? <Check size={18} /> : <Sparkles size={18} />}
                    <span>{successAnimation ? 'Criando sua Conta...' : 'Começar Minha Jornada 🚀'}</span>
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Footer com indicação descontraída */}
        <div
          style={{
            padding: '0.85rem 1.3rem',
            borderTop: '1px solid var(--line)',
            background: 'var(--panel-strong)',
            fontSize: '0.72rem',
            color: 'var(--ink-soft)',
            textAlign: 'center',
          }}
        >
          🔒 Seus dados ficam protegidos e salvos no seu próprio dispositivo.
        </div>
      </div>
    </div>
  );
};
