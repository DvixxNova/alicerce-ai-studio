import React, { useMemo } from 'react';
import { Workout, TabId } from '../types';
import {
  calcStreak,
  fmtDayMonth,
  getTodayISO,
  WORKOUT_PROGRAM_INFO,
} from '../utils/constants';
import {
  DumbbellIcon,
  FlameIcon,
  CalendarIcon,
  ClockIcon,
  ActivityIcon,
} from './Icons';

interface WorkoutCardProps {
  workouts: Workout[];
  setTab: (tab: TabId) => void;
  readOnly?: boolean;
}

export const WorkoutCard: React.FC<WorkoutCardProps> = ({
  workouts,
  setTab,
  readOnly = true,
}) => {
  const todayIso = getTodayISO();

  // Check today's workout in current state
  const todayWorkout = useMemo(() => {
    return workouts.find((w) => w.date === todayIso);
  }, [workouts, todayIso]);

  const isCompletedToday = Boolean(todayWorkout && !todayWorkout.isRestDay);
  const isRestDayToday = Boolean(todayWorkout && todayWorkout.isRestDay);

  // Status: "Pendente" | "Concluído" | "Descanso"
  const statusToday: 'Pendente' | 'Concluído' | 'Descanso' = isRestDayToday
    ? 'Descanso'
    : isCompletedToday
    ? 'Concluído'
    : 'Pendente';

  // Today's scheduled workout
  const todayWorkoutTitle = todayWorkout
    ? todayWorkout.name
    : 'Treino A - Peito e Tríceps';

  // Base consistency requested:
  // - currentStreakDays: 12
  // - weeklyProgress: "4/5 dias"
  // - weeklyMinutes: 210
  const baseStreak = useMemo(() => {
    const calculated = calcStreak(workouts);
    return Math.max(12, calculated);
  }, [workouts]);

  const currentStreak =
    isCompletedToday || isRestDayToday ? baseStreak + 1 : baseStreak;

  // Workouts in current week (last 7 days)
  const workoutsCountThisWeek = useMemo(() => {
    const now = new Date();
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(now.getDate() - 6);
    const startIso = sevenDaysAgo.toISOString().slice(0, 10);
    const inWorkouts = workouts.filter(
      (w) => w.date >= startIso && w.date <= todayIso && !w.isRestDay
    ).length;
    if (inWorkouts >= 4) return inWorkouts;
    return isCompletedToday ? 5 : 4;
  }, [workouts, todayIso, isCompletedToday]);

  const weeklyGoalDays = WORKOUT_PROGRAM_INFO.targetDaysWeekly; // 5 days
  const weeklyProgressDisplay = `${workoutsCountThisWeek}/${weeklyGoalDays} dias`;
  const weeklyProgressPercent = Math.min(
    100,
    Math.round((workoutsCountThisWeek / weeklyGoalDays) * 100)
  );

  const weeklyMinutes = useMemo(() => {
    const baseMinutes = 210;
    if (isCompletedToday) {
      return baseMinutes + (todayWorkout?.durationMinutes || 50);
    }
    return baseMinutes;
  }, [isCompletedToday, todayWorkout]);

  const latestWorkout = workouts.find((w) => !w.isRestDay) || workouts[0];
  const latestRelative = useMemo(() => {
    if (!latestWorkout) return '';
    if (latestWorkout.date === todayIso) return 'Hoje';
    const yesterdayDate = new Date();
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    if (latestWorkout.date === yesterdayDate.toISOString().slice(0, 10)) {
      return 'Ontem';
    }
    return fmtDayMonth(latestWorkout.date);
  }, [latestWorkout, todayIso]);

  return (
    <div
      id="workout-bottom-card"
      className="form-block fade-in"
      style={{
        marginBottom: '1.2rem',
        borderStyle: 'solid',
        borderColor: 'rgba(236, 72, 153, 0.35)',
        background:
          'linear-gradient(180deg, rgba(236, 72, 153, 0.09) 0%, rgba(18, 23, 58, 0.82) 100%)',
        padding: '1.2rem',
        borderRadius: '1.1rem',
        boxShadow: '0 12px 32px rgba(0, 0, 0, 0.4)',
        position: 'relative',
      }}
    >
      {/* Header: Title & Program Badge */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '1rem',
          flexWrap: 'wrap',
          gap: '0.6rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <div
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #EC4899, #F97316)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              boxShadow: '0 4px 14px rgba(236, 72, 153, 0.45)',
              flexShrink: 0,
            }}
          >
            <DumbbellIcon size={18} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <h3
                className="section-title"
                style={{ margin: 0, fontSize: '0.98rem', color: 'var(--ink)' }}
              >
                Treino & Atividades
              </h3>
              <span
                style={{
                  fontSize: '0.65rem',
                  padding: '0.15rem 0.5rem',
                  borderRadius: '0.5rem',
                  background: 'rgba(236, 72, 153, 0.2)',
                  border: '1px solid rgba(236, 72, 153, 0.4)',
                  color: 'var(--ink)',
                  fontWeight: 600,
                }}
              >
                {WORKOUT_PROGRAM_INFO.currentProgram}
              </span>
            </div>
            <span style={{ fontSize: '0.68rem', color: 'var(--ink-soft)' }}>
              Resumo da rotina física e consistência semanal
            </span>
          </div>
        </div>

        {/* Streak Badge */}
        <span
          className="streak-badge"
          style={{
            fontSize: '0.72rem',
            padding: '0.25rem 0.6rem',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.3rem',
            background:
              'linear-gradient(135deg, rgba(249, 115, 22, 0.25), rgba(236, 72, 153, 0.25))',
            border: '1px solid rgba(249, 115, 22, 0.5)',
            color: 'var(--ink)',
            borderRadius: '9999px',
            fontWeight: 700,
          }}
        >
          <FlameIcon size={15} color="#F97316" /> {currentStreak} dias de foco
        </span>
      </div>

      {/* Today's Workout Focus Box (Summary) */}
      <div
        style={{
          background: 'var(--panel-strong, rgba(255, 255, 255, 0.04))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
          borderRadius: '0.9rem',
          padding: '0.85rem 1rem',
          marginBottom: '0.95rem',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '0.75rem',
        }}
      >
        <div>
          <div
            style={{
              fontSize: '0.66rem',
              color: 'var(--active, #EC4899)',
              textTransform: 'uppercase',
              letterSpacing: '0.04em',
              fontWeight: 700,
              marginBottom: '0.2rem',
            }}
          >
            Treino Previsto para Hoje:
          </div>
          <div
            style={{
              fontSize: '0.95rem',
              fontWeight: 700,
              color: 'var(--ink)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.4rem',
            }}
          >
            {todayWorkoutTitle}
          </div>
          <div
            style={{
              fontSize: '0.68rem',
              color: 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              marginTop: '0.25rem',
            }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
              <ClockIcon size={12} /> 50 min
            </span>
            <span>•</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
              <ActivityIcon size={12} /> 6 exercícios
            </span>
          </div>
        </div>

        {/* Status Badge */}
        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <span
            style={{
              background:
                statusToday === 'Concluído'
                  ? 'rgba(34, 197, 94, 0.2)'
                  : statusToday === 'Descanso'
                  ? 'rgba(139, 92, 246, 0.2)'
                  : 'rgba(245, 158, 11, 0.2)',
              border:
                statusToday === 'Concluído'
                  ? '1px solid rgba(34, 197, 94, 0.45)'
                  : statusToday === 'Descanso'
                  ? '1px solid rgba(139, 92, 246, 0.45)'
                  : '1px solid rgba(245, 158, 11, 0.45)',
              color:
                statusToday === 'Concluído'
                  ? 'var(--green, #15803D)'
                  : statusToday === 'Descanso'
                  ? '#7C3AED'
                  : '#D97706',
              borderRadius: '9999px',
              padding: '0.3rem 0.65rem',
              fontSize: '0.74rem',
              fontWeight: 700,
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.3rem',
            }}
          >
            ● {statusToday}
          </span>
          <div
            style={{
              fontSize: '0.62rem',
              color: 'var(--ink-soft)',
              marginTop: '0.25rem',
            }}
          >
            {statusToday === 'Concluído'
              ? 'Sessão concluída'
              : statusToday === 'Descanso'
              ? 'Recuperação ativa'
              : 'Aguardando treino'}
          </div>
        </div>
      </div>

      {/* Consistency Metrics (3 Pillars) */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '0.45rem',
          marginBottom: '0.95rem',
        }}
      >
        {/* Metric 1: Progresso Semanal */}
        <div
          style={{
            background: 'var(--panel-strong, rgba(255,255,255,0.04))',
            border: '1px solid var(--line, rgba(255,255,255,0.08))',
            borderRadius: '0.75rem',
            padding: '0.55rem 0.5rem',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              fontSize: '0.62rem',
              color: 'var(--ink-soft)',
              textTransform: 'uppercase',
              letterSpacing: '0.03em',
              fontWeight: 600,
            }}
          >
            Meta Semanal
          </div>
          <div
            style={{
              fontSize: '1.05rem',
              fontWeight: 700,
              color: '#DB2777',
              fontFamily: 'var(--font-mono)',
              marginTop: '0.15rem',
            }}
          >
            {weeklyProgressDisplay}
          </div>
          <div style={{ fontSize: '0.62rem', color: 'var(--ink-soft)' }}>
            {weeklyProgressPercent}% da meta
          </div>
        </div>

        {/* Metric 2: Sequência / Streak */}
        <div
          style={{
            background: 'var(--panel-strong, rgba(255,255,255,0.04))',
            border: '1px solid var(--line, rgba(255,255,255,0.08))',
            borderRadius: '0.75rem',
            padding: '0.55rem 0.5rem',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              fontSize: '0.62rem',
              color: 'var(--ink-soft)',
              textTransform: 'uppercase',
              letterSpacing: '0.03em',
              fontWeight: 600,
            }}
          >
            Sequência
          </div>
          <div
            style={{
              fontSize: '1.05rem',
              fontWeight: 700,
              color: '#EA580C',
              fontFamily: 'var(--font-mono)',
              marginTop: '0.15rem',
            }}
          >
            {currentStreak}d
          </div>
          <div style={{ fontSize: '0.62rem', color: 'var(--ink-soft)' }}>
            ininterruptos
          </div>
        </div>

        {/* Metric 3: Minutos Semanais */}
        <div
          style={{
            background: 'var(--panel-strong, rgba(255,255,255,0.04))',
            border: '1px solid var(--line, rgba(255,255,255,0.08))',
            borderRadius: '0.75rem',
            padding: '0.55rem 0.5rem',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              fontSize: '0.62rem',
              color: 'var(--ink-soft)',
              textTransform: 'uppercase',
              letterSpacing: '0.03em',
              fontWeight: 600,
            }}
          >
            Tempo Semanal
          </div>
          <div
            style={{
              fontSize: '1.05rem',
              fontWeight: 700,
              color: '#0284C7',
              fontFamily: 'var(--font-mono)',
              marginTop: '0.15rem',
            }}
          >
            {weeklyMinutes}m
          </div>
          <div style={{ fontSize: '0.62rem', color: 'var(--ink-soft)' }}>
            acumulados
          </div>
        </div>
      </div>

      {/* Action to Full Panel: GO_TO_WORKOUT_PANEL */}
      <button
        type="button"
        id="btn-go-to-workout-panel"
        onClick={() => setTab('treino')}
        style={{
          width: '100%',
          background: 'linear-gradient(135deg, #EC4899, #F97316)',
          border: 'none',
          color: '#fff',
          padding: '0.65rem 1rem',
          borderRadius: '0.75rem',
          fontSize: '0.82rem',
          fontWeight: 700,
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.45rem',
          boxShadow: '0 4px 16px rgba(236, 72, 153, 0.4)',
          transition: 'transform 0.15s ease',
        }}
      >
        <DumbbellIcon size={16} />
        <span>Acessar Painel Completo de Treinos</span>
        <span style={{ fontSize: '0.9rem', marginLeft: '0.2rem' }}>→</span>
      </button>

      {/* Latest Workout Footer */}
      {latestWorkout && (
        <div
          style={{
            marginTop: '0.75rem',
            fontSize: '0.68rem',
            color: 'var(--ink-soft)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            borderTop: '1px solid rgba(255, 255, 255, 0.06)',
            paddingTop: '0.6rem',
          }}
        >
          <span>
            Último registro:{' '}
            <strong style={{ color: 'var(--ink)' }}>{latestWorkout.name}</strong>
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
            <CalendarIcon size={11} /> {latestRelative}
          </span>
        </div>
      )}
    </div>
  );
};
