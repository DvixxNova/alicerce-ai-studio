import React from 'react';
import { NotesView } from './NotesView';

export { NotesView };
export const NotasView = NotesView;
export default NotesView;
