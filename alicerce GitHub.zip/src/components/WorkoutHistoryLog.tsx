import React, { useState, useMemo } from 'react';
import { Workout } from '../types';
import {
  fmtDayMonth,
  fmtVolumeKg,
  genId,
  getDefaultWorkouts,
  getTodayISO,
  getWorkoutTotalVolume,
  WORKOUT_OPTIONS,
  WorkoutProgramOption,
} from '../utils/constants';
import {
  ActivityIcon,
  CalendarIcon,
  ClockIcon,
  DumbbellIcon,
  FlameIcon,
  PlusIcon,
  RotateCcwIcon,
  SparklesIcon,
  TrashIcon,
  ZapIcon,
  XIcon,
  CheckIcon,
} from './Icons';

interface WorkoutHistoryLogProps {
  workouts: Workout[];
  setWorkouts: React.Dispatch<React.SetStateAction<Workout[]>>;
  programs?: WorkoutProgramOption[];
  onFeedback?: (msg: string) => void;
}

export const WorkoutHistoryLog: React.FC<WorkoutHistoryLogProps> = ({
  workouts,
  setWorkouts,
  programs = WORKOUT_OPTIONS,
  onFeedback,
}) => {
  const todayIso = getTodayISO();

  // Mode: show only last 5 (requested by user) or expand all
  const [viewAll, setViewAll] = useState<boolean>(false);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // New Workout Form state
  const [newName, setNewName] = useState<string>('Treino A - Peito, Ombro e Tríceps');
  const [newDate, setNewDate] = useState<string>(todayIso);
  const [newVolume, setNewVolume] = useState<string>('6420');
  const [newDuration, setNewDuration] = useState<string>('50');
  const [newLoadNote, setNewLoadNote] = useState<string>(
    'Supino Reto: 60kg | Inclinado: 22kg | Tríceps: 25kg'
  );

  // Filter completed workouts (excluding rest days from volume rankings, though user can still see them)
  const completedWorkouts = useMemo(() => {
    return [...workouts]
      .filter((w) => !w.isRestDay)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [workouts]);

  // Exactly the last 5 completed workouts
  const lastFiveWorkouts = useMemo(() => {
    return completedWorkouts.slice(0, 5);
  }, [completedWorkouts]);

  const displayList = viewAll ? completedWorkouts : lastFiveWorkouts;

  // Maximum volume among the displayed workouts (for proportional comparison bar)
  const maxVolumeInList = useMemo(() => {
    if (lastFiveWorkouts.length === 0) return 1;
    return Math.max(
      ...lastFiveWorkouts.map((w) => getWorkoutTotalVolume(w, programs)),
      1
    );
  }, [lastFiveWorkouts, programs]);

  // Volume metrics for the last 5 sessions
  const metrics = useMemo(() => {
    if (lastFiveWorkouts.length === 0) {
      return { totalVolume: 0, avgVolume: 0, totalMinutes: 0 };
    }
    const totalVolume = lastFiveWorkouts.reduce(
      (acc, w) => acc + getWorkoutTotalVolume(w, programs),
      0
    );
    const totalMinutes = lastFiveWorkouts.reduce(
      (acc, w) => acc + (w.durationMinutes || 45),
      0
    );
    const avgVolume = Math.round(totalVolume / lastFiveWorkouts.length);
    return { totalVolume, avgVolume, totalMinutes };
  }, [lastFiveWorkouts, programs]);

  // Relative human date formatting (Hoje, Ontem, Dia da Semana)
  const formatWorkoutDate = (isoDate: string) => {
    if (isoDate === todayIso) return 'Hoje';
    const d = new Date(isoDate + 'T00:00:00');
    const today = new Date(todayIso + 'T00:00:00');
    const diffDays = Math.round(
      (today.getTime() - d.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (diffDays === 1) return 'Ontem';

    const weekdayShort = d.toLocaleDateString('pt-BR', { weekday: 'short' });
    const formatted = d.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
    });
    return `${weekdayShort.charAt(0).toUpperCase() + weekdayShort.slice(1)}, ${formatted}`;
  };

  const handleDeleteWorkout = (id: string, name: string) => {
    setWorkouts((prev) => prev.filter((w) => w.id !== id));
    if (onFeedback) {
      onFeedback(`Registro de "${name}" removido do histórico.`);
    }
  };

  const handleResetDefaults = () => {
    const defaults = getDefaultWorkouts();
    setWorkouts((prev) => {
      // Keep today's workout if exists, and append defaults
      const todayExisting = prev.filter((w) => w.date === todayIso);
      return [...todayExisting, ...defaults];
    });
    if (onFeedback) {
      onFeedback('Histórico redefinido com os últimos 5 treinos de referência!');
    }
  };

  const handleQuickAddWorkout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const parsedVolume = parseFloat(newVolume.replace(',', '.'));
    const parsedDuration = parseInt(newDuration, 10);

    const newWorkout: Workout = {
      id: genId(),
      name: newName.trim(),
      date: newDate,
      totalVolumeKg: !isNaN(parsedVolume) && parsedVolume > 0 ? parsedVolume : undefined,
      durationMinutes: !isNaN(parsedDuration) && parsedDuration > 0 ? parsedDuration : 50,
      loadNote: newLoadNote.trim() || undefined,
      isRestDay: false,
    };

    // If volume was not provided, auto compute from program
    if (!newWorkout.totalVolumeKg) {
      newWorkout.totalVolumeKg = getWorkoutTotalVolume(newWorkout, programs);
    }

    setWorkouts((prev) => [newWorkout, ...prev.filter((w) => w.id !== newWorkout.id)]);
    setShowAddModal(false);
    if (onFeedback) {
      onFeedback(
        `Treino "${newWorkout.name}" adicionado ao histórico com ${fmtVolumeKg(
          newWorkout.totalVolumeKg || 0
        )}!`
      );
    }
  };

  return (
    <div
      id="workout-history-log-section"
      style={{
        background: 'var(--panel-strong, rgba(20, 24, 60, 0.55))',
        border: '1px solid var(--line, rgba(255, 255, 255, 0.09))',
        borderRadius: '1.25rem',
        padding: '1.25rem',
        marginTop: '1.5rem',
        boxShadow: '0 8px 30px rgba(0, 0, 0, 0.25)',
      }}
    >
      {/* Header & Controls */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'flex-start',
          flexWrap: 'wrap',
          gap: '0.8rem',
          marginBottom: '1rem',
          borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
          paddingBottom: '0.9rem',
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
            <span
              style={{
                background: 'linear-gradient(135deg, #EC4899, #8B5CF6)',
                color: '#fff',
                padding: '0.3rem',
                borderRadius: '0.5rem',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <DumbbellIcon size={16} />
            </span>
            <h3
              style={{
                margin: 0,
                fontSize: '1.05rem',
                fontWeight: 800,
                color: 'var(--ink)',
                letterSpacing: '-0.01em',
              }}
            >
              Histórico de Treinos
            </h3>
            <span
              style={{
                fontSize: '0.66rem',
                fontWeight: 700,
                color: '#EC4899',
                background: 'rgba(236, 72, 153, 0.14)',
                border: '1px solid rgba(236, 72, 153, 0.3)',
                padding: '0.2rem 0.55rem',
                borderRadius: '9999px',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}
            >
              Últimos 5 Realizados
            </span>
          </div>
          <p style={{ margin: 0, fontSize: '0.74rem', color: 'var(--ink-soft)' }}>
            Acompanhe a data, nome do treino e o volume total de carga (kg) acumulado nas suas últimas sessões.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
          {completedWorkouts.length > 5 && (
            <button
              type="button"
              onClick={() => setViewAll((prev) => !prev)}
              style={{
                background: viewAll
                  ? 'rgba(139, 92, 246, 0.22)'
                  : 'var(--panel, rgba(255, 255, 255, 0.05))',
                border: viewAll ? '1px solid #8B5CF6' : '1px solid var(--line)',
                color: viewAll ? '#A78BFA' : 'var(--ink-soft)',
                borderRadius: '0.55rem',
                padding: '0.35rem 0.7rem',
                fontSize: '0.72rem',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
            >
              {viewAll ? 'Mostrar apenas 5' : `Ver todos (${completedWorkouts.length})`}
            </button>
          )}

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            style={{
              background: 'linear-gradient(135deg, #EC4899, #8B5CF6)',
              border: 'none',
              color: '#fff',
              borderRadius: '0.55rem',
              padding: '0.38rem 0.8rem',
              fontSize: '0.72rem',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem',
              boxShadow: '0 4px 12px rgba(236, 72, 153, 0.3)',
            }}
          >
            <PlusIcon size={13} />
            <span>Registrar Treino</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Pills (Last 5 Sessions) */}
      {lastFiveWorkouts.length > 0 && (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
            gap: '0.65rem',
            marginBottom: '1.1rem',
          }}
        >
          <div
            style={{
              background: 'rgba(236, 72, 153, 0.08)',
              border: '1px solid rgba(236, 72, 153, 0.25)',
              borderRadius: '0.85rem',
              padding: '0.65rem 0.85rem',
            }}
          >
            <div style={{ fontSize: '0.66rem', color: '#EC4899', fontWeight: 700, textTransform: 'uppercase' }}>
              Volume Acumulado (5 Treinos)
            </div>
            <div style={{ fontSize: '1.25rem', fontWeight: 900, color: 'var(--ink)', marginTop: '0.15rem' }}>
              {fmtVolumeKg(metrics.totalVolume)}
            </div>
            <div style={{ fontSize: '0.65rem', color: 'var(--ink-soft)', marginTop: '0.1rem' }}>
              Tonelagem total levantada
            </div>
          </div>

          <div
            style={{
              background: 'rgba(139, 92, 246, 0.08)',
              border: '1px solid rgba(139, 92, 246, 0.25)',
              borderRadius: '0.85rem',
              padding: '0.65rem 0.85rem',
            }}
          >
            <div style={{ fontSize: '0.66rem', color: '#A78BFA', fontWeight: 700, textTransform: 'uppercase' }}>
              Média por Sessão
            </div>
            <div style={{ fontSize: '1.25rem', fontWeight: 900, color: 'var(--ink)', marginTop: '0.15rem' }}>
              {fmtVolumeKg(metrics.avgVolume)}
            </div>
            <div style={{ fontSize: '0.65rem', color: 'var(--ink-soft)', marginTop: '0.1rem' }}>
              Volume médio de trabalho
            </div>
          </div>

          <div
            style={{
              background: 'rgba(34, 197, 94, 0.08)',
              border: '1px solid rgba(34, 197, 94, 0.25)',
              borderRadius: '0.85rem',
              padding: '0.65rem 0.85rem',
            }}
          >
            <div style={{ fontSize: '0.66rem', color: '#16A34A', fontWeight: 700, textTransform: 'uppercase' }}>
              Tempo Total Ativo
            </div>
            <div style={{ fontSize: '1.25rem', fontWeight: 900, color: 'var(--ink)', marginTop: '0.15rem' }}>
              {metrics.totalMinutes} min
            </div>
            <div style={{ fontSize: '0.65rem', color: 'var(--ink-soft)', marginTop: '0.1rem' }}>
              Nas 5 últimas sessões
            </div>
          </div>
        </div>
      )}

      {/* List of the Last 5 Workouts */}
      {displayList.length === 0 ? (
        <div
          style={{
            padding: '2rem 1rem',
            textAlign: 'center',
            background: 'var(--panel, rgba(255, 255, 255, 0.02))',
            borderRadius: '0.85rem',
            border: '1px dashed var(--line)',
          }}
        >
          <p style={{ fontSize: '0.82rem', color: 'var(--ink-soft)', margin: '0 0 0.8rem 0' }}>
            Nenhum treino realizado encontrado no histórico.
          </p>
          <button
            type="button"
            onClick={handleResetDefaults}
            style={{
              background: 'rgba(139, 92, 246, 0.2)',
              border: '1px solid #8B5CF6',
              color: '#A78BFA',
              borderRadius: '0.55rem',
              padding: '0.45rem 0.9rem',
              fontSize: '0.74rem',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.4rem',
            }}
          >
            <RotateCcwIcon size={14} />
            <span>Carregar 5 Treinos Padrões de Exemplo</span>
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
          {displayList.map((workout, index) => {
            const volumeKg = getWorkoutTotalVolume(workout, programs);
            const relativePercent = Math.min(100, Math.round((volumeKg / maxVolumeInList) * 100));
            const humanDate = formatWorkoutDate(workout.date);
            const fullDate = fmtDayMonth(workout.date);

            return (
              <div
                key={workout.id}
                style={{
                  background: 'var(--panel, rgba(255, 255, 255, 0.035))',
                  border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
                  borderRadius: '0.95rem',
                  padding: '0.85rem 1rem',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.55rem',
                  transition: 'all 0.15s ease',
                  position: 'relative',
                }}
              >
                {/* Main Row: Order # + Date + Name + Volume Badge + Delete */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: '0.6rem',
                  }}
                >
                  {/* Left info: Index badge + Date + Workout Name */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', flex: 1, minWidth: 220 }}>
                    <div
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: '0.5rem',
                        background:
                          index === 0
                            ? 'linear-gradient(135deg, #EC4899, #F97316)'
                            : 'rgba(255, 255, 255, 0.06)',
                        color: index === 0 ? '#fff' : 'var(--ink-soft)',
                        fontSize: '0.72rem',
                        fontWeight: 800,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0,
                      }}
                    >
                      #{index + 1}
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <span
                          style={{
                            fontSize: '0.7rem',
                            fontWeight: 700,
                            color: workout.date === todayIso ? '#22C55E' : 'var(--ink-soft)',
                            background:
                              workout.date === todayIso
                                ? 'rgba(34, 197, 94, 0.15)'
                                : 'rgba(255, 255, 255, 0.06)',
                            padding: '0.1rem 0.45rem',
                            borderRadius: '0.35rem',
                          }}
                        >
                          {humanDate}
                        </span>
                        <span style={{ fontSize: '0.66rem', color: 'var(--ink-soft)' }}>
                          ({fullDate})
                        </span>
                      </div>

                      <div
                        style={{
                          fontSize: '0.84rem',
                          fontWeight: 700,
                          color: 'var(--ink)',
                          marginTop: '0.15rem',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.4rem',
                          flexWrap: 'wrap',
                        }}
                      >
                        <span>{workout.name}</span>
                        {workout.focus && (
                          <span
                            style={{
                              fontSize: '0.64rem',
                              fontWeight: 600,
                              color: 'var(--ink-soft)',
                              background: 'rgba(255, 255, 255, 0.05)',
                              padding: '0.1rem 0.4rem',
                              borderRadius: '0.3rem',
                            }}
                          >
                            {workout.focus}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right info: Duration + High-Visibility Volume Total Metric + Delete button */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    {workout.durationMinutes && workout.durationMinutes > 0 && (
                      <div
                        style={{
                          fontSize: '0.7rem',
                          color: 'var(--ink-soft)',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.25rem',
                        }}
                      >
                        <ClockIcon size={12} />
                        <span>{workout.durationMinutes} min</span>
                      </div>
                    )}

                    {/* Volume Total de Carga Badge */}
                    <div
                      style={{
                        background: 'linear-gradient(135deg, rgba(236, 72, 153, 0.15), rgba(139, 92, 246, 0.2))',
                        border: '1px solid rgba(236, 72, 153, 0.35)',
                        borderRadius: '0.65rem',
                        padding: '0.35rem 0.65rem',
                        textAlign: 'right',
                        minWidth: 105,
                      }}
                    >
                      <div
                        style={{
                          fontSize: '0.58rem',
                          fontWeight: 700,
                          textTransform: 'uppercase',
                          letterSpacing: '0.04em',
                          color: '#EC4899',
                        }}
                      >
                        Volume Total
                      </div>
                      <div
                        style={{
                          fontSize: '0.9rem',
                          fontWeight: 900,
                          color: 'var(--ink)',
                          lineHeight: 1.1,
                          marginTop: '0.1rem',
                        }}
                      >
                        {fmtVolumeKg(volumeKg)}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteWorkout(workout.id, workout.name)}
                      title="Excluir treino do histórico"
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--ink-soft)',
                        cursor: 'pointer',
                        padding: '0.3rem',
                        borderRadius: '0.4rem',
                        transition: 'color 0.15s ease',
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.color = '#EF4444')}
                      onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--ink-soft)')}
                    >
                      <TrashIcon size={15} />
                    </button>
                  </div>
                </div>

                {/* Relative Volume Progress Bar */}
                <div style={{ marginTop: '0.1rem' }}>
                  <div
                    style={{
                      height: 4,
                      width: '100%',
                      background: 'rgba(255, 255, 255, 0.06)',
                      borderRadius: 9999,
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={{
                        height: '100%',
                        width: `${relativePercent}%`,
                        background: 'linear-gradient(90deg, #EC4899, #8B5CF6)',
                        borderRadius: 9999,
                        transition: 'width 0.4s ease',
                      }}
                    />
                  </div>
                </div>

                {/* Load Notes / Exercise breakdown if available */}
                {workout.loadNote && (
                  <div
                    style={{
                      fontSize: '0.68rem',
                      color: 'var(--ink-soft)',
                      background: 'rgba(255, 255, 255, 0.03)',
                      borderLeft: '2px solid #8B5CF6',
                      padding: '0.25rem 0.55rem',
                      borderRadius: '0 0.35rem 0.35rem 0',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span style={{ fontWeight: 700, color: '#A78BFA' }}>Cargas:</span>
                    <span>{workout.loadNote}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Footer Info & Quick Reset Action */}
      <div
        style={{
          marginTop: '1rem',
          paddingTop: '0.75rem',
          borderTop: '1px solid var(--line, rgba(255, 255, 255, 0.07))',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '0.5rem',
          fontSize: '0.7rem',
          color: 'var(--ink-soft)',
        }}
      >
        <span>
          Exibindo {displayList.length} de {completedWorkouts.length} treinos no histórico geral
        </span>

        <button
          type="button"
          onClick={handleResetDefaults}
          style={{
            background: 'transparent',
            border: 'none',
            color: 'var(--ink-soft)',
            fontSize: '0.68rem',
            cursor: 'pointer',
            textDecoration: 'underline',
          }}
        >
          Restaurar 5 treinos de exemplo
        </button>
      </div>

      {/* Modal: Quick Register Workout with Load Volume */}
      {showAddModal && (
        <div
          className="fade-in"
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0, 0, 0, 0.75)',
            backdropFilter: 'blur(8px)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1rem',
          }}
        >
          <div
            style={{
              background: 'var(--panel-strong, #12173A)',
              border: '1px solid rgba(236, 72, 153, 0.4)',
              borderRadius: '1.15rem',
              maxWidth: 480,
              width: '100%',
              padding: '1.3rem',
              boxShadow: '0 20px 50px rgba(0, 0, 0, 0.6)',
              color: 'var(--ink)',
            }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '1rem',
                borderBottom: '1px solid var(--line)',
                paddingBottom: '0.75rem',
              }}
            >
              <div>
                <h4 style={{ margin: 0, fontSize: '1.05rem', color: 'var(--ink)' }}>
                  Registrar Treino no Histórico
                </h4>
                <p style={{ margin: '0.2rem 0 0 0', fontSize: '0.72rem', color: 'var(--ink-soft)' }}>
                  Informe a data, o nome do treino e o volume total de carga
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                style={{ background: 'transparent', border: 'none', color: 'var(--ink-soft)', cursor: 'pointer' }}
              >
                <XIcon size={18} />
              </button>
            </div>

            <form onSubmit={handleQuickAddWorkout} style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div>
                <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 600, display: 'block', marginBottom: '0.25rem' }}>
                  Nome do Treino
                </label>
                <input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Ex: Treino A - Peito, Ombro e Tríceps"
                  style={{
                    width: '100%',
                    padding: '0.5rem 0.7rem',
                    borderRadius: '0.55rem',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.06))',
                    border: '1px solid var(--line)',
                    color: 'var(--ink)',
                    fontSize: '0.8rem',
                  }}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.65rem' }}>
                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 600, display: 'block', marginBottom: '0.25rem' }}>
                    Data do Treino
                  </label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.5rem 0.7rem',
                      borderRadius: '0.55rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.06))',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.8rem',
                    }}
                    required
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 600, display: 'block', marginBottom: '0.25rem' }}>
                    Volume Total de Carga (kg)
                  </label>
                  <input
                    type="number"
                    step="10"
                    placeholder="Ex: 6420"
                    value={newVolume}
                    onChange={(e) => setNewVolume(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.5rem 0.7rem',
                      borderRadius: '0.55rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.06))',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.8rem',
                    }}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '0.65rem' }}>
                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 600, display: 'block', marginBottom: '0.25rem' }}>
                    Duração (min)
                  </label>
                  <input
                    type="number"
                    value={newDuration}
                    onChange={(e) => setNewDuration(e.target.value)}
                    placeholder="50"
                    style={{
                      width: '100%',
                      padding: '0.5rem 0.7rem',
                      borderRadius: '0.55rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.06))',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.8rem',
                    }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--ink-soft)', fontWeight: 600, display: 'block', marginBottom: '0.25rem' }}>
                    Cargas / Exercícios (Opcional)
                  </label>
                  <input
                    value={newLoadNote}
                    onChange={(e) => setNewLoadNote(e.target.value)}
                    placeholder="Ex: Supino: 60kg | Rosca: 24kg"
                    style={{
                      width: '100%',
                      padding: '0.5rem 0.7rem',
                      borderRadius: '0.55rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.06))',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.8rem',
                    }}
                  />
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '0.6rem' }}>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  style={{
                    background: 'transparent',
                    border: '1px solid var(--line)',
                    color: 'var(--ink-soft)',
                    borderRadius: '0.55rem',
                    padding: '0.45rem 0.85rem',
                    fontSize: '0.74rem',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  style={{
                    background: 'linear-gradient(135deg, #EC4899, #8B5CF6)',
                    border: 'none',
                    color: '#fff',
                    borderRadius: '0.55rem',
                    padding: '0.45rem 1.15rem',
                    fontSize: '0.76rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    boxShadow: '0 4px 14px rgba(236, 72, 153, 0.35)',
                  }}
                >
                  Salvar no Histórico
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
