import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  X,
  Volume2,
  Sparkles,
  Zap,
  Activity,
  Send,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
}

// Convert Float32Array from microphone into 16-bit PCM base64
function floatTo16BitPCMBase64(input: Float32Array): string {
  const buffer = new ArrayBuffer(input.length * 2);
  const view = new DataView(buffer);
  for (let i = 0; i < input.length; i++) {
    // Clamp between -1 and 1
    const s = Math.max(-1, Math.min(1, input[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunkSize)));
  }
  return btoa(binary);
}

// Convert base64 PCM 24kHz to AudioBuffer
function base64PCMToAudioBuffer(base64: string, ctx: AudioContext): AudioBuffer {
  const binary = atob(base64);
  const len = binary.length / 2;
  const buffer = ctx.createBuffer(1, len, 24000);
  const channelData = buffer.getChannelData(0);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const view = new DataView(bytes.buffer);
  for (let i = 0; i < len; i++) {
    const int16 = view.getInt16(i * 2, true);
    channelData[i] = int16 / 32768.0;
  }
  return buffer;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  userName,
}) => {
  const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'listening' | 'speaking'>('disconnected');
  const [isMuted, setIsMuted] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [typedMessage, setTypedMessage] = useState('');
  const [conversationLog, setConversationLog] = useState<{ sender: 'user' | 'model'; text: string; time: string }[]>([]);

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const isMutedRef = useRef(isMuted);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  // Start live session when modal opens
  useEffect(() => {
    if (isOpen) {
      startSession();
    } else {
      stopSession();
    }
    return () => {
      stopSession();
    };
  }, [isOpen]);

  const stopAudioPlayback = () => {
    activeSourcesRef.current.forEach((src) => {
      try {
        src.stop();
      } catch {
        // Source might already have stopped
      }
    });
    activeSourcesRef.current = [];
    if (outputAudioCtxRef.current) {
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
  };

  const startSession = async () => {
    setErrorMsg(null);
    setStatus('connecting');

    try {
      // 1. Microphone access & 16kHz context
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      const inputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 16000,
      });
      inputAudioCtxRef.current = inputAudioCtx;

      // 2. Output 24kHz context for Gemini Live playback
      const outputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 24000,
      });
      outputAudioCtxRef.current = outputAudioCtx;
      nextStartTimeRef.current = outputAudioCtx.currentTime;

      // 3. Connect WebSocket to server
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live-ws`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setStatus('connected');
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'connected') {
            setStatus('listening');
          } else if (msg.type === 'audio' && msg.audio) {
            setStatus('speaking');
            playAudioChunk(msg.audio);
          } else if (msg.type === 'interrupted') {
            stopAudioPlayback();
            setStatus('listening');
          } else if (msg.type === 'turnComplete') {
            setTimeout(() => {
              if (wsRef.current?.readyState === WebSocket.OPEN) {
                setStatus('listening');
              }
            }, 600);
          } else if (msg.type === 'error') {
            setErrorMsg(msg.error || 'Erro no canal do Gemini Live.');
            setStatus('disconnected');
          }
        } catch (e) {
          console.error('Error handling live message:', e);
        }
      };

      ws.onerror = (e) => {
        console.error('Live WS error:', e);
        setErrorMsg('Não foi possível conectar ao servidor de voz.');
        setStatus('disconnected');
      };

      ws.onclose = () => {
        setStatus('disconnected');
      };

      // 4. Audio processor
      const source = inputAudioCtx.createMediaStreamSource(stream);
      const processor = inputAudioCtx.createScriptProcessor(2048, 1, 1);
      processorRef.current = processor;

      processor.onaudioprocess = (e) => {
        if (isMutedRef.current) return;
        if (wsRef.current?.readyState !== WebSocket.OPEN) return;

        const inputData = e.inputBuffer.getChannelData(0);
        // Quick volume check to avoid sending complete silence
        let maxVal = 0;
        for (let i = 0; i < inputData.length; i++) {
          const abs = Math.abs(inputData[i]);
          if (abs > maxVal) maxVal = abs;
        }

        if (maxVal > 0.005) {
          const base64Pcm = floatTo16BitPCMBase64(inputData);
          wsRef.current.send(JSON.stringify({ audio: base64Pcm }));
        }
      };

      source.connect(processor);
      processor.connect(inputAudioCtx.destination);
    } catch (err) {
      console.error('Error starting live session:', err);
      setErrorMsg(
        err instanceof Error && err.name === 'NotAllowedError'
          ? 'Permissão de microfone negada. Conceda acesso ao microfone no navegador.'
          : 'Falha ao iniciar conversa de voz. Verifique suas permissões.'
      );
      setStatus('disconnected');
    }
  };

  const playAudioChunk = (base64Audio: string) => {
    if (!outputAudioCtxRef.current) return;
    const ctx = outputAudioCtxRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    try {
      const buffer = base64PCMToAudioBuffer(base64Audio, ctx);
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);

      const currentTime = ctx.currentTime;
      const startTime = Math.max(currentTime, nextStartTimeRef.current);
      source.start(startTime);
      nextStartTimeRef.current = startTime + buffer.duration;

      activeSourcesRef.current.push(source);
      source.onended = () => {
        const idx = activeSourcesRef.current.indexOf(source);
        if (idx !== -1) {
          activeSourcesRef.current.splice(idx, 1);
        }
        if (activeSourcesRef.current.length === 0 && wsRef.current?.readyState === WebSocket.OPEN) {
          setStatus('listening');
        }
      };
    } catch (err) {
      console.error('Audio playback error:', err);
    }
  };

  const stopSession = () => {
    stopAudioPlayback();

    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch {}
      processorRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      inputAudioCtxRef.current.close().catch(() => {});
      inputAudioCtxRef.current = null;
    }

    if (outputAudioCtxRef.current) {
      outputAudioCtxRef.current.close().catch(() => {});
      outputAudioCtxRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    setStatus('disconnected');
  };

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedMessage.trim() || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

    wsRef.current.send(JSON.stringify({ text: typedMessage.trim() }));
    setConversationLog((prev) => [
      ...prev,
      {
        sender: 'user',
        text: typedMessage.trim(),
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setTypedMessage('');
  };

  const handleQuickPrompt = (text: string) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(JSON.stringify({ text }));
    setConversationLog((prev) => [
      ...prev,
      {
        sender: 'user',
        text,
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 99999,
        background: 'rgba(5, 8, 22, 0.85)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '540px',
          background: 'linear-gradient(180deg, rgba(15, 23, 42, 0.95), rgba(10, 14, 39, 0.98))',
          border: '1px solid rgba(56, 189, 248, 0.25)',
          borderRadius: '1.5rem',
          boxShadow: '0 25px 60px rgba(0, 0, 0, 0.7), 0 0 40px rgba(56, 189, 248, 0.15)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: '1.2rem 1.4rem',
            borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'rgba(255, 255, 255, 0.02)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div
              style={{
                width: '38px',
                height: '38px',
                borderRadius: '10px',
                background: 'linear-gradient(135deg, #0284C7, #06B6D4)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fff',
                boxShadow: '0 4px 14px rgba(6, 182, 212, 0.3)',
              }}
            >
              <Zap size={20} />
            </div>
            <div>
              <div style={{ fontSize: '1.05rem', fontWeight: 700, color: '#fff', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                Alicerce Voz
                <span
                  style={{
                    fontSize: '0.65rem',
                    background: 'rgba(56, 189, 248, 0.18)',
                    color: '#38BDF8',
                    padding: '0.15rem 0.45rem',
                    borderRadius: '999px',
                    fontWeight: 600,
                  }}
                >
                  Live API · gemini-3.8-live
                </span>
              </div>
              <div style={{ fontSize: '0.75rem', color: 'rgba(255, 255, 255, 0.55)' }}>
                Conversa por voz em tempo real {userName ? `com ${userName}` : ''}
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            style={{
              background: 'rgba(255, 255, 255, 0.06)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '50%',
              width: '34px',
              height: '34px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'rgba(255, 255, 255, 0.7)',
              cursor: 'pointer',
            }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Error notice */}
        {errorMsg && (
          <div
            style={{
              margin: '1rem 1.4rem 0',
              padding: '0.8rem 1rem',
              borderRadius: '0.75rem',
              background: 'rgba(239, 68, 68, 0.15)',
              border: '1px solid rgba(239, 68, 68, 0.35)',
              color: '#FCA5A5',
              fontSize: '0.82rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '0.5rem',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <AlertCircle size={16} />
              <span>{errorMsg}</span>
            </div>
            <button
              onClick={startSession}
              style={{
                background: 'rgba(239, 68, 68, 0.25)',
                border: 'none',
                color: '#fff',
                padding: '0.25rem 0.6rem',
                borderRadius: '6px',
                fontSize: '0.75rem',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.3rem',
              }}
            >
              <RotateCcw size={12} /> Tentar novamente
            </button>
          </div>
        )}

        {/* Visualizer & Orb area */}
        <div
          style={{
            padding: '2.5rem 1.5rem 1.5rem',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'relative',
          }}
        >
          {/* Animated Glowing Orb */}
          <div
            style={{
              position: 'relative',
              width: '130px',
              height: '130px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {/* Outer pulse wave */}
            <div
              style={{
                position: 'absolute',
                inset: status === 'speaking' ? '-18px' : status === 'listening' ? '-8px' : '0px',
                borderRadius: '50%',
                background:
                  status === 'speaking'
                    ? 'radial-gradient(circle, rgba(14, 165, 233, 0.4) 0%, rgba(99, 102, 241, 0.15) 70%, transparent 100%)'
                    : status === 'listening'
                    ? 'radial-gradient(circle, rgba(34, 197, 94, 0.35) 0%, rgba(56, 189, 248, 0.1) 70%, transparent 100%)'
                    : 'rgba(255, 255, 255, 0.05)',
                transition: 'all 0.3s ease',
                filter: 'blur(8px)',
              }}
            />

            {/* Core Orb */}
            <div
              style={{
                width: '100px',
                height: '100px',
                borderRadius: '50%',
                background:
                  status === 'speaking'
                    ? 'linear-gradient(135deg, #0284C7, #8B5CF6)'
                    : status === 'listening'
                    ? 'linear-gradient(135deg, #059669, #0284C7)'
                    : 'linear-gradient(135deg, #334155, #1E293B)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow:
                  status === 'speaking'
                    ? '0 0 35px rgba(14, 165, 233, 0.7), inset 0 0 20px rgba(255, 255, 255, 0.3)'
                    : status === 'listening'
                    ? '0 0 30px rgba(34, 197, 94, 0.6), inset 0 0 15px rgba(255, 255, 255, 0.3)'
                    : 'none',
                position: 'relative',
                zIndex: 2,
                transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
              }}
            >
              {status === 'speaking' ? (
                <Volume2 size={42} color="#fff" />
              ) : status === 'listening' ? (
                <Mic size={42} color="#fff" />
              ) : (
                <Activity size={36} color="rgba(255, 255, 255, 0.5)" />
              )}
            </div>
          </div>

          {/* Status Label */}
          <div style={{ marginTop: '1.2rem', textAlign: 'center' }}>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.45rem',
                padding: '0.35rem 0.9rem',
                borderRadius: '999px',
                fontSize: '0.85rem',
                fontWeight: 600,
                background:
                  status === 'speaking'
                    ? 'rgba(14, 165, 233, 0.15)'
                    : status === 'listening'
                    ? 'rgba(34, 197, 94, 0.15)'
                    : 'rgba(255, 255, 255, 0.08)',
                color:
                  status === 'speaking'
                    ? '#38BDF8'
                    : status === 'listening'
                    ? '#4ADE80'
                    : 'rgba(255, 255, 255, 0.7)',
                border:
                  status === 'speaking'
                    ? '1px solid rgba(56, 189, 248, 0.3)'
                    : status === 'listening'
                    ? '1px solid rgba(74, 222, 128, 0.3)'
                    : '1px solid rgba(255, 255, 255, 0.1)',
              }}
            >
              <span
                style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background:
                    status === 'speaking'
                      ? '#38BDF8'
                      : status === 'listening'
                      ? '#4ADE80'
                      : 'rgba(255, 255, 255, 0.4)',
                }}
              />
              {status === 'speaking' && 'Alicerce respondendo em voz alta...'}
              {status === 'listening' && (isMuted ? 'Microfone pausado' : 'Ouvindo você... Fale naturalmente!')}
              {status === 'connecting' && 'Conectando ao Gemini Live...'}
              {status === 'connected' && 'Iniciando áudio...'}
              {status === 'disconnected' && 'Sessão desconectada'}
            </div>
            <p
              style={{
                fontSize: '0.78rem',
                color: 'rgba(255, 255, 255, 0.5)',
                marginTop: '0.4rem',
                maxWidth: '340px',
              }}
            >
              Você pode falar sobre seus gastos, o treino do dia, metas financeiras ou pedir conselhos de foco e constância.
            </p>
          </div>

          {/* Controls: Mute & Interrupt */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginTop: '1rem' }}>
            <button
              onClick={() => setIsMuted((prev) => !prev)}
              style={{
                background: isMuted ? 'rgba(239, 68, 68, 0.2)' : 'rgba(255, 255, 255, 0.08)',
                border: `1px solid ${isMuted ? 'rgba(239, 68, 68, 0.4)' : 'rgba(255, 255, 255, 0.15)'}`,
                color: isMuted ? '#FCA5A5' : '#fff',
                padding: '0.5rem 1rem',
                borderRadius: '0.75rem',
                fontSize: '0.82rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
                cursor: 'pointer',
              }}
            >
              {isMuted ? <MicOff size={16} /> : <Mic size={16} />}
              {isMuted ? 'Ativar Mic' : 'Mudar para Mudo'}
            </button>

            {status === 'speaking' && (
              <button
                onClick={stopAudioPlayback}
                style={{
                  background: 'rgba(245, 158, 11, 0.18)',
                  border: '1px solid rgba(245, 158, 11, 0.35)',
                  color: '#FDE047',
                  padding: '0.5rem 1rem',
                  borderRadius: '0.75rem',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Interromper
              </button>
            )}
          </div>
        </div>

        {/* Quick prompt chips */}
        <div style={{ padding: '0 1.4rem 0.8rem' }}>
          <div style={{ fontSize: '0.72rem', color: 'rgba(255, 255, 255, 0.45)', marginBottom: '0.4rem', fontWeight: 600 }}>
            Sugestões para perguntar:
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
            {[
              'Dê uma dica para meu treino de hoje',
              'Como manter o foco nos gastos este mês?',
              'Preciso de motivação para vencer o desânimo',
              'Como dividir melhor o treino de musculação?',
            ].map((chip) => (
              <button
                key={chip}
                onClick={() => handleQuickPrompt(chip)}
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '999px',
                  padding: '0.3rem 0.7rem',
                  fontSize: '0.74rem',
                  color: 'rgba(255, 255, 255, 0.8)',
                  cursor: 'pointer',
                  textAlign: 'left',
                }}
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* Text fallback input */}
        <form
          onSubmit={handleSendText}
          style={{
            padding: '0.8rem 1.4rem 1.2rem',
            borderTop: '1px solid rgba(255, 255, 255, 0.08)',
            display: 'flex',
            gap: '0.5rem',
          }}
        >
          <input
            type="text"
            value={typedMessage}
            onChange={(e) => setTypedMessage(e.target.value)}
            placeholder="Ou digite uma mensagem para o Alicerce Voz..."
            style={{
              flex: 1,
              background: 'rgba(255, 255, 255, 0.05)',
              border: '1px solid rgba(255, 255, 255, 0.12)',
              borderRadius: '0.75rem',
              padding: '0.65rem 0.9rem',
              color: '#fff',
              fontSize: '0.85rem',
              outline: 'none',
            }}
          />
          <button
            type="submit"
            disabled={!typedMessage.trim()}
            style={{
              background: typedMessage.trim() ? '#0284C7' : 'rgba(255, 255, 255, 0.1)',
              border: 'none',
              borderRadius: '0.75rem',
              padding: '0 1rem',
              color: '#fff',
              cursor: typedMessage.trim() ? 'pointer' : 'not-allowed',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Send size={16} />
          </button>
        </form>
      </div>
    </div>
  );
};
