import React, { useState } from 'react';
import {
  TIPS_SECTIONS,
  genId,
  getDayOfYearIndex,
  getTodayISO,
} from '../utils/constants';
import { ProductiveTask } from '../types';
import {
  CheckIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  PlusIcon,
  SparklesIcon,
  TrashIcon,
} from './Icons';

interface DicasViewProps {
  productiveTasks: ProductiveTask[];
  setProductiveTasks: React.Dispatch<React.SetStateAction<ProductiveTask[]>>;
}

export const DicasView: React.FC<DicasViewProps> = ({
  productiveTasks,
  setProductiveTasks,
}) => {
  const [expandedMap, setExpandedMap] = useState<Record<string, boolean>>({
    orcamento: true,
  });
  const [newTaskText, setNewTaskText] = useState('');

  const todayIso = getTodayISO();
  const completedCount = productiveTasks.filter((task) =>
    (task.doneDates || []).includes(todayIso)
  ).length;

  const pct = productiveTasks.length
    ? Math.round((completedCount / productiveTasks.length) * 100)
    : 0;

  function handleToggleTask(id: string) {
    setProductiveTasks(
      productiveTasks.map((t) => {
        if (t.id !== id) return t;
        const done = t.doneDates || [];
        const isDone = done.includes(todayIso);
        return {
          ...t,
          doneDates: isDone
            ? done.filter((d) => d !== todayIso)
            : [...done, todayIso],
        };
      })
    );
  }

  function handleAddTask(e: React.FormEvent) {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    setProductiveTasks([
      ...productiveTasks,
      {
        id: genId(),
        text: newTaskText.trim(),
        doneDates: [],
      },
    ]);
    setNewTaskText('');
  }

  function handleDeleteTask(id: string) {
    setProductiveTasks(productiveTasks.filter((t) => t.id !== id));
  }

  return (
    <div>
      <h2 className="section-title">Painel produtivo</h2>

      {/* Daily productive tasks card */}
      <div className="prod-card">
        <div className="prod-head">
          <span>
            Hoje ·{' '}
            {new Date().toLocaleDateString('pt-BR', {
              day: '2-digit',
              month: '2-digit',
            })}
          </span>
          <span className="prod-pct">{pct}%</span>
        </div>

        <div
          className="bar"
          style={{
            display: 'flex',
            height: '9px',
            borderRadius: '5px',
            overflow: 'hidden',
            background: 'rgba(255,255,255,0.1)',
          }}
        >
          <div
            style={{
              width: `${pct}%`,
              background: 'linear-gradient(90deg, #F59E0B, #FDE047)',
            }}
          />
        </div>

        <div className="prod-list">
          {productiveTasks.map((task) => {
            const isDone = (task.doneDates || []).includes(todayIso);
            return (
              <div className="prod-item" key={task.id}>
                <button
                  type="button"
                  className={`prod-check ${isDone ? 'done' : ''}`}
                  onClick={() => handleToggleTask(task.id)}
                >
                  {isDone && <CheckIcon size={13} color="#fff" />}
                </button>
                <span className={`prod-text ${isDone ? 'done' : ''}`}>
                  {task.text}
                </span>
                <button
                  type="button"
                  className="icon-btn"
                  onClick={() => handleDeleteTask(task.id)}
                >
                  <TrashIcon size={13} />
                </button>
              </div>
            );
          })}
        </div>

        <form
          className="field-row"
          style={{ marginTop: '0.6rem' }}
          onSubmit={handleAddTask}
        >
          <input
            placeholder="Nova tarefa do dia"
            value={newTaskText}
            onChange={(e) => setNewTaskText(e.target.value)}
          />
          <button
            className="btn-add"
            style={{ width: 'auto', padding: '0.5rem 0.7rem' }}
            type="submit"
          >
            <PlusIcon size={16} />
          </button>
        </form>
      </div>

      <h2 className="section-title" style={{ marginTop: '1.1rem' }}>
        Dicas para melhorar orçamento e vida pessoal
      </h2>

      <div className="accordion-grid">
        {TIPS_SECTIONS.map((section) => {
          const isHabitos = section.id === 'habitos';
          const tipOfDay = isHabitos
            ? section.tips[getDayOfYearIndex(section.tips.length)]
            : null;
          const isExpanded = !!expandedMap[section.id];

          return (
            <div className="accordion-item" key={section.id}>
              <button
                type="button"
                className="accordion-head"
                onClick={() =>
                  setExpandedMap((prev) => ({
                    ...prev,
                    [section.id]: !prev[section.id],
                  }))
                }
              >
                <span className="t" style={{ color: section.color }}>
                  {section.title}
                  {isHabitos ? ' · dica do dia' : ''}
                </span>
                {isExpanded ? (
                  <ChevronUpIcon size={17} color={section.color} />
                ) : (
                  <ChevronDownIcon size={17} color={section.color} />
                )}
              </button>

              {isExpanded && (
                <div className="accordion-body">
                  {isHabitos ? (
                    <p className="habit-of-day">
                      <SparklesIcon size={14} color={section.color} />{' '}
                      {tipOfDay}
                    </p>
                  ) : (
                    <ul>
                      {section.tips.map((tip, idx) => (
                        <li key={idx}>{tip}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
