import React from 'react';
import { InvestmentsView, InvestmentsViewProps } from './InvestmentsView';

export type FinanceInvestmentsTabProps = InvestmentsViewProps;

export const FinanceInvestmentsTab: React.FC<FinanceInvestmentsTabProps> = (props) => {
  return <InvestmentsView {...props} />;
};
