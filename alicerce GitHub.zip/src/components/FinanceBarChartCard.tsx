import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { BarChart3, PieChart as PieChartIcon, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Transaction } from '../types';

export type ChartPeriodFilter = 'mes' | 'ano' | 'total';
export type ChartViewType = 'bar' | 'pie';

interface FinanceBarChartCardProps {
  transactions?: Transaction[];
  hideValues?: boolean;
  formatMoney?: (val: number) => string;
}

interface ChartItem {
  period: string;
  entradas: number;
  saidas: number;
}

// Fallback / standard mock datasets as specified in requirements
const MOCK_CHART_DATA: Record<ChartPeriodFilter, ChartItem[]> = {
  mes: [
    { period: 'Semana 1', entradas: 1500, saidas: 800 },
    { period: 'Semana 2', entradas: 1200, saidas: 950 },
    { period: 'Semana 3', entradas: 1800, saidas: 1100 },
    { period: 'Semana 4', entradas: 1500, saidas: 950 },
  ],
  ano: [
    { period: 'Jan', entradas: 5000, saidas: 3500 },
    { period: 'Fev', entradas: 5200, saidas: 3800 },
    { period: 'Mar', entradas: 4800, saidas: 3200 },
    { period: 'Abr', entradas: 5300, saidas: 3600 },
    { period: 'Mai', entradas: 4900, saidas: 3100 },
    { period: 'Jun', entradas: 5600, saidas: 3900 },
    { period: 'Jul', entradas: 5100, saidas: 3400 },
    { period: 'Ago', entradas: 5400, saidas: 3700 },
    { period: 'Set', entradas: 5800, saidas: 3800 },
    { period: 'Out', entradas: 5200, saidas: 3500 },
    { period: 'Nov', entradas: 6100, saidas: 4200 },
    { period: 'Dez', entradas: 7200, saidas: 5100 },
  ],
  total: [
    { period: '2024', entradas: 58000, saidas: 41000 },
    { period: '2025', entradas: 64000, saidas: 45000 },
    { period: '2026', entradas: 42000, saidas: 28000 },
  ],
};

const MONTH_LABELS = [
  'Jan',
  'Fev',
  'Mar',
  'Abr',
  'Mai',
  'Jun',
  'Jul',
  'Ago',
  'Set',
  'Out',
  'Nov',
  'Dez',
];

export const FinanceBarChartCard: React.FC<FinanceBarChartCardProps> = ({
  transactions = [],
  hideValues = false,
  formatMoney,
}) => {
  // Period filter state: 'mes' | 'ano' | 'total'
  const [selectedPeriod, setSelectedPeriod] = useState<ChartPeriodFilter>('mes');
  // Chart visual type: 'bar' (Barras) vs. 'pie' (Pizza / Donut)
  const [chartView, setChartView] = useState<ChartViewType>('bar');

  // Format currency helper
  const fmt = (val: number): string => {
    if (hideValues) return 'R$ •••••';
    if (formatMoney) return formatMoney(val);
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  // Dynamic Dataset calculation based on transactions with fallback to mock data
  const chartData = useMemo<ChartItem[]>(() => {
    if (!transactions || transactions.length === 0) {
      return MOCK_CHART_DATA[selectedPeriod];
    }

    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    if (selectedPeriod === 'mes') {
      const weeks: Record<string, { entradas: number; saidas: number }> = {
        'Semana 1': { entradas: 0, saidas: 0 },
        'Semana 2': { entradas: 0, saidas: 0 },
        'Semana 3': { entradas: 0, saidas: 0 },
        'Semana 4': { entradas: 0, saidas: 0 },
      };

      let hasMonthTx = false;
      const targetPrefix = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}`;

      transactions.forEach((t) => {
        if (!t.date || !t.date.startsWith(targetPrefix)) return;
        hasMonthTx = true;
        const day = parseInt(t.date.split('-')[2] || '1', 10);
        let weekKey = 'Semana 4';
        if (day <= 7) weekKey = 'Semana 1';
        else if (day <= 14) weekKey = 'Semana 2';
        else if (day <= 21) weekKey = 'Semana 3';

        if (t.type === 'entrada') {
          weeks[weekKey].entradas += t.value;
        } else {
          weeks[weekKey].saidas += t.value;
        }
      });

      if (hasMonthTx) {
        return Object.entries(weeks).map(([period, data]) => ({
          period,
          entradas: data.entradas,
          saidas: data.saidas,
        }));
      }
      return MOCK_CHART_DATA.mes;
    }

    if (selectedPeriod === 'ano') {
      const monthsData: Record<number, { entradas: number; saidas: number }> = {};
      for (let i = 0; i < 12; i++) {
        monthsData[i] = { entradas: 0, saidas: 0 };
      }

      let hasYearTx = false;
      const yearPrefix = `${currentYear}-`;

      transactions.forEach((t) => {
        if (!t.date || !t.date.startsWith(yearPrefix)) return;
        hasYearTx = true;
        const monthNum = parseInt(t.date.split('-')[1] || '1', 10) - 1;
        if (monthNum >= 0 && monthNum < 12) {
          if (t.type === 'entrada') {
            monthsData[monthNum].entradas += t.value;
          } else {
            monthsData[monthNum].saidas += t.value;
          }
        }
      });

      if (hasYearTx) {
        return MONTH_LABELS.map((label, idx) => ({
          period: label,
          entradas: monthsData[idx]?.entradas || 0,
          saidas: monthsData[idx]?.saidas || 0,
        }));
      }
      return MOCK_CHART_DATA.ano;
    }

    // 'total': Acumulado histórico agrupado por anos
    const yearsMap: Record<string, { entradas: number; saidas: number }> = {};
    let hasTx = false;

    transactions.forEach((t) => {
      if (!t.date) return;
      hasTx = true;
      const yr = t.date.split('-')[0] || String(currentYear);
      if (!yearsMap[yr]) {
        yearsMap[yr] = { entradas: 0, saidas: 0 };
      }
      if (t.type === 'entrada') {
        yearsMap[yr].entradas += t.value;
      } else {
        yearsMap[yr].saidas += t.value;
      }
    });

    const sortedYears = Object.keys(yearsMap).sort();
    if (hasTx && sortedYears.length >= 2) {
      return sortedYears.map((yr) => ({
        period: yr,
        entradas: yearsMap[yr].entradas,
        saidas: yearsMap[yr].saidas,
      }));
    }

    return MOCK_CHART_DATA.total;
  }, [transactions, selectedPeriod]);

  // Aggregate totals for the active view
  const { totalEntradas, totalSaidas, saldoPeriodo, totalMovimentado } = useMemo(() => {
    let ent = 0;
    let sai = 0;
    chartData.forEach((item) => {
      ent += item.entradas;
      sai += item.saidas;
    });
    return {
      totalEntradas: ent,
      totalSaidas: sai,
      saldoPeriodo: ent - sai,
      totalMovimentado: ent + sai,
    };
  }, [chartData]);

  // Pie Chart distribution data (Entradas vs Saídas)
  const pieData = useMemo(() => {
    if (totalMovimentado === 0) return [];
    const entPct = Math.round((totalEntradas / totalMovimentado) * 100);
    const saiPct = 100 - entPct;
    return [
      {
        name: 'Entradas (Receitas)',
        value: totalEntradas,
        color: '#22C55E',
        pct: entPct,
      },
      {
        name: 'Saídas (Despesas)',
        value: totalSaidas,
        color: '#EF4444',
        pct: saiPct,
      },
    ];
  }, [totalEntradas, totalSaidas, totalMovimentado]);

  // Period subtitle description
  const periodDescription = useMemo(() => {
    switch (selectedPeriod) {
      case 'mes':
        return 'Comparação semana a semana (Mês Atual)';
      case 'ano':
        return 'Comparação mês a mês (12 Meses)';
      case 'total':
        return 'Acumulado histórico consolidado por ano';
    }
  }, [selectedPeriod]);

  return (
    <div
      id="finance-bar-chart-card"
      style={{
        background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
        border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
        borderRadius: '1.15rem',
        padding: '1rem',
        boxShadow: 'var(--card-shadow, 0 10px 30px rgba(0, 0, 0, 0.25))',
        backdropFilter: 'blur(12px)',
        display: 'flex',
        flexDirection: 'column',
        gap: '0.85rem',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <style>{`
        /* Segmented Button Group Styling */
        .chart-ctrl-btn {
          padding: 0.28rem 0.65rem;
          border-radius: 0.55rem;
          font-size: 0.72rem;
          font-weight: 600;
          border: 1px solid transparent;
          background: transparent;
          color: var(--ink-soft, #94A3B8);
          cursor: pointer;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          white-space: nowrap;
          display: inline-flex;
          align-items: center;
          gap: 0.3rem;
          user-select: none;
        }
        .chart-ctrl-btn:hover {
          color: var(--ink, #FFFFFF);
          background: rgba(255, 255, 255, 0.06);
        }
        .chart-ctrl-btn.active {
          background: var(--active, #3B82F6);
          color: #FFFFFF;
          border-color: var(--active, #3B82F6);
          box-shadow: 0 2px 10px var(--active-glow, rgba(6, 182, 212, 0.35));
        }

        /* ⚡ Cyberpunk Theme - Glow em Verde Neon */
        .theme-cyberpunk .chart-ctrl-btn.active {
          background: rgba(0, 255, 102, 0.16) !important;
          border-color: #00FF66 !important;
          color: #00FF66 !important;
          box-shadow: 0 0 14px rgba(0, 255, 102, 0.5), inset 0 0 8px rgba(0, 255, 102, 0.2) !important;
        }

        /* ☀️ Modo Claro - Fundo Escuro / Slate */
        .theme-light .chart-ctrl-btn.active {
          background: #0F172A !important;
          border-color: #0F172A !important;
          color: #FFFFFF !important;
          box-shadow: 0 4px 12px rgba(15, 23, 42, 0.25) !important;
        }

        /* 👑 Luxury Theme - Amber/Gold */
        .theme-luxury .chart-ctrl-btn.active {
          background: #1C1917 !important;
          border-color: #D97706 !important;
          color: #FBBF24 !important;
          box-shadow: 0 3px 12px rgba(217, 119, 6, 0.3) !important;
        }
      `}</style>

      {/* 1. Header do Card: Título à esquerda & Seletores (Tipo de Gráfico + Período) à direita */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.65rem',
        }}
      >
        {/* Lado Esquerdo: Ícone + Título */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '0.65rem',
              background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(6, 182, 212, 0.2))',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--active, #06B6D4)',
              flexShrink: 0,
            }}
          >
            {chartView === 'bar' ? <BarChart3 size={17} /> : <PieChartIcon size={17} />}
          </div>
          <div>
            <h3
              style={{
                margin: 0,
                fontSize: '0.9rem',
                fontWeight: 700,
                fontFamily: 'var(--font-display)',
                color: 'var(--ink, #FFFFFF)',
                display: 'flex',
                alignItems: 'center',
                gap: '0.35rem',
              }}
            >
              <span>{chartView === 'bar' ? 'Entradas vs. Saídas' : 'Distribuição Proporcional'}</span>
            </h3>
            <span
              style={{
                fontSize: '0.66rem',
                color: 'var(--ink-soft, #94A3B8)',
                display: 'block',
              }}
            >
              {periodDescription}
            </span>
          </div>
        </div>

        {/* Lado Direito: Grupo de Controles (Tipo de Visualização + Filtro de Período) */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '0.45rem',
          }}
        >
          {/* Seletor Discreto: Barras | Pizza */}
          <div
            id="chart-type-selector"
            role="tablist"
            aria-label="Tipo de Visualização do Gráfico"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              background: 'var(--panel, rgba(0, 0, 0, 0.25))',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
              borderRadius: '0.75rem',
              padding: '0.2rem',
              gap: '0.15rem',
            }}
          >
            <button
              type="button"
              role="tab"
              id="chart-type-bar"
              aria-selected={chartView === 'bar'}
              onClick={() => setChartView('bar')}
              className={`chart-ctrl-btn ${chartView === 'bar' ? 'active' : ''}`}
              title="Gráfico de Barras"
            >
              <BarChart3 size={13} />
              <span>Barras</span>
            </button>
            <button
              type="button"
              role="tab"
              id="chart-type-pie"
              aria-selected={chartView === 'pie'}
              onClick={() => setChartView('pie')}
              className={`chart-ctrl-btn ${chartView === 'pie' ? 'active' : ''}`}
              title="Gráfico de Pizza / Donut"
            >
              <PieChartIcon size={13} />
              <span>Pizza</span>
            </button>
          </div>

          {/* Seletor de Período: Mês | Ano | Total */}
          <div
            id="chart-period-selector"
            role="tablist"
            aria-label="Filtro de período do gráfico"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              background: 'var(--panel, rgba(0, 0, 0, 0.25))',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
              borderRadius: '0.75rem',
              padding: '0.2rem',
              gap: '0.15rem',
            }}
          >
            <button
              type="button"
              role="tab"
              id="chart-tab-mes"
              aria-selected={selectedPeriod === 'mes'}
              onClick={() => setSelectedPeriod('mes')}
              className={`chart-ctrl-btn ${selectedPeriod === 'mes' ? 'active' : ''}`}
            >
              Mês
            </button>
            <button
              type="button"
              role="tab"
              id="chart-tab-ano"
              aria-selected={selectedPeriod === 'ano'}
              onClick={() => setSelectedPeriod('ano')}
              className={`chart-ctrl-btn ${selectedPeriod === 'ano' ? 'active' : ''}`}
            >
              Ano
            </button>
            <button
              type="button"
              role="tab"
              id="chart-tab-total"
              aria-selected={selectedPeriod === 'total'}
              onClick={() => setSelectedPeriod('total')}
              className={`chart-ctrl-btn ${selectedPeriod === 'total' ? 'active' : ''}`}
            >
              Total
            </button>
          </div>
        </div>
      </div>

      {/* 2. Barra de Resumo Rápido de Valores do Período */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.5rem',
          padding: '0.45rem 0.75rem',
          background: 'var(--panel-strong, rgba(255, 255, 255, 0.03))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.07))',
          borderRadius: '0.75rem',
          fontSize: '0.72rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem', flexWrap: 'wrap' }}>
          {/* Entradas */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                background: 'var(--green, #22C55E)',
                boxShadow: '0 0 6px rgba(34, 197, 94, 0.5)',
              }}
            />
            <span style={{ color: 'var(--ink-soft, #94A3B8)' }}>Receitas:</span>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontWeight: 700,
                color: 'var(--green, #22C55E)',
              }}
            >
              {fmt(totalEntradas)}
            </span>
          </div>

          {/* Saídas */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                background: 'var(--red, #EF4444)',
                boxShadow: '0 0 6px rgba(239, 68, 68, 0.5)',
              }}
            />
            <span style={{ color: 'var(--ink-soft, #94A3B8)' }}>Despesas:</span>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontWeight: 700,
                color: 'var(--red, #EF4444)',
              }}
            >
              {fmt(totalSaidas)}
            </span>
          </div>
        </div>

        {/* Saldo Líquido do Período */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <span style={{ color: 'var(--ink-soft, #94A3B8)' }}>Saldo:</span>
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontWeight: 700,
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.2rem',
              color: saldoPeriodo >= 0 ? 'var(--green, #22C55E)' : 'var(--red, #EF4444)',
            }}
          >
            {saldoPeriodo >= 0 ? (
              <ArrowUpRight size={13} />
            ) : (
              <ArrowDownRight size={13} />
            )}
            {fmt(saldoPeriodo)}
          </span>
        </div>
      </div>

      {/* 3. Área Gráfica (Alternância entre Barras e Pizza) */}
      <div style={{ width: '100%', height: 230, position: 'relative', marginTop: '0.2rem' }}>
        {chartView === 'pie' ? (
          // VISUALIZAÇÃO EM PIZZA / DONUT
          totalMovimentado === 0 ? (
            <div
              style={{
                height: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--ink-soft, #94A3B8)',
                fontSize: '0.8rem',
              }}
            >
              Sem movimentações no período selecionado.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--panel-strong, #0F1434)',
                    borderColor: 'var(--line, rgba(255, 255, 255, 0.15))',
                    borderRadius: '0.75rem',
                    fontSize: '0.74rem',
                    color: 'var(--ink, #F3F5FF)',
                    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.35)',
                    backdropFilter: 'blur(10px)',
                  }}
                  itemStyle={{ color: 'var(--ink, #F3F5FF)' }}
                  formatter={(value: any, name: any) => [
                    `${fmt(Number(value) || 0)} (${
                      totalMovimentado > 0
                        ? Math.round(((Number(value) || 0) / totalMovimentado) * 100)
                        : 0
                    }%)`,
                    name,
                  ]}
                />
                <Legend
                  wrapperStyle={{ fontSize: '0.72rem', paddingTop: '4px' }}
                  formatter={(value, entry: any) => {
                    const pct = entry?.payload?.pct ?? 0;
                    return (
                      <span style={{ color: 'var(--ink, #FFFFFF)', fontWeight: 600, marginRight: '0.5rem' }}>
                        {value} <span style={{ opacity: 0.7 }}>({pct}%)</span>
                      </span>
                    );
                  }}
                />
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="45%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                  animationDuration={650}
                  stroke="var(--panel, rgba(15, 23, 42, 0.8))"
                  strokeWidth={2}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`slice-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          )
        ) : (
          // VISUALIZAÇÃO EM BARRAS (PADRÃO)
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 12, right: 8, left: -18, bottom: 2 }}
              barGap={4}
            >
              <defs>
                <linearGradient id="barGradEntradas" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22C55E" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#15803D" stopOpacity={0.65} />
                </linearGradient>
                <linearGradient id="barGradSaidas" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#EF4444" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#B91C1C" stopOpacity={0.65} />
                </linearGradient>
              </defs>

              <CartesianGrid
                strokeDasharray="3 3"
                stroke="var(--line, rgba(255, 255, 255, 0.07))"
                vertical={false}
              />

              <XAxis
                dataKey="period"
                stroke="var(--ink-soft, #6C769E)"
                fontSize={11}
                tickLine={false}
                axisLine={{ stroke: 'var(--line, rgba(255, 255, 255, 0.1))' }}
              />

              <YAxis
                stroke="var(--ink-soft, #6C769E)"
                fontSize={10}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => {
                  if (hideValues) return '••••';
                  if (val >= 1000000) return `${(val / 1000000).toFixed(1)}M`;
                  if (val >= 1000) return `${(val / 1000).toFixed(0)}k`;
                  return `${val}`;
                }}
              />

              <Tooltip
                cursor={{ fill: 'rgba(255, 255, 255, 0.04)' }}
                contentStyle={{
                  backgroundColor: 'var(--panel-strong, #0F1434)',
                  borderColor: 'var(--line, rgba(255, 255, 255, 0.15))',
                  borderRadius: '0.75rem',
                  fontSize: '0.74rem',
                  color: 'var(--ink, #F3F5FF)',
                  boxShadow: '0 8px 24px rgba(0, 0, 0, 0.35)',
                  backdropFilter: 'blur(10px)',
                }}
                itemStyle={{ color: 'var(--ink, #F3F5FF)' }}
                labelStyle={{ color: 'var(--ink, #F3F5FF)', fontWeight: 700, marginBottom: '0.2rem' }}
                formatter={(value: any, name: any) => [
                  fmt(Number(value) || 0),
                  name === 'entradas' ? 'Receitas' : 'Despesas',
                ]}
                labelFormatter={(label) => `Período: ${label}`}
              />

              <Legend
                wrapperStyle={{ fontSize: '0.72rem', paddingTop: '8px' }}
                formatter={(value) => (
                  <span style={{ color: 'var(--ink, #FFFFFF)', fontWeight: 600 }}>
                    {value === 'entradas' ? 'Receitas (Entradas)' : 'Despesas (Saídas)'}
                  </span>
                )}
              />

              <Bar
                dataKey="entradas"
                name="entradas"
                fill="url(#barGradEntradas)"
                radius={[4, 4, 0, 0]}
                maxBarSize={selectedPeriod === 'ano' ? 18 : 28}
                animationDuration={650}
              />

              <Bar
                dataKey="saidas"
                name="saidas"
                fill="url(#barGradSaidas)"
                radius={[4, 4, 0, 0]}
                maxBarSize={selectedPeriod === 'ano' ? 18 : 28}
                animationDuration={650}
              />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};
