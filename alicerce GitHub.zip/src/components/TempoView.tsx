import React, { useMemo } from 'react';
import {
  NIGHT_WEATHER_STYLE,
  WEEKDAYS_SHORT,
  getWeatherConditionInfo,
} from '../utils/constants';
import { WeatherState } from '../types';
import {
  DropletsIcon,
  LoaderIcon,
  NavigationIcon,
  SearchIcon,
  SunriseIcon,
  SunsetIcon,
  ThermometerIcon,
  WindIcon,
} from './Icons';

interface TempoViewProps {
  weather: WeatherState;
  setWeather: React.Dispatch<React.SetStateAction<WeatherState>>;
  onClose?: () => void;
  hideTitle?: boolean;
}

export const TempoView: React.FC<TempoViewProps> = ({
  weather,
  setWeather,
  onClose,
  hideTitle = false,
}) => {
  const { city, data, loading, error, recent } = weather;

  async function fetchForecast(
    lat: number,
    lon: number,
    cityName: string,
    admin1?: string
  ) {
    setWeather((prev) => ({
      ...prev,
      loading: true,
      error: null,
      data: null,
    }));
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&hourly=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code,sunrise,sunset&timezone=auto`;
      const res = await fetch(url);
      const json = await res.json();
      setWeather((prev) => ({
        ...prev,
        loading: false,
        data: {
          name: cityName,
          admin1,
          current: json.current,
          daily: json.daily,
          hourly: json.hourly,
        },
      }));
    } catch {
      setWeather((prev) => ({
        ...prev,
        loading: false,
        error:
          'Não foi possível buscar a previsão agora. Tente novamente.',
      }));
    }
  }

  async function handleSearch(
    e?: React.FormEvent,
    overrideCity?: string
  ) {
    if (e && e.preventDefault) e.preventDefault();
    const query = (overrideCity || city).trim();
    if (!query) return;

    setWeather((prev) => ({
      ...prev,
      loading: true,
      error: null,
      data: null,
    }));

    try {
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
        query
      )}&count=1&language=pt&format=json`;
      const geoRes = await fetch(geoUrl);
      const geoData = await geoRes.json();

      if (!geoData.results || geoData.results.length === 0) {
        throw new Error('Cidade não encontrada. Tente outro nome.');
      }

      const { latitude, longitude, name: cityName, admin1 } =
        geoData.results[0];

      setWeather((prev) => ({
        ...prev,
        recent: [
          cityName,
          ...prev.recent.filter((c) => c !== cityName),
        ].slice(0, 4),
      }));

      await fetchForecast(latitude, longitude, cityName, admin1);
    } catch (err: unknown) {
      const msg =
        err instanceof Error ? err.message : 'Não foi possível buscar a previsão agora.';
      setWeather((prev) => ({
        ...prev,
        loading: false,
        error: msg,
      }));
    }
  }

  function handleUseGeolocation() {
    if (!navigator.geolocation) {
      setWeather((prev) => ({
        ...prev,
        error: 'Geolocalização não é suportada neste navegador.',
      }));
      return;
    }

    setWeather((prev) => ({
      ...prev,
      loading: true,
      error: null,
      data: null,
    }));

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        let cityName = 'Sua localização';
        let admin1 = '';

        try {
          const revUrl = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=pt`;
          const revRes = await fetch(revUrl);
          const revData = await revRes.json();
          cityName = revData.city || revData.locality || cityName;
          admin1 = revData.principalSubdivision || '';
        } catch {
          // fallback to default
        }

        fetchForecast(latitude, longitude, cityName, admin1);
      },
      () => {
        setWeather((prev) => ({
          ...prev,
          loading: false,
          error: 'Não foi possível obter sua localização.',
        }));
      },
      { timeout: 8000 }
    );
  }

  const condInfo = data
    ? getWeatherConditionInfo(data.current.weather_code)
    : null;

  const isNight = useMemo(() => {
    if (!data) return false;
    const now = Date.now();
    const sunrise = new Date(data.daily.sunrise[0]).getTime();
    const sunset = new Date(data.daily.sunset[0]).getTime();
    return now < sunrise || now > sunset;
  }, [data]);

  const activeTheme = isNight ? NIGHT_WEATHER_STYLE : condInfo;

  const hourlySlice = useMemo(() => {
    if (!data) return [];
    const now = Date.now();
    const idx = data.hourly.time.findIndex(
      (t) => new Date(t).getTime() >= now
    );
    const startIdx = idx === -1 ? 0 : idx;
    return data.hourly.time.slice(startIdx, startIdx + 6).map((time, i) => ({
      time,
      temp: data.hourly.temperature_2m[startIdx + i],
      code: data.hourly.weather_code[startIdx + i],
    }));
  }, [data]);

  return (
    <div>
      {!hideTitle && (
        <div className="section-row">
          <h2 className="section-title" style={{ margin: 0 }}>
            Previsão do tempo
          </h2>
          {onClose && (
            <button
              type="button"
              className="link-btn"
              onClick={onClose}
              style={{ color: 'var(--ink-soft)' }}
            >
              Fechar
            </button>
          )}
        </div>
      )}

      {hideTitle && onClose && (
        <div className="section-row" style={{ justifyContent: 'flex-end', marginBottom: '0.4rem' }}>
          <button
            type="button"
            className="link-btn"
            onClick={onClose}
            style={{ color: 'var(--ink-soft)' }}
          >
            Fechar previsão
          </button>
        </div>
      )}

      <form className="weather-search" onSubmit={handleSearch}>
        <input
          placeholder="Nome da cidade"
          value={city}
          onChange={(e) =>
            setWeather((prev) => ({ ...prev, city: e.target.value }))
          }
        />
        <button
          className="btn-add"
          style={{ width: 'auto', padding: '0.55rem 0.7rem' }}
          type="submit"
        >
          <SearchIcon size={16} />
        </button>
        <button
          type="button"
          className="btn-add"
          style={{
            width: 'auto',
            padding: '0.55rem 0.7rem',
            background: 'linear-gradient(135deg, #64748B, #334155)',
          }}
          onClick={handleUseGeolocation}
        >
          <NavigationIcon size={16} />
        </button>
      </form>

      {recent.length > 0 && (
        <div className="chip-row">
          {recent.map((cityName) => (
            <button
              key={cityName}
              type="button"
              className="chip"
              onClick={() => handleSearch(undefined, cityName)}
            >
              {cityName}
            </button>
          ))}
        </div>
      )}

      {loading && (
        <div
          className="empty"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            fontStyle: 'normal',
          }}
        >
          <LoaderIcon size={16} className="spin" /> Buscando previsão...
        </div>
      )}

      {error && !loading && (
        <div className="empty" style={{ color: 'var(--red)' }}>
          {error}
        </div>
      )}

      {data && !loading && !error && condInfo && activeTheme && (
        <>
          <div
            className="weather-card"
            style={{
              background: `linear-gradient(160deg, ${activeTheme.g1}, ${activeTheme.g2})`,
            }}
          >
            <div className="weather-city">
              {data.name}
              {data.admin1 ? `, ${data.admin1}` : ''}
            </div>

            <span className="weather-icon-anim">
              <condInfo.Icon size={50} color={activeTheme.color} />
            </span>

            <div className="weather-temp">
              {Math.round(data.current.temperature_2m)}°
            </div>

            <div>
              {condInfo.label}
              {isNight ? ' · Noite' : ''}
            </div>

            <div className="weather-chips">
              <div className="w-chip">
                <ThermometerIcon size={14} /> Sensação{' '}
                {Math.round(data.current.apparent_temperature)}°
              </div>
              <div className="w-chip">
                <DropletsIcon size={14} />{' '}
                {data.current.relative_humidity_2m}%
              </div>
              <div className="w-chip">
                <WindIcon size={14} />{' '}
                {Math.round(data.current.wind_speed_10m)} km/h
              </div>
            </div>

            <div className="weather-meta">
              <span>
                Máx {Math.round(data.daily.temperature_2m_max[0])}° / Mín{' '}
                {Math.round(data.daily.temperature_2m_min[0])}°
              </span>
            </div>

            <div className="sun-row">
              <span>
                <SunriseIcon size={14} />{' '}
                {new Date(data.daily.sunrise[0]).toLocaleTimeString(
                  'pt-BR',
                  { hour: '2-digit', minute: '2-digit' }
                )}
              </span>
              <span>
                <SunsetIcon size={14} />{' '}
                {new Date(data.daily.sunset[0]).toLocaleTimeString(
                  'pt-BR',
                  { hour: '2-digit', minute: '2-digit' }
                )}
              </span>
            </div>
          </div>

          {/* Hourly forecast */}
          {hourlySlice.length > 0 && (
            <div className="hours-scroll">
              {hourlySlice.map((item) => {
                const hourCond = getWeatherConditionInfo(item.code);
                const HourIcon = hourCond.Icon;
                return (
                  <div className="hour-card" key={item.time}>
                    <div className="hour-lbl">
                      {new Date(item.time).toLocaleTimeString('pt-BR', {
                        hour: '2-digit',
                      })}
                    </div>
                    <HourIcon size={18} color={hourCond.color} />
                    <div className="hour-temp">
                      {Math.round(item.temp)}°
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Daily forecast */}
          <div
            className="section-title"
            style={{ fontSize: '0.85rem', marginTop: '0.9rem' }}
          >
            Próximos dias
          </div>

          <div className="days-list">
            {data.daily.temperature_2m_max.slice(0, 5).map((maxTemp, idx) => {
              const dayCond = getWeatherConditionInfo(
                data.daily.weather_code[idx]
              );
              const DayIcon = dayCond.Icon;
              const dateObj = new Date(data.daily.sunrise[idx]);

              return (
                <div className="day-row" key={idx}>
                  <span className="day-name">
                    {idx === 0 ? 'Hoje' : WEEKDAYS_SHORT[dateObj.getDay()]}
                  </span>
                  <DayIcon size={17} color={dayCond.color} />
                  <span className="day-minmax">
                    <b>{Math.round(maxTemp)}°</b> /{' '}
                    {Math.round(data.daily.temperature_2m_min[idx])}°
                  </span>
                </div>
              );
            })}
          </div>
        </>
      )}

      {!data && !loading && !error && (
        <div className="empty">
          Digite uma cidade ou toque no ícone de localização para ver a previsão
          atual.
        </div>
      )}
    </div>
  );
};
