import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  Layers,
  Trash2,
  Edit2,
  Plus,
  X,
  Check,
  Eye,
  EyeOff,
  Filter,
} from 'lucide-react';
import { Investment } from '../types';
import {
  INVESTMENT_TYPES,
  INVESTMENT_INSTITUTIONS,
  getTodayISO,
  genId,
} from '../utils/constants';

export interface InvestmentsViewProps {
  investments: Investment[];
  setInvestments: React.Dispatch<React.SetStateAction<Investment[]>>;
  hideValues: boolean;
  formatMoney: (val: number) => string;
  onToggleHideValues?: () => void;
}

// Cores para as classes de ativos
const CLASS_COLORS: Record<string, { color: string; label: string }> = {
  'Renda Fixa': { color: '#22C55E', label: 'Renda Fixa' },
  'Fundos Imobiliários': { color: '#EC4899', label: 'FIIs' },
  Cripto: { color: '#F59E0B', label: 'Cripto' },
  Ações: { color: '#3B82F6', label: 'Ações' },
  'Tesouro Direto': { color: '#06B6D4', label: 'Tesouro' },
  Fundos: { color: '#8B5CF6', label: 'Fundos' },
  Outro: { color: '#64748B', label: 'Outro' },
};

export const InvestmentsView: React.FC<InvestmentsViewProps> = ({
  investments,
  setInvestments,
  hideValues,
  formatMoney,
  onToggleHideValues,
}) => {
  // Modais
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Investment | null>(null);

  // Filtro de classe de ativos
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('Todas');

  // Gerenciamento dinâmico de bancos/instituições
  const [customInstitutions, setCustomInstitutions] = useState<string[]>(() => {
    try {
      const s = localStorage.getItem('alicerce_custom_institutions');
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  const allInstitutions = useMemo(() => {
    const combined = [...INVESTMENT_INSTITUTIONS, ...customInstitutions];
    return Array.from(new Set(combined.filter(Boolean)));
  }, [customInstitutions]);

  const [isAddingNewBank, setIsAddingNewBank] = useState(false);
  const [newBankInput, setNewBankInput] = useState('');

  // Formulário (Novo / Editar)
  const [formName, setFormName] = useState('');
  const [formDate, setFormDate] = useState(getTodayISO());
  const [formBank, setFormBank] = useState(INVESTMENT_INSTITUTIONS[0]);
  const [formType, setFormType] = useState(INVESTMENT_TYPES[0]);
  const [formValue, setFormValue] = useState('');
  const [formYield, setFormYield] = useState('100% CDI');

  // Total Investido
  const totalInvestido = useMemo(() => {
    return investments.reduce((acc, item) => acc + (item.value || 0), 0);
  }, [investments]);

  // Alocação por classe de ativos
  const allocationByClass = useMemo(() => {
    if (totalInvestido === 0) return [];
    const classMap: Record<string, number> = {};

    investments.forEach((item) => {
      const type = item.type || 'Outro';
      classMap[type] = (classMap[type] || 0) + item.value;
    });

    return Object.entries(classMap)
      .map(([type, value]) => {
        const pct = Math.round((value / totalInvestido) * 100);
        const config = CLASS_COLORS[type] || CLASS_COLORS['Outro'];
        return {
          type,
          value,
          pct,
          color: config.color,
        };
      })
      .sort((a, b) => b.value - a.value);
  }, [investments, totalInvestido]);

  // Ativos filtrados para exibição limpa
  const filteredInvestments = useMemo(() => {
    if (selectedClassFilter === 'Todas') return investments;
    return investments.filter((item) => (item.type || 'Outro') === selectedClassFilter);
  }, [investments, selectedClassFilter]);

  // Formatador de data: "DD/MM/AAAA"
  const formatDateDisplay = (dateStr?: string) => {
    if (!dateStr) return '20/09/2026';
    const clean = dateStr.split('T')[0];
    const parts = clean.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateStr;
  };

  // Abrir Modal de Edição
  const handleOpenEdit = (item: Investment) => {
    setEditingItem(item);
    setFormName(item.name);
    setFormDate(item.date ? item.date.split('T')[0] : getTodayISO());
    setFormBank(item.institution || INVESTMENT_INSTITUTIONS[0]);
    setFormType(item.type || INVESTMENT_TYPES[0]);
    setFormValue(String(item.value));
    setFormYield(item.yieldRate || '100% CDI');
    setIsAddingNewBank(false);
    setNewBankInput('');
    setIsAddModalOpen(true);
  };

  // Abrir Modal de Criação
  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormName('');
    setFormDate(getTodayISO());
    setFormBank(INVESTMENT_INSTITUTIONS[0]);
    setFormType(INVESTMENT_TYPES[0]);
    setFormValue('');
    setFormYield('100% CDI');
    setIsAddingNewBank(false);
    setNewBankInput('');
    setIsAddModalOpen(true);
  };

  // Cadastrar nova instituição dinamicamente
  const handleAddNewBank = () => {
    const trimmed = newBankInput.trim();
    if (!trimmed) return;
    if (!allInstitutions.includes(trimmed)) {
      const updated = [...customInstitutions, trimmed];
      setCustomInstitutions(updated);
      try {
        localStorage.setItem('alicerce_custom_institutions', JSON.stringify(updated));
      } catch {
        // ignore
      }
    }
    setFormBank(trimmed);
    setNewBankInput('');
    setIsAddingNewBank(false);
  };

  // Excluir ativo
  const handleDelete = (id: string) => {
    setInvestments((prev) => prev.filter((item) => item.id !== id));
  };

  // Salvar (Novo ou Edição)
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedValue = parseFloat(formValue.replace(',', '.')) || 0;
    if (!formName.trim() || parsedValue <= 0) return;
    const finalDate = formDate || getTodayISO();

    if (editingItem) {
      setInvestments((prev) =>
        prev.map((item) =>
          item.id === editingItem.id
            ? {
                ...item,
                name: formName.trim(),
                institution: formBank,
                type: formType,
                value: parsedValue,
                yieldRate: formYield.trim() || '100% CDI',
                date: finalDate,
              }
            : item
        )
      );
    } else {
      const newItem: Investment = {
        id: genId(),
        name: formName.trim(),
        institution: formBank,
        type: formType,
        value: parsedValue,
        yieldRate: formYield.trim() || '100% CDI',
        date: finalDate,
      };
      setInvestments((prev) => [newItem, ...prev]);
    }

    setIsAddModalOpen(false);
  };

  // Classes existentes para o filtro
  const availableClasses = useMemo(() => {
    const set = new Set<string>();
    investments.forEach((i) => {
      if (i.type) set.add(i.type);
    });
    return ['Todas', ...Array.from(set)];
  }, [investments]);

  return (
    <div
      id="investments-view-container"
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '0.9rem',
        width: '100%',
        color: 'var(--ink, #FFFFFF)',
      }}
    >
      {/* 1. AÇÕES RÁPIDAS EXCLUSIVAS DE INVESTIMENTOS */}
      <div
        id="invest-quick-actions-bar"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '2.5rem',
          padding: '0.85rem 1rem',
          background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
          borderRadius: '1.1rem',
          backdropFilter: 'blur(16px)',
          boxShadow: 'var(--card-shadow, 0 6px 22px rgba(0, 0, 0, 0.25))',
          transition: 'all 0.25s ease',
        }}
      >
        {/* Botão: Investir (Novo Aporte) */}
        <button
          type="button"
          id="btn-investir-top"
          onClick={handleOpenAdd}
          className="group"
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '0.35rem',
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: 0,
          }}
        >
          <div
            style={{
              width: '48px',
              height: '48px',
              borderRadius: '50%',
              background: 'var(--green, #22C55E)',
              color: '#FFFFFF',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 14px rgba(34, 197, 94, 0.38)',
              transition: 'transform 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
            }}
            className="group-hover:scale-105"
          >
            <TrendingUp size={22} />
          </div>
          <span
            style={{
              fontSize: '0.74rem',
              fontWeight: 700,
              fontFamily: 'var(--font-display)',
              color: 'var(--ink, #FFFFFF)',
            }}
          >
            Investir
          </span>
        </button>

        {/* Botão: Resumo da Carteira */}
        <button
          type="button"
          id="btn-resumo-invest-top"
          onClick={() => setIsSummaryModalOpen(true)}
          className="group"
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '0.35rem',
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: 0,
          }}
        >
          <div
            style={{
              width: '48px',
              height: '48px',
              borderRadius: '50%',
              background: 'var(--active, #6366F1)',
              color: '#FFFFFF',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 14px var(--active-glow, rgba(99, 102, 241, 0.38))',
              transition: 'transform 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
            }}
            className="group-hover:scale-105"
          >
            <Layers size={22} />
          </div>
          <span
            style={{
              fontSize: '0.74rem',
              fontWeight: 700,
              fontFamily: 'var(--font-display)',
              color: 'var(--ink, #FFFFFF)',
            }}
          >
            Resumo
          </span>
        </button>

        {/* Botão: Ocultar / Mostrar Valores (Privacidade) */}
        {onToggleHideValues && (
          <button
            type="button"
            id="btn-hide-values-invest-top"
            onClick={onToggleHideValues}
            className="group"
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.35rem',
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            <div
              style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                color: 'var(--ink, #FFFFFF)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'transform 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
              className="group-hover:scale-105"
            >
              {hideValues ? <EyeOff size={20} /> : <Eye size={20} />}
            </div>
            <span
              style={{
                fontSize: '0.74rem',
                fontWeight: 700,
                fontFamily: 'var(--font-display)',
                color: 'var(--ink-soft, #94A3B8)',
              }}
            >
              {hideValues ? 'Exibir' : 'Ocultar'}
            </span>
          </button>
        )}
      </div>

      {/* 2. CARD HERO: Patrimônio Investido */}
      <div
        id="card-patrimonio-investido"
        style={{
          background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
          borderRadius: '1.1rem',
          padding: '1.15rem 1.25rem',
          boxShadow: 'var(--card-shadow, 0 6px 24px rgba(0, 0, 0, 0.25))',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.85rem',
          backdropFilter: 'blur(14px)',
          transition: 'all 0.25s ease',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div>
            <span
              style={{
                fontSize: '0.68rem',
                fontWeight: 700,
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                color: 'var(--ink-soft, #94A3B8)',
                fontFamily: 'var(--font-mono)',
              }}
            >
              Patrimônio Investido
            </span>
            <h2
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '2rem',
                fontWeight: 800,
                letterSpacing: '-0.02em',
                color: 'var(--ink, #FFFFFF)',
                margin: '0.2rem 0',
                lineHeight: 1.15,
              }}
            >
              {hideValues ? 'R$ ••••••' : formatMoney(totalInvestido)}
            </h2>
          </div>

          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.3rem',
              fontSize: '0.7rem',
              fontWeight: 700,
              color: 'var(--green, #22C55E)',
              background: 'rgba(34, 197, 94, 0.12)',
              border: '1px solid rgba(34, 197, 94, 0.28)',
              padding: '0.22rem 0.65rem',
              borderRadius: '999px',
            }}
          >
            +13.2% a.a. (Média)
          </span>
        </div>

        {/* Barras de alocação por classe */}
        <div
          style={{
            paddingTop: '0.75rem',
            borderTop: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.5rem',
          }}
        >
          {allocationByClass.length > 0 ? (
            <>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontSize: '0.7rem',
                  color: 'var(--ink-soft, #94A3B8)',
                  flexWrap: 'wrap',
                  gap: '0.5rem',
                }}
              >
                {allocationByClass.slice(0, 4).map((item) => (
                  <span key={item.type} style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
                    <span
                      style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        backgroundColor: item.color,
                      }}
                    />
                    {item.type} ({item.pct}%)
                  </span>
                ))}
              </div>
              <div
                style={{
                  width: '100%',
                  height: '8px',
                  borderRadius: '999px',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                  overflow: 'hidden',
                  display: 'flex',
                }}
              >
                {allocationByClass.map((item) => (
                  <div
                    key={item.type}
                    style={{
                      width: `${item.pct}%`,
                      height: '100%',
                      backgroundColor: item.color,
                      transition: 'width 0.4s ease',
                    }}
                    title={`${item.type}: ${item.pct}%`}
                  />
                ))}
              </div>
            </>
          ) : (
            <div style={{ fontSize: '0.72rem', color: 'var(--ink-soft, #94A3B8)', padding: '0.2rem 0' }}>
              Nenhum ativo alocado no momento.
            </div>
          )}
        </div>
      </div>

      {/* 3. FILTRO DE CLASSE (SE HOUVER MAIS DE 1 CLASSE) */}
      {availableClasses.length > 2 && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            overflowX: 'auto',
            padding: '0.1rem 0',
            scrollbarWidth: 'none',
          }}
        >
          <Filter size={13} style={{ color: 'var(--ink-soft)', flexShrink: 0 }} />
          {availableClasses.map((cls) => {
            const isSelected = selectedClassFilter === cls;
            return (
              <button
                key={cls}
                type="button"
                onClick={() => setSelectedClassFilter(cls)}
                style={{
                  fontSize: '0.68rem',
                  fontWeight: isSelected ? 700 : 500,
                  padding: '0.2rem 0.6rem',
                  borderRadius: '999px',
                  background: isSelected
                    ? 'var(--active, #3B82F6)'
                    : 'var(--input-bg, rgba(255, 255, 255, 0.05))',
                  border: isSelected
                    ? '1px solid transparent'
                    : '1px solid var(--line, rgba(255, 255, 255, 0.1))',
                  color: isSelected ? '#FFFFFF' : 'var(--ink-soft, #94A3B8)',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  transition: 'all 0.18s ease',
                }}
              >
                {cls}
              </button>
            );
          })}
        </div>
      )}

      {/* 4. LISTA DE ATIVOS ("Seus Ativos") */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 0.25rem',
          }}
        >
          <h3
            style={{
              fontSize: '0.72rem',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              color: 'var(--ink-soft, #94A3B8)',
              margin: 0,
            }}
          >
            Seus Ativos ({filteredInvestments.length})
          </h3>
          <button
            type="button"
            onClick={handleOpenAdd}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.25rem',
              fontSize: '0.72rem',
              fontWeight: 700,
              color: 'var(--active, #06B6D4)',
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: '0.2rem 0.4rem',
              borderRadius: '0.4rem',
            }}
          >
            <Plus size={14} />
            Novo Ativo
          </button>
        </div>

        {filteredInvestments.length === 0 ? (
          <div
            style={{
              padding: '1.5rem',
              textAlign: 'center',
              fontSize: '0.76rem',
              color: 'var(--ink-soft, #94A3B8)',
              borderRadius: '0.9rem',
              background: 'var(--panel, rgba(255, 255, 255, 0.03))',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
            }}
          >
            {selectedClassFilter === 'Todas'
              ? 'Você ainda não cadastrou nenhum ativo. Clique em "Investir" para começar.'
              : `Nenhum ativo encontrado na categoria "${selectedClassFilter}".`}
          </div>
        ) : (
          filteredInvestments.map((item) => (
            <div
              key={item.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '0.8rem 1rem',
                borderRadius: '0.9rem',
                background: 'var(--panel, rgba(255, 255, 255, 0.04))',
                border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
                boxShadow: 'var(--card-shadow, 0 2px 10px rgba(0, 0, 0, 0.15))',
                transition: 'border-color 0.2s ease, transform 0.2s ease',
              }}
            >
              {/* Lado Esquerdo: Nome do Ativo + Tag da Classe (Sem nome de banco) */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span
                    style={{
                      fontWeight: 700,
                      fontSize: '0.92rem',
                      color: 'var(--ink, #FFFFFF)',
                    }}
                  >
                    {item.name}
                  </span>
                  <span
                    style={{
                      fontSize: '0.64rem',
                      fontWeight: 700,
                      padding: '0.12rem 0.5rem',
                      borderRadius: '0.35rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                      border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                      color: 'var(--ink-soft, #94A3B8)',
                    }}
                  >
                    {item.type || 'Renda Fixa'}
                  </span>
                </div>
                <div
                  style={{
                    fontSize: '0.72rem',
                    color: 'var(--ink-soft, #94A3B8)',
                    marginTop: '0.25rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    flexWrap: 'wrap',
                  }}
                >
                  <span>
                    Aplicado:{' '}
                    <strong style={{ color: 'var(--ink, #FFFFFF)', fontFamily: 'var(--font-mono)' }}>
                      {hideValues ? 'R$ ••••••' : formatMoney(item.value)}
                    </strong>
                  </span>
                  <span>•</span>
                  <span>
                    Rendimento:{' '}
                    <strong style={{ color: 'var(--green, #22C55E)' }}>
                      {item.yieldRate || '100% CDI'}
                    </strong>
                  </span>
                </div>
              </div>

              {/* Lado Direito: Ações (Editar e Excluir) */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <button
                  type="button"
                  onClick={() => handleOpenEdit(item)}
                  style={{
                    padding: '0.4rem',
                    borderRadius: '0.45rem',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--ink-soft, #94A3B8)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'color 0.15s ease',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--ink, #FFFFFF)')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--ink-soft, #94A3B8)')}
                  title="Editar Ativo"
                >
                  <Edit2 size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(item.id)}
                  style={{
                    padding: '0.4rem',
                    borderRadius: '0.45rem',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--ink-soft, #94A3B8)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'color 0.15s ease',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--red, #EF4444)')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--ink-soft, #94A3B8)')}
                  title="Excluir Ativo"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 5. EXTRATO DE APORTES (Onde o Banco é discriminado) */}
      <div
        style={{
          paddingTop: '0.85rem',
          borderTop: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.6rem',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 0.25rem',
          }}
        >
          <h3
            style={{
              fontSize: '0.72rem',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              color: 'var(--ink-soft, #94A3B8)',
              margin: 0,
            }}
          >
            Extrato de Aportes
          </h3>
          <span
            style={{
              fontSize: '0.66rem',
              color: 'var(--ink-soft, #94A3B8)',
              fontFamily: 'var(--font-mono)',
            }}
          >
            {investments.length} {investments.length === 1 ? 'aporte' : 'aportes'}
          </span>
        </div>

        {investments.length === 0 ? (
          <div
            style={{
              padding: '1rem',
              textAlign: 'center',
              fontSize: '0.74rem',
              color: 'var(--ink-soft, #94A3B8)',
            }}
          >
            Nenhum aporte registrado.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
            {investments.map((item) => (
              <div
                key={item.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '0.6rem 0.8rem',
                  borderRadius: '0.7rem',
                  background: 'var(--panel, rgba(255, 255, 255, 0.03))',
                  border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
                  fontSize: '0.76rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                  <span
                    style={{
                      color: 'var(--ink-soft, #94A3B8)',
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.7rem',
                    }}
                  >
                    {formatDateDisplay(item.date)}
                  </span>
                  <span style={{ fontWeight: 600, color: 'var(--ink, #FFFFFF)' }}>
                    {item.name}
                  </span>
                  {/* Instituição / Banco apenas aqui no extrato detalhado */}
                  <span
                    style={{
                      fontSize: '0.62rem',
                      fontWeight: 600,
                      padding: '0.1rem 0.42rem',
                      borderRadius: '0.3rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                      border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
                      color: 'var(--ink-soft, #94A3B8)',
                    }}
                  >
                    {item.institution || 'Banco'}
                  </span>
                </div>

                <span
                  style={{
                    fontWeight: 700,
                    color: 'var(--green, #22C55E)',
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.78rem',
                  }}
                >
                  + {hideValues ? 'R$ ••••••' : formatMoney(item.value)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODAL: Investir / Editar Ativo */}
      {isAddModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 60,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1rem',
            background: 'rgba(0, 0, 0, 0.65)',
            backdropFilter: 'blur(6px)',
          }}
        >
          <div
            style={{
              width: '100%',
              maxWidth: '430px',
              background: 'var(--settings-panel-bg, #0F1433)',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.16))',
              borderRadius: '1.1rem',
              boxShadow: 'var(--card-shadow, 0 16px 40px rgba(0, 0, 0, 0.5))',
              padding: '1.25rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '1rem',
              color: 'var(--ink, #FFFFFF)',
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                paddingBottom: '0.75rem',
              }}
            >
              <h3
                style={{
                  fontSize: '0.94rem',
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.45rem',
                  margin: 0,
                }}
              >
                <TrendingUp size={18} style={{ color: 'var(--green, #22C55E)' }} />
                <span>{editingItem ? 'Editar Ativo' : 'Novo Aporte / Investimento'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: 'var(--ink-soft, #94A3B8)',
                  cursor: 'pointer',
                  padding: '0.2rem',
                  borderRadius: '50%',
                }}
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div>
                <label
                  style={{
                    display: 'block',
                    fontSize: '0.7rem',
                    fontWeight: 600,
                    color: 'var(--ink-soft, #94A3B8)',
                    marginBottom: '0.25rem',
                  }}
                >
                  Nome do Ativo
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Caixinha, CDB Sofisa, Bitcoin..."
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.55rem 0.75rem',
                    borderRadius: '0.6rem',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                    color: 'var(--ink, #FFFFFF)',
                    fontSize: '0.8rem',
                    outline: 'none',
                  }}
                />
              </div>

              {/* Data do Lançamento */}
              <div>
                <label
                  style={{
                    display: 'block',
                    fontSize: '0.7rem',
                    fontWeight: 600,
                    color: 'var(--ink-soft, #94A3B8)',
                    marginBottom: '0.25rem',
                  }}
                >
                  Data do Lançamento
                </label>
                <input
                  type="date"
                  required
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.55rem 0.75rem',
                    borderRadius: '0.6rem',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                    color: 'var(--ink, #FFFFFF)',
                    fontSize: '0.8rem',
                    outline: 'none',
                    fontFamily: 'var(--font-mono)',
                  }}
                />
              </div>

              {/* Instituição / Nome do Banco */}
              <div>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '0.25rem',
                  }}
                >
                  <label
                    style={{
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      color: 'var(--ink-soft, #94A3B8)',
                    }}
                  >
                    Instituição / Nome do Banco
                  </label>
                  {!isAddingNewBank && (
                    <button
                      type="button"
                      onClick={() => setIsAddingNewBank(true)}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: 'var(--active, #3B82F6)',
                        fontSize: '0.68rem',
                        fontWeight: 700,
                        cursor: 'pointer',
                        padding: 0,
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.2rem',
                      }}
                    >
                      <Plus size={11} />
                      <span>+ Acrescentar Novo Banco</span>
                    </button>
                  )}
                </div>

                {!isAddingNewBank ? (
                  <select
                    value={formBank}
                    onChange={(e) => {
                      if (e.target.value === '__NEW_BANK__') {
                        setIsAddingNewBank(true);
                      } else {
                        setFormBank(e.target.value);
                      }
                    }}
                    style={{
                      width: '100%',
                      padding: '0.55rem 0.75rem',
                      borderRadius: '0.6rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                      border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                      color: 'var(--ink, #FFFFFF)',
                      fontSize: '0.8rem',
                      outline: 'none',
                    }}
                  >
                    {allInstitutions.map((inst) => (
                      <option key={inst} value={inst} style={{ background: 'var(--option-bg, #0F1433)' }}>
                        {inst}
                      </option>
                    ))}
                    <option
                      value="__NEW_BANK__"
                      style={{ background: 'var(--option-bg, #0F1433)', fontWeight: 700, color: '#38BDF8' }}
                    >
                      + Acrescentar Novo Banco...
                    </option>
                  </select>
                ) : (
                  <div style={{ display: 'flex', gap: '0.35rem' }}>
                    <input
                      type="text"
                      placeholder="Nome do banco ou corretora..."
                      value={newBankInput}
                      autoFocus
                      onChange={(e) => setNewBankInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddNewBank();
                        }
                      }}
                      style={{
                        flex: 1,
                        padding: '0.55rem 0.75rem',
                        borderRadius: '0.6rem',
                        background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                        border: '1px solid var(--active, #3B82F6)',
                        color: 'var(--ink, #FFFFFF)',
                        fontSize: '0.8rem',
                        outline: 'none',
                      }}
                    />
                    <button
                      type="button"
                      onClick={handleAddNewBank}
                      disabled={!newBankInput.trim()}
                      style={{
                        padding: '0.55rem 0.75rem',
                        borderRadius: '0.6rem',
                        background: 'var(--active, #3B82F6)',
                        border: 'none',
                        color: '#FFFFFF',
                        fontSize: '0.74rem',
                        fontWeight: 700,
                        cursor: newBankInput.trim() ? 'pointer' : 'not-allowed',
                        opacity: newBankInput.trim() ? 1 : 0.6,
                        whiteSpace: 'nowrap',
                      }}
                    >
                      Salvar
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddingNewBank(false);
                        setNewBankInput('');
                      }}
                      style={{
                        padding: '0.55rem 0.6rem',
                        borderRadius: '0.6rem',
                        background: 'rgba(255, 255, 255, 0.08)',
                        border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                        color: 'var(--ink-soft, #94A3B8)',
                        cursor: 'pointer',
                      }}
                      title="Cancelar"
                    >
                      <X size={14} />
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label
                  style={{
                    display: 'block',
                    fontSize: '0.7rem',
                    fontWeight: 600,
                    color: 'var(--ink-soft, #94A3B8)',
                    marginBottom: '0.25rem',
                  }}
                >
                  Classe do Ativo
                </label>
                <select
                  value={formType}
                  onChange={(e) => setFormType(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.55rem 0.75rem',
                    borderRadius: '0.6rem',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                    color: 'var(--ink, #FFFFFF)',
                    fontSize: '0.8rem',
                    outline: 'none',
                  }}
                >
                  {INVESTMENT_TYPES.map((t) => (
                    <option key={t} value={t} style={{ background: 'var(--option-bg, #0F1433)' }}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                <div>
                  <label
                    style={{
                      display: 'block',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      color: 'var(--ink-soft, #94A3B8)',
                      marginBottom: '0.25rem',
                    }}
                  >
                    Valor Aplicado (R$)
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    placeholder="0,00"
                    value={formValue}
                    onChange={(e) => setFormValue(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.55rem 0.75rem',
                      borderRadius: '0.6rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                      border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                      color: 'var(--ink, #FFFFFF)',
                      fontSize: '0.8rem',
                      fontFamily: 'var(--font-mono)',
                      outline: 'none',
                    }}
                  />
                </div>
                <div>
                  <label
                    style={{
                      display: 'block',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      color: 'var(--ink-soft, #94A3B8)',
                      marginBottom: '0.25rem',
                    }}
                  >
                    Rendimento
                  </label>
                  <input
                    type="text"
                    placeholder="100% CDI, 12.5% a.a."
                    value={formYield}
                    onChange={(e) => setFormYield(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.55rem 0.75rem',
                      borderRadius: '0.6rem',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                      border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                      color: 'var(--ink, #FFFFFF)',
                      fontSize: '0.8rem',
                      outline: 'none',
                    }}
                  />
                </div>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  gap: '0.5rem',
                  paddingTop: '0.65rem',
                  borderTop: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                }}
              >
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  style={{
                    padding: '0.5rem 0.85rem',
                    borderRadius: '0.6rem',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.08))',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                    color: 'var(--ink-soft, #94A3B8)',
                    fontSize: '0.76rem',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '0.5rem 1rem',
                    borderRadius: '0.6rem',
                    background: 'var(--green, #22C55E)',
                    border: 'none',
                    color: '#FFFFFF',
                    fontSize: '0.76rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    boxShadow: '0 3px 10px rgba(34, 197, 94, 0.35)',
                  }}
                >
                  <Check size={14} />
                  <span>Salvar</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Resumo de Investimentos */}
      {isSummaryModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 60,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1rem',
            background: 'rgba(0, 0, 0, 0.65)',
            backdropFilter: 'blur(6px)',
          }}
        >
          <div
            style={{
              width: '100%',
              maxWidth: '430px',
              background: 'var(--settings-panel-bg, #0F1433)',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.16))',
              borderRadius: '1.1rem',
              boxShadow: 'var(--card-shadow, 0 16px 40px rgba(0, 0, 0, 0.5))',
              padding: '1.25rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '1rem',
              color: 'var(--ink, #FFFFFF)',
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                paddingBottom: '0.75rem',
              }}
            >
              <h3
                style={{
                  fontSize: '0.94rem',
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.45rem',
                  margin: 0,
                }}
              >
                <Layers size={18} style={{ color: 'var(--active, #6366F1)' }} />
                <span>Resumo Consolidado da Carteira</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsSummaryModalOpen(false)}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: 'var(--ink-soft, #94A3B8)',
                  cursor: 'pointer',
                  padding: '0.2rem',
                  borderRadius: '50%',
                }}
              >
                <X size={18} />
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
              <div
                style={{
                  padding: '0.85rem 1rem',
                  borderRadius: '0.85rem',
                  background: 'var(--panel, rgba(255, 255, 255, 0.04))',
                  border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                }}
              >
                <span style={{ fontSize: '0.68rem', color: 'var(--ink-soft, #94A3B8)', fontWeight: 600 }}>
                  Total Geral Investido
                </span>
                <div
                  style={{
                    fontSize: '1.6rem',
                    fontWeight: 800,
                    fontFamily: 'var(--font-mono)',
                    color: 'var(--active, #6366F1)',
                    marginTop: '0.2rem',
                  }}
                >
                  {hideValues ? 'R$ ••••••' : formatMoney(totalInvestido)}
                </div>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
                <span
                  style={{
                    fontSize: '0.68rem',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    color: 'var(--ink-soft, #94A3B8)',
                  }}
                >
                  Alocação de Carteira
                </span>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                  {allocationByClass.map((item) => (
                    <div
                      key={item.type}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '0.5rem 0.75rem',
                        borderRadius: '0.6rem',
                        background: 'var(--input-bg, rgba(255, 255, 255, 0.06))',
                        border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
                        fontSize: '0.76rem',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                        <span
                          style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            backgroundColor: item.color,
                          }}
                        />
                        <span style={{ fontWeight: 600 }}>{item.type}</span>
                      </div>
                      <div style={{ fontFamily: 'var(--font-mono)', color: 'var(--ink-soft, #94A3B8)' }}>
                        {hideValues ? '••••' : formatMoney(item.value)}{' '}
                        <span style={{ color: 'var(--ink, #FFFFFF)', fontWeight: 700 }}>({item.pct}%)</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', paddingTop: '0.4rem' }}>
                <button
                  type="button"
                  onClick={() => setIsSummaryModalOpen(false)}
                  style={{
                    padding: '0.5rem 1rem',
                    borderRadius: '0.6rem',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.1))',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                    color: 'var(--ink, #FFFFFF)',
                    fontSize: '0.76rem',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
