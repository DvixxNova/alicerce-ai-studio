import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { Transaction } from '../types';
import { fmtBRL, FINANCE_CATEGORIES } from '../utils/constants';
import { PieChartIcon, BarChart3Icon, TrendingUpIcon } from './Icons';

interface DashboardChartProps {
  transactions: Transaction[];
}

const MONTH_NAMES_SHORT = [
  'Jan',
  'Fev',
  'Mar',
  'Abr',
  'Mai',
  'Jun',
  'Jul',
  'Ago',
  'Set',
  'Out',
  'Nov',
  'Dez',
];

interface MonthlyFinancialData {
  monthKey: string;
  monthLabel: string;
  entradas: number;
  saidas: number;
  saldo: number;
}

interface DistributionItem {
  name: string;
  value: number;
  color: string;
  type: 'entrada' | 'saida';
  percent?: number;
}

export const DashboardChart: React.FC<DashboardChartProps> = ({ transactions }) => {
  // Toggle between 'pie' (Pizza/Rosca) and 'bar' (Barras)
  const [chartView, setChartView] = useState<'pie' | 'bar'>('pie');
  // Optional sub-filter for pie: 'tipo' (Entradas vs Saídas) or 'categorias' (Despesas por categoria)
  const [pieMode, setPieMode] = useState<'tipo' | 'categorias'>('tipo');

  // Compute last 6 months for bar comparison
  const last6Months = useMemo(() => {
    const months: { key: string; label: string }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = `${MONTH_NAMES_SHORT[d.getMonth()]}/${String(d.getFullYear()).slice(2)}`;
      months.push({ key, label });
    }
    return months;
  }, []);

  // Financial Bar Data (monthly absolute values)
  const monthlyBarData: MonthlyFinancialData[] = useMemo(() => {
    const dataMap: Record<string, { entradas: number; saidas: number }> = {};
    last6Months.forEach((m) => {
      dataMap[m.key] = { entradas: 0, saidas: 0 };
    });

    transactions.forEach((t) => {
      const ym = (t.date || '').slice(0, 7);
      if (dataMap[ym]) {
        if (t.type === 'entrada') {
          dataMap[ym].entradas += t.value;
        } else {
          dataMap[ym].saidas += t.value;
        }
      }
    });

    return last6Months.map((m) => {
      const item = dataMap[m.key];
      return {
        monthKey: m.key,
        monthLabel: m.label,
        entradas: item ? item.entradas : 0,
        saidas: item ? item.saidas : 0,
        saldo: item ? item.entradas - item.saidas : 0,
      };
    });
  }, [transactions, last6Months]);

  // Overall totals
  const { totalEntradas, totalSaidas, totalMovimentado } = useMemo(() => {
    let inc = 0;
    let exp = 0;
    transactions.forEach((t) => {
      if (t.type === 'entrada') inc += t.value;
      else exp += t.value;
    });
    return {
      totalEntradas: inc,
      totalSaidas: exp,
      totalMovimentado: inc + exp,
    };
  }, [transactions]);

  // Pie Data - Entradas vs Saídas
  const pieDataTipo: DistributionItem[] = useMemo(() => {
    if (totalMovimentado === 0) return [];
    const items: DistributionItem[] = [];
    if (totalEntradas > 0) {
      items.push({
        name: 'Entradas',
        value: totalEntradas,
        color: '#22C55E',
        type: 'entrada',
        percent: (totalEntradas / totalMovimentado) * 100,
      });
    }
    if (totalSaidas > 0) {
      items.push({
        name: 'Saídas',
        value: totalSaidas,
        color: '#F43F5E',
        type: 'saida',
        percent: (totalSaidas / totalMovimentado) * 100,
      });
    }
    return items;
  }, [totalEntradas, totalSaidas, totalMovimentado]);

  // Pie Data - Categories (Despesas por Categoria)
  const pieDataCategorias: DistributionItem[] = useMemo(() => {
    const catMap: Record<string, number> = {};
    let totalCatExpense = 0;

    transactions.forEach((t) => {
      if (t.type === 'saida') {
        const cat = t.category || 'Outros';
        catMap[cat] = (catMap[cat] || 0) + t.value;
        totalCatExpense += t.value;
      }
    });

    if (totalCatExpense === 0) return [];

    return Object.entries(catMap)
      .map(([name, value]) => ({
        name,
        value,
        color: FINANCE_CATEGORIES[name]?.color || '#94A3B8',
        type: 'saida' as const,
        percent: (value / totalCatExpense) * 100,
      }))
      .sort((a, b) => b.value - a.value);
  }, [transactions]);

  const activePieData = pieMode === 'tipo' ? pieDataTipo : pieDataCategorias;

  return (
    <div
      className="form-block fade-in"
      style={{
        marginBottom: '1rem',
        borderStyle: 'solid',
        borderColor: 'rgba(255, 255, 255, 0.12)',
        padding: '1rem',
        transition: 'all 0.3s ease',
      }}
    >
      {/* Header and Main View Selector */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '0.6rem',
          marginBottom: '0.8rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
          <div
            style={{
              width: '28px',
              height: '28px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #3B82F6, #06B6D4)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
            }}
          >
            <TrendingUpIcon size={15} />
          </div>
          <div>
            <h3
              className="section-title"
              style={{ margin: 0, fontSize: '0.95rem', color: 'var(--ink)' }}
            >
              Gráfico Financeiro
            </h3>
            <span style={{ fontSize: '0.68rem', color: 'var(--ink-soft)' }}>
              {chartView === 'pie'
                ? 'Distribuição percentual das finanças'
                : 'Comparativo mensal de valores absolutos'}
            </span>
          </div>
        </div>

        {/* View Toggle (Pizza/Rosca vs Barras) */}
        <div
          style={{
            display: 'inline-flex',
            background: 'var(--panel-strong, rgba(255,255,255,0.08))',
            borderRadius: '0.65rem',
            padding: '3px',
            border: '1px solid var(--line)',
          }}
        >
          <button
            type="button"
            onClick={() => setChartView('pie')}
            style={{
              padding: '0.35rem 0.65rem',
              fontSize: '0.7rem',
              fontWeight: 600,
              borderRadius: '0.5rem',
              border: 'none',
              background:
                chartView === 'pie'
                  ? 'linear-gradient(135deg, #3B82F6, #8B5CF6)'
                  : 'transparent',
              color: chartView === 'pie' ? '#fff' : 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
            }}
            title="Visualizar gráfico de Pizza / Rosca"
          >
            <PieChartIcon size={13} />
            Pizza / Rosca
          </button>
          <button
            type="button"
            onClick={() => setChartView('bar')}
            style={{
              padding: '0.35rem 0.65rem',
              fontSize: '0.7rem',
              fontWeight: 600,
              borderRadius: '0.5rem',
              border: 'none',
              background:
                chartView === 'bar'
                  ? 'linear-gradient(135deg, #3B82F6, #06B6D4)'
                  : 'transparent',
              color: chartView === 'bar' ? '#fff' : 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
            }}
            title="Visualizar gráfico de Barras"
          >
            <BarChart3Icon size={13} />
            Barras
          </button>
        </div>
      </div>

      {/* Sub-controls / Quick summary banner */}
      {chartView === 'pie' ? (
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.75rem',
            padding: '0.4rem 0.6rem',
            background: 'var(--panel-strong, rgba(255,255,255,0.03))',
            borderRadius: '0.6rem',
            border: '1px solid var(--line, rgba(255,255,255,0.05))',
            fontSize: '0.72rem',
          }}
        >
          <div style={{ color: 'var(--ink)' }}>
            Total:{' '}
            <strong style={{ color: 'var(--ink)' }}>{fmtBRL(totalMovimentado)}</strong>
            {totalMovimentado > 0 && (
              <span style={{ marginLeft: '0.5rem', color: 'var(--ink)' }}>
                (<span style={{ color: 'var(--green, #22C55E)', fontWeight: 600 }}>{totalMovimentado > 0 ? ((totalEntradas / totalMovimentado) * 100).toFixed(0) : 0}% Entradas</span> /{' '}
                <span style={{ color: 'var(--red, #F43F5E)', fontWeight: 600 }}>{totalMovimentado > 0 ? ((totalSaidas / totalMovimentado) * 100).toFixed(0) : 0}% Saídas</span>)
              </span>
            )}
          </div>

          {/* Sub-toggle: Por Tipo vs Por Categoria */}
          <div style={{ display: 'flex', gap: '0.25rem' }}>
            <button
              type="button"
              onClick={() => setPieMode('tipo')}
              style={{
                fontSize: '0.62rem',
                fontWeight: 600,
                padding: '0.2rem 0.45rem',
                borderRadius: '0.4rem',
                border: '1px solid var(--line)',
                background:
                  pieMode === 'tipo'
                    ? 'rgba(59, 130, 246, 0.2)'
                    : 'transparent',
                color: pieMode === 'tipo' ? 'var(--ink)' : 'var(--ink-soft)',
                cursor: 'pointer',
              }}
            >
              Entradas vs Saídas
            </button>
            <button
              type="button"
              onClick={() => setPieMode('categorias')}
              style={{
                fontSize: '0.62rem',
                fontWeight: 600,
                padding: '0.2rem 0.45rem',
                borderRadius: '0.4rem',
                border: '1px solid var(--line)',
                background:
                  pieMode === 'categorias'
                    ? 'rgba(59, 130, 246, 0.2)'
                    : 'transparent',
                color: pieMode === 'categorias' ? 'var(--ink)' : 'var(--ink-soft)',
                cursor: 'pointer',
              }}
            >
              Por Categoria
            </button>
          </div>
        </div>
      ) : (
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.75rem',
            padding: '0.4rem 0.6rem',
            background: 'var(--panel-strong, rgba(255,255,255,0.03))',
            borderRadius: '0.6rem',
            border: '1px solid var(--line, rgba(255,255,255,0.05))',
            fontSize: '0.72rem',
            color: 'var(--ink-soft)',
          }}
        >
          <span style={{ color: 'var(--ink)' }}>Comparativo mensal (últimos 6 meses)</span>
          <div style={{ display: 'flex', gap: '0.8rem' }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: 'var(--ink)' }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--green, #22C55E)' }} />
              Entradas
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: 'var(--ink)' }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--red, #F43F5E)' }} />
              Saídas
            </span>
          </div>
        </div>
      )}

      {/* Chart Canvas Area */}
      <div style={{ width: '100%', height: 230, position: 'relative' }}>
        {totalMovimentado === 0 ? (
          <div
            style={{
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem',
              color: 'var(--ink-soft)',
              fontSize: '0.82rem',
              textAlign: 'center',
            }}
          >
            <div
              style={{
                width: 44,
                height: 44,
                borderRadius: '50%',
                background: 'rgba(255,255,255,0.05)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--ink-soft)',
              }}
            >
              {chartView === 'pie' ? <PieChartIcon size={22} /> : <BarChart3Icon size={22} />}
            </div>
            <span>Nenhuma transação registrada ainda para gerar o gráfico.</span>
            <span style={{ fontSize: '0.7rem', opacity: 0.7 }}>
              Registre entradas ou saídas na aba Finanças para ver a distribuição.
            </span>
          </div>
        ) : chartView === 'pie' ? (
          // PIE / DOUGHNUT CHART
          activePieData.length === 0 ? (
            <div
              style={{
                height: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--ink-soft)',
                fontSize: '0.8rem',
              }}
            >
              Nenhuma despesa por categoria registrada no momento.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--panel-strong, #0F1434)',
                    borderColor: 'var(--line, rgba(255, 255, 255, 0.15))',
                    borderRadius: '0.75rem',
                    fontSize: '0.75rem',
                    color: 'var(--ink, #F3F5FF)',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                  }}
                  itemStyle={{ color: 'var(--ink, #F3F5FF)' }}
                  labelStyle={{ color: 'var(--ink, #F3F5FF)', fontWeight: 600 }}
                  formatter={(val: any, name: any) => {
                    const num = Number(val) || 0;
                    const totalBase =
                      pieMode === 'tipo'
                        ? totalMovimentado
                        : activePieData.reduce((a, b) => a + b.value, 0);
                    const pct = totalBase > 0 ? ((num / totalBase) * 100).toFixed(1) : '0';
                    return [`${fmtBRL(num)} (${pct}%)`, name];
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  wrapperStyle={{ fontSize: '0.72rem', paddingTop: '6px', color: 'var(--ink)' }}
                  formatter={(val: string) => {
                    const found = activePieData.find((d) => d.name === val);
                    const pct = found?.percent ? `${found.percent.toFixed(0)}%` : '';
                    return (
                      <span style={{ color: 'var(--ink)', fontWeight: 600 }}>
                        {val} {pct ? `(${pct})` : ''}
                      </span>
                    );
                  }}
                />
                <Pie
                  data={activePieData}
                  cx="50%"
                  cy="45%"
                  innerRadius={48}
                  outerRadius={75}
                  paddingAngle={3}
                  dataKey="value"
                  animationDuration={600}
                >
                  {activePieData.map((entry, index) => (
                    <Cell
                      key={`cell-${entry.name}-${index}`}
                      fill={entry.color}
                      stroke="var(--panel, rgba(10, 14, 39, 0.8))"
                      strokeWidth={2}
                    />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          )
        ) : (
          // BAR CHART
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={monthlyBarData}
              margin={{ top: 10, right: 10, left: -18, bottom: 0 }}
            >
              <defs>
                <linearGradient id="finEntradasBarGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22C55E" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#15803D" stopOpacity={0.4} />
                </linearGradient>
                <linearGradient id="finSaidasBarGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#F43F5E" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#BE123C" stopOpacity={0.4} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="var(--line, rgba(255,255,255,0.07))"
                vertical={false}
              />
              <XAxis
                dataKey="monthLabel"
                stroke="var(--ink-soft, #6C769E)"
                fontSize={11}
                tickLine={false}
              />
              <YAxis
                stroke="var(--ink-soft, #6C769E)"
                fontSize={10}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => (val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val)}
              />
              <Tooltip
                cursor={{ fill: 'rgba(99, 102, 241, 0.08)' }}
                contentStyle={{
                  backgroundColor: 'var(--panel-strong, #0F1434)',
                  borderColor: 'var(--line, rgba(255, 255, 255, 0.15))',
                  borderRadius: '0.75rem',
                  fontSize: '0.75rem',
                  color: 'var(--ink, #F3F5FF)',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                }}
                itemStyle={{ color: 'var(--ink, #F3F5FF)' }}
                labelStyle={{ color: 'var(--ink, #F3F5FF)', fontWeight: 600 }}
                formatter={(value: any, name: any) => [
                  fmtBRL(Number(value) || 0),
                  name === 'entradas' ? 'Entradas' : 'Saídas',
                ]}
                labelFormatter={(label) => `Mês: ${label}`}
              />
              <Legend
                wrapperStyle={{ fontSize: '0.72rem', paddingTop: '6px' }}
                formatter={(value) => (
                  <span style={{ color: 'var(--ink)', fontWeight: 600 }}>
                    {value === 'entradas' ? 'Entradas' : 'Saídas'}
                  </span>
                )}
              />
              <Bar
                dataKey="entradas"
                name="entradas"
                fill="url(#finEntradasBarGrad)"
                radius={[4, 4, 0, 0]}
                maxBarSize={28}
                animationDuration={600}
              />
              <Bar
                dataKey="saidas"
                name="saidas"
                fill="url(#finSaidasBarGrad)"
                radius={[4, 4, 0, 0]}
                maxBarSize={28}
                animationDuration={600}
              />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};
