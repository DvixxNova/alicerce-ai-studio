import React, { useState } from 'react';
import { ArrowDownLeft, ArrowUpRight, Trash2, ReceiptText, Search, X } from 'lucide-react';
import { Investment, Transaction } from '../types';

interface FinanceExtratoTableProps {
  transactions: Transaction[];
  investments?: Investment[];
  onDeleteTransaction: (id: string) => void;
  onDeleteInvestment?: (id: string) => void;
  hideValues?: boolean;
  formatMoney?: (val: number) => string;
}

interface ExtratoItem {
  id: string;
  source: 'transaction';
  desc: string;
  categoryOrType: string;
  date: string;
  value: number;
  type: 'entrada' | 'saida';
}

export const FinanceExtratoTable: React.FC<FinanceExtratoTableProps> = ({
  transactions = [],
  investments = [],
  onDeleteTransaction,
  onDeleteInvestment,
  hideValues = false,
  formatMoney,
}) => {
  // Format currency helper
  const fmt = (val: number): string => {
    if (hideValues) return 'R$ •••••';
    if (formatMoney) return formatMoney(val);
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  // Format date helper: returns "20/09" or "20/09 • 14:30"
  const formatExtratoDate = (dateStr?: string): string => {
    if (!dateStr) return '--/--';
    if (dateStr.includes('T')) {
      const [d, t] = dateStr.split('T');
      const parts = d.split('-');
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]} • ${t.slice(0, 5)}`;
      }
    }
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}`;
    }
    return dateStr;
  };

  // Search filter query
  const [searchQuery, setSearchQuery] = useState('');

  // Strictly transactions (Entradas e Saídas)
  const extratoItems: ExtratoItem[] = React.useMemo(() => {
    return transactions
      .map((t) => ({
        id: t.id,
        source: 'transaction' as const,
        desc: t.desc,
        categoryOrType: t.category || (t.type === 'entrada' ? 'Receita' : 'Despesa'),
        date: t.date || '',
        value: t.value,
        type: t.type,
      }))
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [transactions]);

  // Real-time filtering by description or category
  const filteredItems = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return extratoItems;
    return extratoItems.filter(
      (item) =>
        item.desc.toLowerCase().includes(q) ||
        item.categoryOrType.toLowerCase().includes(q)
    );
  }, [extratoItems, searchQuery]);

  const handleDelete = (item: ExtratoItem) => {
    onDeleteTransaction(item.id);
  };

  return (
    <div
      id="finance-extrato-container"
      style={{
        background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
        border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
        borderRadius: '1.15rem',
        padding: '0.85rem 1rem',
        boxShadow: 'var(--card-shadow, 0 8px 24px rgba(0, 0, 0, 0.2))',
        backdropFilter: 'blur(12px)',
        display: 'flex',
        flexDirection: 'column',
        gap: '0.65rem',
        overflow: 'hidden',
      }}
    >
      <style>{`
        .extrato-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0.42rem 0.5rem;
          border-bottom: 1px solid var(--line, rgba(255, 255, 255, 0.08));
          transition: background 0.15s ease;
          gap: 0.5rem;
        }
        .extrato-row:last-child {
          border-bottom: none;
        }
        .extrato-row:hover {
          background: rgba(255, 255, 255, 0.03);
        }
        .theme-light .extrato-row {
          border-bottom-color: rgba(226, 232, 240, 0.7);
        }
        .theme-light .extrato-row:hover {
          background: rgba(241, 245, 249, 0.6);
        }
        .theme-cyberpunk .extrato-row:hover {
          background: rgba(0, 255, 102, 0.05);
        }
        .delete-btn {
          opacity: 0.5;
          transition: all 0.2s ease;
        }
        .extrato-row:hover .delete-btn {
          opacity: 1;
        }
        .delete-btn:hover {
          color: var(--red, #EF4444) !important;
          background: rgba(239, 68, 68, 0.15) !important;
        }
        .extrato-search-box:focus-within {
          border-color: var(--active, #06B6D4) !important;
          box-shadow: 0 0 0 1px var(--active, #06B6D4) !important;
        }
        .theme-cyberpunk .extrato-search-box:focus-within {
          border-color: #00FF66 !important;
          box-shadow: 0 0 8px rgba(0, 255, 102, 0.35) !important;
        }
      `}</style>

      {/* Header do Extrato */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
          paddingBottom: '0.45rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
          <ReceiptText size={15} style={{ color: 'var(--active, #06B6D4)' }} />
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.74rem',
              fontWeight: 800,
              letterSpacing: '0.06em',
              textTransform: 'uppercase',
              color: 'var(--ink, #FFFFFF)',
            }}
          >
            EXTRATO DE LANÇAMENTOS
          </span>
        </div>
        <span
          style={{
            fontSize: '0.66rem',
            color: 'var(--ink-soft, #94A3B8)',
            fontFamily: 'var(--font-mono)',
          }}
        >
          {searchQuery
            ? `${filteredItems.length} de ${extratoItems.length} ${
                extratoItems.length === 1 ? 'registro' : 'registros'
              }`
            : `${extratoItems.length} ${
                extratoItems.length === 1 ? 'registro' : 'registros'
              }`}
        </span>
      </div>

      {/* Campo de Pesquisa em Tempo Real */}
      <div
        id="extrato-search-container"
        className="extrato-search-box"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.45rem',
          background: 'var(--panel, rgba(0, 0, 0, 0.22))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
          borderRadius: '0.65rem',
          padding: '0.32rem 0.65rem',
          transition: 'all 0.2s ease',
        }}
      >
        <Search size={14} style={{ color: 'var(--ink-soft, #94A3B8)', flexShrink: 0 }} />
        <input
          id="extrato-search-input"
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Pesquisar por descrição ou categoria..."
          style={{
            background: 'transparent',
            border: 'none',
            outline: 'none',
            fontSize: '0.74rem',
            color: 'var(--ink, #FFFFFF)',
            width: '100%',
            fontFamily: 'inherit',
          }}
        />
        {searchQuery && (
          <button
            type="button"
            id="extrato-search-clear"
            onClick={() => setSearchQuery('')}
            style={{
              background: 'transparent',
              border: 'none',
              padding: '2px',
              cursor: 'pointer',
              color: 'var(--ink-soft, #94A3B8)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: '50%',
            }}
            title="Limpar pesquisa"
          >
            <X size={13} />
          </button>
        )}
      </div>

      {/* Lista de Linhas Compactas */}
      {filteredItems.length === 0 ? (
        <div
          style={{
            textAlign: 'center',
            padding: '1.25rem 0.5rem',
            color: 'var(--ink-soft, #94A3B8)',
            fontSize: '0.75rem',
          }}
        >
          {searchQuery
            ? `Nenhum lançamento encontrado para "${searchQuery}"`
            : 'Nenhum lançamento registrado'}
        </div>
      ) : (
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            maxHeight: '360px',
            overflowY: 'auto',
          }}
        >
          {filteredItems.map((item) => {
            const isEntrada = item.type === 'entrada';

            // Cores do valor formatado
            const valueColor = isEntrada ? 'var(--green, #22C55E)' : 'var(--red, #EF4444)';
            const valuePrefix = isEntrada ? '+ ' : '- ';

            return (
              <div key={`${item.source}-${item.id}`} className="extrato-row">
                {/* 1. Tipo / Ícone Discreto */}
                <div
                  style={{
                    width: '22px',
                    height: '22px',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                    background: isEntrada
                      ? 'rgba(34, 197, 94, 0.15)'
                      : 'rgba(239, 68, 68, 0.15)',
                    color: isEntrada
                      ? 'var(--green, #22C55E)'
                      : 'var(--red, #EF4444)',
                  }}
                  title={isEntrada ? 'Entrada (Receita)' : 'Saída (Despesa)'}
                >
                  {isEntrada ? (
                    <ArrowDownLeft size={12} />
                  ) : (
                    <ArrowUpRight size={12} />
                  )}
                </div>

                {/* 2. Descrição / Categoria */}
                <div
                  style={{
                    flex: 1,
                    minWidth: 0,
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                  }}
                >
                  <div
                    style={{
                      fontSize: '0.78rem',
                      fontWeight: 600,
                      color: 'var(--ink, #FFFFFF)',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      lineHeight: 1.25,
                    }}
                  >
                    {item.desc}
                  </div>
                  <div
                    style={{
                      fontSize: '0.64rem',
                      color: 'var(--ink-soft, #94A3B8)',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                  >
                    {item.categoryOrType}
                  </div>
                </div>

                {/* 3. Data e Hora */}
                <div
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.67rem',
                    color: 'var(--ink-soft, #94A3B8)',
                    textAlign: 'right',
                    whiteSpace: 'nowrap',
                    flexShrink: 0,
                  }}
                >
                  {formatExtratoDate(item.date)}
                </div>

                {/* 4. Valor Formatado */}
                <div
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.78rem',
                    fontWeight: 700,
                    color: valueColor,
                    textAlign: 'right',
                    minWidth: '78px',
                    whiteSpace: 'nowrap',
                    flexShrink: 0,
                  }}
                >
                  {valuePrefix}
                  {fmt(item.value)}
                </div>

                {/* 5. Ação Rápida Discreta: Excluir */}
                <button
                  type="button"
                  className="delete-btn"
                  onClick={() => handleDelete(item)}
                  title="Excluir lançamento"
                  style={{
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '0.35rem',
                    width: '22px',
                    height: '22px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'var(--ink-soft, #94A3B8)',
                    cursor: 'pointer',
                    padding: 0,
                    flexShrink: 0,
                  }}
                >
                  <Trash2 size={12} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
