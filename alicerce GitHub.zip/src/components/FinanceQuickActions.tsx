import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  Layers,
  SlidersHorizontal,
  FileText,
  Eye,
  EyeOff,
  Calendar,
  Sparkles,
  RotateCcw,
  Sliders,
  Check,
} from 'lucide-react';

interface FinanceQuickActionsProps {
  onOpenEntrada: () => void;
  onOpenSaida: () => void;
  onOpenInvestir?: () => void;
  onOpenResumo: () => void;
  showInvestir?: boolean;
  onDownloadPDF?: () => void;
  onToggleHideValues?: () => void;
  hideValues?: boolean;
  onToggleCustomizer?: () => void;
  onResetFilters?: () => void;
}

export const FinanceQuickActions: React.FC<FinanceQuickActionsProps> = ({
  onOpenEntrada,
  onOpenSaida,
  onOpenInvestir,
  onOpenResumo,
  showInvestir = false,
  onDownloadPDF,
  onToggleHideValues,
  hideValues = false,
  onToggleCustomizer,
  onResetFilters,
}) => {
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const moreButtonRef = useRef<HTMLButtonElement>(null);

  // Close dropdown on click outside or escape key
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target as Node) &&
        moreButtonRef.current &&
        !moreButtonRef.current.contains(event.target as Node)
      ) {
        setIsMoreMenuOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsMoreMenuOpen(false);
      }
    };

    if (isMoreMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isMoreMenuOpen]);

  return (
    <div
      id="finance-quick-actions-bar"
      className="sticky top-0 z-20 backdrop-blur-md mb-6 pt-2 finance-quick-actions-wrapper"
      style={{
        width: '100%',
        background: 'var(--panel-strong, rgba(15, 23, 42, 0.85))',
        border: '1px solid var(--line, rgba(255, 255, 255, 0.14))',
        borderRadius: '1.25rem',
        padding: '0.85rem 0.75rem 0.8rem 0.75rem',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        boxShadow: 'var(--card-shadow, 0 10px 30px rgba(0, 0, 0, 0.28))',
      }}
    >
      <style>{`
        /* Quick Actions Pill Container Styling */
        .quick-action-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.5rem;
          background: transparent;
          border: none;
          cursor: pointer;
          padding: 0;
          outline: none;
          transition: transform 0.18s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .quick-action-item:active {
          transform: scale(0.92);
        }

        .quick-action-circle {
          width: 54px;
          height: 54px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.22s cubic-bezier(0.34, 1.56, 0.64, 1);
          position: relative;
          border: 1px solid rgba(255, 255, 255, 0.22);
          box-sizing: border-box;
        }

        @media (min-width: 640px) {
          .quick-action-circle {
            width: 58px;
            height: 58px;
          }
        }

        .quick-action-item:hover .quick-action-circle {
          transform: translateY(-3px) scale(1.05);
        }

        .quick-action-label {
          font-size: 0.78rem;
          font-weight: 700;
          letter-spacing: -0.01em;
          color: var(--ink, #FFFFFF);
          transition: color 0.15s ease;
          text-align: center;
          user-select: none;
        }

        /* ☀️ Light Mode: Alto Contraste */
        .theme-light .quick-action-label {
          color: #0F172A !important;
          font-weight: 800;
        }
        .theme-light .quick-action-item:hover .quick-action-label {
          color: #2563EB !important;
        }

        /* ⚡ Cyberpunk Theme: Efeito Neon Brilhante */
        .theme-cyberpunk .quick-action-circle {
          border: 1px solid rgba(0, 255, 102, 0.4) !important;
        }
        .theme-cyberpunk .quick-action-item:hover .quick-action-circle {
          box-shadow: 0 0 20px rgba(0, 255, 102, 0.6), inset 0 0 10px rgba(0, 255, 102, 0.3) !important;
        }
        .theme-cyberpunk .quick-action-label {
          color: #E2E8F0;
        }
        .theme-cyberpunk .quick-action-item:hover .quick-action-label {
          color: #00FF66 !important;
          text-shadow: 0 0 8px rgba(0, 255, 102, 0.6);
        }

        /* Gradient Glows */
        .qa-blue {
          background: linear-gradient(135deg, #00A3FF 0%, #0072E5 100%);
          box-shadow: 0 8px 20px -4px rgba(0, 163, 255, 0.45), inset 0 1px 1px rgba(255, 255, 255, 0.4);
        }
        .qa-blue:hover {
          box-shadow: 0 12px 24px -4px rgba(0, 163, 255, 0.65), inset 0 1px 1px rgba(255, 255, 255, 0.5);
        }

        .qa-coral {
          background: linear-gradient(135deg, #FF4D6D 0%, #FF6548 50%, #FF8533 100%);
          box-shadow: 0 8px 20px -4px rgba(255, 77, 109, 0.45), inset 0 1px 1px rgba(255, 255, 255, 0.4);
        }
        .qa-coral:hover {
          box-shadow: 0 12px 24px -4px rgba(255, 77, 109, 0.65), inset 0 1px 1px rgba(255, 255, 255, 0.5);
        }

        .qa-aqua {
          background: linear-gradient(135deg, #00E6A8 0%, #00B894 50%, #00A8B5 100%);
          box-shadow: 0 8px 20px -4px rgba(0, 230, 168, 0.45), inset 0 1px 1px rgba(255, 255, 255, 0.4);
        }
        .qa-aqua:hover {
          box-shadow: 0 12px 24px -4px rgba(0, 230, 168, 0.65), inset 0 1px 1px rgba(255, 255, 255, 0.5);
        }

        .qa-purple {
          background: linear-gradient(135deg, #9333EA 0%, #8A5CF6 50%, #6366F1 100%);
          box-shadow: 0 8px 20px -4px rgba(138, 92, 246, 0.45), inset 0 1px 1px rgba(255, 255, 255, 0.4);
        }
        .qa-purple:hover {
          box-shadow: 0 12px 24px -4px rgba(138, 92, 246, 0.65), inset 0 1px 1px rgba(255, 255, 255, 0.5);
        }

        .qa-slate {
          background: linear-gradient(135deg, #475569 0%, #334155 50%, #1E293B 100%);
          box-shadow: 0 8px 20px -4px rgba(51, 65, 85, 0.45), inset 0 1px 1px rgba(255, 255, 255, 0.3);
        }
        .qa-slate:hover {
          box-shadow: 0 12px 24px -4px rgba(51, 65, 85, 0.65), inset 0 1px 1px rgba(255, 255, 255, 0.4);
        }
      `}</style>

      {/* Grid of 5 Quick Action Buttons com suporte a rolagem horizontal suave em telas menores */}
      <div
        style={{
          width: '100%',
          overflowX: 'auto',
          scrollbarWidth: 'none',
          WebkitOverflowScrolling: 'touch',
        }}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: showInvestir
              ? 'repeat(5, minmax(56px, 1fr))'
              : 'repeat(4, minmax(64px, 1fr))',
            gap: '0.45rem',
            alignItems: 'center',
            justifyItems: 'center',
            minWidth: showInvestir ? '290px' : '240px',
          }}
        >
          {/* 1. Entrada (Azul com Seta para Baixo/Esquerda) */}
          <button
            type="button"
            id="btn-quick-entrada"
            onClick={onOpenEntrada}
            className="quick-action-item"
            aria-label="Registrar Nova Entrada (Receita)"
          >
            <div className="quick-action-circle qa-blue">
              <ArrowDownLeft size={24} color="#FFFFFF" strokeWidth={2.4} />
            </div>
            <span className="quick-action-label">Entrada</span>
          </button>

          {/* 2. Saída (Coral/Rosa com Seta para Cima/Direita) */}
          <button
            type="button"
            id="btn-quick-saida"
            onClick={onOpenSaida}
            className="quick-action-item"
            aria-label="Registrar Nova Saída (Despesa)"
          >
            <div className="quick-action-circle qa-coral">
              <ArrowUpRight size={24} color="#FFFFFF" strokeWidth={2.4} />
            </div>
            <span className="quick-action-label">Saída</span>
          </button>

          {/* 3. Investir (Apenas se showInvestir for ativado) */}
          {showInvestir && onOpenInvestir && (
            <button
              type="button"
              id="btn-quick-investir"
              onClick={onOpenInvestir}
              className="quick-action-item"
              aria-label="Fazer Novo Aporte ou Investimento"
            >
              <div className="quick-action-circle qa-aqua">
                <TrendingUp size={24} color="#FFFFFF" strokeWidth={2.4} />
              </div>
              <span className="quick-action-label">Investir</span>
            </button>
          )}

          {/* 4. Resumo (Roxo/Violeta com Camadas de Cards) */}
          <button
            type="button"
            id="btn-quick-resumo"
            onClick={onOpenResumo}
            className="quick-action-item"
            aria-label="Ver Balanço e Resumo Consolidado"
          >
            <div className="quick-action-circle qa-purple">
              <Layers size={24} color="#FFFFFF" strokeWidth={2.4} />
            </div>
            <span className="quick-action-label">Resumo</span>
          </button>

          {/* 5. Mais (Cinza/Grafite com Sliders de Ajuste) */}
          <button
            ref={moreButtonRef}
            type="button"
            id="btn-quick-mais"
            onClick={() => setIsMoreMenuOpen((prev) => !prev)}
            className="quick-action-item"
            aria-label="Mais Ações e Opções Financeiras"
            aria-expanded={isMoreMenuOpen}
          >
            <div className="quick-action-circle qa-slate">
              <SlidersHorizontal size={23} color="#FFFFFF" strokeWidth={2.4} />
            </div>
            <span className="quick-action-label">Mais</span>
          </button>
        </div>
      </div>

      {/* Dropdown Menu para "Mais" */}
      {isMoreMenuOpen && (
        <div
          ref={menuRef}
          id="quick-actions-more-dropdown"
          className="fade-in"
          style={{
            position: 'absolute',
            top: 'calc(100% + 8px)',
            right: '12px',
            zIndex: 50,
            width: '260px',
            maxWidth: 'calc(100vw - 32px)',
            background: 'var(--panel-strong, rgba(15, 23, 42, 0.95))',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
            borderRadius: '1rem',
            padding: '0.45rem',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            boxShadow: '0 16px 36px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.08)',
          }}
        >
          <div
            style={{
              padding: '0.5rem 0.65rem 0.35rem 0.65rem',
              fontSize: '0.68rem',
              fontWeight: 800,
              color: 'var(--ink-soft, #94A3B8)',
              textTransform: 'uppercase',
              letterSpacing: '0.04em',
              fontFamily: 'var(--font-mono, monospace)',
            }}
          >
            Ações Rápidas & Relatórios
          </div>

          {/* Opção 1: Baixar Relatório Completo em PDF */}
          {onDownloadPDF && (
            <button
              type="button"
              onClick={() => {
                setIsMoreMenuOpen(false);
                onDownloadPDF();
              }}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.6rem 0.7rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: 'transparent',
                color: 'var(--ink, #FFFFFF)',
                fontSize: '0.8rem',
                fontWeight: 700,
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'background 0.12s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(16, 185, 129, 0.15)';
                e.currentTarget.style.color = '#10B981';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = 'var(--ink, #FFFFFF)';
              }}
            >
              <FileText size={16} color="#10B981" />
              <span>Baixar Relatório em PDF</span>
            </button>
          )}

          {/* Opção 2: Alternar Privacidade de Valores */}
          {onToggleHideValues && (
            <button
              type="button"
              onClick={() => {
                onToggleHideValues();
                setIsMoreMenuOpen(false);
              }}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.6rem 0.7rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: 'transparent',
                color: 'var(--ink, #FFFFFF)',
                fontSize: '0.8rem',
                fontWeight: 700,
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'background 0.12s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(56, 189, 248, 0.15)';
                e.currentTarget.style.color = '#38BDF8';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = 'var(--ink, #FFFFFF)';
              }}
            >
              {hideValues ? <Eye size={16} color="#38BDF8" /> : <EyeOff size={16} color="#38BDF8" />}
              <span>{hideValues ? 'Mostrar Valores (R$)' : 'Ocultar Valores (R$)'}</span>
            </button>
          )}

          {/* Opção 3: Balanço Mês a Mês */}
          <button
            type="button"
            onClick={() => {
              setIsMoreMenuOpen(false);
              onOpenResumo();
            }}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              gap: '0.65rem',
              padding: '0.6rem 0.7rem',
              borderRadius: '0.65rem',
              border: 'none',
              background: 'transparent',
              color: 'var(--ink, #FFFFFF)',
              fontSize: '0.8rem',
              fontWeight: 700,
              textAlign: 'left',
              cursor: 'pointer',
              transition: 'background 0.12s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(139, 92, 246, 0.15)';
              e.currentTarget.style.color = '#A855F7';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = 'var(--ink, #FFFFFF)';
            }}
          >
            <Calendar size={16} color="#A855F7" />
            <span>Balanço Mês a Mês</span>
          </button>

          {/* Opção 4: Personalizar Módulos */}
          {onToggleCustomizer && (
            <button
              type="button"
              onClick={() => {
                setIsMoreMenuOpen(false);
                onToggleCustomizer();
              }}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.6rem 0.7rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: 'transparent',
                color: 'var(--ink, #FFFFFF)',
                fontSize: '0.8rem',
                fontWeight: 700,
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'background 0.12s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.08)';
                e.currentTarget.style.color = '#F59E0B';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = 'var(--ink, #FFFFFF)';
              }}
            >
              <Sliders size={16} color="#F59E0B" />
              <span>Personalizar Módulos</span>
            </button>
          )}

          {/* Opção 5: Redefinir Filtros */}
          {onResetFilters && (
            <button
              type="button"
              onClick={() => {
                setIsMoreMenuOpen(false);
                onResetFilters();
              }}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                padding: '0.6rem 0.7rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: 'transparent',
                color: 'var(--ink, #FFFFFF)',
                fontSize: '0.8rem',
                fontWeight: 700,
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'background 0.12s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.08)';
                e.currentTarget.style.color = '#EF4444';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = 'var(--ink, #FFFFFF)';
              }}
            >
              <RotateCcw size={16} color="#EF4444" />
              <span>Redefinir Filtros</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
