import React, { useState } from 'react';
import {
  Search,
  MapPin,
  ExternalLink,
  Globe,
  Sparkles,
  TrendingUp,
  Dumbbell,
  Compass,
  Navigation,
  Loader2,
  RefreshCw,
  Info,
} from 'lucide-react';

interface GroundingWebChunk {
  web?: {
    uri: string;
    title: string;
  };
}

interface GroundingMapsChunk {
  maps?: {
    uri?: string;
    title?: string;
    placeAnswerSources?: {
      reviewSnippets?: {
        content?: string;
      }[];
    };
  };
}

export const AiGroundingView: React.FC = () => {
  const [activeMode, setActiveMode] = useState<'search' | 'maps'>('search');

  // Search Grounding states
  const [searchPrompt, setSearchPrompt] = useState('');
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchResponse, setSearchResponse] = useState<string | null>(null);
  const [searchChunks, setSearchChunks] = useState<GroundingWebChunk[]>([]);
  const [searchQueries, setSearchQueries] = useState<string[]>([]);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Maps Grounding states
  const [mapsPrompt, setMapsPrompt] = useState('');
  const [mapsLoading, setMapsLoading] = useState(false);
  const [mapsResponse, setMapsResponse] = useState<string | null>(null);
  const [mapsChunks, setMapsChunks] = useState<GroundingMapsChunk[]>([]);
  const [mapsError, setMapsError] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locatingUser, setLocatingUser] = useState(false);

  // Quick preset triggers for Search
  const SEARCH_PRESETS = [
    { label: '📊 Notícias de Finanças & Selic', query: 'Quais são as notícias mais recentes sobre a Taxa Selic, inflação e cenário econômico no Brasil hoje?' },
    { label: '📈 Tendências de Investimentos', query: 'Tendências e projeções atuais para investimentos em renda fixa (CDB, Tesouro Direto) e fundos imobiliários em 2026.' },
    { label: '💪 Ciência do Treino & Hipertrofia', query: 'Novas evidências científicas e consensos sobre volume de treino semanal ideal para hipertrofia muscular.' },
    { label: '🥑 Nutrição & Saúde Metabólica', query: 'Orientações atuais de nutricionistas para ganho de massa muscular magra mantendo baixo percentual de gordura.' },
  ];

  // Quick preset triggers for Maps
  const MAPS_PRESETS = [
    { label: '🏋️ Academias de Musculação', query: 'Encontre academias de musculação e centros fitness bem avaliados' },
    { label: '🏃 Parques & Pistas de Corrida', query: 'Onde encontrar parques públicos com pista de corrida e cooper ao ar livre?' },
    { label: '🥤 Lojas de Suplementos', query: 'Lojas de suplementos alimentares e nutrição esportiva mais próximas' },
    { label: '🥗 Restaurantes Saudáveis', query: 'Restaurantes saudáveis, comida fit e saladas nas redondezas' },
  ];

  const handleRequestLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocalização não é suportada pelo seu navegador.');
      return;
    }
    setLocatingUser(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
        setLocatingUser(false);
      },
      (err) => {
        console.warn('Geolocation error:', err);
        setLocatingUser(false);
        alert('Não foi possível obter sua localização exata. A busca continuará por referências de texto.');
      },
      { timeout: 10000 }
    );
  };

  const handleExecuteSearch = async (queryText?: string) => {
    const q = queryText || searchPrompt;
    if (!q.trim()) return;

    setSearchLoading(true);
    setSearchError(null);
    setSearchResponse(null);
    setSearchChunks([]);
    setSearchQueries([]);

    try {
      const res = await fetch('/api/search-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: q }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro na consulta do Google Search.');
      }
      setSearchResponse(data.text);
      setSearchChunks(data.groundingChunks || []);
      setSearchQueries(data.searchQueries || []);
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'Falha na busca.');
    } finally {
      setSearchLoading(false);
    }
  };

  const handleExecuteMaps = async (queryText?: string) => {
    const q = queryText || mapsPrompt;
    if (!q.trim()) return;

    setMapsLoading(true);
    setMapsError(null);
    setMapsResponse(null);
    setMapsChunks([]);

    try {
      const body: any = { prompt: q };
      if (userLocation) {
        body.lat = userLocation.lat;
        body.lng = userLocation.lng;
      }

      const res = await fetch('/api/maps-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro na consulta do Google Maps.');
      }
      setMapsResponse(data.text);
      setMapsChunks(data.groundingChunks || []);
    } catch (err) {
      setMapsError(err instanceof Error ? err.message : 'Falha na busca de locais.');
    } finally {
      setMapsLoading(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.2rem' }}>
      {/* Mode Selector Tabs */}
      <div
        style={{
          display: 'flex',
          background: 'var(--panel)',
          padding: '0.35rem',
          borderRadius: '1rem',
          border: '1px solid var(--line)',
          gap: '0.4rem',
        }}
      >
        <button
          onClick={() => setActiveMode('search')}
          style={{
            flex: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem',
            padding: '0.65rem 1rem',
            borderRadius: '0.75rem',
            border: 'none',
            background: activeMode === 'search' ? 'linear-gradient(135deg, #0284C7, #06B6D4)' : 'transparent',
            color: activeMode === 'search' ? '#fff' : 'var(--muted)',
            fontWeight: 600,
            fontSize: '0.88rem',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            boxShadow: activeMode === 'search' ? '0 4px 14px rgba(6, 182, 212, 0.3)' : 'none',
          }}
        >
          <Globe size={18} />
          <span>Pesquisa Web (Google Search)</span>
        </button>

        <button
          onClick={() => setActiveMode('maps')}
          style={{
            flex: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem',
            padding: '0.65rem 1rem',
            borderRadius: '0.75rem',
            border: 'none',
            background: activeMode === 'maps' ? 'linear-gradient(135deg, #10B981, #059669)' : 'transparent',
            color: activeMode === 'maps' ? '#fff' : 'var(--muted)',
            fontWeight: 600,
            fontSize: '0.88rem',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            boxShadow: activeMode === 'maps' ? '0 4px 14px rgba(16, 185, 129, 0.3)' : 'none',
          }}
        >
          <MapPin size={18} />
          <span>Locais & Treino (Google Maps)</span>
        </button>
      </div>

      {/* SECTION 1: GOOGLE SEARCH GROUNDING */}
      {activeMode === 'search' && (
        <div className="dash-card" style={{ padding: '1.4rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.8rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <div
                style={{
                  width: '36px',
                  height: '36px',
                  borderRadius: '10px',
                  background: 'rgba(56, 189, 248, 0.15)',
                  border: '1px solid rgba(56, 189, 248, 0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#38BDF8',
                }}
              >
                <Search size={18} />
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: 700, color: 'var(--text)' }}>
                  Radar Web em Tempo Real
                </h3>
                <span style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>
                  Grounded com Google Search · gemini-3.5-flash
                </span>
              </div>
            </div>
          </div>

          {/* Quick presets */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem', marginBottom: '1rem' }}>
            {SEARCH_PRESETS.map((p) => (
              <button
                key={p.label}
                onClick={() => {
                  setSearchPrompt(p.query);
                  handleExecuteSearch(p.query);
                }}
                disabled={searchLoading}
                style={{
                  background: 'var(--panel-strong)',
                  border: '1px solid var(--line)',
                  borderRadius: '999px',
                  padding: '0.35rem 0.8rem',
                  fontSize: '0.78rem',
                  color: 'var(--text)',
                  cursor: 'pointer',
                  fontWeight: 500,
                  transition: 'background 0.15s ease',
                }}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Input field */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleExecuteSearch();
            }}
            style={{ display: 'flex', gap: '0.6rem', marginBottom: '1.2rem' }}
          >
            <input
              type="text"
              value={searchPrompt}
              onChange={(e) => setSearchPrompt(e.target.value)}
              placeholder="Ex: Como está a Selic e rendimento do CDI hoje? Ou dicas para treino..."
              style={{
                flex: 1,
                background: 'var(--panel)',
                border: '1px solid var(--line)',
                borderRadius: '0.8rem',
                padding: '0.7rem 1rem',
                color: 'var(--text)',
                fontSize: '0.88rem',
                outline: 'none',
              }}
            />
            <button
              type="submit"
              disabled={searchLoading || !searchPrompt.trim()}
              style={{
                background: 'linear-gradient(135deg, #0284C7, #06B6D4)',
                border: 'none',
                borderRadius: '0.8rem',
                padding: '0 1.3rem',
                color: '#fff',
                fontWeight: 600,
                fontSize: '0.88rem',
                cursor: searchLoading || !searchPrompt.trim() ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
                opacity: searchLoading || !searchPrompt.trim() ? 0.6 : 1,
              }}
            >
              {searchLoading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
              <span>{searchLoading ? 'Buscando...' : 'Pesquisar'}</span>
            </button>
          </form>

          {/* Error Message */}
          {searchError && (
            <div
              style={{
                padding: '0.8rem 1rem',
                borderRadius: '0.75rem',
                background: 'rgba(239, 68, 68, 0.15)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                color: '#FCA5A5',
                fontSize: '0.84rem',
                marginBottom: '1rem',
              }}
            >
              {searchError}
            </div>
          )}

          {/* Search Result */}
          {searchResponse && (
            <div
              style={{
                background: 'var(--panel)',
                border: '1px solid var(--line)',
                borderRadius: '1rem',
                padding: '1.2rem',
                marginTop: '0.5rem',
              }}
            >
              <div
                style={{
                  fontSize: '0.9rem',
                  lineHeight: 1.65,
                  color: 'var(--text)',
                  whiteSpace: 'pre-wrap',
                }}
              >
                {searchResponse}
              </div>

              {/* Grounding Source Chunks */}
              {searchChunks.length > 0 && (
                <div style={{ marginTop: '1.2rem', paddingTop: '1rem', borderTop: '1px solid var(--line)' }}>
                  <div
                    style={{
                      fontSize: '0.76rem',
                      fontWeight: 700,
                      color: 'var(--muted)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                      marginBottom: '0.6rem',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                    }}
                  >
                    <Globe size={13} />
                    Fontes oficiais consultadas no Google Search:
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                    {searchChunks.map((c, i) => {
                      if (!c.web?.uri) return null;
                      return (
                        <a
                          key={i}
                          href={c.web.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            background: 'var(--panel-strong)',
                            border: '1px solid rgba(56, 189, 248, 0.25)',
                            borderRadius: '0.6rem',
                            padding: '0.4rem 0.75rem',
                            fontSize: '0.76rem',
                            color: '#38BDF8',
                            textDecoration: 'none',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '0.35rem',
                            transition: 'all 0.15s ease',
                          }}
                        >
                          <span style={{ maxWidth: '280px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {c.web.title || c.web.uri}
                          </span>
                          <ExternalLink size={12} />
                        </a>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: GOOGLE MAPS GROUNDING */}
      {activeMode === 'maps' && (
        <div className="dash-card" style={{ padding: '1.4rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.8rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <div
                style={{
                  width: '36px',
                  height: '36px',
                  borderRadius: '10px',
                  background: 'rgba(16, 185, 129, 0.15)',
                  border: '1px solid rgba(16, 185, 129, 0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#10B981',
                }}
              >
                <MapPin size={18} />
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: 700, color: 'var(--text)' }}>
                  Locais de Treino & Saúde no Google Maps
                </h3>
                <span style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>
                  Grounded com Google Maps · gemini-3.5-flash
                </span>
              </div>
            </div>

            <button
              onClick={handleRequestLocation}
              disabled={locatingUser}
              style={{
                background: userLocation ? 'rgba(16, 185, 129, 0.2)' : 'var(--panel-strong)',
                border: `1px solid ${userLocation ? 'rgba(16, 185, 129, 0.4)' : 'var(--line)'}`,
                color: userLocation ? '#34D399' : 'var(--text)',
                padding: '0.4rem 0.8rem',
                borderRadius: '0.75rem',
                fontSize: '0.78rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                cursor: 'pointer',
              }}
            >
              <Navigation size={14} />
              <span>{userLocation ? 'Localização Ativa' : locatingUser ? 'Obtendo GPS...' : 'Usar meu GPS'}</span>
            </button>
          </div>

          {/* Quick presets for Maps */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem', marginBottom: '1rem' }}>
            {MAPS_PRESETS.map((p) => (
              <button
                key={p.label}
                onClick={() => {
                  setMapsPrompt(p.query);
                  handleExecuteMaps(p.query);
                }}
                disabled={mapsLoading}
                style={{
                  background: 'var(--panel-strong)',
                  border: '1px solid var(--line)',
                  borderRadius: '999px',
                  padding: '0.35rem 0.8rem',
                  fontSize: '0.78rem',
                  color: 'var(--text)',
                  cursor: 'pointer',
                  fontWeight: 500,
                  transition: 'background 0.15s ease',
                }}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Maps Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleExecuteMaps();
            }}
            style={{ display: 'flex', gap: '0.6rem', marginBottom: '1.2rem' }}
          >
            <input
              type="text"
              value={mapsPrompt}
              onChange={(e) => setMapsPrompt(e.target.value)}
              placeholder="Ex: Melhores academias de musculação em São Paulo ou perto de mim..."
              style={{
                flex: 1,
                background: 'var(--panel)',
                border: '1px solid var(--line)',
                borderRadius: '0.8rem',
                padding: '0.7rem 1rem',
                color: 'var(--text)',
                fontSize: '0.88rem',
                outline: 'none',
              }}
            />
            <button
              type="submit"
              disabled={mapsLoading || !mapsPrompt.trim()}
              style={{
                background: 'linear-gradient(135deg, #10B981, #059669)',
                border: 'none',
                borderRadius: '0.8rem',
                padding: '0 1.3rem',
                color: '#fff',
                fontWeight: 600,
                fontSize: '0.88rem',
                cursor: mapsLoading || !mapsPrompt.trim() ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
                opacity: mapsLoading || !mapsPrompt.trim() ? 0.6 : 1,
              }}
            >
              {mapsLoading ? <Loader2 size={16} className="animate-spin" /> : <MapPin size={16} />}
              <span>{mapsLoading ? 'Buscando...' : 'Buscar no Mapa'}</span>
            </button>
          </form>

          {/* Maps Error */}
          {mapsError && (
            <div
              style={{
                padding: '0.8rem 1rem',
                borderRadius: '0.75rem',
                background: 'rgba(239, 68, 68, 0.15)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                color: '#FCA5A5',
                fontSize: '0.84rem',
                marginBottom: '1rem',
              }}
            >
              {mapsError}
            </div>
          )}

          {/* Maps Response & Links */}
          {mapsResponse && (
            <div
              style={{
                background: 'var(--panel)',
                border: '1px solid var(--line)',
                borderRadius: '1rem',
                padding: '1.2rem',
                marginTop: '0.5rem',
              }}
            >
              <div
                style={{
                  fontSize: '0.9rem',
                  lineHeight: 1.65,
                  color: 'var(--text)',
                  whiteSpace: 'pre-wrap',
                }}
              >
                {mapsResponse}
              </div>

              {/* Direct Maps Links from Grounding Chunks */}
              {mapsChunks.length > 0 && (
                <div style={{ marginTop: '1.2rem', paddingTop: '1rem', borderTop: '1px solid var(--line)' }}>
                  <div
                    style={{
                      fontSize: '0.76rem',
                      fontWeight: 700,
                      color: 'var(--muted)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                      marginBottom: '0.6rem',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                    }}
                  >
                    <Compass size={13} />
                    Locais mapeados no Google Maps (Clique para abrir rotas e avaliações):
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '0.6rem' }}>
                    {mapsChunks.map((c, i) => {
                      if (!c.maps?.uri && !c.maps?.title) return null;
                      const uri = c.maps.uri || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(c.maps.title || '')}`;
                      return (
                        <a
                          key={i}
                          href={uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            background: 'var(--panel-strong)',
                            border: '1px solid rgba(16, 185, 129, 0.3)',
                            borderRadius: '0.75rem',
                            padding: '0.75rem 0.9rem',
                            fontSize: '0.82rem',
                            color: 'var(--text)',
                            textDecoration: 'none',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '0.3rem',
                            transition: 'transform 0.15s ease, border-color 0.15s ease',
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <span style={{ fontWeight: 600, color: '#34D399' }}>{c.maps.title || 'Ver no Google Maps'}</span>
                            <ExternalLink size={13} color="#34D399" />
                          </div>
                          {c.maps.placeAnswerSources?.reviewSnippets?.[0]?.content && (
                            <span style={{ fontSize: '0.72rem', color: 'var(--muted)', lineHeight: 1.35 }}>
                              "{c.maps.placeAnswerSources.reviewSnippets[0].content.slice(0, 140)}..."
                            </span>
                          )}
                        </a>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
