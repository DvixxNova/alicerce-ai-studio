import React, { useState, useMemo } from 'react';
import {
  FileText,
  ChevronDown,
  ChevronUp,
  Download,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Percent,
  CheckCircle2,
  AlertCircle,
  BarChart3,
  Sparkles,
} from 'lucide-react';
import { Transaction, Investment } from '../types';
import { fmtBRL } from '../utils/constants';
import { jsPDF } from 'jspdf';
import { generateFinancialPDF } from '../utils/generateFinancialPdf';

interface FinanceMultiMonthSummaryCardProps {
  transactions: Transaction[];
  investments?: Investment[];
  hideValues: boolean;
  formatMoney: (val: number) => string;
}

interface MonthSummary {
  key: string; // YYYY-MM
  label: string; // ex: "Janeiro 2026"
  shortLabel: string; // ex: "Jan/26"
  entradas: number;
  saidas: number;
  saldo: number;
  savingsRate: number;
  txCount: number;
}

const MONTH_NAMES = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
];

const MONTH_SHORT = [
  'Jan',
  'Fev',
  'Mar',
  'Abr',
  'Mai',
  'Jun',
  'Jul',
  'Ago',
  'Set',
  'Out',
  'Nov',
  'Dez',
];

export const FinanceMultiMonthSummaryCard: React.FC<FinanceMultiMonthSummaryCardProps> = ({
  transactions,
  investments = [],
  hideValues,
  formatMoney,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Group transactions by month (YYYY-MM)
  const monthlyData = useMemo(() => {
    const map = new Map<string, { entradas: number; saidas: number; count: number }>();

    transactions.forEach((tx) => {
      const ym = tx.date && tx.date.length >= 7 ? tx.date.slice(0, 7) : 'Sem Data';
      const current = map.get(ym) || { entradas: 0, saidas: 0, count: 0 };

      if (tx.type === 'entrada') {
        current.entradas += Number(tx.value) || 0;
      } else if (tx.type === 'saida') {
        current.saidas += Number(tx.value) || 0;
      }
      current.count += 1;
      map.set(ym, current);
    });

    const list: MonthSummary[] = [];

    map.forEach((data, ym) => {
      if (ym === 'Sem Data') {
        list.push({
          key: ym,
          label: 'Sem Data Definida',
          shortLabel: 'S/D',
          entradas: data.entradas,
          saidas: data.saidas,
          saldo: data.entradas - data.saidas,
          savingsRate:
            data.entradas > 0
              ? Math.round(((data.entradas - data.saidas) / data.entradas) * 100)
              : 0,
          txCount: data.count,
        });
        return;
      }

      const parts = ym.split('-');
      const year = parseInt(parts[0], 10);
      const monthIdx = parseInt(parts[1], 10) - 1;
      const monthName = MONTH_NAMES[monthIdx] || parts[1];
      const shortName = MONTH_SHORT[monthIdx] || parts[1];

      const saldo = data.entradas - data.saidas;
      const savingsRate =
        data.entradas > 0 ? Math.round((saldo / data.entradas) * 100) : 0;

      list.push({
        key: ym,
        label: `${monthName} ${year}`,
        shortLabel: `${shortName}/${String(year).slice(2)}`,
        entradas: data.entradas,
        saidas: data.saidas,
        saldo,
        savingsRate,
        txCount: data.count,
      });
    });

    // Sort descending by month key (most recent first)
    list.sort((a, b) => b.key.localeCompare(a.key));

    return list;
  }, [transactions]);

  // Consolidated global metrics
  const totals = useMemo(() => {
    let totalEntradas = 0;
    let totalSaidas = 0;

    transactions.forEach((tx) => {
      const val = Number(tx.value) || 0;
      if (tx.type === 'entrada') totalEntradas += val;
      if (tx.type === 'saida') totalSaidas += val;
    });

    const saldoGeral = totalEntradas - totalSaidas;
    const taxaGeral =
      totalEntradas > 0 ? Math.round((saldoGeral / totalEntradas) * 100) : 0;

    // Total invested in portfolio
    const totalInvestido = investments.reduce(
      (acc, curr) => acc + (Number(curr.value) || 0),
      0
    );

    return {
      totalEntradas,
      totalSaidas,
      saldoGeral,
      taxaGeral,
      totalInvestido,
      totalMeses: monthlyData.length,
      totalTransacoes: transactions.length,
    };
  }, [transactions, investments, monthlyData]);

  // Expenses grouped by category (for breakdown & PDF)
  const categoryExpenses = useMemo(() => {
    const catMap = new Map<string, { total: number; count: number }>();

    transactions.forEach((tx) => {
      if (tx.type === 'saida') {
        const cat = tx.category || 'Outros';
        const current = catMap.get(cat) || { total: 0, count: 0 };
        current.total += Number(tx.value) || 0;
        current.count += 1;
        catMap.set(cat, current);
      }
    });

    const result = Array.from(catMap.entries()).map(([cat, data]) => ({
      category: cat,
      total: data.total,
      count: data.count,
      percent:
        totals.totalSaidas > 0
          ? Math.round((data.total / totals.totalSaidas) * 100)
          : 0,
    }));

    result.sort((a, b) => b.total - a.total);
    return result;
  }, [transactions, totals.totalSaidas]);

  // PDF Export Generation
  const handleDownloadPDF = () => {
    try {
      setIsGeneratingPdf(true);

      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageWidth = 210;
      const margin = 14;
      const contentWidth = pageWidth - margin * 2; // 182mm
      let yPos = 14;

      // 1. Header Banner
      doc.setFillColor(15, 23, 42); // Slate-900
      doc.roundedRect(margin, yPos, contentWidth, 24, 2, 2, 'F');

      // Top title
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(15);
      doc.setTextColor(255, 255, 255);
      doc.text('BALANÇO FINANCEIRO - ALICERCE', margin + 6, yPos + 10);

      // Subtitle
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(203, 213, 225); // Slate-300
      doc.text(
        'Relatório Consolidado Multimeses • Gestão & Produtividade Pessoal',
        margin + 6,
        yPos + 17
      );

      // Issue date & time on the right
      const nowStr = new Date().toLocaleDateString('pt-BR');
      const timeStr = new Date().toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit',
      });
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text(`Emissão: ${nowStr} às ${timeStr}`, pageWidth - margin - 6, yPos + 10, {
        align: 'right',
      });
      doc.text(
        `${totals.totalMeses} meses • ${totals.totalTransacoes} lançamentos`,
        pageWidth - margin - 6,
        yPos + 17,
        { align: 'right' }
      );

      yPos += 30;

      // 2. Executive Summary Cards (4 Boxes)
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10.5);
      doc.setTextColor(15, 23, 42);
      doc.text('1. RESUMO EXECUTIVO CONSOLIDADO', margin, yPos);
      yPos += 4;

      const cardWidth = (contentWidth - 9) / 4;
      const cardHeight = 22;

      // Box 1: Receitas
      doc.setFillColor(240, 253, 244); // Green 50
      doc.setDrawColor(187, 247, 208); // Green 200
      doc.roundedRect(margin, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(22, 101, 52);
      doc.text('TOTAL RECEITAS', margin + 4, yPos + 6);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(21, 128, 61);
      doc.text(fmtBRL(totals.totalEntradas), margin + 4, yPos + 13);
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text('Entradas acumuladas', margin + 4, yPos + 18);

      // Box 2: Despesas
      const b2X = margin + cardWidth + 3;
      doc.setFillColor(254, 242, 242); // Red 50
      doc.setDrawColor(254, 202, 202); // Red 200
      doc.roundedRect(b2X, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(153, 27, 27);
      doc.text('TOTAL DESPESAS', b2X + 4, yPos + 6);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(185, 28, 28);
      doc.text(fmtBRL(totals.totalSaidas), b2X + 4, yPos + 13);
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text('Saídas acumuladas', b2X + 4, yPos + 18);

      // Box 3: Saldo Líquido
      const b3X = b2X + cardWidth + 3;
      const isPositive = totals.saldoGeral >= 0;
      doc.setFillColor(isPositive ? 238 : 255, isPositive ? 242 : 241, isPositive ? 255 : 242);
      doc.setDrawColor(isPositive ? 199 : 254, isPositive ? 210 : 202, isPositive ? 254 : 202);
      doc.roundedRect(b3X, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(isPositive ? 30 : 153, isPositive ? 64 : 27, isPositive ? 175 : 27);
      doc.text('SALDO LÍQUIDO', b3X + 4, yPos + 6);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(isPositive ? 37 : 185, isPositive ? 99 : 28, isPositive ? 235 : 28);
      doc.text(fmtBRL(totals.saldoGeral), b3X + 4, yPos + 13);
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(isPositive ? 'Superávit acumulado' : 'Déficit acumulado', b3X + 4, yPos + 18);

      // Box 4: Taxa de Economia
      const b4X = b3X + cardWidth + 3;
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(b4X, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      doc.text('TAXA DE ECONOMIA', b4X + 4, yPos + 6);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text(`${totals.taxaGeral}%`, b4X + 4, yPos + 13);
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(`Patrimônio: ${fmtBRL(totals.totalInvestido)}`, b4X + 4, yPos + 18);

      yPos += cardHeight + 8;

      // 3. Tabela Comparativa Mês a Mês
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10.5);
      doc.setTextColor(15, 23, 42);
      doc.text('2. COMPARATIVO DETALHADO MÊS A MÊS', margin, yPos);
      yPos += 4;

      // Table Columns:
      // Mês/Ano: 38mm | Receitas: 32mm | Despesas: 32mm | Saldo Líquido: 34mm | Economia: 22mm | Situação: 24mm (Total = 182mm)
      const colW = {
        mes: 38,
        rec: 32,
        des: 32,
        sal: 34,
        tax: 22,
        sit: 24,
      };

      // Table Header Row
      doc.setFillColor(30, 41, 59); // Slate-800
      doc.rect(margin, yPos, contentWidth, 7, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(255, 255, 255);

      let xCursor = margin + 3;
      doc.text('MÊS / ANO', xCursor, yPos + 4.8);

      xCursor += colW.mes;
      doc.text('RECEITAS', xCursor + colW.rec - 6, yPos + 4.8, { align: 'right' });

      xCursor += colW.rec;
      doc.text('DESPESAS', xCursor + colW.des - 6, yPos + 4.8, { align: 'right' });

      xCursor += colW.des;
      doc.text('SALDO LÍQUIDO', xCursor + colW.sal - 6, yPos + 4.8, { align: 'right' });

      xCursor += colW.sal;
      doc.text('TX. ECON.', xCursor + colW.tax / 2, yPos + 4.8, { align: 'center' });

      xCursor += colW.tax;
      doc.text('SITUAÇÃO', xCursor + colW.sit / 2, yPos + 4.8, { align: 'center' });

      yPos += 7;

      // Table Rows
      monthlyData.forEach((m, idx) => {
        // Page break check
        if (yPos > 265) {
          doc.addPage();
          yPos = 16;
        }

        const isEven = idx % 2 === 0;
        doc.setFillColor(isEven ? 255 : 248, isEven ? 255 : 250, isEven ? 255 : 252);
        doc.rect(margin, yPos, contentWidth, 6.5, 'F');

        // Line bottom border
        doc.setDrawColor(241, 245, 249);
        doc.line(margin, yPos + 6.5, margin + contentWidth, yPos + 6.5);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(30, 41, 59);

        let rowX = margin + 3;
        doc.text(m.label, rowX, yPos + 4.5);

        rowX += colW.mes;
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(21, 128, 61); // Green
        doc.text(fmtBRL(m.entradas), rowX + colW.rec - 6, yPos + 4.5, { align: 'right' });

        rowX += colW.rec;
        doc.setTextColor(185, 28, 28); // Red
        doc.text(fmtBRL(m.saidas), rowX + colW.des - 6, yPos + 4.5, { align: 'right' });

        rowX += colW.des;
        const mPos = m.saldo >= 0;
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(mPos ? 21 : 185, mPos ? 128 : 28, mPos ? 61 : 28);
        doc.text(fmtBRL(m.saldo), rowX + colW.sal - 6, yPos + 4.5, { align: 'right' });

        rowX += colW.sal;
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        doc.text(`${m.savingsRate}%`, rowX + colW.tax / 2, yPos + 4.5, { align: 'center' });

        rowX += colW.tax;
        const sitLabel = mPos ? 'Superávit' : 'Déficit';
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(mPos ? 22 : 153, mPos ? 101 : 27, mPos ? 52 : 27);
        doc.text(sitLabel, rowX + colW.sit / 2, yPos + 4.5, { align: 'center' });

        yPos += 6.5;
      });

      // Total Row at bottom of table
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, yPos, contentWidth, 7, 'F');
      doc.setDrawColor(203, 213, 225);
      doc.line(margin, yPos, margin + contentWidth, yPos);
      doc.line(margin, yPos + 7, margin + contentWidth, yPos + 7);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);

      let totX = margin + 3;
      doc.text('TOTAL CONSOLIDADO', totX, yPos + 4.8);

      totX += colW.mes;
      doc.setTextColor(21, 128, 61);
      doc.text(fmtBRL(totals.totalEntradas), totX + colW.rec - 6, yPos + 4.8, { align: 'right' });

      totX += colW.rec;
      doc.setTextColor(185, 28, 28);
      doc.text(fmtBRL(totals.totalSaidas), totX + colW.des - 6, yPos + 4.8, { align: 'right' });

      totX += colW.des;
      const totPos = totals.saldoGeral >= 0;
      doc.setTextColor(totPos ? 21 : 185, totPos ? 128 : 28, totPos ? 61 : 28);
      doc.text(fmtBRL(totals.saldoGeral), totX + colW.sal - 6, yPos + 4.8, { align: 'right' });

      totX += colW.sal;
      doc.setTextColor(15, 23, 42);
      doc.text(`${totals.taxaGeral}%`, totX + colW.tax / 2, yPos + 4.8, { align: 'center' });

      totX += colW.tax;
      doc.setTextColor(totPos ? 22 : 153, totPos ? 101 : 27, totPos ? 52 : 27);
      doc.text(totPos ? 'Superávit' : 'Déficit', totX + colW.sit / 2, yPos + 4.8, {
        align: 'center',
      });

      yPos += 13;

      // 4. Detalhamento por Categoria
      if (yPos > 230) {
        doc.addPage();
        yPos = 16;
      }

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10.5);
      doc.setTextColor(15, 23, 42);
      doc.text('3. MAIORES GASTOS POR CATEGORIA (PERÍODO ACUMULADO)', margin, yPos);
      yPos += 4;

      // Category Table Header
      const catColW = {
        cat: 64,
        cnt: 30,
        val: 48,
        pct: 40,
      };

      doc.setFillColor(30, 41, 59);
      doc.rect(margin, yPos, contentWidth, 7, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(255, 255, 255);

      let cX = margin + 3;
      doc.text('CATEGORIA', cX, yPos + 4.8);
      cX += catColW.cat;
      doc.text('LANÇAMENTOS', cX + catColW.cnt / 2, yPos + 4.8, { align: 'center' });
      cX += catColW.cnt;
      doc.text('TOTAL GASTO', cX + catColW.val - 6, yPos + 4.8, { align: 'right' });
      cX += catColW.val;
      doc.text('% DO TOTAL', cX + catColW.pct / 2, yPos + 4.8, { align: 'center' });

      yPos += 7;

      categoryExpenses.slice(0, 8).forEach((catItem, idx) => {
        if (yPos > 265) {
          doc.addPage();
          yPos = 16;
        }

        const isEven = idx % 2 === 0;
        doc.setFillColor(isEven ? 255 : 248, isEven ? 255 : 250, isEven ? 255 : 252);
        doc.rect(margin, yPos, contentWidth, 6.5, 'F');

        doc.setDrawColor(241, 245, 249);
        doc.line(margin, yPos + 6.5, margin + contentWidth, yPos + 6.5);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(30, 41, 59);

        let rowCatX = margin + 3;
        doc.text(catItem.category, rowCatX, yPos + 4.5);

        rowCatX += catColW.cat;
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(100, 116, 139);
        doc.text(`${catItem.count} itens`, rowCatX + catColW.cnt / 2, yPos + 4.5, {
          align: 'center',
        });

        rowCatX += catColW.cnt;
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(185, 28, 28);
        doc.text(fmtBRL(catItem.total), rowCatX + catColW.val - 6, yPos + 4.5, {
          align: 'right',
        });

        rowCatX += catColW.val;
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        doc.text(`${catItem.percent}%`, rowCatX + catColW.pct / 2, yPos + 4.5, {
          align: 'center',
        });

        yPos += 6.5;
      });

      // 5. Page Numbering & Footer
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setDrawColor(226, 232, 240);
        doc.line(margin, 285, pageWidth - margin, 285);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7);
        doc.setTextColor(148, 163, 184);
        doc.text(
          'Alicerce • Gestão Financeira & Produtividade Pessoal • Relatório Gerado Automaticamente',
          margin,
          290
        );
        doc.text(`Página ${i} de ${totalPages}`, pageWidth - margin, 290, {
          align: 'right',
        });
      }

      // Download file
      const fileName = `balanco-financeiro-alicerce-${new Date().toISOString().slice(0, 10)}.pdf`;
      doc.save(fileName);

      setIsGeneratingPdf(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3500);
    } catch (err) {
      console.error('Erro ao gerar PDF:', err);
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div
      id="card-balanco-geral-multimeses"
      className="multi-month-card"
      style={{
        background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
        border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
        borderRadius: '1.1rem',
        padding: '1.1rem 1.25rem',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        boxShadow: 'var(--card-shadow, 0 8px 24px rgba(0, 0, 0, 0.25))',
        transition: 'all 0.25s ease',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Subtle Ambient Background Glow */}
      <div
        style={{
          position: 'absolute',
          top: -40,
          right: -40,
          width: 140,
          height: 140,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(59, 130, 246, 0.12), transparent 70%)',
          pointerEvents: 'none',
        }}
      />

      {/* Header: Title + Action Button */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.8rem',
          marginBottom: '1rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div
            style={{
              width: '38px',
              height: '38px',
              borderRadius: '0.75rem',
              background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.22), rgba(16, 185, 129, 0.22))',
              border: '1px solid rgba(59, 130, 246, 0.35)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--active, #38BDF8)',
              flexShrink: 0,
            }}
          >
            <BarChart3 size={20} />
          </div>

          <div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
                flexWrap: 'wrap',
              }}
            >
              <h3
                style={{
                  fontSize: '0.98rem',
                  fontWeight: 800,
                  color: 'var(--ink, #FFFFFF)',
                  margin: 0,
                  fontFamily: 'var(--font-display, sans-serif)',
                  letterSpacing: '-0.01em',
                }}
              >
                Balanço Geral Multimeses
              </h3>
              <span
                style={{
                  fontSize: '0.66rem',
                  fontWeight: 700,
                  padding: '0.12rem 0.48rem',
                  borderRadius: '999px',
                  background: 'rgba(59, 130, 246, 0.15)',
                  color: 'var(--active, #38BDF8)',
                  border: '1px solid rgba(59, 130, 246, 0.3)',
                  fontFamily: 'var(--font-mono, monospace)',
                }}
              >
                {totals.totalMeses} {totals.totalMeses === 1 ? 'mês' : 'meses'} registrados
              </span>
            </div>
            <p
              style={{
                fontSize: '0.74rem',
                color: 'var(--ink-soft, #94A3B8)',
                margin: '0.15rem 0 0 0',
              }}
            >
              Consolidado histórico de todas as receitas e despesas registradas
            </p>
          </div>
        </div>

        {/* Action Button: Baixar Relatório em PDF */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <button
            type="button"
            id="btn-export-pdf-multimeses"
            onClick={handleDownloadPDF}
            disabled={isGeneratingPdf}
            className="multi-month-pdf-btn"
            style={{
              background: 'linear-gradient(135deg, #10B981, #059669)',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '0.75rem',
              padding: '0.55rem 1.05rem',
              fontSize: '0.78rem',
              fontWeight: 800,
              cursor: isGeneratingPdf ? 'wait' : 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.45rem',
              boxShadow: '0 4px 14px rgba(16, 185, 129, 0.35)',
              transition: 'all 0.18s ease',
            }}
          >
            {downloadSuccess ? (
              <>
                <CheckCircle2 size={16} />
                <span>PDF Baixado!</span>
              </>
            ) : isGeneratingPdf ? (
              <>
                <Sparkles size={16} className="animate-spin" />
                <span>Gerando Relatório...</span>
              </>
            ) : (
              <>
                <FileText size={16} />
                <span>📄 Baixar Relatório Completo em PDF</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Consolidated Metrics Grid (3 Main Cards + Savings Rate Bar) */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: '0.75rem',
          marginBottom: '1rem',
        }}
      >
        {/* Metric 1: Total Histórico Entrado */}
        <div
          style={{
            background: 'var(--panel, rgba(255, 255, 255, 0.03))',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
            borderRadius: '0.85rem',
            padding: '0.75rem 0.95rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.65rem',
          }}
        >
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '0.55rem',
              background: 'rgba(34, 197, 94, 0.15)',
              border: '1px solid rgba(34, 197, 94, 0.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#22C55E',
              flexShrink: 0,
            }}
          >
            <ArrowDownRight size={17} />
          </div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div
              className="stat-lbl"
              style={{
                fontSize: '0.68rem',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                color: 'var(--ink-soft, #94A3B8)',
                fontWeight: 700,
              }}
            >
              Receitas Acumuladas
            </div>
            <div
              className="stat-val"
              style={{
                fontSize: '1.08rem',
                fontWeight: 800,
                color: '#22C55E',
                fontFamily: 'var(--font-mono, monospace)',
                lineHeight: 1.2,
                marginTop: '0.1rem',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {formatMoney(totals.totalEntradas)}
            </div>
          </div>
        </div>

        {/* Metric 2: Total Histórico Saído */}
        <div
          style={{
            background: 'var(--panel, rgba(255, 255, 255, 0.03))',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
            borderRadius: '0.85rem',
            padding: '0.75rem 0.95rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.65rem',
          }}
        >
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '0.55rem',
              background: 'rgba(239, 68, 68, 0.15)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#EF4444',
              flexShrink: 0,
            }}
          >
            <ArrowUpRight size={17} />
          </div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div
              className="stat-lbl"
              style={{
                fontSize: '0.68rem',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                color: 'var(--ink-soft, #94A3B8)',
                fontWeight: 700,
              }}
            >
              Despesas Acumuladas
            </div>
            <div
              className="stat-val"
              style={{
                fontSize: '1.08rem',
                fontWeight: 800,
                color: '#EF4444',
                fontFamily: 'var(--font-mono, monospace)',
                lineHeight: 1.2,
                marginTop: '0.1rem',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {formatMoney(totals.totalSaidas)}
            </div>
          </div>
        </div>

        {/* Metric 3: Saldo / Resultado Líquido Acumulado */}
        <div
          style={{
            background:
              totals.saldoGeral >= 0
                ? 'rgba(16, 185, 129, 0.08)'
                : 'rgba(239, 68, 68, 0.08)',
            border:
              totals.saldoGeral >= 0
                ? '1px solid rgba(16, 185, 129, 0.25)'
                : '1px solid rgba(239, 68, 68, 0.25)',
            borderRadius: '0.85rem',
            padding: '0.75rem 0.95rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.65rem',
          }}
        >
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '0.55rem',
              background:
                totals.saldoGeral >= 0
                  ? 'rgba(16, 185, 129, 0.2)'
                  : 'rgba(239, 68, 68, 0.2)',
              border:
                totals.saldoGeral >= 0
                  ? '1px solid rgba(16, 185, 129, 0.4)'
                  : '1px solid rgba(239, 68, 68, 0.4)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: totals.saldoGeral >= 0 ? '#10B981' : '#EF4444',
              flexShrink: 0,
            }}
          >
            {totals.saldoGeral >= 0 ? <TrendingUp size={17} /> : <AlertCircle size={17} />}
          </div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <span
                className="stat-lbl"
                style={{
                  fontSize: '0.68rem',
                  textTransform: 'uppercase',
                  letterSpacing: '0.04em',
                  color: 'var(--ink-soft, #94A3B8)',
                  fontWeight: 700,
                }}
              >
                Saldo Líquido Acumulado
              </span>
              <span
                style={{
                  fontSize: '0.62rem',
                  fontWeight: 800,
                  padding: '0.08rem 0.35rem',
                  borderRadius: '0.35rem',
                  background:
                    totals.saldoGeral >= 0
                      ? 'rgba(16, 185, 129, 0.2)'
                      : 'rgba(239, 68, 68, 0.2)',
                  color: totals.saldoGeral >= 0 ? '#10B981' : '#EF4444',
                }}
              >
                {totals.saldoGeral >= 0 ? 'Superávit' : 'Déficit'}
              </span>
            </div>
            <div
              className="stat-val"
              style={{
                fontSize: '1.08rem',
                fontWeight: 800,
                color: totals.saldoGeral >= 0 ? '#10B981' : '#EF4444',
                fontFamily: 'var(--font-mono, monospace)',
                lineHeight: 1.2,
                marginTop: '0.1rem',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {formatMoney(totals.saldoGeral)}
            </div>
          </div>
        </div>

        {/* Metric 4: Taxa de Poupança / Economia Geral */}
        <div
          style={{
            background: 'var(--panel, rgba(255, 255, 255, 0.03))',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
            borderRadius: '0.85rem',
            padding: '0.75rem 0.95rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.65rem',
          }}
        >
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '0.55rem',
              background: 'rgba(56, 189, 248, 0.15)',
              border: '1px solid rgba(56, 189, 248, 0.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#38BDF8',
              flexShrink: 0,
            }}
          >
            <Percent size={17} />
          </div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div
              className="stat-lbl"
              style={{
                fontSize: '0.68rem',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                color: 'var(--ink-soft, #94A3B8)',
                fontWeight: 700,
              }}
            >
              Taxa Geral de Economia
            </div>
            <div
              style={{
                display: 'flex',
                alignItems: 'baseline',
                gap: '0.4rem',
                marginTop: '0.1rem',
              }}
            >
              <span
                className="stat-val"
                style={{
                  fontSize: '1.08rem',
                  fontWeight: 800,
                  color: totals.taxaGeral >= 20 ? '#10B981' : totals.taxaGeral > 0 ? '#38BDF8' : '#EF4444',
                  fontFamily: 'var(--font-mono, monospace)',
                  lineHeight: 1.2,
                }}
              >
                {totals.taxaGeral}%
              </span>
              <span style={{ fontSize: '0.64rem', color: 'var(--ink-soft)' }}>
                {totals.taxaGeral >= 20 ? 'Excelente' : totals.taxaGeral > 0 ? 'Positiva' : 'Negativa'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Toggle Button for Detailed Breakdown */}
      <button
        type="button"
        id="btn-toggle-detalhado-multimeses"
        onClick={() => setIsExpanded((prev) => !prev)}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0.65rem 0.9rem',
          borderRadius: '0.75rem',
          background: 'var(--panel, rgba(255, 255, 255, 0.04))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
          color: 'var(--ink, #FFFFFF)',
          fontSize: '0.8rem',
          fontWeight: 700,
          cursor: 'pointer',
          transition: 'all 0.15s ease',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Calendar size={15} color="var(--active, #38BDF8)" />
          <span>
            {isExpanded
              ? 'Ocultar Balanço Detalhado por Mês'
              : 'Ver Balanço Detalhado por Mês (Mês a Mês)'}
          </span>
          <span
            style={{
              fontSize: '0.66rem',
              fontWeight: 700,
              padding: '0.1rem 0.4rem',
              borderRadius: '999px',
              background: 'rgba(255, 255, 255, 0.08)',
              color: 'var(--ink-soft)',
            }}
          >
            {monthlyData.length} {monthlyData.length === 1 ? 'mês' : 'meses'}
          </span>
        </div>
        {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>

      {/* Collapsible Monthly Table / List */}
      {isExpanded && (
        <div
          className="fade-in"
          style={{
            marginTop: '0.85rem',
            borderTop: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
            paddingTop: '0.85rem',
          }}
        >
          {monthlyData.length === 0 ? (
            <div
              style={{
                textAlign: 'center',
                padding: '1.5rem',
                color: 'var(--ink-soft)',
                fontSize: '0.82rem',
              }}
            >
              Nenhuma transação registrada até o momento.
            </div>
          ) : (
            <div
              style={{
                overflowX: 'auto',
                WebkitOverflowScrolling: 'touch',
                borderRadius: '0.75rem',
                border: '1px solid var(--line, rgba(255, 255, 255, 0.08))',
              }}
            >
              <table
                style={{
                  width: '100%',
                  borderCollapse: 'collapse',
                  fontSize: '0.76rem',
                  textAlign: 'left',
                }}
              >
                <thead>
                  <tr
                    style={{
                      background: 'var(--panel-strong, rgba(255, 255, 255, 0.06))',
                      borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                      color: 'var(--ink-soft, #94A3B8)',
                      fontSize: '0.68rem',
                      textTransform: 'uppercase',
                      letterSpacing: '0.04em',
                    }}
                  >
                    <th style={{ padding: '0.65rem 0.8rem', fontWeight: 800 }}>Mês / Período</th>
                    <th style={{ padding: '0.65rem 0.8rem', textAlign: 'right', fontWeight: 800 }}>Receitas</th>
                    <th style={{ padding: '0.65rem 0.8rem', textAlign: 'right', fontWeight: 800 }}>Despesas</th>
                    <th style={{ padding: '0.65rem 0.8rem', textAlign: 'right', fontWeight: 800 }}>Saldo Líquido</th>
                    <th style={{ padding: '0.65rem 0.8rem', textAlign: 'center', fontWeight: 800 }}>Taxa Poupança</th>
                    <th style={{ padding: '0.65rem 0.8rem', textAlign: 'center', fontWeight: 800 }}>Situação</th>
                  </tr>
                </thead>
                <tbody>
                  {monthlyData.map((m, idx) => {
                    const isPos = m.saldo >= 0;
                    return (
                      <tr
                        key={m.key}
                        style={{
                          background:
                            idx % 2 === 0
                              ? 'transparent'
                              : 'var(--panel, rgba(255, 255, 255, 0.02))',
                          borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.05))',
                          transition: 'background 0.12s ease',
                        }}
                      >
                        {/* Mês */}
                        <td style={{ padding: '0.6rem 0.8rem' }}>
                          <div style={{ fontWeight: 800, color: 'var(--ink, #FFFFFF)' }}>
                            {m.label}
                          </div>
                          <div
                            style={{
                              fontSize: '0.64rem',
                              color: 'var(--ink-soft)',
                              fontFamily: 'var(--font-mono, monospace)',
                            }}
                          >
                            {m.txCount} {m.txCount === 1 ? 'registro' : 'registros'}
                          </div>
                        </td>

                        {/* Receitas */}
                        <td
                          style={{
                            padding: '0.6rem 0.8rem',
                            textAlign: 'right',
                            color: '#22C55E',
                            fontWeight: 700,
                            fontFamily: 'var(--font-mono, monospace)',
                          }}
                        >
                          +{formatMoney(m.entradas)}
                        </td>

                        {/* Despesas */}
                        <td
                          style={{
                            padding: '0.6rem 0.8rem',
                            textAlign: 'right',
                            color: '#EF4444',
                            fontWeight: 700,
                            fontFamily: 'var(--font-mono, monospace)',
                          }}
                        >
                          -{formatMoney(m.saidas)}
                        </td>

                        {/* Saldo Líquido */}
                        <td
                          style={{
                            padding: '0.6rem 0.8rem',
                            textAlign: 'right',
                            color: isPos ? '#10B981' : '#EF4444',
                            fontWeight: 800,
                            fontFamily: 'var(--font-mono, monospace)',
                          }}
                        >
                          {isPos ? '+' : ''}
                          {formatMoney(m.saldo)}
                        </td>

                        {/* Taxa Poupança */}
                        <td style={{ padding: '0.6rem 0.8rem', textAlign: 'center' }}>
                          <span
                            style={{
                              fontSize: '0.72rem',
                              fontWeight: 700,
                              color:
                                m.savingsRate >= 20
                                  ? '#10B981'
                                  : m.savingsRate > 0
                                  ? '#38BDF8'
                                  : '#EF4444',
                              fontFamily: 'var(--font-mono, monospace)',
                            }}
                          >
                            {m.savingsRate}%
                          </span>
                        </td>

                        {/* Situação / Badge */}
                        <td style={{ padding: '0.6rem 0.8rem', textAlign: 'center' }}>
                          <span
                            style={{
                              display: 'inline-block',
                              fontSize: '0.64rem',
                              fontWeight: 800,
                              padding: '0.15rem 0.5rem',
                              borderRadius: '999px',
                              background: isPos
                                ? 'rgba(16, 185, 129, 0.15)'
                                : 'rgba(239, 68, 68, 0.15)',
                              color: isPos ? '#10B981' : '#EF4444',
                              border: isPos
                                ? '1px solid rgba(16, 185, 129, 0.3)'
                                : '1px solid rgba(239, 68, 68, 0.3)',
                            }}
                          >
                            {isPos ? 'Superávit' : 'Déficit'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr
                    style={{
                      background: 'var(--panel-strong, rgba(255, 255, 255, 0.08))',
                      borderTop: '2px solid var(--line, rgba(255, 255, 255, 0.15))',
                      fontWeight: 800,
                    }}
                  >
                    <td style={{ padding: '0.7rem 0.8rem', color: 'var(--ink, #FFFFFF)' }}>
                      Total Consolidado ({totals.totalMeses} meses)
                    </td>
                    <td
                      style={{
                        padding: '0.7rem 0.8rem',
                        textAlign: 'right',
                        color: '#22C55E',
                        fontFamily: 'var(--font-mono, monospace)',
                      }}
                    >
                      +{formatMoney(totals.totalEntradas)}
                    </td>
                    <td
                      style={{
                        padding: '0.7rem 0.8rem',
                        textAlign: 'right',
                        color: '#EF4444',
                        fontFamily: 'var(--font-mono, monospace)',
                      }}
                    >
                      -{formatMoney(totals.totalSaidas)}
                    </td>
                    <td
                      style={{
                        padding: '0.7rem 0.8rem',
                        textAlign: 'right',
                        color: totals.saldoGeral >= 0 ? '#10B981' : '#EF4444',
                        fontFamily: 'var(--font-mono, monospace)',
                        fontSize: '0.84rem',
                      }}
                    >
                      {totals.saldoGeral >= 0 ? '+' : ''}
                      {formatMoney(totals.saldoGeral)}
                    </td>
                    <td
                      style={{
                        padding: '0.7rem 0.8rem',
                        textAlign: 'center',
                        color: 'var(--ink, #FFFFFF)',
                        fontFamily: 'var(--font-mono, monospace)',
                      }}
                    >
                      {totals.taxaGeral}%
                    </td>
                    <td style={{ padding: '0.7rem 0.8rem', textAlign: 'center' }}>
                      <span
                        style={{
                          fontSize: '0.66rem',
                          fontWeight: 800,
                          padding: '0.15rem 0.5rem',
                          borderRadius: '999px',
                          background:
                            totals.saldoGeral >= 0
                              ? 'rgba(16, 185, 129, 0.25)'
                              : 'rgba(239, 68, 68, 0.25)',
                          color: totals.saldoGeral >= 0 ? '#10B981' : '#EF4444',
                        }}
                      >
                        {totals.saldoGeral >= 0 ? 'Superávit' : 'Déficit'}
                      </span>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
