import React from 'react';

interface IconProps {
  size?: number;
  color?: string;
  style?: React.CSSProperties;
  className?: string;
}

function BaseSvg({ children, size = 20, color = 'currentColor', style, className }: IconProps & { children: React.ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      style={style}
      className={className}
    >
      {children}
    </svg>
  );
}

export const WalletIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="2" y="7" width="20" height="13" rx="2" />
    <path d="M16 7V5a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v2" />
    <circle cx="17" cy="13.5" r="1.4" fill="currentColor" stroke="none" />
  </BaseSvg>
);

export const DumbbellIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="1" y="9" width="4" height="6" rx="1" />
    <rect x="19" y="9" width="4" height="6" rx="1" />
    <line x1="6" y1="12" x2="18" y2="12" />
    <line x1="4" y1="7" x2="4" y2="17" />
    <line x1="20" y1="7" x2="20" y2="17" />
  </BaseSvg>
);

export const FileTextIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M4 4h13l3 3v13H4z" />
    <path d="M17 4v3h3" />
  </BaseSvg>
);

export const LightbulbIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M9 18h6" />
    <path d="M10 22h4" />
    <path d="M12 2a6 6 0 0 0-4 10.5c.6.6 1 1.4 1 2.5h6c0-1.1.4-1.9 1-2.5A6 6 0 0 0 12 2z" />
  </BaseSvg>
);

export const CloudSunIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="8" cy="8" r="3" />
    <path d="M8 2v1M3.5 4.5l.7.7M13 4.5l-.7.7" />
    <path d="M6 18a4 4 0 0 1 0-8 5 5 0 0 1 9.6 1.7A3.5 3.5 0 0 1 17 18H6z" />
  </BaseSvg>
);

export const PlusIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </BaseSvg>
);

export const TrashIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M3 6h18" />
    <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
    <line x1="10" y1="11" x2="10" y2="17" />
    <line x1="14" y1="11" x2="14" y2="17" />
  </BaseSvg>
);

export const ChevronDownIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="6 9 12 15 18 9" />
  </BaseSvg>
);

export const ChevronUpIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="6 15 12 9 18 15" />
  </BaseSvg>
);

export const ChevronLeftIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="15 6 9 12 15 18" />
  </BaseSvg>
);

export const ChevronRightIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="9 6 15 12 9 18" />
  </BaseSvg>
);

export const SunIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="12" cy="12" r="4" />
    <line x1="12" y1="2" x2="12" y2="4" />
    <line x1="12" y1="20" x2="12" y2="22" />
    <line x1="2" y1="12" x2="4" y2="12" />
    <line x1="20" y1="12" x2="22" y2="12" />
    <line x1="4.9" y1="4.9" x2="6.3" y2="6.3" />
    <line x1="17.7" y1="17.7" x2="19.1" y2="19.1" />
    <line x1="4.9" y1="19.1" x2="6.3" y2="17.7" />
    <line x1="17.7" y1="6.3" x2="19.1" y2="4.9" />
  </BaseSvg>
);

export const CloudIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 18a4 4 0 0 1 0-8 5 5 0 0 1 9.6 1.7A3.5 3.5 0 0 1 17 18H6z" />
  </BaseSvg>
);

export const CloudRainIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 16a4 4 0 0 1 0-8 5 5 0 0 1 9.6 1.7A3.5 3.5 0 0 1 17 16H6z" />
    <line x1="8" y1="19" x2="8" y2="21" />
    <line x1="12" y1="19" x2="12" y2="21" />
    <line x1="16" y1="19" x2="16" y2="21" />
  </BaseSvg>
);

export const CloudSnowIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 16a4 4 0 0 1 0-8 5 5 0 0 1 9.6 1.7A3.5 3.5 0 0 1 17 16H6z" />
    <circle cx="8" cy="20" r="0.6" fill="currentColor" stroke="none" />
    <circle cx="12" cy="21" r="0.6" fill="currentColor" stroke="none" />
    <circle cx="16" cy="20" r="0.6" fill="currentColor" stroke="none" />
  </BaseSvg>
);

export const CloudFogIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 15a3.5 3.5 0 0 1 .3-7 4.5 4.5 0 0 1 8.6 1.4A3 3 0 0 1 15 15H6z" />
    <line x1="4" y1="19" x2="20" y2="19" />
    <line x1="6" y1="22" x2="18" y2="22" />
  </BaseSvg>
);

export const CloudLightningIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 15a3.5 3.5 0 0 1 .3-7 4.5 4.5 0 0 1 8.6 1.4A3 3 0 0 1 15 15H6z" />
    <polyline points="13 15 10.5 19.5 12.5 19.5 10 23" />
  </BaseSvg>
);

export const SearchIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="10" cy="10" r="6" />
    <line x1="21" y1="21" x2="15" y2="15" />
  </BaseSvg>
);

export const LoaderIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M21 12a9 9 0 1 1-6.2-8.5" />
  </BaseSvg>
);

export const BellIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 8a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6" />
    <path d="M10 20a2 2 0 0 0 4 0" />
  </BaseSvg>
);

export const HomeIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M3 11l9-7 9 7" />
    <path d="M5 10v10h14V10" />
  </BaseSvg>
);

export const UtensilsIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="5" y1="3" x2="19" y2="21" />
    <line x1="19" y1="3" x2="5" y2="21" />
  </BaseSvg>
);

export const CarIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M3 13l2-5a2 2 0 0 1 2-1h10a2 2 0 0 1 2 1l2 5" />
    <rect x="2" y="13" width="20" height="5" rx="1.5" />
    <circle cx="7" cy="18" r="1.5" fill="currentColor" stroke="none" />
    <circle cx="17" cy="18" r="1.5" fill="currentColor" stroke="none" />
  </BaseSvg>
);

export const GamepadIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="3" y="3" width="18" height="18" rx="1" />
    <line x1="3" y1="8" x2="21" y2="8" />
    <line x1="3" y1="16" x2="21" y2="16" />
    <line x1="9" y1="3" x2="9" y2="8" />
    <line x1="15" y1="3" x2="15" y2="8" />
    <line x1="9" y1="16" x2="9" y2="21" />
    <line x1="15" y1="16" x2="15" y2="21" />
  </BaseSvg>
);

export const HeartPulseIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6c-2.5 4.5-9.5 9-9.5 9z" />
    <polyline points="4 12 8 12 10 8 13 16 15 12 20 12" />
  </BaseSvg>
);

export const GraduationCapIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M2 9l10-5 10 5-10 5-10-5z" />
    <path d="M6 11v5c0 1.5 2.5 3 6 3s6-1.5 6-3v-5" />
  </BaseSvg>
);

export const BanknoteIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="2" y="6" width="20" height="12" rx="2" />
    <circle cx="12" cy="12" r="3" />
  </BaseSvg>
);

export const MoreHorizontalIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="5" cy="12" r="1.5" fill="currentColor" stroke="none" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none" />
    <circle cx="19" cy="12" r="1.5" fill="currentColor" stroke="none" />
  </BaseSvg>
);

export const ArrowDownRightIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="7" y1="7" x2="17" y2="17" />
    <polyline points="17 9 17 17 9 17" />
  </BaseSvg>
);

export const ArrowUpRightIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="7" y1="17" x2="17" y2="7" />
    <polyline points="9 7 17 7 17 15" />
  </BaseSvg>
);

export const LayersIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polygon points="12 2 22 8 12 14 2 8" />
    <polyline points="2 12 12 18 22 12" />
    <polyline points="2 16 12 22 22 16" />
  </BaseSvg>
);

export const SlidersIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="4" y1="6" x2="20" y2="6" />
    <circle cx="9" cy="6" r="2" fill="currentColor" stroke="none" />
    <line x1="4" y1="12" x2="20" y2="12" />
    <circle cx="15" cy="12" r="2" fill="currentColor" stroke="none" />
    <line x1="4" y1="18" x2="20" y2="18" />
    <circle cx="7" cy="18" r="2" fill="currentColor" stroke="none" />
  </BaseSvg>
);

export const CreditCardIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="2" y="5" width="20" height="14" rx="2" />
    <line x1="2" y1="10" x2="22" y2="10" />
  </BaseSvg>
);

export const CheckIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="20 6 9 17 4 12" />
  </BaseSvg>
);

export const FlameIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M12 2c1 4-3 5-3 9a3 3 0 0 0 6 0c0-1-1-2-1-3 2 1 3 3 3 5a5 5 0 0 1-10 0c0-5 3-6 5-11z" />
  </BaseSvg>
);

export const SparklesIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z" />
    <path d="M19 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z" />
  </BaseSvg>
);

export const SunriseIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 18a6 6 0 0 1 12 0" />
    <line x1="2" y1="18" x2="22" y2="18" />
    <polyline points="9 13 12 10 15 13" />
    <line x1="12" y1="4" x2="12" y2="10" />
  </BaseSvg>
);

export const SunsetIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M6 18a6 6 0 0 1 12 0" />
    <line x1="2" y1="18" x2="22" y2="18" />
    <polyline points="9 8 12 11 15 8" />
    <line x1="12" y1="3" x2="12" y2="11" />
  </BaseSvg>
);

export const WindIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M3 8h11a3 3 0 1 0-3-3" />
    <path d="M3 13h15a3 3 0 1 1-3 3" />
    <path d="M3 18h8" />
  </BaseSvg>
);

export const DropletsIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M12 2s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z" />
  </BaseSvg>
);

export const ThermometerIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M10 14V4a2 2 0 1 1 4 0v10a4 4 0 1 1-4 0z" />
  </BaseSvg>
);

export const NavigationIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="12" cy="12" r="2.5" fill="currentColor" stroke="none" />
    <line x1="12" y1="2" x2="12" y2="5" />
    <line x1="12" y1="19" x2="12" y2="22" />
    <line x1="2" y1="12" x2="5" y2="12" />
    <line x1="19" y1="12" x2="22" y2="12" />
    <circle cx="12" cy="12" r="7" />
  </BaseSvg>
);

export const TrendingUpIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="3 17 9 11 13 15 21 7" />
    <polyline points="14 7 21 7 21 14" />
  </BaseSvg>
);

export const BriefcaseIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="2" y="7" width="20" height="13" rx="2" />
    <path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    <line x1="2" y1="13" x2="22" y2="13" />
  </BaseSvg>
);

export const HeartIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M12 21s-6.5-4.2-9-8.3C1 9.6 2.3 6.5 5.2 6c2-.4 3.4.7 4.3 2 .9-1.3 2.3-2.4 4.3-2 2.9.5 4.2 3.6 2.2 6.7-2.5 4.1-9 8.3-9 8.3z" />
  </BaseSvg>
);

export const UserIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="12" cy="8" r="4" />
    <path d="M4 20c0-4 4-6 8-6s8 2 8 6" />
  </BaseSvg>
);

export const AlarmClockIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="12" cy="13" r="8" />
    <line x1="12" y1="13" x2="12" y2="9" />
    <line x1="12" y1="13" x2="15" y2="15" />
    <line x1="5" y1="4" x2="7.5" y2="6.5" />
    <line x1="19" y1="4" x2="16.5" y2="6.5" />
  </BaseSvg>
);

export const CalendarIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="3" y="5" width="18" height="16" rx="2" />
    <line x1="3" y1="10" x2="21" y2="10" />
    <line x1="8" y1="3" x2="8" y2="7" />
    <line x1="16" y1="3" x2="16" y2="7" />
  </BaseSvg>
);

export const PieChartIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
    <path d="M22 12A10 10 0 0 0 12 2v10z" />
  </BaseSvg>
);

export const BarChart3Icon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="12" y1="20" x2="12" y2="10" />
    <line x1="18" y1="20" x2="18" y2="4" />
    <line x1="6" y1="20" x2="6" y2="16" />
  </BaseSvg>
);

export const RefreshCwIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="23 4 23 10 17 10" />
    <polyline points="1 20 1 14 7 14" />
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
  </BaseSvg>
);

export const BookOpenIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
  </BaseSvg>
);

export const MoonIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </BaseSvg>
);

export const ZapIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
  </BaseSvg>
);

export const ClockIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="12" cy="12" r="10" />
    <polyline points="12 6 12 12 16 14" />
  </BaseSvg>
);

export const ActivityIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
  </BaseSvg>
);

export const SettingsGearIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </BaseSvg>
);

export const MailIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="2" y="4" width="20" height="16" rx="2" />
    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
  </BaseSvg>
);

export const CameraIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
    <circle cx="12" cy="13" r="4" />
  </BaseSvg>
);

export const MonitorIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="2" y="3" width="20" height="14" rx="2" />
    <line x1="8" y1="21" x2="16" y2="21" />
    <line x1="12" y1="17" x2="12" y2="21" />
  </BaseSvg>
);

export const TargetIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="12" r="6" />
    <circle cx="12" cy="12" r="2" />
  </BaseSvg>
);

export const XIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </BaseSvg>
);

export const PlayIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polygon points="5 3 19 12 5 21 5 3" />
  </BaseSvg>
);

export const PauseIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <rect x="6" y="4" width="4" height="16" />
    <rect x="14" y="4" width="4" height="16" />
  </BaseSvg>
);

export const RotateCcwIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <polyline points="1 4 1 10 7 10" />
    <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
  </BaseSvg>
);

export const Edit3Icon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M12 20h9" />
    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
  </BaseSvg>
);

export const CheckCircle2Icon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
    <path d="m9 12 2 2 4-4" />
  </BaseSvg>
);

export const MinusIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <line x1="5" y1="12" x2="19" y2="12" />
  </BaseSvg>
);

export const EyeIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
    <circle cx="12" cy="12" r="3" />
  </BaseSvg>
);

export const EyeOffIcon: React.FC<IconProps> = (p) => (
  <BaseSvg {...p}>
    <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" />
    <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68" />
    <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61" />
    <line x1="2" y1="2" x2="22" y2="22" />
  </BaseSvg>
);
