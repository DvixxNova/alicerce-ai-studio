import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Save,
  ArrowDownRight,
  ArrowUpRight,
  TrendingUp,
  CheckCircle2,
  Clock,
  Tag,
  DollarSign,
  FileText,
  Calendar as CalendarIcon,
} from 'lucide-react';
import { Transaction, Investment } from '../types';
import {
  FINANCE_CATEGORY_NAMES,
  INVESTMENT_TYPES,
  INVESTMENT_INSTITUTIONS,
  getTodayISO,
} from '../utils/constants';

interface FinanceTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveTransaction: (
    data: Omit<Transaction, 'id'>,
    editingId?: string
  ) => void;
  onSaveInvestment: (data: Omit<Investment, 'id'>) => void;
  editingTransaction: Transaction | null;
  initialType?: 'entrada' | 'saida' | 'investimento';
}

export const FinanceTransactionModal: React.FC<FinanceTransactionModalProps> = ({
  isOpen,
  onClose,
  onSaveTransaction,
  onSaveInvestment,
  editingTransaction,
  initialType = 'saida',
}) => {
  const [modalType, setModalType] = useState<'entrada' | 'saida' | 'investimento'>(
    initialType
  );
  const [desc, setDesc] = useState('');
  const [val, setVal] = useState('');
  const [category, setCategory] = useState(FINANCE_CATEGORY_NAMES[0]);
  const [invType, setInvType] = useState(INVESTMENT_TYPES[0]);
  const [institution, setInstitution] = useState('');
  const [yieldRate, setYieldRate] = useState('');
  const [liquidity, setLiquidity] = useState('');
  const [date, setDate] = useState(getTodayISO());
  const [status, setStatus] = useState<'pago' | 'pendente'>('pago');
  const [error, setError] = useState<string | null>(null);

  // Sync state when modal opens or editingTransaction changes
  useEffect(() => {
    if (editingTransaction) {
      setModalType(editingTransaction.type);
      setDesc(editingTransaction.desc);
      setVal(editingTransaction.value.toString().replace('.', ','));
      setCategory(editingTransaction.category);
      setInstitution('');
      setYieldRate('');
      setLiquidity('');
      setDate(editingTransaction.date || getTodayISO());
      setStatus(editingTransaction.status || 'pago');
      setError(null);
    } else {
      setModalType(initialType);
      setDesc('');
      setVal('');
      setCategory(FINANCE_CATEGORY_NAMES[0]);
      setInvType(INVESTMENT_TYPES[0]);
      setInstitution('');
      setYieldRate('');
      setLiquidity('');
      setDate(getTodayISO());
      setStatus('pago');
      setError(null);
    }
  }, [isOpen, editingTransaction, initialType]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanVal = val.replace(/\./g, '').replace(',', '.');
    const parsedVal = parseFloat(cleanVal);

    if (!desc.trim()) {
      setError('Por favor, informe uma descrição para o lançamento.');
      return;
    }
    if (!Number.isFinite(parsedVal) || parsedVal <= 0) {
      setError('Por favor, informe um valor válido maior que zero.');
      return;
    }

    if (modalType === 'investimento') {
      onSaveInvestment({
        name: desc.trim(),
        type: invType,
        institution: institution.trim() || undefined,
        value: parsedVal,
        yieldRate: yieldRate.trim() || undefined,
        liquidity: liquidity.trim() || undefined,
        date: date || getTodayISO(),
      });
    } else {
      onSaveTransaction(
        {
          desc: desc.trim(),
          value: parsedVal,
          type: modalType,
          category,
          date: date || getTodayISO(),
          status,
        },
        editingTransaction ? editingTransaction.id : undefined
      );
    }

    onClose();
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
        backdropFilter: 'blur(8px)',
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: '440px',
          maxHeight: '90vh',
          overflowY: 'auto',
          backgroundColor: 'var(--settings-panel-bg, #0F1433)',
          border: '1px solid var(--settings-border, rgba(255, 255, 255, 0.15))',
          borderRadius: '1.25rem',
          padding: '1.25rem',
          boxShadow: 'var(--card-shadow, 0 20px 50px rgba(0, 0, 0, 0.6))',
          color: 'var(--ink, #FFFFFF)',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '1.1rem',
            paddingBottom: '0.75rem',
            borderBottom: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <div
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background:
                  modalType === 'entrada'
                    ? 'rgba(34, 197, 94, 0.2)'
                    : modalType === 'investimento'
                    ? 'rgba(6, 182, 212, 0.2)'
                    : 'rgba(239, 68, 68, 0.2)',
                color:
                  modalType === 'entrada'
                    ? 'var(--green, #22C55E)'
                    : modalType === 'investimento'
                    ? '#06B6D4'
                    : 'var(--red, #EF4444)',
              }}
            >
              {modalType === 'entrada' ? (
                <ArrowDownRight size={18} />
              ) : modalType === 'investimento' ? (
                <TrendingUp size={18} />
              ) : (
                <ArrowUpRight size={18} />
              )}
            </div>
            <div>
              <h3
                style={{
                  margin: 0,
                  fontSize: '1.05rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-display)',
                }}
              >
                {editingTransaction ? 'Editar Lançamento' : 'Nova Transação'}
              </h3>
              <p
                style={{
                  margin: 0,
                  fontSize: '0.7rem',
                  color: 'var(--ink-soft, #94A3B8)',
                }}
              >
                {editingTransaction
                  ? 'Atualize os dados da movimentação financeira'
                  : 'Registre uma receita, despesa ou investimento'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            style={{
              background: 'rgba(255, 255, 255, 0.08)',
              border: 'none',
              borderRadius: '50%',
              width: '30px',
              height: '30px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--ink-soft, #94A3B8)',
              cursor: 'pointer',
            }}
          >
            <X size={16} />
          </button>
        </div>

        {/* Type Selector (Only if not editing existing) */}
        {!editingTransaction && (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '0.4rem',
              marginBottom: '1rem',
              background: 'var(--panel, rgba(255, 255, 255, 0.04))',
              padding: '0.3rem',
              borderRadius: '0.8rem',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
            }}
          >
            <button
              type="button"
              onClick={() => setModalType('saida')}
              style={{
                border: 'none',
                borderRadius: '0.6rem',
                padding: '0.5rem 0.2rem',
                fontSize: '0.75rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.3rem',
                cursor: 'pointer',
                background:
                  modalType === 'saida'
                    ? 'linear-gradient(135deg, #EF4444, #DC2626)'
                    : 'transparent',
                color: modalType === 'saida' ? '#FFFFFF' : 'var(--ink-soft)',
                boxShadow:
                  modalType === 'saida'
                    ? '0 4px 12px rgba(239, 68, 68, 0.35)'
                    : 'none',
                transition: 'all 0.15s ease',
              }}
            >
              <ArrowUpRight size={14} />
              Despesa
            </button>
            <button
              type="button"
              onClick={() => setModalType('entrada')}
              style={{
                border: 'none',
                borderRadius: '0.6rem',
                padding: '0.5rem 0.2rem',
                fontSize: '0.75rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.3rem',
                cursor: 'pointer',
                background:
                  modalType === 'entrada'
                    ? 'linear-gradient(135deg, #22C55E, #16A34A)'
                    : 'transparent',
                color: modalType === 'entrada' ? '#FFFFFF' : 'var(--ink-soft)',
                boxShadow:
                  modalType === 'entrada'
                    ? '0 4px 12px rgba(34, 197, 94, 0.35)'
                    : 'none',
                transition: 'all 0.15s ease',
              }}
            >
              <ArrowDownRight size={14} />
              Receita
            </button>
            <button
              type="button"
              onClick={() => setModalType('investimento')}
              style={{
                border: 'none',
                borderRadius: '0.6rem',
                padding: '0.5rem 0.2rem',
                fontSize: '0.75rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.3rem',
                cursor: 'pointer',
                background:
                  modalType === 'investimento'
                    ? 'linear-gradient(135deg, #06B6D4, #3B82F6)'
                    : 'transparent',
                color: modalType === 'investimento' ? '#FFFFFF' : 'var(--ink-soft)',
                boxShadow:
                  modalType === 'investimento'
                    ? '0 4px 12px rgba(6, 182, 212, 0.35)'
                    : 'none',
                transition: 'all 0.15s ease',
              }}
            >
              <TrendingUp size={14} />
              Investimento
            </button>
          </div>
        )}

        {/* Error Alert */}
        {error && (
          <div
            style={{
              padding: '0.6rem 0.8rem',
              borderRadius: '0.6rem',
              backgroundColor: 'rgba(239, 68, 68, 0.15)',
              border: '1px solid rgba(239, 68, 68, 0.35)',
              color: '#FCA5A5',
              fontSize: '0.75rem',
              marginBottom: '0.9rem',
            }}
          >
            {error}
          </div>
        )}

        {/* Form Fields */}
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
          {/* Description */}
          <div>
            <label
              style={{
                display: 'block',
                fontSize: '0.72rem',
                fontWeight: 600,
                color: 'var(--settings-label-color, #94A3B8)',
                marginBottom: '0.35rem',
              }}
            >
              {modalType === 'investimento' ? 'Nome do Ativo / Aplicação' : 'Descrição'}
            </label>
            <div style={{ position: 'relative' }}>
              <input
                type="text"
                autoFocus
                placeholder={
                  modalType === 'entrada'
                    ? 'Ex: Salário mensal, Freelance, Rendimentos'
                    : modalType === 'investimento'
                    ? 'Ex: Tesouro Selic 2029, CDB Inter, Ações PETR4'
                    : 'Ex: Supermercado, Aluguel, Combustível, Jantar'
                }
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.65rem 0.8rem',
                  fontSize: '0.88rem',
                  borderRadius: '0.7rem',
                  border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.07))',
                  color: 'var(--ink, #FFFFFF)',
                  outline: 'none',
                }}
              />
            </div>
          </div>

          {/* Value and Date in Row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.65rem' }}>
            <div>
              <label
                style={{
                  display: 'block',
                  fontSize: '0.72rem',
                  fontWeight: 600,
                  color: 'var(--settings-label-color, #94A3B8)',
                  marginBottom: '0.35rem',
                }}
              >
                Valor (R$)
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type="text"
                  inputMode="decimal"
                  placeholder="0,00"
                  value={val}
                  onChange={(e) => setVal(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.65rem 0.8rem',
                    fontSize: '0.95rem',
                    fontWeight: 700,
                    fontFamily: 'var(--font-mono)',
                    borderRadius: '0.7rem',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.07))',
                    color:
                      modalType === 'entrada'
                        ? 'var(--green, #22C55E)'
                        : modalType === 'investimento'
                        ? '#06B6D4'
                        : 'var(--red, #EF4444)',
                    outline: 'none',
                  }}
                />
              </div>
            </div>

            <div>
              <label
                style={{
                  display: 'block',
                  fontSize: '0.72rem',
                  fontWeight: 600,
                  color: 'var(--settings-label-color, #94A3B8)',
                  marginBottom: '0.35rem',
                }}
              >
                Data
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.65rem 0.6rem',
                  fontSize: '0.82rem',
                  borderRadius: '0.7rem',
                  border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                  background: 'var(--input-bg, rgba(255, 255, 255, 0.07))',
                  color: 'var(--ink, #FFFFFF)',
                  outline: 'none',
                }}
              />
            </div>
          </div>

          {/* Category or Investment Type */}
          {modalType === 'investimento' ? (
            <>
              <div>
                <label
                  style={{
                    display: 'block',
                    fontSize: '0.72rem',
                    fontWeight: 600,
                    color: 'var(--settings-label-color, #94A3B8)',
                    marginBottom: '0.35rem',
                  }}
                >
                  Tipo de Investimento / Classe
                </label>
                <select
                  value={invType}
                  onChange={(e) => setInvType(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.65rem 0.8rem',
                    fontSize: '0.85rem',
                    borderRadius: '0.7rem',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                    background: 'var(--option-bg, #12173A)',
                    color: 'var(--ink, #FFFFFF)',
                    outline: 'none',
                    cursor: 'pointer',
                  }}
                >
                  {INVESTMENT_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  style={{
                    display: 'block',
                    fontSize: '0.72rem',
                    fontWeight: 600,
                    color: 'var(--settings-label-color, #94A3B8)',
                    marginBottom: '0.35rem',
                  }}
                >
                  Instituição Financeira / Corretora
                </label>
                <input
                  type="text"
                  placeholder="ex: Nubank, XP Investimentos, Banco Inter, Binance"
                  value={institution}
                  onChange={(e) => setInstitution(e.target.value)}
                  list="institution-list"
                  style={{
                    width: '100%',
                    padding: '0.65rem 0.8rem',
                    fontSize: '0.85rem',
                    borderRadius: '0.7rem',
                    border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                    background: 'var(--input-bg, rgba(255, 255, 255, 0.07))',
                    color: 'var(--ink, #FFFFFF)',
                    outline: 'none',
                  }}
                />
                <datalist id="institution-list">
                  {INVESTMENT_INSTITUTIONS.map((inst) => (
                    <option key={inst} value={inst} />
                  ))}
                </datalist>
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '0.65rem',
                }}
              >
                <div>
                  <label
                    style={{
                      display: 'block',
                      fontSize: '0.72rem',
                      fontWeight: 600,
                      color: 'var(--settings-label-color, #94A3B8)',
                      marginBottom: '0.35rem',
                    }}
                  >
                    Rendimento (opcional)
                  </label>
                  <input
                    type="text"
                    placeholder="ex: +100% CDI, +12,5% a.a."
                    value={yieldRate}
                    onChange={(e) => setYieldRate(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.65rem 0.8rem',
                      fontSize: '0.82rem',
                      borderRadius: '0.7rem',
                      border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.07))',
                      color: 'var(--ink, #FFFFFF)',
                      outline: 'none',
                    }}
                  />
                </div>
                <div>
                  <label
                    style={{
                      display: 'block',
                      fontSize: '0.72rem',
                      fontWeight: 600,
                      color: 'var(--settings-label-color, #94A3B8)',
                      marginBottom: '0.35rem',
                    }}
                  >
                    Liquidez / Vencimento
                  </label>
                  <input
                    type="text"
                    placeholder="ex: Diária (D+0), Venc. 2027"
                    value={liquidity}
                    onChange={(e) => setLiquidity(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.65rem 0.8rem',
                      fontSize: '0.82rem',
                      borderRadius: '0.7rem',
                      border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                      background: 'var(--input-bg, rgba(255, 255, 255, 0.07))',
                      color: 'var(--ink, #FFFFFF)',
                      outline: 'none',
                    }}
                  />
                </div>
              </div>
            </>
          ) : (
            <div>
              <label
                style={{
                  display: 'block',
                  fontSize: '0.72rem',
                  fontWeight: 600,
                  color: 'var(--settings-label-color, #94A3B8)',
                  marginBottom: '0.35rem',
                }}
              >
                Categoria
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.65rem 0.8rem',
                  fontSize: '0.85rem',
                  borderRadius: '0.7rem',
                  border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                  background: 'var(--option-bg, #12173A)',
                  color: 'var(--ink, #FFFFFF)',
                  outline: 'none',
                  cursor: 'pointer',
                }}
              >
                {FINANCE_CATEGORY_NAMES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Status (Pago vs Pendente) - Only for standard transactions */}
          {modalType !== 'investimento' && (
            <div>
              <label
                style={{
                  display: 'block',
                  fontSize: '0.72rem',
                  fontWeight: 600,
                  color: 'var(--settings-label-color, #94A3B8)',
                  marginBottom: '0.35rem',
                }}
              >
                Status do Lançamento
              </label>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '0.5rem',
                }}
              >
                <button
                  type="button"
                  onClick={() => setStatus('pago')}
                  style={{
                    padding: '0.55rem',
                    borderRadius: '0.65rem',
                    fontSize: '0.76rem',
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.35rem',
                    cursor: 'pointer',
                    border:
                      status === 'pago'
                        ? '1px solid var(--green, #22C55E)'
                        : '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                    background:
                      status === 'pago'
                        ? 'rgba(34, 197, 94, 0.15)'
                        : 'transparent',
                    color: status === 'pago' ? 'var(--green, #22C55E)' : 'var(--ink-soft)',
                  }}
                >
                  <CheckCircle2 size={15} />
                  {modalType === 'entrada' ? 'Recebido (Pago)' : 'Liquidado (Pago)'}
                </button>
                <button
                  type="button"
                  onClick={() => setStatus('pendente')}
                  style={{
                    padding: '0.55rem',
                    borderRadius: '0.65rem',
                    fontSize: '0.76rem',
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.35rem',
                    cursor: 'pointer',
                    border:
                      status === 'pendente'
                        ? '1px solid #F59E0B'
                        : '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                    background:
                      status === 'pendente'
                        ? 'rgba(245, 158, 11, 0.15)'
                        : 'transparent',
                    color: status === 'pendente' ? '#F59E0B' : 'var(--ink-soft)',
                  }}
                >
                  <Clock size={15} />
                  Pendente / Agendado
                </button>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div
            style={{
              display: 'flex',
              gap: '0.55rem',
              marginTop: '0.5rem',
              paddingTop: '0.75rem',
              borderTop: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
            }}
          >
            <button
              type="button"
              onClick={onClose}
              style={{
                flex: 1,
                padding: '0.65rem',
                borderRadius: '0.7rem',
                border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
                background: 'transparent',
                color: 'var(--ink-soft, #94A3B8)',
                fontSize: '0.82rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Cancelar
            </button>
            <button
              type="submit"
              style={{
                flex: 2,
                padding: '0.65rem',
                borderRadius: '0.7rem',
                border: 'none',
                background:
                  modalType === 'entrada'
                    ? 'linear-gradient(135deg, #22C55E, #16A34A)'
                    : modalType === 'investimento'
                    ? 'linear-gradient(135deg, #06B6D4, #3B82F6)'
                    : 'linear-gradient(135deg, var(--active, #3B82F6), var(--active2, #06B6D4))',
                color: '#FFFFFF',
                fontSize: '0.85rem',
                fontWeight: 700,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.4rem',
                boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)',
              }}
            >
              <Save size={16} />
              {editingTransaction ? 'Salvar Alterações' : 'Confirmar Lançamento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
