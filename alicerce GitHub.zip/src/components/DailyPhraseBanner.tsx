import React, { useState, useEffect, useMemo } from 'react';
import { DAILY_PHRASES, PhraseItem } from '../utils/constants';
import { BookOpenIcon, SparklesIcon, RefreshCwIcon } from './Icons';

export const DailyPhraseBanner: React.FC = () => {
  // Initialize with index 0 (Salmos 28:7), with support for user rotation
  const [currentIndex, setCurrentIndex] = useState(0);

  const [isRotating, setIsRotating] = useState(false);
  const [fadeAnim, setFadeAnim] = useState(true);

  const currentPhrase: PhraseItem = useMemo(() => {
    return DAILY_PHRASES[currentIndex % DAILY_PHRASES.length];
  }, [currentIndex]);

  const handleNextPhrase = () => {
    if (isRotating) return;
    setIsRotating(true);
    setFadeAnim(false);

    setTimeout(() => {
      // Pick next index, naturally alternating between biblical and motivational
      setCurrentIndex((prev) => (prev + 1) % DAILY_PHRASES.length);
      setFadeAnim(true);
      setTimeout(() => {
        setIsRotating(false);
      }, 350);
    }, 180);
  };

  const isVerse = currentPhrase.type === 'versiculo';

  return (
    <div
      className="fade-in"
      style={{
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: '1px solid rgba(255, 255, 255, 0.08)',
        borderRadius: '0.9rem',
        padding: '0.75rem 1rem',
        position: 'relative',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
        transition: 'all 0.3s ease',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '0.75rem',
          marginBottom: '0.4rem',
        }}
      >
        {/* Subtle Category Badge */}
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.35rem',
            fontSize: '0.66rem',
            fontWeight: 600,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            padding: '0.18rem 0.5rem',
            borderRadius: '0.4rem',
            background: isVerse
              ? 'rgba(139, 92, 246, 0.18)'
              : 'rgba(59, 130, 246, 0.18)',
            color: isVerse ? 'var(--verse-accent, #8B5CF6)' : 'var(--insp-accent, #3B82F6)',
            border: isVerse
              ? '1px solid rgba(139, 92, 246, 0.35)'
              : '1px solid rgba(59, 130, 246, 0.35)',
          }}
        >
          {isVerse ? <BookOpenIcon size={11} /> : <SparklesIcon size={11} />}
          <span>{isVerse ? 'Palavra & Fé' : 'Inspiração Diária'}</span>
        </div>

        {/* Action Button: Nova Frase */}
        <button
          type="button"
          onClick={handleNextPhrase}
          title="Ver outra frase ou versículo"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.3rem',
            background: 'var(--panel-strong, rgba(255, 255, 255, 0.06))',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.1))',
            borderRadius: '0.5rem',
            padding: '0.22rem 0.55rem',
            fontSize: '0.67rem',
            fontWeight: 500,
            color: 'var(--ink-soft)',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--ink)';
            e.currentTarget.style.borderColor = 'var(--active)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--ink-soft)';
            e.currentTarget.style.borderColor = 'var(--line)';
          }}
        >
          <span
            style={{
              display: 'inline-flex',
              transform: isRotating ? 'rotate(180deg)' : 'none',
              transition: 'transform 0.35s ease',
            }}
          >
            <RefreshCwIcon size={11} />
          </span>
          <span>Nova frase</span>
        </button>
      </div>

      {/* Quote / Verse Body */}
      <div
        style={{
          opacity: fadeAnim ? 1 : 0,
          transform: fadeAnim ? 'translateY(0)' : 'translateY(3px)',
          transition: 'opacity 0.2s ease, transform 0.2s ease',
        }}
      >
        <p
          style={{
            margin: '0 0 0.35rem 0',
            fontSize: '0.86rem',
            lineHeight: 1.5,
            color: 'var(--ink)',
            fontWeight: 500,
            fontStyle: isVerse ? 'normal' : 'italic',
            letterSpacing: '0.01em',
          }}
        >
          "{currentPhrase.text}"
        </p>
        <div
          style={{
            fontSize: '0.72rem',
            fontWeight: 600,
            color: isVerse ? 'var(--verse-ref, #7C3AED)' : 'var(--ink-soft)',
            textAlign: 'right',
            letterSpacing: '0.02em',
          }}
        >
          — {currentPhrase.authorOrRef}
        </div>
      </div>
    </div>
  );
};
