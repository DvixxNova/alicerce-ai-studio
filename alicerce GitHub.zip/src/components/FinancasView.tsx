import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Eye,
  EyeOff,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Wallet,
  PieChart,
  CreditCard,
  Target,
  Settings,
} from 'lucide-react';
import { Investment, Transaction, UserProfile } from '../types';
import {
  fmtBRL,
  genId,
  getTodayISO,
} from '../utils/constants';
import { FinanceTransactionModal } from './FinanceTransactionModal';
import { InvestmentsView } from './InvestmentsView';
import { FinanceQuickActions } from './FinanceQuickActions';
import { FinanceBarChartCard } from './FinanceBarChartCard';
import { FinanceExtratoTable } from './FinanceExtratoTable';
import { generateFinancialPDF } from '../utils/generateFinancialPdf';

interface FinancasViewProps {
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  investments: Investment[];
  setInvestments: React.Dispatch<React.SetStateAction<Investment[]>>;
  userProfile?: UserProfile;
  onUpdateProfile?: (profile: UserProfile) => void;
  onOpenSettings?: () => void;
}

type PeriodFilter = 'este_mes' | 'mes_passado' | 'ano' | 'todas';
type TypeFilter = 'todas' | 'entradas' | 'saidas';

export const FinancasView: React.FC<FinancasViewProps> = ({
  transactions,
  setTransactions,
  investments,
  setInvestments,
  userProfile,
  onUpdateProfile,
  onOpenSettings,
}) => {
  // Privacy: Hide/Show Values
  const [hideValues, setHideValues] = useState<boolean>(() => {
    try {
      return localStorage.getItem('alicerce_hide_financial_values') === 'true';
    } catch {
      return false;
    }
  });

  const toggleHideValues = () => {
    setHideValues((prev) => {
      const next = !prev;
      return next;
    });
    try {
      localStorage.setItem('alicerce_hide_financial_values', String(!hideValues));
    } catch {
      // ignore
    }
  };

  const formatMoney = (val: number): string => {
    if (hideValues) return 'R$ ••••••';
    return fmtBRL(val);
  };

  // Top Tabs Navigation: Controle de Gastos vs. Investimentos
  const [activeTab, setActiveTab] = useState<'gastos' | 'investimentos'>('gastos');

  // Filter States
  const [periodFilter, setPeriodFilter] = useState<PeriodFilter>('este_mes');
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('todas');
  const [searchQuery, setSearchQuery] = useState('');

  // Quick Actions Handlers
  const handleOpenEntrada = () => {
    setEditingTransaction(null);
    setModalInitialType('entrada');
    setIsModalOpen(true);
  };

  const handleOpenSaida = () => {
    setEditingTransaction(null);
    setModalInitialType('saida');
    setIsModalOpen(true);
  };

  const handleOpenInvestir = () => {
    setEditingTransaction(null);
    setModalInitialType('investimento');
    setIsModalOpen(true);
  };

  const handleOpenResumo = () => {
    setActiveTab('gastos');
    const el = document.getElementById('card-saldo-total-hero');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleDownloadPDF = () => {
    generateFinancialPDF(transactions, investments);
  };

  const handleResetFilters = () => {
    setPeriodFilter('este_mes');
    setTypeFilter('todas');
    setSearchQuery('');
  };

  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalInitialType, setModalInitialType] = useState<
    'entrada' | 'saida' | 'investimento'
  >('saida');
  const [editingTransaction, setEditingTransaction] =
    useState<Transaction | null>(null);

  // Calculate Dates for Period Filtering
  const now = new Date();
  const currentYearMonth = `${now.getFullYear()}-${String(
    now.getMonth() + 1
  ).padStart(2, '0')}`;

  const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const lastYearMonth = `${lastMonthDate.getFullYear()}-${String(
    lastMonthDate.getMonth() + 1
  ).padStart(2, '0')}`;

  const currentYear = `${now.getFullYear()}`;

  // Filter Transactions by Period
  const periodFilteredTransactions = useMemo(() => {
    return transactions.filter((t) => {
      const dateStr = t.date || getTodayISO();
      if (periodFilter === 'este_mes') {
        return dateStr.startsWith(currentYearMonth);
      }
      if (periodFilter === 'mes_passado') {
        return dateStr.startsWith(lastYearMonth);
      }
      if (periodFilter === 'ano') {
        return dateStr.startsWith(currentYear);
      }
      return true; // 'todas'
    });
  }, [transactions, periodFilter, currentYearMonth, lastYearMonth, currentYear]);

  // Overall Historical Balance
  const globalSaldo = useMemo(() => {
    let total = 0;
    transactions.forEach((t) => {
      total += t.type === 'entrada' ? t.value : -t.value;
    });
    return total;
  }, [transactions]);

  // Total Invested
  const totalInvestido = useMemo(() => {
    return investments.reduce((acc, i) => acc + i.value, 0);
  }, [investments]);

  // Total Net Worth (Global Balance + Investments)
  const patrimonioLiquido = useMemo(() => {
    return globalSaldo + totalInvestido;
  }, [globalSaldo, totalInvestido]);

  // Meta Financeira Total definida no perfil
  const metaFinanceira = userProfile?.totalFinancialGoal || 0;
  const percentMeta = useMemo(() => {
    if (metaFinanceira <= 0) return 0;
    const pct = (patrimonioLiquido / metaFinanceira) * 100;
    return Math.round(pct);
  }, [patrimonioLiquido, metaFinanceira]);

  const clampedProgressPct = useMemo(() => {
    if (metaFinanceira <= 0) return 0;
    return Math.max(0, Math.min(100, percentMeta));
  }, [percentMeta, metaFinanceira]);

  // Period Metrics (Entradas, Saídas, Saldo do Período)
  const { periodEntradas, periodSaidas, countEntradas, countSaidas } =
    useMemo(() => {
      let inc = 0;
      let exp = 0;
      let cInc = 0;
      let cExp = 0;

      periodFilteredTransactions.forEach((t) => {
        if (t.type === 'entrada') {
          inc += t.value;
          cInc++;
        } else {
          exp += t.value;
          cExp++;
        }
      });

      return {
        periodEntradas: inc,
        periodSaidas: exp,
        countEntradas: cInc,
        countSaidas: cExp,
      };
    }, [periodFilteredTransactions]);

  // Save Transaction (Add or Edit)
  const handleSaveTransaction = (
    data: Omit<Transaction, 'id'>,
    editingId?: string
  ) => {
    if (editingId) {
      setTransactions((prev) =>
        prev.map((t) => (t.id === editingId ? { ...t, ...data } : t))
      );
    } else {
      const newTx: Transaction = {
        id: genId(),
        ...data,
      };
      setTransactions((prev) => [newTx, ...prev]);
    }
  };

  // Save Investment
  const handleSaveInvestment = (data: Omit<Investment, 'id'>) => {
    const newInv: Investment = {
      id: genId(),
      ...data,
    };
    setInvestments((prev) => [newInv, ...prev]);
  };

  // Delete Transaction
  const handleDeleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  // Delete Investment
  const handleDeleteInvestment = (id: string) => {
    setInvestments((prev) => prev.filter((i) => i.id !== id));
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      {/* 1. Header Toolbar & Quick Controls */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.6rem',
        }}
      >
        <div>
          <h2
            style={{
              margin: 0,
              fontSize: '1.25rem',
              fontWeight: 800,
              fontFamily: 'var(--font-display)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.45rem',
              color: 'var(--ink, #FFFFFF)',
            }}
          >
            <Wallet size={22} style={{ color: 'var(--active, #06B6D4)' }} />
            <span>Finanças</span>
          </h2>
          <p
            style={{
              margin: 0,
              fontSize: '0.72rem',
              color: 'var(--ink-soft, #94A3B8)',
              marginTop: '0.1rem',
            }}
          >
            Controle de fluxo de caixa, patrimônio e despesas
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
          {/* Eye Toggle (Hide/Show values) */}
          <button
            type="button"
            onClick={toggleHideValues}
            title={hideValues ? 'Mostrar valores monetários' : 'Ocultar valores monetários'}
            style={{
              background: 'var(--panel-strong, rgba(255, 255, 255, 0.08))',
              border: '1px solid var(--line, rgba(255, 255, 255, 0.15))',
              borderRadius: '0.65rem',
              padding: '0.45rem 0.65rem',
              color: hideValues ? 'var(--green, #22C55E)' : 'var(--ink-soft, #94A3B8)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              fontSize: '0.75rem',
              fontWeight: 600,
              cursor: 'pointer',
              transition: 'all 0.15s ease',
            }}
          >
            {hideValues ? <EyeOff size={15} /> : <Eye size={15} />}
            <span>{hideValues ? 'Oculto' : 'Visível'}</span>
          </button>
        </div>
      </div>

      {/* Estilos específicos do seletor de abas com suporte a Cyberpunk e Light Mode */}
      <style>{`
        .finance-main-tab-pill {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 0.65rem 0.9rem;
          border-radius: 0.75rem;
          font-family: var(--font-display);
          font-weight: 800;
          font-size: 0.84rem;
          cursor: pointer;
          transition: all 0.22s cubic-bezier(0.16, 1, 0.3, 1);
          border: 1px solid transparent;
          color: var(--ink-soft, #94A3B8);
          background: transparent;
        }
        .finance-main-tab-pill:hover {
          color: var(--ink, #FFFFFF);
          background: rgba(255, 255, 255, 0.04);
        }
        .finance-main-tab-pill.active {
          background: var(--active, #3B82F6);
          color: #FFFFFF;
          border-color: var(--active, #3B82F6);
          box-shadow: 0 4px 16px var(--active-glow, rgba(6, 182, 212, 0.35));
        }
        /* ⚡ Tema Cyberpunk (Verde Neon & Preto) */
        .theme-cyberpunk .finance-main-tab-pill.active {
          background: rgba(0, 255, 102, 0.16) !important;
          border-color: #00FF66 !important;
          color: #00FF66 !important;
          box-shadow: 0 0 16px rgba(0, 255, 102, 0.45), inset 0 0 10px rgba(0, 255, 102, 0.15) !important;
        }
        /* ☀️ Modo Claro (Slate Escuro com Glassmorphism) */
        .theme-light .finance-main-tab-pill.active {
          background: #0F172A !important;
          border-color: #0F172A !important;
          color: #FFFFFF !important;
          box-shadow: 0 4px 14px rgba(15, 23, 42, 0.25) !important;
        }
        /* 👑 Luxury Theme */
        .theme-luxury .finance-main-tab-pill.active {
          background: #1C1917 !important;
          border-color: #D97706 !important;
          color: #FBBF24 !important;
          box-shadow: 0 4px 14px rgba(217, 119, 6, 0.25) !important;
        }
        /* 🌌 Cosmic Theme */
        .theme-cosmic .finance-main-tab-pill.active {
          background: rgba(168, 85, 247, 0.28) !important;
          border-color: #A855F7 !important;
          color: #FAF5FF !important;
          box-shadow: 0 0 16px rgba(168, 85, 247, 0.4) !important;
        }
        /* 🌊 Ocean Theme */
        .theme-ocean .finance-main-tab-pill.active {
          background: rgba(6, 182, 212, 0.25) !important;
          border-color: #06B6D4 !important;
          color: #ECFEFF !important;
          box-shadow: 0 0 16px rgba(6, 182, 212, 0.4) !important;
        }
      `}</style>

      {/* 1.1 Navegação por Abas (Tabs System) */}
      <div
        id="finance-tabs-nav"
        role="tablist"
        aria-label="Abas do Painel Financeiro"
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '0.4rem',
          background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
          borderRadius: '0.95rem',
          padding: '0.35rem',
          backdropFilter: 'blur(14px)',
          boxShadow: 'var(--card-shadow, 0 4px 18px rgba(0, 0, 0, 0.25))',
        }}
      >
        {/* Aba 1: Controle de Gastos */}
        <button
          type="button"
          role="tab"
          id="tab-btn-controle-gastos"
          aria-selected={activeTab === 'gastos'}
          onClick={() => setActiveTab('gastos')}
          className={`finance-main-tab-pill ${activeTab === 'gastos' ? 'active' : ''}`}
        >
          <PieChart size={16} />
          <span>Controle de Gastos</span>
        </button>

        {/* Aba 2: Investimentos */}
        <button
          type="button"
          role="tab"
          id="tab-btn-investimentos"
          aria-selected={activeTab === 'investimentos'}
          onClick={() => setActiveTab('investimentos')}
          className={`finance-main-tab-pill ${activeTab === 'investimentos' ? 'active' : ''}`}
        >
          <TrendingUp size={16} />
          <span>Investimentos</span>
          <span
            style={{
              fontSize: '0.66rem',
              padding: '0.1rem 0.4rem',
              borderRadius: '999px',
              background: activeTab === 'investimentos'
                ? 'rgba(255, 255, 255, 0.25)'
                : 'rgba(255, 255, 255, 0.08)',
              color: activeTab === 'investimentos' ? 'inherit' : 'var(--ink-soft)',
              fontFamily: 'var(--font-mono)',
              fontWeight: 700,
            }}
          >
            {investments.length}
          </span>
        </button>
      </div>

      {/* 2. TRANSIÇÃO SUAVE EM FADE ENTRE O PAINEL DE FINANÇAS E INVESTIMENTOS */}
      <AnimatePresence mode="wait">
        {activeTab === 'investimentos' ? (
          <motion.div
            key="tab-panel-investimentos"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
            style={{ width: '100%' }}
          >
            <InvestmentsView
              investments={investments}
              setInvestments={setInvestments}
              hideValues={hideValues}
              formatMoney={formatMoney}
              onToggleHideValues={toggleHideValues}
            />
          </motion.div>
        ) : (
          <motion.div
            key="tab-panel-gastos"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '0.85rem',
              width: '100%',
            }}
          >
            {/* Barra de Ações Rápidas (Apenas no Controle de Gastos) */}
            <FinanceQuickActions
              onOpenEntrada={handleOpenEntrada}
              onOpenSaida={handleOpenSaida}
              onOpenInvestir={handleOpenInvestir}
              onOpenResumo={handleOpenResumo}
              showInvestir={false}
              onDownloadPDF={handleDownloadPDF}
              onToggleHideValues={toggleHideValues}
              hideValues={hideValues}
              onResetFilters={handleResetFilters}
            />

            {/* 3. Hero Card: Saldo Total Atual */}
            <div
              id="card-saldo-total-hero"
              className="hero-card"
              style={{
                position: 'relative',
                overflow: 'hidden',
                borderRadius: '1.25rem',
                padding: '1.15rem 1.25rem',
                background:
                  'linear-gradient(135deg, var(--active, #3B82F6), var(--active2, #06B6D4))',
                boxShadow: 'var(--card-shadow, 0 14px 34px rgba(0, 0, 0, 0.4))',
                color: '#FFFFFF',
                marginBottom: 0,
              }}
            >
        <CreditCard
          size={74}
          style={{
            position: 'absolute',
            right: '-10px',
            top: '12px',
            opacity: 0.22,
            transform: 'rotate(12deg)',
            pointerEvents: 'none',
          }}
        />

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '0.2rem',
          }}
        >
          <span
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: '0.76rem',
              fontWeight: 500,
              opacity: 0.9,
              letterSpacing: '0.02em',
            }}
          >
            Saldo Total Atual
          </span>
          <button
            type="button"
            onClick={toggleHideValues}
            style={{
              background: 'rgba(255, 255, 255, 0.15)',
              border: 'none',
              borderRadius: '50%',
              width: '28px',
              height: '28px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              cursor: 'pointer',
            }}
            title={hideValues ? 'Mostrar Saldo' : 'Ocultar Saldo'}
          >
            {hideValues ? <EyeOff size={14} /> : <Eye size={14} />}
          </button>
        </div>

        {/* Amount */}
        <div
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '2.1rem',
            fontWeight: 800,
            lineHeight: 1.15,
            letterSpacing: '-0.02em',
          }}
        >
          {formatMoney(globalSaldo)}
        </div>

        {/* Trend & Net Worth Subtitle */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginTop: '0.65rem',
            flexWrap: 'wrap',
            gap: '0.4rem',
          }}
        >
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.25rem',
              fontSize: '0.72rem',
              fontWeight: 600,
              background: 'rgba(255, 255, 255, 0.22)',
              padding: '0.2rem 0.55rem',
              borderRadius: '1rem',
              backdropFilter: 'blur(4px)',
            }}
          >
            {globalSaldo >= 0 ? (
              <ArrowUpRight size={13} />
            ) : (
              <ArrowDownRight size={13} />
            )}
            <span>
              {globalSaldo >= 0 ? 'Saldo Positivo' : 'Atenção: Saldo Negativo'}
            </span>
          </div>

          <div
            style={{
              fontSize: '0.72rem',
              opacity: 0.9,
              fontFamily: 'var(--font-mono)',
            }}
          >
            Líquido Período: <strong>{formatMoney(periodEntradas - periodSaidas)}</strong>
          </div>
        </div>
      </div>

      {/* Barra de Progresso Visual: Meta Financeira Total */}
      <div
        id="card-meta-financeira-progresso"
        style={{
          background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
          border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
          borderRadius: '1rem',
          padding: '0.85rem 1rem',
          boxShadow: 'var(--card-shadow, 0 4px 18px rgba(0, 0, 0, 0.25))',
          backdropFilter: 'blur(12px)',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.55rem',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '0.5rem',
            flexWrap: 'wrap',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <div
              style={{
                width: '28px',
                height: '28px',
                borderRadius: '0.55rem',
                background: metaFinanceira > 0 ? 'rgba(34, 197, 94, 0.16)' : 'rgba(255, 255, 255, 0.08)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: metaFinanceira > 0 ? 'var(--green, #22C55E)' : 'var(--ink-soft, #94A3B8)',
              }}
            >
              <Target size={15} />
            </div>
            <div>
              <div
                style={{
                  fontSize: '0.78rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-display)',
                  color: 'var(--ink, #FFFFFF)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                }}
              >
                <span>Meta Financeira Total</span>
                {metaFinanceira > 0 && percentMeta >= 100 && (
                  <span
                    style={{
                      fontSize: '0.62rem',
                      fontWeight: 800,
                      padding: '0.1rem 0.4rem',
                      borderRadius: '999px',
                      background: 'rgba(34, 197, 94, 0.22)',
                      color: '#4ADE80',
                      border: '1px solid rgba(34, 197, 94, 0.4)',
                    }}
                  >
                    🎉 Atingida!
                  </span>
                )}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            {metaFinanceira > 0 ? (
              <span
                style={{
                  fontSize: '0.82rem',
                  fontWeight: 800,
                  fontFamily: 'var(--font-mono)',
                  color: percentMeta >= 100 ? 'var(--green, #22C55E)' : 'var(--active, #3B82F6)',
                }}
              >
                {percentMeta}%
              </span>
            ) : null}

            {onOpenSettings && (
              <button
                type="button"
                id="btn-ajustar-meta-perfil"
                onClick={onOpenSettings}
                title="Definir ou ajustar meta no perfil"
                style={{
                  background: 'rgba(255, 255, 255, 0.07)',
                  border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
                  borderRadius: '0.5rem',
                  padding: '0.22rem 0.5rem',
                  fontSize: '0.68rem',
                  fontWeight: 600,
                  color: 'var(--ink-soft, #94A3B8)',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.25rem',
                  transition: 'all 0.18s ease',
                }}
              >
                <Settings size={12} />
                <span>{metaFinanceira > 0 ? 'Ajustar Meta' : 'Definir Meta'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Visual Progress Bar */}
        {metaFinanceira > 0 ? (
          <>
            <div
              style={{
                width: '100%',
                height: '9px',
                background: 'rgba(255, 255, 255, 0.08)',
                borderRadius: '999px',
                overflow: 'hidden',
                position: 'relative',
              }}
            >
              <div
                style={{
                  height: '100%',
                  width: `${clampedProgressPct}%`,
                  background:
                    percentMeta >= 100
                      ? 'linear-gradient(90deg, #10B981, #22C55E)'
                      : 'linear-gradient(90deg, var(--active, #3B82F6), var(--active2, #06B6D4))',
                  borderRadius: '999px',
                  boxShadow:
                    percentMeta >= 100
                      ? '0 0 10px rgba(34, 197, 94, 0.5)'
                      : '0 0 10px var(--active-glow, rgba(6, 182, 212, 0.4))',
                  transition: 'width 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
                }}
              />
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                fontSize: '0.7rem',
                color: 'var(--ink-soft, #94A3B8)',
                fontFamily: 'var(--font-mono)',
              }}
            >
              <span>
                Patrimônio: <strong style={{ color: 'var(--ink, #FFFFFF)' }}>{formatMoney(patrimonioLiquido)}</strong>
              </span>
              <span>
                Meta: <strong style={{ color: 'var(--ink, #FFFFFF)' }}>{formatMoney(metaFinanceira)}</strong>
              </span>
            </div>
          </>
        ) : (
          <div
            style={{
              fontSize: '0.72rem',
              color: 'var(--ink-soft, #94A3B8)',
              lineHeight: 1.4,
            }}
          >
            Nenhuma meta financeira definida ainda. Clique em <strong>"Definir Meta"</strong> ou acesse as configurações do perfil para acompanhar a barra de progresso do seu patrimônio acumulado.
          </div>
        )}
      </div>

      {/* 4. Métricas Principais: Entradas e Saídas (Exclusivo Controle de Gastos) */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: '0.55rem',
        }}
      >
        {/* Entradas */}
        <div
          style={{
            background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
            borderRadius: '0.9rem',
            padding: '0.75rem 0.75rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.25rem',
            boxShadow: 'var(--card-shadow)',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <span
              style={{
                fontSize: '0.62rem',
                fontFamily: 'var(--font-mono)',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                color: 'var(--ink-soft, #94A3B8)',
              }}
            >
              Receitas
            </span>
            <span
              style={{
                width: '20px',
                height: '20px',
                borderRadius: '50%',
                background: 'rgba(34, 197, 94, 0.18)',
                color: 'var(--green, #22C55E)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <ArrowDownRight size={12} />
            </span>
          </div>
          <div
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '1rem',
              fontWeight: 700,
              color: 'var(--green, #22C55E)',
            }}
          >
            {formatMoney(periodEntradas)}
          </div>
          <div
            style={{
              fontSize: '0.6rem',
              color: 'var(--ink-soft, #94A3B8)',
            }}
          >
            {countEntradas} {countEntradas === 1 ? 'entrada' : 'entradas'}
          </div>
        </div>

        {/* Saídas */}
        <div
          style={{
            background: 'var(--panel-strong, rgba(255, 255, 255, 0.05))',
            border: '1px solid var(--line, rgba(255, 255, 255, 0.12))',
            borderRadius: '0.9rem',
            padding: '0.75rem 0.75rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.25rem',
            boxShadow: 'var(--card-shadow)',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <span
              style={{
                fontSize: '0.62rem',
                fontFamily: 'var(--font-mono)',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                color: 'var(--ink-soft, #94A3B8)',
              }}
            >
              Despesas
            </span>
            <span
              style={{
                width: '20px',
                height: '20px',
                borderRadius: '50%',
                background: 'rgba(239, 68, 68, 0.18)',
                color: 'var(--red, #EF4444)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <ArrowUpRight size={12} />
            </span>
          </div>
          <div
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '1rem',
              fontWeight: 700,
              color: 'var(--red, #EF4444)',
            }}
          >
            {formatMoney(periodSaidas)}
          </div>
          <div
            style={{
              fontSize: '0.6rem',
              color: 'var(--ink-soft, #94A3B8)',
            }}
          >
            {countSaidas} {countSaidas === 1 ? 'saída' : 'saídas'}
          </div>
        </div>
      </div>

      {/* 5. Gráfico Principal com Alternância: Barras vs. Pizza e Filtro Interativo (Mês, Ano, Total) */}
      <FinanceBarChartCard
        transactions={transactions}
        hideValues={hideValues}
        formatMoney={formatMoney}
      />

      {/* 6. Extrato de Lançamentos em Linhas Simples (Apenas Receitas e Despesas) */}
      <FinanceExtratoTable
        transactions={transactions}
        onDeleteTransaction={handleDeleteTransaction}
        hideValues={hideValues}
        formatMoney={formatMoney}
      />
          </motion.div>
        )}
      </AnimatePresence>

      {/* 12. Modal for New / Edit Transaction */}
      <FinanceTransactionModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSaveTransaction={handleSaveTransaction}
        onSaveInvestment={handleSaveInvestment}
        editingTransaction={editingTransaction}
        initialType={modalInitialType}
      />
    </div>
  );
};
