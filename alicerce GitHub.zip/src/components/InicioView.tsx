import React, { useState, useEffect, useMemo } from 'react';
import {
  fmtBRL,
  getDailyTip,
  getGreeting,
  getWeatherConditionInfo,
} from '../utils/constants';
import {
  Investment,
  Note,
  TabId,
  Transaction,
  UserProfile,
  WeatherState,
  Workout,
} from '../types';
import {
  CheckIcon,
  CloudSunIcon,
  CreditCardIcon,
  FileTextIcon,
  LightbulbIcon,
} from './Icons';
import { LogIn } from 'lucide-react';
import { TempoView } from './TempoView';
import { DashboardChart } from './DashboardChart';
import { WorkoutCard } from './WorkoutCard';
import { DailyPhraseBanner } from './DailyPhraseBanner';

interface InicioViewProps {
  transactions: Transaction[];
  workouts: Workout[];
  setWorkouts?: React.Dispatch<React.SetStateAction<Workout[]>>;
  notes: Note[];
  investments: Investment[];
  setTab: (tab: TabId) => void;
  name: string;
  setName: (name: string) => void;
  weather: WeatherState;
  setWeather: React.Dispatch<React.SetStateAction<WeatherState>>;
  userProfile?: UserProfile;
  onOpenLogin?: () => void;
  onOpenIPhoneDownload?: () => void;
}

export const InicioView: React.FC<InicioViewProps> = ({
  transactions,
  workouts,
  setWorkouts,
  notes,
  investments,
  setTab,
  name,
  setName,
  weather,
  setWeather,
  userProfile,
  onOpenLogin,
  onOpenIPhoneDownload,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(name);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showWeather, setShowWeather] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const { entradas, saidas, saldo } = useMemo(() => {
    let inc = 0;
    let exp = 0;
    transactions.forEach((t) => {
      if (t.type === 'entrada') inc += t.value;
      else exp += t.value;
    });
    return { entradas: inc, saidas: exp, saldo: inc - exp };
  }, [transactions]);

  const totalInvestido = useMemo(
    () => investments.reduce((acc, inv) => acc + inv.value, 0),
    [investments]
  );

  const dailyTip = useMemo(() => getDailyTip(), []);
  const weatherInfo = weather.data
    ? getWeatherConditionInfo(weather.data.current.weather_code)
    : null;

  function handleSaveName(e: React.FormEvent) {
    e.preventDefault();
    setName(tempName.trim());
    setIsEditingName(false);
  }

  return (
    <div>
      {/* Bloco de Frases e Versículos no Topo do Menu Início */}
      <DailyPhraseBanner />

      {/* Card de Boas-Vindas & Login Descontraído se não estiver logado */}
      {!userProfile?.isLoggedIn && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.12), rgba(239, 68, 68, 0.08))',
            border: '1px solid rgba(245, 158, 11, 0.28)',
            borderRadius: '1rem',
            padding: '0.75rem 0.9rem',
            marginBottom: '0.85rem',
            gap: '0.6rem',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.2rem',
                flexShrink: 0,
                boxShadow: '0 4px 12px rgba(245, 158, 11, 0.35)',
              }}
            >
              🚀
            </div>
            <div>
              <div style={{ fontSize: '0.82rem', fontWeight: 800, color: 'var(--ink)' }}>
                Painel de Acesso & Avatares
              </div>
              <div style={{ fontSize: '0.68rem', color: 'var(--ink-soft)' }}>
                Crie seu perfil ou entre com 1 toque como VIP
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenLogin}
            style={{
              padding: '0.45rem 0.75rem',
              borderRadius: '0.65rem',
              background: '#F59E0B',
              border: 'none',
              color: '#000000',
              fontSize: '0.72rem',
              fontWeight: 800,
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              boxShadow: '0 4px 12px rgba(245, 158, 11, 0.3)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.3rem',
            }}
          >
            <LogIn size={13} />
            <span>Entrar</span>
          </button>
        </div>
      )}

      {name && !isEditingName ? (
        <div className="hi-row">
          <h2 className="section-title" style={{ margin: 0 }}>
            {getGreeting()}, {name} 👋
          </h2>
          <button
            type="button"
            className="link-btn"
            onClick={() => {
              setTempName(name);
              setIsEditingName(true);
            }}
          >
            editar
          </button>
        </div>
      ) : (
        <form
          className="form-block"
          onSubmit={handleSaveName}
          style={{ marginBottom: '0.9rem' }}
        >
          <div className="field-row">
            <input
              placeholder="Como podemos te chamar?"
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              autoFocus
            />
          </div>
          <button className="btn-add" type="submit">
            <CheckIcon size={16} /> Salvar nome
          </button>
        </form>
      )}

      {/* Clock card */}
      <div className="clock-card">
        <div className="clock-left">
          <div className="clock-time">
            {currentTime.toLocaleTimeString('pt-BR', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </div>
          <div className="clock-date">
            {currentTime.toLocaleDateString('pt-BR', { weekday: 'long' })}
          </div>
          <div className="clock-date-sub">
            {currentTime.toLocaleDateString('pt-BR', {
              day: '2-digit',
              month: 'long',
              year: 'numeric',
            })}
          </div>
        </div>
        <div className="clock-divider" />
        {weather.data && weatherInfo ? (
          <button
            type="button"
            className="clock-right"
            onClick={() => setShowWeather((prev) => !prev)}
            title="Toque para ver a previsão detalhada"
          >
            <weatherInfo.Icon size={30} color={weatherInfo.color} />
            <div className="clock-temp">
              {Math.round(weather.data.current.temperature_2m)}°
            </div>
            <div className="clock-city">{weather.data.name}</div>
          </button>
        ) : (
          <button
            type="button"
            className="clock-right clock-right-cta"
            onClick={() => setShowWeather((prev) => !prev)}
            title="Toque para ver a previsão do tempo"
          >
            <CloudSunIcon size={26} />
            <span>{showWeather ? 'Fechar clima' : 'Ver clima'}</span>
          </button>
        )}
      </div>

      {/* Inline Weather Panel */}
      {showWeather && (
        <div
          className="form-block fade-in"
          style={{
            marginBottom: '1rem',
            borderStyle: 'solid',
            borderColor: 'rgba(34, 211, 238, 0.4)',
            padding: '0.9rem',
          }}
        >
          <TempoView
            weather={weather}
            setWeather={setWeather}
            onClose={() => setShowWeather(false)}
            hideTitle={false}
          />
        </div>
      )}

      {/* Wallet section */}
      <div className="section-row">
        <span
          className="section-title"
          style={{ margin: 0, fontSize: '0.95rem' }}
        >
          Carteira
        </span>
        <button
          type="button"
          className="link-btn"
          onClick={() => setTab('financas')}
        >
          ver tudo
        </button>
      </div>

      <div className="hero-card" style={{ marginBottom: '0.55rem' }}>
        <CreditCardIcon size={70} className="deco" />
        <div className="l">Saldo total</div>
        <div className="v">{fmtBRL(saldo)}</div>
      </div>

      <div className="stat-row" style={{ marginBottom: '0.55rem' }}>
        <div className="stat-sm">
          <div className="l">Entradas</div>
          <div className="v" style={{ color: 'var(--green)' }}>
            {fmtBRL(entradas)}
          </div>
        </div>
        <div className="stat-sm">
          <div className="l">Saídas</div>
          <div className="v" style={{ color: 'var(--red)' }}>
            {fmtBRL(saidas)}
          </div>
        </div>
      </div>

      <div className="stat-sm" style={{ marginBottom: '1rem' }}>
        <div className="l">Valor investido</div>
        <div className="v" style={{ color: 'var(--green-invest, #22C55E)' }}>
          {fmtBRL(totalInvestido)}
        </div>
      </div>

      {/* 2. Gráfico Financeiro Exclusivo com Seletor Pizza/Rosca vs Barras */}
      <DashboardChart transactions={transactions} />

      {/* Shortcuts */}
      <div className="section-row">
        <span
          className="section-title"
          style={{ margin: 0, fontSize: '0.95rem' }}
        >
          Atalhos
        </span>
      </div>

      <div className="overview-grid" style={{ marginBottom: '1.2rem' }}>
        <button
          type="button"
          className="overview-card"
          onClick={() => setTab('notas')}
        >
          <span
            className="ic-wrap"
            style={{
              background: 'linear-gradient(135deg, #8B5CF6, #6366F1)',
            }}
          >
            <FileTextIcon size={19} />
          </span>
          <div className="ov-label">Anotações</div>
          <div className="ov-value">
            {notes.length} {notes.length === 1 ? 'nota' : 'notas'}
          </div>
        </button>

        <button
          type="button"
          className="overview-card"
          onClick={() => setTab('dicas')}
        >
          <span
            className="ic-wrap"
            style={{
              background: 'linear-gradient(135deg, #F59E0B, #FDE047)',
            }}
          >
            <LightbulbIcon size={19} />
          </span>
          <div className="ov-label">Dica do dia</div>
          <div
            className="ov-value"
            style={{ fontSize: '0.72rem', fontWeight: 500 }}
          >
            {dailyTip.cat}
          </div>
        </button>
      </div>

      {/* 3. Card de Treinos Separado na Parte Inferior da Tela */}
      <WorkoutCard workouts={workouts} setWorkouts={setWorkouts} setTab={setTab} />

      {transactions.length === 0 &&
        workouts.length === 0 &&
        notes.length === 0 && (
          <div className="empty" style={{ marginTop: '0.9rem' }}>
            Seu painel vai ganhar vida assim que você registrar algo em
            Finanças, Treino ou Notas.
          </div>
        )}
    </div>
  );
};
