import React, { useState, useEffect, useMemo } from 'react';
import {
  fmtBRL,
  getDailyTip,
  getGreeting,
  getWeatherConditionInfo,
} from '../utils/constants';
import {
  Investment,
  Note,
  TabId,
  Transaction,
  UserProfile,
  WeatherState,
  Workout,
} from '../types';
import {
  CheckIcon,
  CloudSunIcon,
  CreditCardIcon,
  FileTextIcon,
  LightbulbIcon,
} from './Icons';
import { LogIn, Smartphone, Copy, Check, QrCode, Mic, Compass } from 'lucide-react';
import { TempoView } from './TempoView';
import { DashboardChart } from './DashboardChart';
import { WorkoutCard } from './WorkoutCard';
import { DailyPhraseBanner } from './DailyPhraseBanner';
import { detectWeatherAlert } from '../utils/weatherAlerts';

interface InicioViewProps {
  transactions: Transaction[];
  workouts: Workout[];
  setWorkouts?: React.Dispatch<React.SetStateAction<Workout[]>>;
  notes: Note[];
  investments: Investment[];
  setTab: (tab: TabId) => void;
  name: string;
  setName: (name: string) => void;
  weather: WeatherState;
  setWeather: React.Dispatch<React.SetStateAction<WeatherState>>;
  userProfile?: UserProfile;
  onOpenLogin?: () => void;
  onOpenIPhoneDownload?: () => void;
  onOpenVoiceAssistant?: () => void;
}

export const InicioView: React.FC<InicioViewProps> = ({
  transactions,
  workouts,
  setWorkouts,
  notes,
  investments,
  setTab,
  name,
  setName,
  weather,
  setWeather,
  userProfile,
  onOpenLogin,
  onOpenIPhoneDownload,
  onOpenVoiceAssistant,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(name);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showWeather, setShowWeather] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyAppUrl = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const url = window.location.href;
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(url);
      } else {
        const input = document.createElement('input');
        input.value = url;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2400);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const { entradas, saidas, saldo } = useMemo(() => {
    let inc = 0;
    let exp = 0;
    transactions.forEach((t) => {
      if (t.type === 'entrada') inc += t.value;
      else exp += t.value;
    });
    return { entradas: inc, saidas: exp, saldo: inc - exp };
  }, [transactions]);

  const totalInvestido = useMemo(
    () => investments.reduce((acc, inv) => acc + inv.value, 0),
    [investments]
  );

  const dailyTip = useMemo(() => getDailyTip(), []);
  const weatherInfo = weather.data
    ? getWeatherConditionInfo(weather.data.current.weather_code)
    : null;
  const weatherAlert = useMemo(() => {
    return detectWeatherAlert(weather.data);
  }, [weather.data]);

  function handleSaveName(e: React.FormEvent) {
    e.preventDefault();
    setName(tempName.trim());
    setIsEditingName(false);
  }

  return (
    <div>
      {/* Bloco de Frases e Versículos no Topo do Menu Início */}
      <DailyPhraseBanner />

      {/* Card de Boas-Vindas & Login Descontraído se não estiver logado */}
      {!userProfile?.isLoggedIn && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.12), rgba(239, 68, 68, 0.08))',
            border: '1px solid rgba(245, 158, 11, 0.28)',
            borderRadius: '1rem',
            padding: '0.75rem 0.9rem',
            marginBottom: '0.85rem',
            gap: '0.6rem',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.2rem',
                flexShrink: 0,
                boxShadow: '0 4px 12px rgba(245, 158, 11, 0.35)',
              }}
            >
              🚀
            </div>
            <div>
              <div style={{ fontSize: '0.82rem', fontWeight: 800, color: 'var(--ink)' }}>
                Painel de Acesso & Avatares
              </div>
              <div style={{ fontSize: '0.68rem', color: 'var(--ink-soft)' }}>
                Crie seu perfil ou entre com 1 toque como VIP
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenLogin}
            style={{
              padding: '0.45rem 0.75rem',
              borderRadius: '0.65rem',
              background: '#F59E0B',
              border: 'none',
              color: '#000000',
              fontSize: '0.72rem',
              fontWeight: 800,
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              boxShadow: '0 4px 12px rgba(245, 158, 11, 0.3)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.3rem',
            }}
          >
            <LogIn size={13} />
            <span>Entrar</span>
          </button>
        </div>
      )}

      {name && !isEditingName ? (
        <div className="hi-row">
          <h2 className="section-title" style={{ margin: 0 }}>
            {getGreeting()}, {name} 👋
          </h2>
          <button
            type="button"
            className="link-btn"
            onClick={() => {
              setTempName(name);
              setIsEditingName(true);
            }}
          >
            editar
          </button>
        </div>
      ) : (
        <form
          className="form-block"
          onSubmit={handleSaveName}
          style={{ marginBottom: '0.9rem' }}
        >
          <div className="field-row">
            <input
              placeholder="Como podemos te chamar?"
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              autoFocus
            />
          </div>
          <button className="btn-add" type="submit">
            <CheckIcon size={16} /> Salvar nome
          </button>
        </form>
      )}

      {/* Clock card */}
      <div className="clock-card">
        <div className="clock-left">
          <div className="clock-time">
            {currentTime.toLocaleTimeString('pt-BR', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </div>
          <div className="clock-date">
            {currentTime.toLocaleDateString('pt-BR', { weekday: 'long' })}
          </div>
          <div className="clock-date-sub">
            {currentTime.toLocaleDateString('pt-BR', {
              day: '2-digit',
              month: 'long',
              year: 'numeric',
            })}
          </div>
        </div>
        <div className="clock-divider" />
        {weather.data && weatherInfo ? (
          <button
            type="button"
            className="clock-right"
            onClick={() => setShowWeather((prev) => !prev)}
            title={weatherAlert ? `${weatherAlert.title} · Toque para ver detalhes` : 'Toque para ver a previsão detalhada'}
            style={
              weatherAlert
                ? {
                    border: `1px solid ${weatherAlert.borderColor}`,
                    boxShadow: `0 0 12px ${weatherAlert.glowColor}`,
                    background: weatherAlert.bgColor,
                    borderRadius: '0.75rem',
                    padding: '0.4rem 0.6rem',
                  }
                : undefined
            }
          >
            <div style={{ position: 'relative', display: 'inline-block' }}>
              <weatherInfo.Icon size={30} color={weatherAlert ? weatherAlert.color : weatherInfo.color} />
              {weatherAlert && (
                <span
                  style={{
                    position: 'absolute',
                    top: '-2px',
                    right: '-3px',
                    width: '9px',
                    height: '9px',
                    borderRadius: '50%',
                    backgroundColor: weatherAlert.color,
                    boxShadow: `0 0 6px ${weatherAlert.color}`,
                    animation: 'alertBeaconPing 1.8s infinite',
                  }}
                />
              )}
            </div>
            <div className="clock-temp" style={{ color: weatherAlert ? weatherAlert.textColor : undefined }}>
              {Math.round(weather.data.current.temperature_2m)}°
            </div>
            <div className="clock-city">{weather.data.name}</div>
            {weatherAlert && (
              <span
                style={{
                  fontSize: '0.58rem',
                  fontWeight: 800,
                  textTransform: 'uppercase',
                  letterSpacing: '0.04em',
                  color: weatherAlert.color,
                  marginTop: '0.1rem',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.15rem',
                }}
              >
                ⚠ {weatherAlert.badge.split('·')[1]?.trim() || 'Alerta'}
              </span>
            )}
          </button>
        ) : (
          <button
            type="button"
            className="clock-right clock-right-cta"
            onClick={() => setShowWeather((prev) => !prev)}
            title="Toque para ver a previsão do tempo"
          >
            <CloudSunIcon size={26} />
            <span>{showWeather ? 'Fechar clima' : 'Ver clima'}</span>
          </button>
        )}
      </div>

      {/* Inline Weather Panel */}
      {showWeather && (
        <div
          className="form-block fade-in"
          style={{
            marginBottom: '1rem',
            borderStyle: 'solid',
            borderColor: 'rgba(34, 211, 238, 0.4)',
            padding: '0.9rem',
          }}
        >
          <TempoView
            weather={weather}
            setWeather={setWeather}
            onClose={() => setShowWeather(false)}
            hideTitle={false}
          />
        </div>
      )}

      {/* Wallet section */}
      <div className="section-row">
        <span
          className="section-title"
          style={{ margin: 0, fontSize: '0.95rem' }}
        >
          Carteira
        </span>
        <button
          type="button"
          className="link-btn"
          onClick={() => setTab('financas')}
        >
          ver tudo
        </button>
      </div>

      <div className="hero-card" style={{ marginBottom: '0.55rem' }}>
        <CreditCardIcon size={70} className="deco" />
        <div className="l">Saldo total</div>
        <div className="v">{fmtBRL(saldo)}</div>
      </div>

      <div className="stat-row" style={{ marginBottom: '0.55rem' }}>
        <div className="stat-sm">
          <div className="l">Entradas</div>
          <div className="v" style={{ color: 'var(--green)' }}>
            {fmtBRL(entradas)}
          </div>
        </div>
        <div className="stat-sm">
          <div className="l">Saídas</div>
          <div className="v" style={{ color: 'var(--red)' }}>
            {fmtBRL(saidas)}
          </div>
        </div>
      </div>

      <div className="stat-sm" style={{ marginBottom: '1rem' }}>
        <div className="l">Valor investido</div>
        <div className="v" style={{ color: 'var(--green-invest, #22C55E)' }}>
          {fmtBRL(totalInvestido)}
        </div>
      </div>

      {/* 2. Gráfico Financeiro Exclusivo com Seletor Pizza/Rosca vs Barras */}
      <DashboardChart transactions={transactions} />

      {/* Bento Card: Baixar no Celular / Link do App */}
      <div
        className="mobile-download-banner-card"
        style={{
          background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.1), rgba(139, 92, 246, 0.08))',
          border: '1px solid rgba(56, 189, 248, 0.28)',
          borderRadius: '1.05rem',
          padding: '0.95rem 1.1rem',
          marginBottom: '1.2rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.8rem',
          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.12)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', minWidth: '220px', flex: 1 }}>
          <div
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '0.85rem',
              background: 'linear-gradient(135deg, #38BDF8, #8B5CF6)',
              color: '#FFFFFF',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              boxShadow: '0 4px 12px rgba(56, 189, 248, 0.28)',
            }}
          >
            <Smartphone size={20} />
          </div>
          <div>
            <div style={{ fontSize: '0.88rem', fontWeight: 700, color: 'var(--ink)' }}>
              Usar no Celular (Android & iPhone)
            </div>
            <div style={{ fontSize: '0.74rem', color: 'var(--ink-soft)', marginTop: '0.1rem' }}>
              Instale na tela de início ou copie o link para abrir no smartphone
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
          <button
            type="button"
            onClick={handleCopyAppUrl}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem',
              padding: '0.48rem 0.8rem',
              borderRadius: '0.65rem',
              background: copiedLink ? 'rgba(34, 197, 94, 0.2)' : 'var(--panel-strong)',
              border: copiedLink ? '1px solid #22C55E' : '1px solid var(--line)',
              color: copiedLink ? '#22C55E' : 'var(--ink)',
              fontSize: '0.76rem',
              fontWeight: 700,
              cursor: 'pointer',
              transition: 'all 0.18s ease',
            }}
          >
            {copiedLink ? <Check size={14} /> : <Copy size={14} />}
            <span>{copiedLink ? 'Link Copiado!' : 'Copiar Link'}</span>
          </button>

          {onOpenIPhoneDownload && (
            <button
              type="button"
              onClick={onOpenIPhoneDownload}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                padding: '0.48rem 0.85rem',
                borderRadius: '0.65rem',
                background: 'linear-gradient(135deg, var(--active, #38BDF8), var(--active2, #8B5CF6))',
                border: 'none',
                color: '#FFFFFF',
                fontSize: '0.76rem',
                fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 4px 12px var(--active-glow, rgba(56, 189, 248, 0.25))',
                transition: 'all 0.18s ease',
              }}
            >
              <QrCode size={14} />
              <span>Ver QR Code & Instalar</span>
            </button>
          )}
        </div>
      </div>

      {/* Shortcuts */}
      <div className="section-row">
        <span
          className="section-title"
          style={{ margin: 0, fontSize: '0.95rem' }}
        >
          Atalhos
        </span>
      </div>

      <div className="overview-grid" style={{ marginBottom: '1.2rem' }}>
        <button
          type="button"
          className="overview-card"
          onClick={() => setTab('notas')}
        >
          <span
            className="ic-wrap"
            style={{
              background: 'linear-gradient(135deg, #8B5CF6, #6366F1)',
            }}
          >
            <FileTextIcon size={19} />
          </span>
          <div className="ov-label">Anotações</div>
          <div className="ov-value">
            {notes.length} {notes.length === 1 ? 'nota' : 'notas'}
          </div>
        </button>

        <button
          type="button"
          className="overview-card"
          onClick={() => setTab('dicas')}
        >
          <span
            className="ic-wrap"
            style={{
              background: 'linear-gradient(135deg, #F59E0B, #FDE047)',
            }}
          >
            <LightbulbIcon size={19} />
          </span>
          <div className="ov-label">Dica do dia</div>
          <div
            className="ov-value"
            style={{ fontSize: '0.72rem', fontWeight: 500 }}
          >
            {dailyTip.cat}
          </div>
        </button>

        <button
          type="button"
          className="overview-card"
          onClick={() => setTab('radar')}
        >
          <span
            className="ic-wrap"
            style={{
              background: 'linear-gradient(135deg, #10B981, #06B6D4)',
            }}
          >
            <Compass size={19} />
          </span>
          <div className="ov-label">Radar IA</div>
          <div
            className="ov-value"
            style={{ fontSize: '0.72rem', fontWeight: 600, color: '#10B981' }}
          >
            Busca & Mapas
          </div>
        </button>

        <button
          type="button"
          className="overview-card"
          onClick={() => onOpenVoiceAssistant?.()}
        >
          <span
            className="ic-wrap"
            style={{
              background: 'linear-gradient(135deg, #0284C7, #38BDF8)',
            }}
          >
            <Mic size={19} />
          </span>
          <div className="ov-label">Alicerce Voz</div>
          <div
            className="ov-value"
            style={{ fontSize: '0.72rem', fontWeight: 600, color: '#38BDF8' }}
          >
            Falar ao Vivo
          </div>
        </button>
      </div>

      {/* 3. Card de Treinos Separado na Parte Inferior da Tela */}
      <WorkoutCard workouts={workouts} setTab={setTab} />

      {transactions.length === 0 &&
        workouts.length === 0 &&
        notes.length === 0 && (
          <div className="empty" style={{ marginTop: '0.9rem' }}>
            Seu painel vai ganhar vida assim que você registrar algo em
            Finanças, Treino ou Notas.
          </div>
        )}
    </div>
  );
};
