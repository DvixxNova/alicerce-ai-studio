import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  Smartphone,
  Share2,
  PlusSquare,
  Check,
  Copy,
  ExternalLink,
  QrCode,
  X,
  Sparkles,
  Zap,
  ShieldCheck,
  Download,
  Link,
  CheckCircle2,
  HelpCircle,
  Globe,
  Edit2,
  MessageCircle,
} from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export interface IPhoneDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// URLs oficiais na nuvem
export const SHARED_APP_URL = 'https://ais-pre-fsfwaeoyoku23ofrjmnwgc-472726236246.us-west1.run.app';
export const DEV_APP_URL = 'https://ais-dev-fsfwaeoyoku23ofrjmnwgc-472726236246.us-west1.run.app';

function getInitialEffectiveUrl(): string {
  if (typeof window === 'undefined') return SHARED_APP_URL;
  try {
    const origin = window.location.origin;
    const hostname = window.location.hostname;

    if (
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname.startsWith('192.168.') ||
      hostname.startsWith('10.') ||
      origin.includes(':3000') ||
      origin.startsWith('about:')
    ) {
      return SHARED_APP_URL;
    }

    if (origin.startsWith('https://')) {
      return window.location.href;
    }

    return SHARED_APP_URL;
  } catch {
    return SHARED_APP_URL;
  }
}

export const IPhoneDownloadModal: React.FC<IPhoneDownloadModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [currentUrl, setCurrentUrl] = useState<string>(() => getInitialEffectiveUrl());
  const [urlType, setUrlType] = useState<'shared' | 'dev' | 'custom'>('shared');
  const [isEditingUrl, setIsEditingUrl] = useState(false);
  const [tempUrl, setTempUrl] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'link' | 'android' | 'iphone'>('link');
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  // Inicializar URL garantindo que não use localhost no celular
  useEffect(() => {
    if (urlType === 'shared') {
      setCurrentUrl(SHARED_APP_URL);
      setTempUrl(SHARED_APP_URL);
    } else if (urlType === 'dev') {
      setCurrentUrl(DEV_APP_URL);
      setTempUrl(DEV_APP_URL);
    }
  }, [isOpen, urlType]);

  // Gerar QR Code offline de altíssima confiabilidade e legibilidade
  useEffect(() => {
    let isMounted = true;
    const urlToEncode = currentUrl || SHARED_APP_URL;

    QRCode.toDataURL(urlToEncode, {
      width: 320,
      margin: 2,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#0F172A',
        light: '#FFFFFF',
      },
    })
      .then((dataUri) => {
        if (isMounted) {
          setQrDataUrl(dataUri);
        }
      })
      .catch((err) => {
        console.error('Erro ao gerar QR code:', err);
        // Fallback para api externa se falhar
        if (isMounted) {
          setQrDataUrl(
            `https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(
              urlToEncode
            )}&bgcolor=ffffff&color=0F172A&margin=8`
          );
        }
      });

    return () => {
      isMounted = false;
    };
  }, [currentUrl]);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCopyLink = async () => {
    try {
      const urlToCopy = currentUrl || SHARED_APP_URL;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(urlToCopy);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = urlToCopy;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2600);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleOpenWhatsApp = () => {
    const url = currentUrl || SHARED_APP_URL;
    const msg = encodeURIComponent(
      `📱 *Alicerce — App Pessoal*\n\nAcesse o app no seu celular:\n${url}\n\n(Dica: salve na tela de início para usar como app nativo!)`
    );
    window.open(`https://api.whatsapp.com/send?text=${msg}`, '_blank');
  };

  const handleNativeShare = async () => {
    const url = currentUrl || SHARED_APP_URL;
    const shareData = {
      title: 'Alicerce — App Pessoal',
      text: 'Acesse o Alicerce no seu celular: finanças, treinos, rotina e anotações completas!',
      url,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        // Usuário cancelou ou navegador não completou
      }
    } else {
      handleCopyLink();
    }
  };

  const handleSaveCustomUrl = () => {
    let trimmed = tempUrl.trim();
    if (!trimmed) {
      trimmed = SHARED_APP_URL;
    } else if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      trimmed = 'https://' + trimmed;
    }
    setCurrentUrl(trimmed);
    setUrlType('custom');
    setIsEditingUrl(false);
  };

  const handleResetToCloud = () => {
    setCurrentUrl(SHARED_APP_URL);
    setTempUrl(SHARED_APP_URL);
    setUrlType('shared');
    setIsEditingUrl(false);
  };

  const handleTriggerInstall = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setInstallSuccess(true);
        setDeferredPrompt(null);
        setIsInstallable(false);
      }
    } else {
      setActiveTab('android');
    }
  };

  return (
    <div
      className="mobile-modal-backdrop"
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        background: 'rgba(0, 0, 0, 0.72)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        animation: 'fadeIn 0.2s ease',
      }}
    >
      <div
        className="mobile-modal-content"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '510px',
          maxHeight: '92vh',
          background: 'var(--panel-strong)',
          border: '1px solid var(--line)',
          borderRadius: '1.4rem',
          boxShadow: '0 25px 60px rgba(0, 0, 0, 0.6), 0 0 30px rgba(56, 189, 248, 0.15)',
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
        }}
      >
        {/* Cabeçalho do Modal */}
        <div
          style={{
            padding: '1.2rem 1.3rem 0.9rem',
            borderBottom: '1px solid var(--line)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'sticky',
            top: 0,
            background: 'var(--panel-strong)',
            zIndex: 10,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <img
              src="/apple-touch-icon.png"
              alt="Ícone do Alicerce"
              style={{
                width: '42px',
                height: '42px',
                borderRadius: '0.9rem',
                border: '1px solid rgba(56, 189, 248, 0.35)',
                boxShadow: '0 4px 14px rgba(14, 165, 233, 0.35)',
                objectFit: 'cover',
                flexShrink: 0,
              }}
              referrerPolicy="no-referrer"
            />
            <div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.68rem',
                  textTransform: 'uppercase',
                  letterSpacing: '0.06em',
                  color: 'var(--active)',
                  fontWeight: 700,
                }}
              >
                <Sparkles size={12} />
                <span>Aplicativo Web / PWA</span>
              </div>
              <h2
                style={{
                  margin: 0,
                  fontSize: '1.2rem',
                  fontWeight: 800,
                  color: 'var(--ink)',
                  fontFamily: 'var(--font-display)',
                  letterSpacing: '-0.02em',
                }}
              >
                Baixar no Celular 📱
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid var(--line)',
              color: 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.18s ease',
            }}
            title="Fechar"
          >
            <X size={16} />
          </button>
        </div>

        {/* Abas: Link & QR Code | Android | iPhone */}
        <div style={{ padding: '0.9rem 1.3rem 0' }}>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1.2fr 1fr 1fr',
              background: 'rgba(0, 0, 0, 0.18)',
              border: '1px solid var(--line)',
              borderRadius: '0.9rem',
              padding: '0.24rem',
              gap: '0.3rem',
            }}
          >
            <button
              type="button"
              onClick={() => setActiveTab('link')}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.35rem',
                padding: '0.55rem 0.5rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: activeTab === 'link' ? 'var(--active)' : 'transparent',
                color: activeTab === 'link' ? '#FFFFFF' : 'var(--ink-soft)',
                fontWeight: 700,
                fontSize: '0.78rem',
                cursor: 'pointer',
                transition: 'all 0.18s ease',
                whiteSpace: 'nowrap',
              }}
            >
              <Link size={13} />
              Link & QR Code
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('android')}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.35rem',
                padding: '0.55rem 0.5rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: activeTab === 'android' ? 'var(--active)' : 'transparent',
                color: activeTab === 'android' ? '#FFFFFF' : 'var(--ink-soft)',
                fontWeight: 700,
                fontSize: '0.78rem',
                cursor: 'pointer',
                transition: 'all 0.18s ease',
                whiteSpace: 'nowrap',
              }}
            >
              <Zap size={13} />
              Android
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('iphone')}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.35rem',
                padding: '0.55rem 0.5rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: activeTab === 'iphone' ? 'var(--active)' : 'transparent',
                color: activeTab === 'iphone' ? '#FFFFFF' : 'var(--ink-soft)',
                fontWeight: 700,
                fontSize: '0.78rem',
                cursor: 'pointer',
                transition: 'all 0.18s ease',
                whiteSpace: 'nowrap',
              }}
            >
              <Smartphone size={13} />
              iPhone (iOS)
            </button>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div style={{ padding: '1.2rem 1.3rem', flex: 1 }}>
          {/* ======================================================== */}
          {/* ABA 1: LINK DIRETO & QR CODE                             */}
          {/* ======================================================== */}
          {activeTab === 'link' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {/* Card com Link Copiável */}
              <div
                style={{
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '1rem',
                  padding: '1rem',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.75rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <Globe size={14} style={{ color: 'var(--active)' }} />
                    <span
                      style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.72rem',
                        textTransform: 'uppercase',
                        letterSpacing: '0.05em',
                        color: 'var(--ink-soft)',
                        fontWeight: 700,
                      }}
                    >
                      Endereço do aplicativo
                    </span>
                  </div>
                  <span
                    style={{
                      fontSize: '0.7rem',
                      color: '#10B981',
                      background: 'rgba(16, 185, 129, 0.12)',
                      padding: '0.15rem 0.5rem',
                      borderRadius: '1rem',
                      fontWeight: 600,
                    }}
                  >
                    Acesso Mobile Seguro
                  </span>
                </div>

                {/* Seletor de Tipo de Link */}
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '0.35rem',
                    background: 'rgba(0, 0, 0, 0.15)',
                    padding: '0.2rem',
                    borderRadius: '0.65rem',
                  }}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setUrlType('shared');
                      setCurrentUrl(SHARED_APP_URL);
                    }}
                    style={{
                      padding: '0.45rem',
                      fontSize: '0.72rem',
                      fontWeight: 700,
                      borderRadius: '0.5rem',
                      border: 'none',
                      background: urlType === 'shared' ? 'var(--active)' : 'transparent',
                      color: urlType === 'shared' ? '#FFFFFF' : 'var(--ink-soft)',
                      cursor: 'pointer',
                      transition: 'all 0.18s ease',
                    }}
                  >
                    🌐 Link Público (Oficial)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setUrlType('dev');
                      setCurrentUrl(DEV_APP_URL);
                    }}
                    style={{
                      padding: '0.45rem',
                      fontSize: '0.72rem',
                      fontWeight: 700,
                      borderRadius: '0.5rem',
                      border: 'none',
                      background: urlType === 'dev' ? 'var(--active)' : 'transparent',
                      color: urlType === 'dev' ? '#FFFFFF' : 'var(--ink-soft)',
                      cursor: 'pointer',
                      transition: 'all 0.18s ease',
                    }}
                  >
                    ⚡ Link de Prévia (Dev)
                  </button>
                </div>

                {/* Caixa explicativa de ativação do link */}
                <div
                  style={{
                    background: 'rgba(56, 189, 248, 0.08)',
                    border: '1px solid rgba(56, 189, 248, 0.22)',
                    borderRadius: '0.75rem',
                    padding: '0.65rem 0.8rem',
                    fontSize: '0.74rem',
                    lineHeight: 1.45,
                    color: 'var(--ink)',
                  }}
                >
                  <div style={{ fontWeight: 700, color: 'var(--active)', marginBottom: '0.2rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <HelpCircle size={13} />
                    <span>Como evitar erro 404 ao abrir no celular:</span>
                  </div>
                  <div style={{ color: 'var(--ink-soft)' }}>
                    {urlType === 'shared' ? (
                      <>
                        No topo direito do <strong>Google AI Studio</strong>, clique em <strong>Share (Compartilhar)</strong> para ativar este link público para qualquer celular.
                      </>
                    ) : (
                      <>
                        Este é o link direto da sua sessão de desenvolvimento. Se abrir no celular, certifique-se de estar conectado com sua conta Google.
                      </>
                    )}
                  </div>
                </div>

                {isEditingUrl ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <input
                      type="text"
                      value={tempUrl}
                      onChange={(e) => setTempUrl(e.target.value)}
                      placeholder="https://..."
                      style={{
                        width: '100%',
                        background: 'var(--input-bg, rgba(0,0,0,0.2))',
                        border: '1px solid var(--active)',
                        borderRadius: '0.75rem',
                        padding: '0.55rem 0.75rem',
                        color: 'var(--ink)',
                        fontSize: '0.8rem',
                        fontFamily: 'var(--font-mono)',
                        outline: 'none',
                      }}
                    />
                    <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
                      <button
                        type="button"
                        onClick={handleResetToCloud}
                        style={{
                          background: 'transparent',
                          border: '1px solid var(--line)',
                          color: 'var(--ink-soft)',
                          borderRadius: '0.5rem',
                          padding: '0.35rem 0.65rem',
                          fontSize: '0.72rem',
                          cursor: 'pointer',
                        }}
                      >
                        Resetar padrão
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveCustomUrl}
                        style={{
                          background: 'var(--active)',
                          border: 'none',
                          color: '#FFFFFF',
                          borderRadius: '0.5rem',
                          padding: '0.35rem 0.75rem',
                          fontSize: '0.72rem',
                          fontWeight: 700,
                          cursor: 'pointer',
                        }}
                      >
                        Salvar Link
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      background: 'var(--input-bg, rgba(0,0,0,0.2))',
                      border: '1px solid var(--line)',
                      borderRadius: '0.75rem',
                      padding: '0.45rem 0.65rem',
                    }}
                  >
                    <input
                      type="text"
                      readOnly
                      value={currentUrl || SHARED_APP_URL}
                      style={{
                        flex: 1,
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--ink)',
                        fontSize: '0.76rem',
                        fontFamily: 'var(--font-mono)',
                        outline: 'none',
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setIsEditingUrl(true)}
                      title="Personalizar endereço"
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--ink-soft)',
                        cursor: 'pointer',
                        padding: '0.2rem',
                      }}
                    >
                      <Edit2 size={13} />
                    </button>
                    <button
                      type="button"
                      onClick={handleCopyLink}
                      style={{
                        background: copied ? '#10B981' : 'var(--active)',
                        color: '#FFFFFF',
                        border: 'none',
                        borderRadius: '0.55rem',
                        padding: '0.4rem 0.8rem',
                        fontSize: '0.74rem',
                        fontWeight: 700,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.35rem',
                        transition: 'all 0.18s ease',
                        flexShrink: 0,
                      }}
                    >
                      {copied ? <Check size={13} /> : <Copy size={13} />}
                      <span>{copied ? 'Copiado!' : 'Copiar'}</span>
                    </button>
                  </div>
                )}

                {/* Ações de Compartilhamento Rápido */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                  <button
                    type="button"
                    onClick={handleOpenWhatsApp}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.4rem',
                      padding: '0.55rem',
                      borderRadius: '0.75rem',
                      background: '#25D366',
                      color: '#FFFFFF',
                      border: 'none',
                      fontSize: '0.76rem',
                      fontWeight: 700,
                      cursor: 'pointer',
                      transition: 'opacity 0.15s ease',
                    }}
                  >
                    <MessageCircle size={14} />
                    <span>Enviar no WhatsApp</span>
                  </button>

                  <a
                    href={currentUrl || SHARED_APP_URL}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.4rem',
                      padding: '0.55rem',
                      borderRadius: '0.75rem',
                      background: 'rgba(255, 255, 255, 0.08)',
                      color: 'var(--ink)',
                      border: '1px solid var(--line)',
                      fontSize: '0.76rem',
                      fontWeight: 600,
                      textDecoration: 'none',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    <ExternalLink size={13} />
                    <span>Testar Link</span>
                  </a>
                </div>
              </div>

              {/* Bloco de Escanear QR Code */}
              <div
                style={{
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '1.1rem',
                  padding: '1.2rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                  gap: '0.9rem',
                }}
              >
                <div
                  style={{
                    background: '#FFFFFF',
                    padding: '0.75rem',
                    borderRadius: '1rem',
                    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.25)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    border: '3px solid var(--active)',
                  }}
                >
                  {qrDataUrl ? (
                    <img
                      src={qrDataUrl}
                      alt="QR Code para baixar o app"
                      style={{
                        width: '180px',
                        height: '180px',
                        borderRadius: '0.4rem',
                        display: 'block',
                      }}
                    />
                  ) : (
                    <div
                      style={{
                        width: '180px',
                        height: '180px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#64748B',
                        fontSize: '0.78rem',
                      }}
                    >
                      Gerando QR Code...
                    </div>
                  )}
                </div>

                <div>
                  <h4 style={{ margin: '0 0 0.25rem', fontSize: '0.92rem', fontWeight: 700, color: 'var(--ink)' }}>
                    Aponte a câmera do seu celular 📷
                  </h4>
                  <p style={{ margin: 0, fontSize: '0.76rem', color: 'var(--ink-soft)', maxWidth: '340px', lineHeight: 1.45 }}>
                    Abra o aplicativo de câmera no seu iPhone ou Android e aponte para o QR Code acima para acessar o app instantaneamente no navegador.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* ABA 2: ANDROID                                           */}
          {/* ======================================================== */}
          {activeTab === 'android' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
              {isInstallable && (
                <div
                  style={{
                    background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(56, 189, 248, 0.12))',
                    border: '1px solid rgba(16, 185, 129, 0.35)',
                    borderRadius: '1rem',
                    padding: '0.9rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '0.8rem',
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 700, fontSize: '0.84rem', color: 'var(--ink)' }}>
                      Instalação direta disponível
                    </div>
                    <div style={{ fontSize: '0.74rem', color: 'var(--ink-soft)', marginTop: '0.15rem' }}>
                      Toque para instalar o aplicativo no seu dispositivo agora.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleTriggerInstall}
                    style={{
                      background: '#10B981',
                      color: '#FFFFFF',
                      border: 'none',
                      borderRadius: '0.65rem',
                      padding: '0.55rem 0.9rem',
                      fontSize: '0.78rem',
                      fontWeight: 700,
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                      flexShrink: 0,
                    }}
                  >
                    <Download size={14} />
                    <span>Instalar</span>
                  </button>
                </div>
              )}

              {/* Passos Android */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.85rem',
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '0.95rem',
                  padding: '0.85rem 0.95rem',
                }}
              >
                <div
                  style={{
                    width: '28px',
                    height: '28px',
                    borderRadius: '50%',
                    background: 'rgba(56, 189, 248, 0.18)',
                    color: '#38BDF8',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 800,
                    fontSize: '0.82rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  1
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.86rem', fontWeight: 700, color: 'var(--ink)' }}>
                    Abra no Google Chrome ou Samsung Internet
                  </div>
                  <div style={{ fontSize: '0.76rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.4 }}>
                    Acesse o link do Alicerce pelo navegador padrão do seu smartphone Android.
                  </div>
                </div>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.85rem',
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '0.95rem',
                  padding: '0.85rem 0.95rem',
                }}
              >
                <div
                  style={{
                    width: '28px',
                    height: '28px',
                    borderRadius: '50%',
                    background: 'rgba(139, 92, 246, 0.18)',
                    color: '#A78BFA',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 800,
                    fontSize: '0.82rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  2
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.86rem', fontWeight: 700, color: 'var(--ink)' }}>
                    Toque no menu de 3 pontinhos (⋮)
                  </div>
                  <div style={{ fontSize: '0.76rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.4 }}>
                    Fica no canto superior direito do Google Chrome.
                  </div>
                </div>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.85rem',
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '0.95rem',
                  padding: '0.85rem 0.95rem',
                }}
              >
                <div
                  style={{
                    width: '28px',
                    height: '28px',
                    borderRadius: '50%',
                    background: 'rgba(34, 197, 94, 0.18)',
                    color: '#22C55E',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 800,
                    fontSize: '0.82rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  3
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.86rem', fontWeight: 700, color: 'var(--ink)' }}>
                    Selecione "Instalar aplicativo"
                  </div>
                  <div style={{ fontSize: '0.76rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.4 }}>
                    Ou toque em <strong>"Adicionar à tela inicial"</strong>. O ícone oficial do Alicerce será criado e abrirá sem barras do navegador!
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* ABA 3: IPHONE / IOS                                      */}
          {/* ======================================================== */}
          {activeTab === 'iphone' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
              <div
                style={{
                  background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.12), rgba(139, 92, 246, 0.08))',
                  border: '1px solid rgba(56, 189, 248, 0.25)',
                  borderRadius: '1rem',
                  padding: '0.85rem 1rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                }}
              >
                <div
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: '50%',
                    background: 'var(--active)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#FFFFFF',
                    flexShrink: 0,
                  }}
                >
                  <Zap size={18} />
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--ink)', lineHeight: 1.45 }}>
                  <strong>Instalação Oficial no iPhone:</strong> Não precisa de App Store. O Alicerce roda em tela cheia como app nativo do iOS.
                </div>
              </div>

              {/* Guia iPhone */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.85rem',
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '0.95rem',
                  padding: '0.85rem 0.95rem',
                }}
              >
                <div
                  style={{
                    width: '28px',
                    height: '28px',
                    borderRadius: '50%',
                    background: 'rgba(56, 189, 248, 0.18)',
                    color: '#38BDF8',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 800,
                    fontSize: '0.82rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  1
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.86rem', fontWeight: 700, color: 'var(--ink)' }}>
                    Abra o link no navegador Safari
                  </div>
                  <div style={{ fontSize: '0.76rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.4 }}>
                    No iPhone, use obrigatoriamente o <strong>Safari</strong> para permitir a criação do atalho nativo.
                  </div>
                </div>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.85rem',
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '0.95rem',
                  padding: '0.85rem 0.95rem',
                }}
              >
                <div
                  style={{
                    width: '28px',
                    height: '28px',
                    borderRadius: '50%',
                    background: 'rgba(139, 92, 246, 0.18)',
                    color: '#A78BFA',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 800,
                    fontSize: '0.82rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  2
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.86rem', fontWeight: 700, color: 'var(--ink)' }}>
                    <span>Toque no botão Compartilhar</span>
                    <span
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: 'rgba(255, 255, 255, 0.12)',
                        padding: '0.15rem 0.35rem',
                        borderRadius: '0.4rem',
                        color: '#38BDF8',
                      }}
                    >
                      <Share2 size={12} />
                    </span>
                  </div>
                  <div style={{ fontSize: '0.76rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.4 }}>
                    O ícone de quadrado com uma seta para cima, na barra inferior do Safari.
                  </div>
                </div>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.85rem',
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  borderRadius: '0.95rem',
                  padding: '0.85rem 0.95rem',
                }}
              >
                <div
                  style={{
                    width: '28px',
                    height: '28px',
                    borderRadius: '50%',
                    background: 'rgba(34, 197, 94, 0.18)',
                    color: '#22C55E',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 800,
                    fontSize: '0.82rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  3
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.86rem', fontWeight: 700, color: 'var(--ink)' }}>
                    <span>Toque em "Adicionar à Tela de Início"</span>
                    <span
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: 'rgba(34, 197, 94, 0.15)',
                        padding: '0.15rem 0.35rem',
                        borderRadius: '0.4rem',
                        color: '#22C55E',
                      }}
                    >
                      <PlusSquare size={12} />
                    </span>
                  </div>
                  <div style={{ fontSize: '0.76rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.4 }}>
                    Role as opções para baixo, escolha <strong>"Adicionar à Tela de Início"</strong> e confirme em <strong>"Adicionar"</strong> no topo!
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Rodapé com botões de ação */}
        <div
          style={{
            padding: '0.9rem 1.3rem 1.2rem',
            borderTop: '1px solid var(--line)',
            background: 'var(--panel-strong)',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.55rem',
          }}
        >
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button
              type="button"
              onClick={handleCopyLink}
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.45rem',
                padding: '0.7rem 1rem',
                borderRadius: '0.8rem',
                background: copied ? 'rgba(34, 197, 94, 0.15)' : 'var(--panel)',
                border: copied ? '1px solid #22C55E' : '1px solid var(--line)',
                color: copied ? '#22C55E' : 'var(--ink)',
                fontSize: '0.82rem',
                fontWeight: 700,
                cursor: 'pointer',
                transition: 'all 0.18s ease',
              }}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              <span>{copied ? 'Link Copiado!' : 'Copiar Link do Celular'}</span>
            </button>

            <button
              type="button"
              onClick={handleNativeShare}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.45rem',
                padding: '0.7rem 1.1rem',
                borderRadius: '0.8rem',
                background: 'linear-gradient(135deg, var(--active), var(--active2, #8B5CF6))',
                border: 'none',
                color: '#FFFFFF',
                fontSize: '0.82rem',
                fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 4px 14px var(--active-glow, rgba(99,102,241,0.3))',
                transition: 'all 0.18s ease',
              }}
            >
              <Share2 size={16} />
              <span>Compartilhar</span>
            </button>
          </div>

          <div
            style={{
              textAlign: 'center',
              fontSize: '0.7rem',
              color: 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.4rem',
            }}
          >
            <ShieldCheck size={14} style={{ color: '#10B981' }} />
            <span>Funciona em 100% dos celulares Android, iPhone e Tablets</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export const MobileDownloadModal = IPhoneDownloadModal;
