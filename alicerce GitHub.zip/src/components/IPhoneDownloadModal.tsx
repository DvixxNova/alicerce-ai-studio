import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Share2,
  PlusSquare,
  Check,
  Copy,
  ExternalLink,
  QrCode,
  X,
  Sparkles,
  Zap,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';

interface IPhoneDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const IPhoneDownloadModal: React.FC<IPhoneDownloadModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');
  const [activeTab, setActiveTab] = useState<'passos' | 'qrcode'>('passos');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setCurrentUrl(window.location.href);
    }
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard && currentUrl) {
        await navigator.clipboard.writeText(currentUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2600);
      }
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Alicerce — App Pessoal',
          text: 'Baixe o Alicerce no seu iPhone e tenha finanças, treino e rotina na palma da mão!',
          url: currentUrl || window.location.href,
        });
      } catch {
        // Dismissed share
      }
    } else {
      handleCopyLink();
    }
  };

  // Simple QR Code image using high-quality google chart / api fallback or encoded SVG
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(
    currentUrl || 'https://alicerce.app'
  )}&bgcolor=ffffff&color=0A0E27&margin=8`;

  return (
    <div
      className="iphone-modal-backdrop"
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        background: 'rgba(0, 0, 0, 0.72)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        animation: 'fadeIn 0.2s ease',
      }}
    >
      <div
        className="iphone-modal-content"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '480px',
          maxHeight: '92vh',
          background: 'var(--panel-strong)',
          border: '1px solid var(--line)',
          borderRadius: '1.4rem',
          boxShadow: '0 25px 60px rgba(0, 0, 0, 0.6), 0 0 30px rgba(56, 189, 248, 0.15)',
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
        }}
      >
        {/* Header com estilo iOS */}
        <div
          style={{
            padding: '1.2rem 1.3rem 0.9rem',
            borderBottom: '1px solid var(--line)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'sticky',
            top: 0,
            background: 'var(--panel-strong)',
            zIndex: 10,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: '42px',
                height: '42px',
                borderRadius: '0.85rem',
                background: 'linear-gradient(135deg, #0A0E27, #1E1B4B)',
                border: '1px solid rgba(255, 255, 255, 0.18)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 8px 18px rgba(0, 0, 0, 0.4)',
                color: '#38BDF8',
              }}
            >
              <Smartphone size={22} />
            </div>
            <div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.68rem',
                  textTransform: 'uppercase',
                  letterSpacing: '0.06em',
                  color: 'var(--active)',
                  fontWeight: 700,
                }}
              >
                <Sparkles size={12} />
                <span>Instalação PWA</span>
              </div>
              <h2
                style={{
                  margin: 0,
                  fontSize: '1.2rem',
                  fontWeight: 800,
                  color: 'var(--ink)',
                  fontFamily: 'var(--font-display)',
                  letterSpacing: '-0.02em',
                }}
              >
                Baixar no iPhone 
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid var(--line)',
              color: 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.18s ease',
            }}
            title="Fechar"
          >
            <X size={16} />
          </button>
        </div>

        {/* Abas: Passo a Passo vs Escanear QR Code */}
        <div style={{ padding: '0.8rem 1.3rem 0' }}>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              background: 'rgba(0, 0, 0, 0.15)',
              border: '1px solid var(--line)',
              borderRadius: '0.85rem',
              padding: '0.22rem',
              gap: '0.3rem',
            }}
          >
            <button
              type="button"
              onClick={() => setActiveTab('passos')}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.4rem',
                padding: '0.55rem 0.6rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: activeTab === 'passos' ? 'var(--active)' : 'transparent',
                color: activeTab === 'passos' ? '#FFFFFF' : 'var(--ink-soft)',
                fontWeight: 700,
                fontSize: '0.78rem',
                cursor: 'pointer',
                transition: 'all 0.18s ease',
              }}
            >
              <Smartphone size={14} />
              Como Instalar
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('qrcode')}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.4rem',
                padding: '0.55rem 0.6rem',
                borderRadius: '0.65rem',
                border: 'none',
                background: activeTab === 'qrcode' ? 'var(--active)' : 'transparent',
                color: activeTab === 'qrcode' ? '#FFFFFF' : 'var(--ink-soft)',
                fontWeight: 700,
                fontSize: '0.78rem',
                cursor: 'pointer',
                transition: 'all 0.18s ease',
              }}
            >
              <QrCode size={14} />
              Escanear no Celular
            </button>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div style={{ padding: '1.2rem 1.3rem', flex: 1 }}>
          {activeTab === 'passos' ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
              {/* Card de Destaque / Resumo */}
              <div
                style={{
                  background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.12), rgba(139, 92, 246, 0.08))',
                  border: '1px solid rgba(56, 189, 248, 0.25)',
                  borderRadius: '1rem',
                  padding: '0.85rem 1rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                }}
              >
                <div
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: '50%',
                    background: 'var(--active)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#FFFFFF',
                    flexShrink: 0,
                    boxShadow: '0 4px 12px var(--active-glow)',
                  }}
                >
                  <Zap size={18} />
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--ink)', lineHeight: 1.45 }}>
                  <strong>Instalação Oficial sem App Store:</strong> O Alicerce funciona como um aplicativo Web progressivo nativo no iOS. Não ocupa espaço e abre em tela cheia!
                </div>
              </div>

              {/* Guia em 3 Passos */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                {/* Passo 1 */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0.85rem',
                    background: 'var(--panel)',
                    border: '1px solid var(--line)',
                    borderRadius: '0.95rem',
                    padding: '0.85rem 0.95rem',
                  }}
                >
                  <div
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      background: 'rgba(56, 189, 248, 0.18)',
                      border: '1px solid rgba(56, 189, 248, 0.35)',
                      color: '#38BDF8',
                      fontFamily: 'var(--font-mono)',
                      fontWeight: 800,
                      fontSize: '0.82rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      marginTop: '0.1rem',
                    }}
                  >
                    1
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '0.88rem', fontWeight: 700, color: 'var(--ink)' }}>
                      Abra este link no Safari
                    </div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.45 }}>
                      No seu iPhone, certifique-se de estar usando o navegador <strong>Safari</strong> (o navegador padrão do iPhone).
                    </div>
                  </div>
                </div>

                {/* Passo 2 */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0.85rem',
                    background: 'var(--panel)',
                    border: '1px solid var(--line)',
                    borderRadius: '0.95rem',
                    padding: '0.85rem 0.95rem',
                  }}
                >
                  <div
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      background: 'rgba(139, 92, 246, 0.18)',
                      border: '1px solid rgba(139, 92, 246, 0.35)',
                      color: '#A78BFA',
                      fontFamily: 'var(--font-mono)',
                      fontWeight: 800,
                      fontSize: '0.82rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      marginTop: '0.1rem',
                    }}
                  >
                    2
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.88rem', fontWeight: 700, color: 'var(--ink)' }}>
                      <span>Toque no botão Compartilhar</span>
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          background: 'rgba(255, 255, 255, 0.12)',
                          padding: '0.2rem 0.4rem',
                          borderRadius: '0.4rem',
                          color: '#38BDF8',
                        }}
                      >
                        <Share2 size={13} />
                      </span>
                    </div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.45 }}>
                      Fica na barra inferior do Safari (o ícone de quadrado com uma seta apontando para cima).
                    </div>
                  </div>
                </div>

                {/* Passo 3 */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '0.85rem',
                    background: 'var(--panel)',
                    border: '1px solid var(--line)',
                    borderRadius: '0.95rem',
                    padding: '0.85rem 0.95rem',
                  }}
                >
                  <div
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      background: 'rgba(34, 197, 94, 0.18)',
                      border: '1px solid rgba(34, 197, 94, 0.35)',
                      color: '#22C55E',
                      fontFamily: 'var(--font-mono)',
                      fontWeight: 800,
                      fontSize: '0.82rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      marginTop: '0.1rem',
                    }}
                  >
                    3
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.88rem', fontWeight: 700, color: 'var(--ink)' }}>
                      <span>Selecione "Adicionar à Tela de Início"</span>
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          background: 'rgba(34, 197, 94, 0.15)',
                          padding: '0.2rem 0.4rem',
                          borderRadius: '0.4rem',
                          color: '#22C55E',
                        }}
                      >
                        <PlusSquare size={13} />
                      </span>
                    </div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--ink-soft)', marginTop: '0.2rem', lineHeight: 1.45 }}>
                      Role o menu um pouco para baixo, toque em <strong>"Adicionar à Tela de Início"</strong> e confirme em <strong>"Adicionar"</strong> no topo!
                    </div>
                  </div>
                </div>
              </div>

              {/* Vantagens */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '0.5rem',
                  marginTop: '0.2rem',
                }}
              >
                <div
                  style={{
                    padding: '0.65rem 0.75rem',
                    background: 'var(--panel)',
                    border: '1px solid var(--line)',
                    borderRadius: '0.85rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.45rem',
                  }}
                >
                  <ShieldCheck size={16} style={{ color: '#10B981', flexShrink: 0 }} />
                  <span style={{ fontSize: '0.72rem', color: 'var(--ink-soft)' }}>
                    Dados seguros e offline
                  </span>
                </div>
                <div
                  style={{
                    padding: '0.65rem 0.75rem',
                    background: 'var(--panel)',
                    border: '1px solid var(--line)',
                    borderRadius: '0.85rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.45rem',
                  }}
                >
                  <Sparkles size={16} style={{ color: '#F59E0B', flexShrink: 0 }} />
                  <span style={{ fontSize: '0.72rem', color: 'var(--ink-soft)' }}>
                    Visual nativo tela cheia
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                textAlign: 'center',
                gap: '1rem',
                padding: '0.5rem 0',
              }}
            >
              <div
                style={{
                  background: '#FFFFFF',
                  padding: '0.9rem',
                  borderRadius: '1.2rem',
                  boxShadow: '0 12px 30px rgba(0, 0, 0, 0.25)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '3px solid var(--active)',
                }}
              >
                <img
                  src={qrCodeUrl}
                  alt="QR Code para baixar no iPhone"
                  style={{
                    width: '190px',
                    height: '190px',
                    borderRadius: '0.5rem',
                    display: 'block',
                  }}
                  referrerPolicy="no-referrer"
                />
              </div>

              <div>
                <h4 style={{ margin: '0 0 0.3rem', fontSize: '0.95rem', fontWeight: 700, color: 'var(--ink)' }}>
                  Aponte a Câmera do seu iPhone 📸
                </h4>
                <p style={{ margin: 0, fontSize: '0.78rem', color: 'var(--ink-soft)', maxWidth: '300px' }}>
                  Abra o aplicativo Câmera no iPhone, aponte para o QR Code e toque no link amarelo que aparecer na tela para abrir no Safari.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer com botões de ação rápida */}
        <div
          style={{
            padding: '0.9rem 1.3rem 1.2rem',
            borderTop: '1px solid var(--line)',
            background: 'var(--panel-strong)',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.55rem',
          }}
        >
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button
              type="button"
              onClick={handleCopyLink}
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.4rem',
                padding: '0.68rem 1rem',
                borderRadius: '0.75rem',
                background: copied ? 'rgba(34, 197, 94, 0.15)' : 'var(--panel)',
                border: copied ? '1px solid #22C55E' : '1px solid var(--line)',
                color: copied ? '#22C55E' : 'var(--ink)',
                fontSize: '0.82rem',
                fontWeight: 700,
                cursor: 'pointer',
                transition: 'all 0.18s ease',
              }}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              <span>{copied ? 'Link Copiado!' : 'Copiar Link do App'}</span>
            </button>

            <button
              type="button"
              onClick={handleNativeShare}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.4rem',
                padding: '0.68rem 1rem',
                borderRadius: '0.75rem',
                background: 'linear-gradient(135deg, var(--active), var(--active2))',
                border: 'none',
                color: '#FFFFFF',
                fontSize: '0.82rem',
                fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 6px 18px var(--active-glow)',
                transition: 'all 0.18s ease',
              }}
            >
              <Share2 size={16} />
              <span>Compartilhar</span>
            </button>
          </div>

          <div
            style={{
              textAlign: 'center',
              fontSize: '0.68rem',
              color: 'var(--ink-soft)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.3rem',
            }}
          >
            <span>Compatível com iOS 13+ e Safari no iPhone</span>
          </div>
        </div>
      </div>
    </div>
  );
};
