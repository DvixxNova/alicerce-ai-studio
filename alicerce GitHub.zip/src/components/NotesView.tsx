import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  LayoutGrid,
  LayoutList,
  Pin,
  PinOff,
  Archive,
  ArchiveRestore,
  Trash2,
  Edit3,
  Copy,
  Check,
  X,
  FileText,
  Briefcase,
  User,
  Lightbulb,
  Target,
  Wallet,
  Heart,
  Calendar,
  Clock,
  Sparkles,
  Filter,
  Minus,
  Maximize2,
  Minimize2,
  CheckSquare,
  Square,
  Palette,
  ChevronDown,
  ChevronUp,
  ListTodo,
  Bell,
} from 'lucide-react';
import { Note, NoteAccentColor } from '../types';
import { genId, getTodayISO } from '../utils/constants';
import { NoteEditorModal } from './NoteEditorModal';

// Categories supported
export type NoteCategory =
  | 'Todas'
  | 'Trabalho'
  | 'Pessoal'
  | 'Ideias'
  | 'Metas'
  | 'Finanças'
  | 'Oração';

interface CategoryConfig {
  label: string;
  color: string;
  bgLight: string;
  bgDark: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}

export const CATEGORY_MAP: Record<string, CategoryConfig> = {
  Trabalho: {
    label: 'Trabalho',
    color: '#3B82F6',
    bgLight: 'rgba(59, 130, 246, 0.12)',
    bgDark: 'rgba(59, 130, 246, 0.22)',
    icon: Briefcase,
  },
  Pessoal: {
    label: 'Pessoal',
    color: '#8B5CF6',
    bgLight: 'rgba(139, 92, 246, 0.12)',
    bgDark: 'rgba(139, 92, 246, 0.22)',
    icon: User,
  },
  Ideias: {
    label: 'Ideias',
    color: '#F59E0B',
    bgLight: 'rgba(245, 158, 11, 0.14)',
    bgDark: 'rgba(245, 158, 11, 0.24)',
    icon: Lightbulb,
  },
  Metas: {
    label: 'Metas',
    color: '#10B981',
    bgLight: 'rgba(16, 185, 129, 0.12)',
    bgDark: 'rgba(16, 185, 129, 0.22)',
    icon: Target,
  },
  Finanças: {
    label: 'Finanças',
    color: '#EC4899',
    bgLight: 'rgba(236, 72, 153, 0.12)',
    bgDark: 'rgba(236, 72, 153, 0.22)',
    icon: Wallet,
  },
  Oração: {
    label: 'Oração',
    color: '#F43F5E',
    bgLight: 'rgba(244, 63, 94, 0.12)',
    bgDark: 'rgba(244, 63, 94, 0.22)',
    icon: Heart,
  },
};

const PILL_CATEGORIES: NoteCategory[] = [
  'Todas',
  'Trabalho',
  'Pessoal',
  'Ideias',
  'Metas',
  'Finanças',
];

// Accent / Highlight Colors requested by user:
// Verde Neon, Roxo Cósmico, Azul Oceano, Dourado ou Neutro
export interface AccentConfig {
  id: NoteAccentColor;
  label: string;
  color: string;
  glow: string;
  border: string;
  bgSubtle: string;
}

export const NOTE_ACCENTS: Record<string, AccentConfig> = {
  neon: {
    id: 'neon',
    label: 'Verde Neon',
    color: '#00FF66',
    glow: 'rgba(0, 255, 102, 0.45)',
    border: '#00FF66',
    bgSubtle: 'rgba(0, 255, 102, 0.1)',
  },
  cosmic: {
    id: 'cosmic',
    label: 'Roxo Cósmico',
    color: '#8B5CF6',
    glow: 'rgba(139, 92, 246, 0.35)',
    border: '#8B5CF6',
    bgSubtle: 'rgba(139, 92, 246, 0.08)',
  },
  ocean: {
    id: 'ocean',
    label: 'Azul Oceano',
    color: '#0EA5E9',
    glow: 'rgba(14, 165, 233, 0.35)',
    border: '#0EA5E9',
    bgSubtle: 'rgba(14, 165, 233, 0.08)',
  },
  gold: {
    id: 'gold',
    label: 'Dourado',
    color: '#F59E0B',
    glow: 'rgba(245, 158, 11, 0.35)',
    border: '#F59E0B',
    bgSubtle: 'rgba(245, 158, 11, 0.08)',
  },
  neutral: {
    id: 'neutral',
    label: 'Neutro',
    color: 'var(--ink-soft)',
    glow: 'transparent',
    border: 'var(--line)',
    bgSubtle: 'transparent',
  },
};

const ACCENT_KEYS: NoteAccentColor[] = ['neon', 'cosmic', 'ocean', 'gold', 'neutral'];

function formatNoteDate(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    const now = new Date();
    const isToday =
      d.getDate() === now.getDate() &&
      d.getMonth() === now.getMonth() &&
      d.getFullYear() === now.getFullYear();
    if (isToday) {
      return `Hoje, ${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
    }
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
  } catch {
    return '';
  }
}

interface ChecklistSummary {
  total: number;
  completed: number;
}

function parseChecklistSummary(content: string): ChecklistSummary {
  const lines = content.split('\n');
  let total = 0;
  let completed = 0;
  for (const line of lines) {
    if (/\[[ xX]\]/.test(line)) {
      total++;
      if (/\[[xX]\]/.test(line)) {
        completed++;
      }
    }
  }
  return { total, completed };
}

interface NotesViewProps {
  notes: Note[];
  setNotes: React.Dispatch<React.SetStateAction<Note[]>>;
}

export const NotesView: React.FC<NotesViewProps> = ({ notes, setNotes }) => {
  // 1. Filter, Search & Layout States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<NoteCategory>('Todas');
  const [layoutMode, setLayoutMode] = useState<'grid' | 'list'>('grid');
  const [showArchivedOnly, setShowArchivedOnly] = useState(false);

  // 2. Editor Modal State
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [targetCategoryForNew, setTargetCategoryForNew] = useState<string | undefined>(undefined);

  // 3. Feedback / Toast Message
  const [feedback, setFeedback] = useState<string | null>(null);
  const [copiedNoteId, setCopiedNoteId] = useState<string | null>(null);

  const triggerFeedback = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 2800);
  };

  // 4. Statistics Calculations
  const stats = useMemo(() => {
    const total = notes.filter((n) => !n.isArchived).length;
    const pinned = notes.filter((n) => !n.isArchived && n.isPinned).length;
    const archived = notes.filter((n) => n.isArchived).length;
    return { total, pinned, archived };
  }, [notes]);

  // Category counters (active notes only)
  const categoryCounts = useMemo(() => {
    const map: Record<string, number> = { Todas: stats.total };
    PILL_CATEGORIES.forEach((cat) => {
      if (cat !== 'Todas') map[cat] = 0;
    });
    notes.forEach((n) => {
      if (!n.isArchived) {
        const cat = n.category || 'Pessoal';
        if (map[cat] !== undefined) {
          map[cat]++;
        } else {
          map[cat] = (map[cat] || 0) + 1;
        }
      }
    });
    return map;
  }, [notes, stats.total]);

  // 5. Filtered & Sorted Notes
  const filteredNotes = useMemo(() => {
    return notes
      .filter((n) => {
        // Archive condition
        if (showArchivedOnly) {
          if (!n.isArchived) return false;
        } else {
          if (n.isArchived) return false;
        }

        // Category filter
        if (selectedCategory !== 'Todas') {
          if (n.category !== selectedCategory) return false;
        }

        // Search text query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchTitle = (n.title || '').toLowerCase().includes(q);
          const matchContent = (n.content || '').toLowerCase().includes(q);
          const matchCategory = (n.category || '').toLowerCase().includes(q);
          return matchTitle || matchContent || matchCategory;
        }

        return true;
      })
      .sort((a, b) => {
        // Pinned notes always come first in active view
        if (!showArchivedOnly) {
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
        }
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      });
  }, [notes, showArchivedOnly, selectedCategory, searchQuery]);

  // 6. Handlers: Create, Edit, Pin, Archive, Delete, Collapse, Checklists
  const handleOpenCreateModal = (defaultCat?: string) => {
    setEditingNote(null);
    setTargetCategoryForNew(
      defaultCat && defaultCat !== 'Todas'
        ? defaultCat
        : selectedCategory !== 'Todas'
        ? selectedCategory
        : undefined
    );
    setIsEditorOpen(true);
  };

  const handleOpenEditModal = (note: Note) => {
    setEditingNote(note);
    setIsEditorOpen(true);
  };

  // Toggle Pin on card
  const handleTogglePin = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          const nextPinned = !n.isPinned;
          triggerFeedback(nextPinned ? 'Nota fixada no topo!' : 'Nota desfixada.');
          return { ...n, isPinned: nextPinned, updatedAt: new Date().toISOString() };
        }
        return n;
      })
    );
  };

  // Toggle Collapse on card (− / +)
  const handleToggleCollapse = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          const nextCollapsed = !n.isCollapsed;
          triggerFeedback(nextCollapsed ? 'Card colapsado.' : 'Card expandido.');
          return { ...n, isCollapsed: nextCollapsed };
        }
        return n;
      })
    );
  };

  // Delete / Ocultar (✕)
  const handleDeleteNote = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) => prev.filter((n) => n.id !== id));
    triggerFeedback('Nota excluída.');
  };

  // Archive / Restore
  const handleToggleArchive = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          const nextArchived = !n.isArchived;
          triggerFeedback(nextArchived ? 'Nota arquivada.' : 'Nota restaurada!');
          return { ...n, isArchived: nextArchived, updatedAt: new Date().toISOString() };
        }
        return n;
      })
    );
  };

  // Direct accent color switch on card
  const handleSetAccentColor = (noteId: string, accent: NoteAccentColor, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? { ...n, color: accent, updatedAt: new Date().toISOString() }
          : n
      )
    );
    const accentCfg = NOTE_ACCENTS[accent];
    triggerFeedback(`Destaque alterado para ${accentCfg ? accentCfg.label : accent}!`);
  };

  // Interactive Checklist Line Toggle directly on card
  const handleToggleChecklistLine = (noteId: string, lineIndex: number, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => {
        if (n.id !== noteId) return n;
        const lines = n.content.split('\n');
        if (lineIndex < 0 || lineIndex >= lines.length) return n;
        const line = lines[lineIndex];
        let nextLine = line;
        if (line.includes('[ ]')) {
          nextLine = line.replace('[ ]', '[x]');
        } else if (/\[[xX]\]/.test(line)) {
          nextLine = line.replace(/\[[xX]\]/, '[ ]');
        }
        lines[lineIndex] = nextLine;
        return {
          ...n,
          content: lines.join('\n'),
          updatedAt: new Date().toISOString(),
        };
      })
    );
  };

  // Copy note content
  const handleCopyContent = (note: Note, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const textToCopy = `${note.title}\n\n${note.content}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(textToCopy);
      setCopiedNoteId(note.id);
      triggerFeedback('Conteúdo copiado para a área de transferência!');
      setTimeout(() => setCopiedNoteId(null), 2000);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Toast Feedback */}
      {feedback && (
        <div
          style={{
            position: 'fixed',
            top: '1.25rem',
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'var(--panel-strong)',
            color: 'var(--ink)',
            border: '1px solid var(--line)',
            boxShadow: '0 12px 30px rgba(0,0,0,0.3)',
            borderRadius: '9999px',
            padding: '0.55rem 1.25rem',
            fontSize: '0.85rem',
            fontWeight: 600,
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            gap: '0.45rem',
            animation: 'fadeInUp 0.25s ease',
          }}
        >
          <Sparkles size={15} style={{ color: 'var(--active)' }} />
          <span>{feedback}</span>
        </div>
      )}

      {/* --- SEÇÃO 1: TOPO COM TÍTULO, BARRA DE BUSCA E BOTÃO + NOVA NOTA --- */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '0.75rem',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: '0.75rem',
                background: 'linear-gradient(135deg, var(--active), var(--active2))',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fff',
                boxShadow: '0 4px 14px var(--active-glow)',
                flexShrink: 0,
              }}
            >
              <FileText size={18} />
            </div>
            <div>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '1.35rem',
                  fontWeight: 800,
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                  color: 'var(--ink)',
                  margin: 0,
                  lineHeight: 1.15,
                }}
              >
                MINHAS ANOTAÇÕES
              </h1>
              <div
                style={{
                  fontSize: '0.75rem',
                  color: 'var(--ink-soft)',
                  marginTop: '0.15rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                }}
              >
                <span>Ideias, checklists interativos e metas</span>
                {showArchivedOnly && (
                  <span
                    style={{
                      background: 'rgba(239, 68, 68, 0.16)',
                      color: 'var(--red)',
                      padding: '0.1rem 0.45rem',
                      borderRadius: '9999px',
                      fontSize: '0.68rem',
                      fontWeight: 700,
                    }}
                  >
                    Arquivo de Notas
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Botão Principal: ＋ Nova Nota */}
          <button
            type="button"
            onClick={() => handleOpenCreateModal()}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.45rem',
              background: 'linear-gradient(135deg, var(--active), var(--active2))',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: '9999px',
              padding: '0.62rem 1.25rem',
              fontSize: '0.85rem',
              fontWeight: 700,
              letterSpacing: '0.01em',
              boxShadow: '0 6px 18px var(--active-glow)',
              cursor: 'pointer',
              transition: 'all 0.18s ease',
              flexShrink: 0,
            }}
            onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-1px)')}
            onMouseLeave={(e) => (e.currentTarget.style.transform = 'translateY(0)')}
          >
            <Plus size={16} strokeWidth={2.5} />
            <span>＋ Nova Nota</span>
          </button>
        </div>

        {/* Barra de Busca */}
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', width: '100%' }}>
          <Search
            size={17}
            style={{
              position: 'absolute',
              left: '0.85rem',
              color: 'var(--ink-soft)',
              pointerEvents: 'none',
            }}
          />
          <input
            type="text"
            className="note-search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar anotação por título, checklist, conteúdo ou tag..."
            style={{
              width: '100%',
              padding: '0.72rem 2.4rem 0.72rem 2.6rem',
              borderRadius: '0.9rem',
              background: 'var(--panel)',
              border: '1px solid var(--line)',
              color: 'var(--ink)',
              fontSize: '0.86rem',
              backdropFilter: 'blur(16px)',
              WebkitBackdropFilter: 'blur(16px)',
              outline: 'none',
              boxShadow: 'var(--card-shadow)',
              transition: 'border-color 0.2s ease, box-shadow 0.2s ease',
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = 'var(--active)';
              e.currentTarget.style.boxShadow = '0 0 0 3px var(--active-glow)';
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = 'var(--line)';
              e.currentTarget.style.boxShadow = 'var(--card-shadow)';
            }}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              title="Limpar busca"
              style={{
                position: 'absolute',
                right: '0.75rem',
                background: 'transparent',
                border: 'none',
                color: 'var(--ink-soft)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '0.2rem',
                borderRadius: '50%',
              }}
            >
              <X size={16} />
            </button>
          )}
        </div>
      </div>

      {/* --- SEÇÃO 2: ESTATÍSTICAS (TOTAL, FIXADAS, ARQUIVADAS) --- */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '0.65rem',
        }}
      >
        <button
          type="button"
          className="note-stat-card"
          onClick={() => {
            setShowArchivedOnly(false);
            setSelectedCategory('Todas');
          }}
          style={{
            background: !showArchivedOnly && selectedCategory === 'Todas' ? 'var(--panel-strong)' : 'var(--panel)',
            border: `1px solid ${!showArchivedOnly && selectedCategory === 'Todas' ? 'var(--active)' : 'var(--line)'}`,
            borderRadius: '1rem',
            padding: '0.75rem 0.85rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.25rem',
            textAlign: 'left',
            backdropFilter: 'blur(18px)',
            WebkitBackdropFilter: 'blur(18px)',
            cursor: 'pointer',
            transition: 'all 0.18s ease',
            boxShadow: 'var(--card-shadow)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span
              className="note-stat-label"
              style={{
                fontSize: '0.68rem',
                fontWeight: 700,
                color: 'var(--ink-soft)',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}
            >
              Total
            </span>
            <FileText size={15} style={{ color: 'var(--active)' }} />
          </div>
          <div
            className="note-stat-value"
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '1.45rem',
              fontWeight: 800,
              color: 'var(--ink)',
              lineHeight: 1.1,
            }}
          >
            {stats.total}
          </div>
          <div className="note-stat-label" style={{ fontSize: '0.68rem', color: 'var(--ink-soft)' }}>
            {stats.total === 1 ? 'Nota ativa' : 'Notas ativas'}
          </div>
        </button>

        <button
          type="button"
          className="note-stat-card"
          onClick={() => {
            setShowArchivedOnly(false);
          }}
          style={{
            background: 'var(--panel)',
            border: '1px solid var(--line)',
            borderRadius: '1rem',
            padding: '0.75rem 0.85rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.25rem',
            textAlign: 'left',
            backdropFilter: 'blur(18px)',
            WebkitBackdropFilter: 'blur(18px)',
            cursor: 'pointer',
            transition: 'all 0.18s ease',
            boxShadow: 'var(--card-shadow)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span
              className="note-stat-label"
              style={{
                fontSize: '0.68rem',
                fontWeight: 700,
                color: 'var(--ink-soft)',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}
            >
              Fixadas
            </span>
            <Pin size={15} style={{ color: '#F59E0B' }} />
          </div>
          <div
            className="note-stat-value"
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '1.45rem',
              fontWeight: 800,
              color: 'var(--ink)',
              lineHeight: 1.1,
            }}
          >
            {stats.pinned}
          </div>
          <div className="note-stat-label" style={{ fontSize: '0.68rem', color: 'var(--ink-soft)' }}>
            {stats.pinned === 1 ? 'Em destaque no topo' : 'Em destaque no topo'}
          </div>
        </button>

        <button
          type="button"
          className="note-stat-card"
          onClick={() => setShowArchivedOnly((prev) => !prev)}
          style={{
            background: showArchivedOnly ? 'rgba(239, 68, 68, 0.12)' : 'var(--panel)',
            border: `1px solid ${showArchivedOnly ? 'var(--red)' : 'var(--line)'}`,
            borderRadius: '1rem',
            padding: '0.75rem 0.85rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.25rem',
            textAlign: 'left',
            backdropFilter: 'blur(18px)',
            WebkitBackdropFilter: 'blur(18px)',
            cursor: 'pointer',
            transition: 'all 0.18s ease',
            boxShadow: 'var(--card-shadow)',
          }}
          title={showArchivedOnly ? 'Voltar para notas ativas' : 'Ver notas arquivadas'}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span
              style={{
                fontSize: '0.68rem',
                fontWeight: 700,
                color: showArchivedOnly ? 'var(--red)' : 'var(--ink-soft)',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}
            >
              Arquivadas
            </span>
            <Archive size={15} style={{ color: showArchivedOnly ? 'var(--red)' : 'var(--ink-soft)' }} />
          </div>
          <div
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '1.45rem',
              fontWeight: 800,
              color: showArchivedOnly ? 'var(--red)' : 'var(--ink)',
              lineHeight: 1.1,
            }}
          >
            {stats.archived}
          </div>
          <div
            style={{
              fontSize: '0.68rem',
              color: showArchivedOnly ? 'var(--red)' : 'var(--ink-soft)',
              fontWeight: showArchivedOnly ? 600 : 400,
            }}
          >
            {showArchivedOnly ? 'Modo exibição ativo' : 'Histórico arquivado'}
          </div>
        </button>
      </div>

      {/* --- SEÇÃO 3: PÍLULAS DE CATEGORIAS E TOGGLE GRADE / LISTA --- */}
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '0.75rem',
          paddingBottom: '0.25rem',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            overflowX: 'auto',
            padding: '0.2rem 0',
            maxWidth: '100%',
            scrollbarWidth: 'none',
          }}
        >
          {PILL_CATEGORIES.map((cat) => {
            const isActive = selectedCategory === cat;
            const config = cat === 'Todas' ? null : CATEGORY_MAP[cat];
            const IconComp = config ? config.icon : Filter;
            const count = categoryCounts[cat] || 0;

            return (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  setSelectedCategory(cat);
                  if (showArchivedOnly) setShowArchivedOnly(false);
                }}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  padding: '0.42rem 0.85rem',
                  borderRadius: '9999px',
                  fontSize: '0.78rem',
                  fontWeight: isActive ? 700 : 500,
                  whiteSpace: 'nowrap',
                  cursor: 'pointer',
                  border: isActive
                    ? `1px solid ${config ? config.color : 'var(--active)'}`
                    : '1px solid var(--line)',
                  background: isActive
                    ? config
                      ? config.color
                      : 'linear-gradient(135deg, var(--active), var(--active2))'
                    : 'var(--panel)',
                  color: isActive ? '#FFFFFF' : 'var(--ink)',
                  boxShadow: isActive
                    ? `0 4px 14px ${config ? config.color + '44' : 'var(--active-glow)'}`
                    : 'none',
                  transition: 'all 0.16s ease',
                  flexShrink: 0,
                }}
              >
                <IconComp size={13} strokeWidth={isActive ? 2.5 : 2} />
                <span>{cat}</span>
                <span
                  style={{
                    fontSize: '0.68rem',
                    fontWeight: 700,
                    padding: '0.05rem 0.38rem',
                    borderRadius: '9999px',
                    background: isActive ? 'rgba(255,255,255,0.28)' : 'rgba(128,128,128,0.14)',
                    color: isActive ? '#FFFFFF' : 'var(--ink-soft)',
                  }}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Alternador de Layout */}
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            background: 'var(--panel)',
            border: '1px solid var(--line)',
            borderRadius: '9999px',
            padding: '0.22rem',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
            flexShrink: 0,
          }}
        >
          <button
            type="button"
            onClick={() => setLayoutMode('grid')}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem',
              padding: '0.36rem 0.75rem',
              borderRadius: '9999px',
              border: 'none',
              background: layoutMode === 'grid' ? 'var(--panel-strong)' : 'transparent',
              color: layoutMode === 'grid' ? 'var(--ink)' : 'var(--ink-soft)',
              boxShadow: layoutMode === 'grid' ? '0 2px 8px rgba(0,0,0,0.18)' : 'none',
              fontSize: '0.76rem',
              fontWeight: layoutMode === 'grid' ? 700 : 500,
              cursor: 'pointer',
              transition: 'all 0.15s ease',
            }}
            title="Visualização em Grade"
          >
            <LayoutGrid size={14} />
            <span>Grade</span>
          </button>

          <button
            type="button"
            onClick={() => setLayoutMode('list')}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem',
              padding: '0.36rem 0.75rem',
              borderRadius: '9999px',
              border: 'none',
              background: layoutMode === 'list' ? 'var(--panel-strong)' : 'transparent',
              color: layoutMode === 'list' ? 'var(--ink)' : 'var(--ink-soft)',
              boxShadow: layoutMode === 'list' ? '0 2px 8px rgba(0,0,0,0.18)' : 'none',
              fontSize: '0.76rem',
              fontWeight: layoutMode === 'list' ? 700 : 500,
              cursor: 'pointer',
              transition: 'all 0.15s ease',
            }}
            title="Visualização em Lista"
          >
            <LayoutList size={14} />
            <span>Lista</span>
          </button>
        </div>
      </div>

      {/* Banner se modo arquivo ativo */}
      {showArchivedOnly && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'rgba(239, 68, 68, 0.08)',
            border: '1px solid rgba(239, 68, 68, 0.25)',
            borderRadius: '0.85rem',
            padding: '0.65rem 1rem',
            fontSize: '0.8rem',
            color: 'var(--ink)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Archive size={16} style={{ color: 'var(--red)' }} />
            <span>
              Exibindo <strong>{filteredNotes.length}</strong> anotações arquivadas.
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowArchivedOnly(false)}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--red)',
              fontSize: '0.78rem',
              fontWeight: 700,
              cursor: 'pointer',
              textDecoration: 'underline',
            }}
          >
            Voltar para ativas
          </button>
        </div>
      )}

      {/* --- SEÇÃO PRINCIPAL DE CARDS DE NOTAS (GRADE OU LISTA) --- */}
      {filteredNotes.length === 0 ? (
        <div
          style={{
            background: 'var(--panel)',
            border: '1px dashed var(--line)',
            borderRadius: '1.2rem',
            padding: '2.8rem 1.5rem',
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '0.75rem',
            color: 'var(--ink-soft)',
          }}
        >
          <div
            style={{
              width: 52,
              height: 52,
              borderRadius: '50%',
              background: 'rgba(128,128,128,0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--ink-soft)',
            }}
          >
            <FileText size={26} />
          </div>
          <div style={{ fontSize: '0.98rem', fontWeight: 700, color: 'var(--ink)' }}>
            {searchQuery
              ? `Nenhuma anotação encontrada para "${searchQuery}"`
              : showArchivedOnly
              ? 'Nenhuma nota arquivada no histórico'
              : selectedCategory !== 'Todas'
              ? `Nenhuma nota na categoria ${selectedCategory}`
              : 'Nenhuma anotação criada ainda'}
          </div>
          <div style={{ fontSize: '0.8rem', maxWidth: 360, lineHeight: 1.5 }}>
            {searchQuery
              ? 'Tente buscar com outros termos ou limpe o campo de busca.'
              : 'Organize suas prioridades diárias, tarefas e ideias com os novos cards interativos.'}
          </div>
          <button
            type="button"
            onClick={() => {
              if (searchQuery) setSearchQuery('');
              handleOpenCreateModal();
            }}
            style={{
              marginTop: '0.5rem',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.4rem',
              background: 'linear-gradient(135deg, var(--active), var(--active2))',
              color: '#fff',
              border: 'none',
              borderRadius: '9999px',
              padding: '0.55rem 1.25rem',
              fontSize: '0.82rem',
              fontWeight: 700,
              cursor: 'pointer',
              boxShadow: '0 4px 14px var(--active-glow)',
            }}
          >
            <Plus size={15} />
            <span>Criar Primeira Nota</span>
          </button>
        </div>
      ) : (
        /* Renderização dos Cards */
        <div
          style={
            layoutMode === 'grid'
              ? {
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(310px, 1fr))',
                  gap: '1rem',
                  alignItems: 'start',
                }
              : {
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.75rem',
                }
          }
        >
          {filteredNotes.map((note) => {
            const catConfig = CATEGORY_MAP[note.category] || CATEGORY_MAP.Trabalho;
            const CatIcon = catConfig.icon;
            const isCopied = copiedNoteId === note.id;

            // Resolved Accent Color
            const accentKey = (note.color as NoteAccentColor) || 'neon';
            const accentConfig = NOTE_ACCENTS[accentKey] || NOTE_ACCENTS.neon;
            const isNeutral = accentKey === 'neutral';

            // Checklist calculation
            const checklistSummary = parseChecklistSummary(note.content || '');
            const hasChecklist = checklistSummary.total > 0;

            // Lines for rendering
            const contentLines = (note.content || '').split('\n');

            return (
              <div
                key={note.id}
                className={`note-card-item note-accent-${accentKey} ${note.isPinned ? 'is-pinned' : ''}`}
                style={{
                  position: 'relative',
                  background: note.isPinned ? 'var(--panel-strong)' : 'var(--panel)',
                  border: isNeutral
                    ? note.isPinned
                      ? '1.5px solid var(--ink-soft)'
                      : '1px solid var(--line)'
                    : `1.5px solid ${accentConfig.border}`,
                  borderRadius: '1.2rem',
                  padding: note.isCollapsed ? '0.85rem 1.05rem' : '1.1rem',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: note.isCollapsed ? '0.5rem' : '0.75rem',
                  boxShadow: note.isPinned
                    ? `0 10px 30px rgba(0,0,0,0.25), 0 0 16px ${isNeutral ? 'transparent' : accentConfig.glow}`
                    : isNeutral
                    ? 'var(--card-shadow)'
                    : `0 6px 20px rgba(0,0,0,0.12), 0 0 12px ${accentConfig.glow}`,
                  backdropFilter: 'blur(20px)',
                  WebkitBackdropFilter: 'blur(20px)',
                  transition: 'all 0.2s ease',
                  overflow: 'hidden',
                }}
              >
                {/* Faixa superior de acento sutil */}
                {!isNeutral && (
                  <div
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      height: '3px',
                      background: accentConfig.color,
                      opacity: note.isPinned ? 1 : 0.8,
                    }}
                  />
                )}

                {/* 1. CABEÇALHO DO CARD
                    - Título da nota, tag de categoria colorida e data da última alteração.
                    - Ícone de "Fixar Nota" (Pin) para manter as notas mais importantes no topo.
                    - Botões de Ação: "Colapsar/Encolher (−)", "Editar (✏️)" e "Excluir/Ocultar (✕)". */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
                  {/* Linha 1 do Cabeçalho: Categoria, Data & Botões de Ação */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '0.5rem',
                    }}
                  >
                    {/* Tag de categoria colorida & Data da última alteração */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.45rem',
                        flexWrap: 'wrap',
                      }}
                    >
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.28rem',
                          padding: '0.18rem 0.55rem',
                          borderRadius: '9999px',
                          fontSize: '0.7rem',
                          fontWeight: 700,
                          background: catConfig.bgLight,
                          color: catConfig.color,
                          border: `1px solid ${catConfig.color}35`,
                        }}
                      >
                        <CatIcon size={12} />
                        <span>{catConfig.label}</span>
                      </span>

                      {/* Data da última alteração */}
                      <span
                        className="note-card-meta"
                        style={{
                          fontSize: '0.68rem',
                          color: 'var(--ink-soft)',
                          fontFamily: 'var(--font-mono)',
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.2rem',
                        }}
                        title={`Última alteração: ${new Date(note.updatedAt).toLocaleString('pt-BR')}`}
                      >
                        <Clock size={11} style={{ opacity: 0.7 }} />
                        <span>{formatNoteDate(note.updatedAt)}</span>
                      </span>

                      {/* Lembrete / Alerta Programado */}
                      {note.reminder && (
                        <span
                          style={{
                            fontSize: '0.68rem',
                            color: '#0EA5E9',
                            background: 'rgba(14, 165, 233, 0.12)',
                            border: '1px solid rgba(14, 165, 233, 0.3)',
                            borderRadius: '9999px',
                            padding: '0.12rem 0.45rem',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '0.25rem',
                            fontWeight: 600,
                          }}
                          title={`Lembrete configurado: ${note.reminder}`}
                        >
                          <Bell size={11} />
                          <span>
                            {(() => {
                              try {
                                const d = new Date(note.reminder);
                                if (isNaN(d.getTime())) return note.reminder;
                                return d.toLocaleString('pt-BR', {
                                  day: '2-digit',
                                  month: '2-digit',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                });
                              } catch {
                                return note.reminder;
                              }
                            })()}
                          </span>
                        </span>
                      )}
                    </div>

                    {/* Botões de Ação do Cabeçalho:
                        - Fixar (Pin)
                        - Colapsar/Encolher (− / +)
                        - Editar (✏️)
                        - Excluir/Ocultar (✕) */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.2rem',
                        flexShrink: 0,
                      }}
                    >
                      {/* Botão Fixar Nota */}
                      <button
                        type="button"
                        onClick={(e) => handleTogglePin(note.id, e)}
                        title={note.isPinned ? 'Desafixar nota do topo' : 'Fixar nota no topo'}
                        style={{
                          background: note.isPinned ? 'rgba(245, 158, 11, 0.2)' : 'transparent',
                          border: note.isPinned ? '1px solid #F59E0B' : '1px solid transparent',
                          color: note.isPinned ? '#F59E0B' : 'var(--ink-soft)',
                          padding: '0.32rem',
                          borderRadius: '0.5rem',
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        {note.isPinned ? (
                          <Pin size={14} style={{ fill: '#F59E0B' }} />
                        ) : (
                          <Pin size={14} />
                        )}
                      </button>

                      {/* Botão Colapsar/Encolher (− / +) */}
                      <button
                        type="button"
                        onClick={(e) => handleToggleCollapse(note.id, e)}
                        title={note.isCollapsed ? 'Expandir nota (+)' : 'Colapsar/Encolher nota (−)'}
                        style={{
                          background: note.isCollapsed ? 'rgba(128,128,128,0.16)' : 'transparent',
                          border: '1px solid transparent',
                          color: 'var(--ink-soft)',
                          padding: '0.32rem',
                          borderRadius: '0.5rem',
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        {note.isCollapsed ? <ChevronDown size={14} /> : <Minus size={14} />}
                      </button>

                      {/* Botão Editar (✏️) */}
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(note)}
                        title="Editar nota (✏️)"
                        style={{
                          background: 'transparent',
                          border: '1px solid transparent',
                          color: 'var(--ink-soft)',
                          padding: '0.32rem',
                          borderRadius: '0.5rem',
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        <Edit3 size={14} />
                      </button>

                      {/* Botão Excluir/Ocultar (✕) */}
                      <button
                        type="button"
                        onClick={(e) => handleDeleteNote(note.id, e)}
                        title="Excluir/Ocultar nota (✕)"
                        style={{
                          background: 'transparent',
                          border: '1px solid transparent',
                          color: 'var(--red)',
                          padding: '0.32rem',
                          borderRadius: '0.5rem',
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        <X size={14} />
                      </button>
                    </div>
                  </div>

                  {/* Linha 2 do Cabeçalho: Título da Nota */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '0.5rem',
                    }}
                  >
                    <h3
                      className="note-card-title"
                      onClick={() => (note.isCollapsed ? handleToggleCollapse(note.id) : handleOpenEditModal(note))}
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: note.isCollapsed ? '0.98rem' : '1.05rem',
                        fontWeight: 700,
                        color: 'var(--ink)',
                        margin: 0,
                        lineHeight: 1.3,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.35rem',
                      }}
                    >
                      {note.title || 'Sem título'}
                    </h3>

                    {/* Badge se houver Checklist */}
                    {hasChecklist && (
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.25rem',
                          fontSize: '0.68rem',
                          fontWeight: 700,
                          padding: '0.12rem 0.45rem',
                          borderRadius: '9999px',
                          background:
                            checklistSummary.completed === checklistSummary.total
                              ? 'rgba(16, 185, 129, 0.18)'
                              : 'rgba(128, 128, 128, 0.12)',
                          color:
                            checklistSummary.completed === checklistSummary.total
                              ? '#10B981'
                              : 'var(--ink-soft)',
                          border:
                            checklistSummary.completed === checklistSummary.total
                              ? '1px solid rgba(16, 185, 129, 0.35)'
                              : '1px solid var(--line)',
                          flexShrink: 0,
                        }}
                      >
                        <ListTodo size={11} />
                        <span>
                          {checklistSummary.completed}/{checklistSummary.total}
                        </span>
                      </span>
                    )}
                  </div>
                </div>

                {/* 2. CORPO DO CARD:
                    - Se COLAPSADO: Pré-visualização do conteúdo recortado.
                    - Se EXPANDIDO: Texto formatado + Checklists interativos clicáveis. */}
                {note.isCollapsed ? (
                  /* Modo Colapsado: Pré-visualização recortada */
                  <div
                    onClick={() => handleToggleCollapse(note.id)}
                    style={{
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      background: 'rgba(128,128,128,0.06)',
                      borderRadius: '0.65rem',
                      padding: '0.45rem 0.65rem',
                      fontSize: '0.78rem',
                      color: 'var(--ink-soft)',
                      gap: '0.5rem',
                    }}
                    title="Clique para expandir esta nota"
                  >
                    <span
                      style={{
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        lineHeight: 1.4,
                        flex: 1,
                      }}
                    >
                      {note.content
                        ? note.content.replace(/\[[ xX]\]/g, '•').split('\n')[0]
                        : 'Nenhum conteúdo adicional.'}
                    </span>
                    <span
                      style={{
                        fontSize: '0.66rem',
                        fontWeight: 700,
                        color: accentConfig.color,
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.2rem',
                        flexShrink: 0,
                      }}
                    >
                      <span>Expandir</span>
                      <ChevronDown size={12} />
                    </span>
                  </div>
                ) : (
                  /* Modo Expandido: Conteúdo Formatado com Checklists Interativos */
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '0.45rem',
                      fontSize: '0.84rem',
                      lineHeight: 1.5,
                      color: 'var(--ink)',
                    }}
                  >
                    {contentLines.map((line, idx) => {
                      const isChecklist = /^\s*([*\-•]?\s*)?\[([ xX])\]\s*(.*)$/.test(line);

                      if (isChecklist) {
                        const match = line.match(/^\s*([*\-•]?\s*)?\[([ xX])\]\s*(.*)$/);
                        const isDone = match ? match[2].toLowerCase() === 'x' : false;
                        const taskText = match ? match[3] : line;

                        return (
                          <div
                            key={idx}
                            onClick={(e) => handleToggleChecklistLine(note.id, idx, e)}
                            style={{
                              display: 'flex',
                              alignItems: 'flex-start',
                              gap: '0.5rem',
                              padding: '0.25rem 0.35rem',
                              borderRadius: '0.5rem',
                              background: isDone
                                ? 'rgba(128,128,128,0.06)'
                                : 'rgba(128,128,128,0.03)',
                              cursor: 'pointer',
                              transition: 'background 0.15s ease',
                              userSelect: 'none',
                            }}
                            title={isDone ? 'Marcar como pendente' : 'Marcar como concluída'}
                          >
                            <button
                              type="button"
                              style={{
                                marginTop: '0.18rem',
                                width: 17,
                                height: 17,
                                borderRadius: '0.35rem',
                                border: isDone
                                  ? `1.5px solid ${accentConfig.color}`
                                  : '1.5px solid var(--ink-soft)',
                                background: isDone ? accentConfig.color : 'transparent',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: '#FFFFFF',
                                cursor: 'pointer',
                                padding: 0,
                                flexShrink: 0,
                                transition: 'all 0.15s ease',
                              }}
                            >
                              {isDone && <Check size={12} strokeWidth={3} />}
                            </button>
                            <span
                              className="note-checklist-text note-card-desc"
                              style={{
                                textDecoration: isDone ? 'line-through' : 'none',
                                color: isDone ? 'var(--ink-soft)' : 'var(--ink)',
                                fontSize: '0.82rem',
                                wordBreak: 'break-word',
                                opacity: isDone ? 0.7 : 1,
                              }}
                            >
                              {taskText || '(Tarefa vazia)'}
                            </span>
                          </div>
                        );
                      }

                      // Linha de parágrafo normal ou bullet point
                      const isBullet = /^\s*([*\-•])\s+(.*)$/.test(line);
                      if (isBullet) {
                        const bulletText = line.replace(/^\s*([*\-•])\s+/, '');
                        return (
                          <div
                            key={idx}
                            style={{
                              display: 'flex',
                              alignItems: 'flex-start',
                              gap: '0.45rem',
                              padding: '0.1rem 0.2rem',
                            }}
                          >
                            <span
                              style={{
                                color: accentConfig.color,
                                fontWeight: 800,
                                fontSize: '0.9rem',
                                lineHeight: 1.2,
                              }}
                            >
                              •
                            </span>
                            <span className="note-card-desc" style={{ fontSize: '0.82rem', color: 'var(--ink)' }}>
                              {bulletText}
                            </span>
                          </div>
                        );
                      }

                      // Linha em branco
                      if (!line.trim()) {
                        return <div key={idx} style={{ height: '0.3rem' }} />;
                      }

                      return (
                        <p
                          key={idx}
                          className="note-card-desc"
                          style={{
                            margin: 0,
                            fontSize: '0.84rem',
                            color: 'var(--ink)',
                            wordBreak: 'break-word',
                          }}
                        >
                          {line}
                        </p>
                      );
                    })}
                  </div>
                )}

                {/* 3. CORES DE DESTAQUE & RODAPÉ DO CARD:
                    - Permita escolher uma cor de borda/acento para o card (Verde Neon, Roxo Cósmico, Azul Oceano, Dourado ou Neutro)
                    - Botão de copiar texto e atalhos rápidos */}
                {!note.isCollapsed && (
                  <div
                    style={{
                      marginTop: 'auto',
                      paddingTop: '0.65rem',
                      borderTop: '1px solid var(--line)',
                      display: 'flex',
                      flexWrap: 'wrap',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '0.5rem',
                    }}
                  >
                    {/* Seletor Rápido de Cores de Destaque no Card */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.3rem',
                      }}
                      title="Alterar cor de destaque do card"
                    >
                      <Palette size={13} style={{ color: 'var(--ink-soft)', marginRight: '0.15rem' }} />
                      {ACCENT_KEYS.map((key) => {
                        const cfg = NOTE_ACCENTS[key];
                        const isSelected = accentKey === key;
                        return (
                          <button
                            key={key}
                            type="button"
                            onClick={(e) => handleSetAccentColor(note.id, key, e)}
                            title={cfg.label}
                            style={{
                              width: 17,
                              height: 17,
                              borderRadius: '50%',
                              background: key === 'neutral' ? 'var(--line)' : cfg.color,
                              border: isSelected
                                ? '2px solid var(--ink)'
                                : '1px solid rgba(0,0,0,0.15)',
                              cursor: 'pointer',
                              padding: 0,
                              transform: isSelected ? 'scale(1.2)' : 'scale(1)',
                              boxShadow: isSelected ? `0 0 8px ${cfg.color}` : 'none',
                              transition: 'all 0.15s ease',
                            }}
                          />
                        );
                      })}
                    </div>

                    {/* Ações adicionais: Copiar e Arquivar */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <button
                        type="button"
                        onClick={(e) => handleCopyContent(note, e)}
                        title="Copiar texto da nota"
                        style={{
                          background: 'transparent',
                          border: 'none',
                          color: isCopied ? '#10B981' : 'var(--ink-soft)',
                          padding: '0.25rem',
                          cursor: 'pointer',
                          borderRadius: '0.4rem',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        {isCopied ? <Check size={14} /> : <Copy size={14} />}
                      </button>

                      <button
                        type="button"
                        onClick={(e) => handleToggleArchive(note.id, e)}
                        title={note.isArchived ? 'Restaurar nota' : 'Arquivar nota'}
                        style={{
                          background: 'transparent',
                          border: 'none',
                          color: 'var(--ink-soft)',
                          padding: '0.25rem',
                          cursor: 'pointer',
                          borderRadius: '0.4rem',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        {note.isArchived ? <ArchiveRestore size={14} /> : <Archive size={14} />}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* --- MODAL / EDITOR DE ANOTAÇÃO (NoteEditorModal.tsx) --- */}
      <NoteEditorModal
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        note={editingNote}
        initialCategory={targetCategoryForNew}
        onSave={({ title, content, category, color, isPinned, isArchived, reminder }) => {
          const now = new Date().toISOString();
          if (editingNote) {
            setNotes((prev) =>
              prev.map((n) =>
                n.id === editingNote.id
                  ? {
                      ...n,
                      title,
                      content,
                      category,
                      color,
                      isPinned,
                      isArchived,
                      reminder,
                      updatedAt: now,
                    }
                  : n
              )
            );
            triggerFeedback('Anotação atualizada com sucesso!');
          } else {
            const newNote: Note = {
              id: genId(),
              title,
              content,
              category,
              color,
              date: getTodayISO(),
              updatedAt: now,
              isPinned,
              isArchived: isArchived ?? false,
              isCollapsed: false,
              reminder,
            };
            setNotes((prev) => [newNote, ...prev]);
            triggerFeedback('Nova anotação criada com sucesso!');
          }
          setIsEditorOpen(false);
        }}
        onArchiveToggle={(noteId) => {
          handleToggleArchive(noteId);
        }}
        onDelete={(noteId) => {
          handleDeleteNote(noteId);
        }}
      />

    </div>
  );
};
