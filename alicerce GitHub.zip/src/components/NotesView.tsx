import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Pin,
  MoreVertical,
  X,
  Edit3,
  Copy,
  Trash2,
  Archive,
  ArchiveRestore,
  CheckSquare,
  Square,
  Briefcase,
  User,
  Lightbulb,
  Target,
  Wallet,
  Heart,
  RotateCcw,
  Calendar,
  List,
  Plus,
} from 'lucide-react';
import { Note, NoteAccentColor } from '../types';
import { genId, getTodayISO, DEFAULT_NOTES } from '../utils/constants';
import { NoteEditorModal } from './NoteEditorModal';
import { NotesCalendarView } from './NotesCalendarView';

// Categories supported & legacy exports for NoteEditorModal
export type NoteCategory =
  | 'Todas'
  | 'Trabalho'
  | 'Pessoal'
  | 'Ideias'
  | 'Metas'
  | 'Finanças'
  | 'Oração';

export interface CategoryConfig {
  label: string;
  color: string;
  bgLight: string;
  bgDark: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}

export const CATEGORY_MAP: Record<string, CategoryConfig> = {
  Trabalho: {
    label: 'Trabalho',
    color: '#3B82F6',
    bgLight: 'rgba(59, 130, 246, 0.12)',
    bgDark: 'rgba(59, 130, 246, 0.22)',
    icon: Briefcase,
  },
  Pessoal: {
    label: 'Pessoal',
    color: '#8B5CF6',
    bgLight: 'rgba(139, 92, 246, 0.12)',
    bgDark: 'rgba(139, 92, 246, 0.22)',
    icon: User,
  },
  Ideias: {
    label: 'Ideias',
    color: '#F59E0B',
    bgLight: 'rgba(245, 158, 11, 0.14)',
    bgDark: 'rgba(245, 158, 11, 0.24)',
    icon: Lightbulb,
  },
  Metas: {
    label: 'Metas',
    color: '#10B981',
    bgLight: 'rgba(16, 185, 129, 0.12)',
    bgDark: 'rgba(16, 185, 129, 0.22)',
    icon: Target,
  },
  Finanças: {
    label: 'Finanças',
    color: '#EC4899',
    bgLight: 'rgba(236, 72, 153, 0.12)',
    bgDark: 'rgba(236, 72, 153, 0.22)',
    icon: Wallet,
  },
  Oração: {
    label: 'Oração',
    color: '#F43F5E',
    bgLight: 'rgba(244, 63, 94, 0.12)',
    bgDark: 'rgba(244, 63, 94, 0.22)',
    icon: Heart,
  },
};

export interface AccentConfig {
  id: NoteAccentColor;
  label: string;
  color: string;
  glow: string;
  border: string;
  bgSubtle: string;
}

export const NOTE_ACCENTS: Record<string, AccentConfig> = {
  neon: {
    id: 'neon',
    label: 'Verde Neon',
    color: '#00FF66',
    glow: 'rgba(0, 255, 102, 0.45)',
    border: '#00FF66',
    bgSubtle: 'rgba(0, 255, 102, 0.1)',
  },
  cosmic: {
    id: 'cosmic',
    label: 'Roxo Cósmico',
    color: '#8B5CF6',
    glow: 'rgba(139, 92, 246, 0.35)',
    border: '#8B5CF6',
    bgSubtle: 'rgba(139, 92, 246, 0.08)',
  },
  ocean: {
    id: 'ocean',
    label: 'Azul Oceano',
    color: '#0EA5E9',
    glow: 'rgba(14, 165, 233, 0.35)',
    border: '#0EA5E9',
    bgSubtle: 'rgba(14, 165, 233, 0.08)',
  },
  gold: {
    id: 'gold',
    label: 'Dourado',
    color: '#F59E0B',
    glow: 'rgba(245, 158, 11, 0.35)',
    border: '#F59E0B',
    bgSubtle: 'rgba(245, 158, 11, 0.08)',
  },
  neutral: {
    id: 'neutral',
    label: 'Neutro',
    color: 'var(--ink-soft)',
    glow: 'transparent',
    border: 'var(--line)',
    bgSubtle: 'transparent',
  },
};

// Formats dates identically to image.png
export function formatNoteDate(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    const now = new Date();
    const isToday =
      d.getDate() === now.getDate() &&
      d.getMonth() === now.getMonth() &&
      d.getFullYear() === now.getFullYear();
    const time = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    if (isToday) {
      return `Editada hoje, ${time}`;
    }
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const isYesterday =
      d.getDate() === yesterday.getDate() &&
      d.getMonth() === yesterday.getMonth() &&
      d.getFullYear() === yesterday.getFullYear();
    if (isYesterday) {
      return `Editada ontem, ${time}`;
    }
    const day = d.getDate();
    const months = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    const month = months[d.getMonth()] || '';
    return `${day} ${month}, ${time}`;
  } catch {
    return '';
  }
}

// Exact pill badge styling matching image.png
export function getTagPill(tag: string): string {
  const t = (tag || '').toLowerCase().trim();
  if (t === 'planejamento') return 'bg-[#FEF08A]/80 text-[#854D0E]';
  if (t === 'produto') return 'bg-[#CCFBF1] text-[#115E59]';
  if (t === 'design') return 'bg-[#CFFAFE] text-[#155E75]';
  if (t === 'reunião' || t === 'reuniao') return 'bg-[#FEF3C7] text-[#92400E]';
  if (t === 'retrospectiva') return 'bg-[#FED7AA]/70 text-[#9A3412]';
  if (t === 'referências' || t === 'referencias') return 'bg-[#FEF9C3] text-[#854D0E]';
  if (t === 'pessoal') return 'bg-[#EDE9FE] text-[#6D28D9]';
  if (t === 'trabalho') return 'bg-[#E0F2FE] text-[#0369A1]';
  if (t === 'finanças' || t === 'financas') return 'bg-[#D1FAE5] text-[#065F46]';
  if (t === 'metas') return 'bg-[#FEF08A]/80 text-[#854D0E]';
  return 'bg-[#F1F5F9] text-[#475569]';
}

interface NotesViewProps {
  notes: Note[];
  setNotes: React.Dispatch<React.SetStateAction<Note[]>>;
}

export const NotesView: React.FC<NotesViewProps> = ({ notes, setNotes }) => {
  // 1° Notas pessoais | 2° Painel trabalho | 3° Painel Todos
  const [activePanel, setActivePanel] = useState<'pessoais' | 'trabalho' | 'todos'>('todos');
  const [search, setSearch] = useState('');

  // Dropdown menu state for note card actions
  const [activeMenuNoteId, setActiveMenuNoteId] = useState<string | null>(null);

  // Editor Modal state
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [targetCategoryForNew, setTargetCategoryForNew] = useState<string | undefined>(undefined);
  const [calendarInitialDate, setCalendarInitialDate] = useState<string | undefined>(undefined);

  // View mode: Lista vs Calendário
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');

  // Close dropdown on click outside
  const menuRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setActiveMenuNoteId(null);
      }
    };
    if (activeMenuNoteId) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [activeMenuNoteId]);

  // Classification for panels:
  // Work keywords: trabalho, reunião, produto, sprint, retrospectiva, tech, projeto
  const isWorkCategory = (cat: string) => {
    const c = (cat || '').toLowerCase().trim();
    return (
      c.includes('trab') ||
      c.includes('reuni') ||
      c.includes('prod') ||
      c.includes('sprint') ||
      c.includes('retro') ||
      c.includes('tech') ||
      c.includes('backlog')
    );
  };

  // Filtered notes list based on the 3 panels and search query
  const filteredNotes = useMemo(() => {
    const q = search.toLowerCase().trim();
    return notes
      .filter((n) => {
        if (n.isArchived) return false;

        // Filter by the 3 requested panels
        if (activePanel === 'pessoais') {
          if (isWorkCategory(n.category || '')) return false;
        } else if (activePanel === 'trabalho') {
          if (!isWorkCategory(n.category || '')) return false;
        }
        // 'todos' includes all notes

        // Search text matching
        if (q) {
          const matchTitle = (n.title || '').toLowerCase().includes(q);
          const matchContent = (n.content || '').toLowerCase().includes(q);
          const matchCategory = (n.category || '').toLowerCase().includes(q);
          return matchTitle || matchContent || matchCategory;
        }

        return true;
      })
      .sort((a, b) => {
        // Pinned notes come first (as in image.png where Card 1 is pinned)
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return new Date(b.updatedAt || b.date || 0).getTime() - new Date(a.updatedAt || a.date || 0).getTime();
      });
  }, [notes, activePanel, search]);

  // Handlers
  const handleOpenCreateModal = () => {
    setEditingNote(null);
    setCalendarInitialDate(undefined);
    let defaultCat = 'planejamento';
    if (activePanel === 'trabalho') defaultCat = 'trabalho';
    if (activePanel === 'pessoais') defaultCat = 'pessoal';
    setTargetCategoryForNew(defaultCat);
    setIsEditorOpen(true);
  };

  const handleCreateNoteAtDate = (dateIso: string) => {
    setEditingNote(null);
    setCalendarInitialDate(dateIso);
    let defaultCat = 'planejamento';
    if (activePanel === 'trabalho') defaultCat = 'trabalho';
    if (activePanel === 'pessoais') defaultCat = 'pessoal';
    setTargetCategoryForNew(defaultCat);
    setIsEditorOpen(true);
  };

  const handleOpenEditModal = (note: Note) => {
    setEditingNote(note);
    setIsEditorOpen(true);
    setActiveMenuNoteId(null);
  };

  const handleTogglePin = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) =>
      prev.map((n) =>
        n.id === id ? { ...n, isPinned: !n.isPinned, updatedAt: new Date().toISOString() } : n
      )
    );
  };

  const handleDeleteNote = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) => prev.filter((n) => n.id !== id));
    setActiveMenuNoteId(null);
  };

  const handleCopyContent = (note: Note, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const textToCopy = `${note.title}\n\n${note.content}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(textToCopy);
    }
    setActiveMenuNoteId(null);
  };

  const handleToggleChecklistLine = (noteId: string, lineIndex: number, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => {
        if (n.id !== noteId) return n;
        const lines = n.content.split('\n');
        if (lineIndex < 0 || lineIndex >= lines.length) return n;
        const line = lines[lineIndex];
        let nextLine = line;
        if (line.includes('[ ]')) {
          nextLine = line.replace('[ ]', '[x]');
        } else if (/\[[xX]\]/.test(line)) {
          nextLine = line.replace(/\[[xX]\]/, '[ ]');
        }
        lines[lineIndex] = nextLine;
        return {
          ...n,
          content: lines.join('\n'),
          updatedAt: new Date().toISOString(),
        };
      })
    );
  };

  const handleResetToExampleNotes = () => {
    setNotes(DEFAULT_NOTES);
  };

  return (
    <div className="w-full bg-[#FBF9F4] text-[#1E293B] rounded-2xl p-4 sm:p-7 transition-colors">
      <div className={`w-full ${viewMode === 'calendar' ? 'max-w-5xl' : 'max-w-lg'} mx-auto flex flex-col transition-all duration-200`}>
        {/* Header Principal */}
        <header className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-teal-700 mb-0.5">
              BLOCO DE NOTAS
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-[#0F172A] leading-tight">
              Minhas notas
            </h1>
            <p className="text-sm text-slate-500 mt-0.5">
              Capture, organize, retome.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Alternância Lista / Calendário */}
            <div className="flex items-center bg-white border border-[#E5E0D5] p-1 rounded-xl shadow-2xs">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  viewMode === 'list'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Visualização em Lista"
              >
                <List className="w-3.5 h-3.5" />
                <span>Lista</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('calendar')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  viewMode === 'calendar'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Visualização em Calendário"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Calendário</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleOpenCreateModal}
              className="bg-[#00897B] hover:bg-[#00796B] text-white font-medium px-4 py-2 rounded-xl text-sm transition-all shadow-xs cursor-pointer active:scale-95 shrink-0 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Nova</span>
            </button>
          </div>
        </header>

        {viewMode === 'calendar' ? (
          <NotesCalendarView
            notes={notes}
            onOpenNote={handleOpenEditModal}
            onCreateNoteAtDate={handleCreateNoteAtDate}
            onTogglePin={handleTogglePin}
            onDeleteNote={handleDeleteNote}
            onCopyNote={handleCopyContent}
            onToggleChecklistLine={handleToggleChecklistLine}
            onBackToList={() => setViewMode('list')}
          />
        ) : (
          <>

        {/* Barra de Busca idêntica à imagem */}
        <div className="relative mb-3.5">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar notas..."
            className="w-full bg-white border border-[#E5E0D5] rounded-xl py-2.5 px-4 text-sm text-[#0F172A] placeholder-slate-400 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600 transition-all text-center placeholder:text-center shadow-xs"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* 1° Notas pessoais | 2° Painel trabalho | 3° Painel Todos */}
        <div className="flex items-center gap-2 mb-4 overflow-x-auto no-scrollbar">
          {[
            { key: 'pessoais', label: '1° Notas pessoais' },
            { key: 'trabalho', label: '2° Painel trabalho' },
            { key: 'todos', label: '3° Painel Todos' },
          ].map((tab) => {
            const isSelected = activePanel === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActivePanel(tab.key as any)}
                className={`text-xs transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-white border border-[#CBD5E1] text-[#0F172A] font-semibold px-4 py-1.5 rounded-full shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 font-medium px-2.5 py-1.5'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Lista de Notas simplificada fiel à imagem */}
        <div className="flex flex-col">
          {filteredNotes.map((note, index) => {
            const lines = (note.content || '').split('\n');
            const hasChecklist = lines.some((l) => /\[[ xX]\]/.test(l));
            const isPinned = note.isPinned;
            const tagPillClass = getTagPill(note.category || 'planejamento');
            const formattedDate = formatNoteDate(note.updatedAt || note.date || '');

            // Card 1 (Fixado): Container branco com cantos arredondados e borda
            if (isPinned) {
              return (
                <article
                  key={note.id}
                  onClick={() => handleOpenEditModal(note)}
                  className="bg-white rounded-2xl p-4 border border-[#E5E0D5] shadow-xs mb-3 transition-all hover:shadow-md cursor-pointer group relative"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-bold text-[#0F172A] text-[15px] group-hover:text-teal-900 transition-colors leading-snug">
                      {note.title || 'Sem título'}
                    </h3>

                    {/* Ações discretas no hover */}
                    <div
                      className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={(e) => handleTogglePin(note.id, e)}
                        title="Desafixar nota"
                        className="p-1 text-teal-600 hover:text-teal-700 cursor-pointer"
                      >
                        <Pin className="w-3.5 h-3.5 fill-teal-600" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveMenuNoteId(activeMenuNoteId === note.id ? null : note.id);
                        }}
                        className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <MoreVertical className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Conteúdo */}
                  <div className="text-[#475569] text-xs sm:text-[13px] leading-relaxed mt-1.5">
                    {hasChecklist ? (
                      <div className="flex flex-col gap-1 py-0.5">
                        {lines.map((line, idx) => {
                          const isCheck = /\[[ xX]\]/.test(line);
                          if (!isCheck) return <p key={idx} className="m-0">{line}</p>;
                          const isDone = /\[[xX]\]/.test(line);
                          const text = line.replace(/\[[ xX]\]/, '').trim();
                          return (
                            <div
                              key={idx}
                              onClick={(e) => handleToggleChecklistLine(note.id, idx, e)}
                              className="flex items-start gap-1.5 hover:text-slate-900 transition-colors cursor-pointer"
                            >
                              <span className="mt-0.5 shrink-0 text-slate-400 hover:text-teal-600">
                                {isDone ? (
                                  <CheckSquare className="w-3.5 h-3.5 text-teal-600" />
                                ) : (
                                  <Square className="w-3.5 h-3.5" />
                                )}
                              </span>
                              <span className={isDone ? 'line-through text-slate-400' : 'text-slate-700'}>
                                {text}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="m-0 whitespace-pre-wrap">{note.content}</p>
                    )}
                  </div>

                  {/* Rodapé: Editada hoje, 20:42 • [ planejamento ] */}
                  <div className="flex items-center text-xs text-[#64748B] mt-3">
                    <span>{formattedDate}</span>
                    <span className="mx-2">•</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium capitalize ${tagPillClass}`}>
                      {note.category || 'geral'}
                    </span>
                  </div>

                  {/* Menu popover rápido */}
                  {activeMenuNoteId === note.id && (
                    <div
                      ref={menuRef}
                      onClick={(e) => e.stopPropagation()}
                      className="absolute right-3 top-9 w-36 bg-white rounded-xl shadow-lg border border-slate-200 p-1 z-30 text-xs flex flex-col gap-0.5"
                    >
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(note)}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left cursor-pointer"
                      >
                        <Edit3 className="w-3 h-3 text-teal-600" />
                        <span>Editar</span>
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleCopyContent(note, e)}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left cursor-pointer"
                      >
                        <Copy className="w-3 h-3 text-slate-400" />
                        <span>Copiar</span>
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleDeleteNote(note.id, e)}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-50 text-rose-600 text-left cursor-pointer border-t border-slate-100"
                      >
                        <Trash2 className="w-3 h-3 text-rose-500" />
                        <span>Excluir</span>
                      </button>
                    </div>
                  )}
                </article>
              );
            }

            // Cards seguintes (Não fixados): Separados por linhas finas exatamente como na imagem
            return (
              <React.Fragment key={note.id}>
                {index > 0 && <div className="border-t border-[#E8E2D6] my-1" />}
                <article
                  onClick={() => handleOpenEditModal(note)}
                  className="py-3 px-2 rounded-xl transition-all hover:bg-black/[0.02] cursor-pointer group relative"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-bold text-[#0F172A] text-[15px] group-hover:text-teal-900 transition-colors leading-snug">
                      {note.title || 'Sem título'}
                    </h3>

                    {/* Ações discretas no hover */}
                    <div
                      className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={(e) => handleTogglePin(note.id, e)}
                        title="Fixar nota"
                        className="p-1 text-slate-400 hover:text-teal-600 cursor-pointer"
                      >
                        <Pin className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveMenuNoteId(activeMenuNoteId === note.id ? null : note.id);
                        }}
                        className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <MoreVertical className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Conteúdo */}
                  <div className="text-[#475569] text-xs sm:text-[13px] leading-relaxed mt-1">
                    {hasChecklist ? (
                      <div className="flex flex-col gap-1 py-0.5">
                        {lines.map((line, idx) => {
                          const isCheck = /\[[ xX]\]/.test(line);
                          if (!isCheck) return <p key={idx} className="m-0">{line}</p>;
                          const isDone = /\[[xX]\]/.test(line);
                          const text = line.replace(/\[[ xX]\]/, '').trim();
                          return (
                            <div
                              key={idx}
                              onClick={(e) => handleToggleChecklistLine(note.id, idx, e)}
                              className="flex items-start gap-1.5 hover:text-slate-900 transition-colors cursor-pointer"
                            >
                              <span className="mt-0.5 shrink-0 text-slate-400 hover:text-teal-600">
                                {isDone ? (
                                  <CheckSquare className="w-3.5 h-3.5 text-teal-600" />
                                ) : (
                                  <Square className="w-3.5 h-3.5" />
                                )}
                              </span>
                              <span className={isDone ? 'line-through text-slate-400' : 'text-slate-700'}>
                                {text}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="m-0 whitespace-pre-wrap">{note.content}</p>
                    )}
                  </div>

                  {/* Rodapé: Editada hoje, 18:10 • [ produto ] */}
                  <div className="flex items-center text-xs text-[#64748B] mt-2">
                    <span>{formattedDate}</span>
                    <span className="mx-2">•</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium capitalize ${tagPillClass}`}>
                      {note.category || 'geral'}
                    </span>
                  </div>

                  {/* Menu popover rápido */}
                  {activeMenuNoteId === note.id && (
                    <div
                      ref={menuRef}
                      onClick={(e) => e.stopPropagation()}
                      className="absolute right-3 top-9 w-36 bg-white rounded-xl shadow-lg border border-slate-200 p-1 z-30 text-xs flex flex-col gap-0.5"
                    >
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(note)}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left cursor-pointer"
                      >
                        <Edit3 className="w-3 h-3 text-teal-600" />
                        <span>Editar</span>
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleCopyContent(note, e)}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left cursor-pointer"
                      >
                        <Copy className="w-3 h-3 text-slate-400" />
                        <span>Copiar</span>
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleDeleteNote(note.id, e)}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-50 text-rose-600 text-left cursor-pointer border-t border-slate-100"
                      >
                        <Trash2 className="w-3 h-3 text-rose-500" />
                        <span>Excluir</span>
                      </button>
                    </div>
                  )}
                </article>
              </React.Fragment>
            );
          })}
        </div>

        {/* Empty state com link para restaurar os exemplos da imagem */}
        {filteredNotes.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-xs flex flex-col items-center gap-2">
            <p>Nenhuma anotação encontrada neste painel.</p>
            <button
              type="button"
              onClick={handleResetToExampleNotes}
              className="inline-flex items-center gap-1.5 text-teal-700 hover:text-teal-800 font-medium underline cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Restaurar notas de exemplo da imagem</span>
            </button>
          </div>
        )}
          </>
        )}
      </div>

      {/* Editor Modal Completo */}
      <NoteEditorModal
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        note={editingNote}
        initialCategory={targetCategoryForNew}
        initialDate={calendarInitialDate}
        onSave={(data) => {
          if (editingNote) {
            setNotes((prev) =>
              prev.map((n) =>
                n.id === editingNote.id
                  ? {
                      ...n,
                      title: data.title,
                      content: data.content,
                      category: data.category,
                      color: data.color,
                      isPinned: data.isPinned,
                      isArchived: data.isArchived,
                      reminder: data.reminder,
                      date: data.date || n.date,
                      updatedAt: new Date().toISOString(),
                    }
                  : n
              )
            );
          } else {
            const newNote: Note = {
              id: genId(),
              title: data.title,
              content: data.content,
              category: data.category,
              color: data.color,
              isPinned: data.isPinned,
              isArchived: data.isArchived,
              reminder: data.reminder,
              date: data.date || calendarInitialDate || getTodayISO(),
              updatedAt: new Date().toISOString(),
            };
            setNotes((prev) => [newNote, ...prev]);
          }
          setIsEditorOpen(false);
        }}
        onArchiveToggle={(noteId) => {
          setNotes((prev) =>
            prev.map((n) => (n.id === noteId ? { ...n, isArchived: !n.isArchived } : n))
          );
        }}
        onDelete={(noteId) => {
          handleDeleteNote(noteId);
        }}
      />
    </div>
  );
};
