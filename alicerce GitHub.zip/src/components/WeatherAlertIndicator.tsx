import React, { useState } from 'react';
import {
  Flame,
  CloudRain,
  CloudLightning,
  Wind,
  ThermometerSnowflake,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
} from 'lucide-react';
import { WeatherAlert } from '../utils/weatherAlerts';

interface WeatherAlertIndicatorProps {
  alert: WeatherAlert;
}

export const WeatherAlertIndicator: React.FC<WeatherAlertIndicatorProps> = ({ alert }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Render appropriate category icon
  const renderCategoryIcon = () => {
    const iconProps = { size: 16, className: 'shrink-0', color: alert.color };
    switch (alert.category) {
      case 'heat':
        return <Flame {...iconProps} />;
      case 'rain':
        return <CloudRain {...iconProps} />;
      case 'storm':
        return <CloudLightning {...iconProps} />;
      case 'wind':
        return <Wind {...iconProps} />;
      case 'cold':
        return <ThermometerSnowflake {...iconProps} />;
      case 'dry':
        return <AlertTriangle {...iconProps} />;
      default:
        return <ShieldAlert {...iconProps} />;
    }
  };

  return (
    <div
      id={`weather-alert-${alert.id}`}
      className="weather-alert-indicator"
      style={{
        width: '100%',
        margin: '0.65rem 0 0.85rem',
        borderRadius: '0.85rem',
        background: alert.bgColor,
        border: `1px solid ${alert.borderColor}`,
        boxShadow: `0 4px 18px ${alert.glowColor}`,
        backdropFilter: 'blur(8px)',
        padding: '0.65rem 0.85rem',
        textAlign: 'left',
        transition: 'all 0.3s ease',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Top row: Pulse Beacon + Icon + Title + Severity Pill + Toggle */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '0.45rem',
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
          {/* Animated Glowing Beacon */}
          <span
            style={{
              position: 'relative',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '10px',
              height: '10px',
            }}
          >
            <span
              style={{
                position: 'absolute',
                width: '100%',
                height: '100%',
                borderRadius: '50%',
                backgroundColor: alert.color,
                opacity: 0.75,
                animation: 'alertBeaconPing 1.8s cubic-bezier(0, 0, 0.2, 1) infinite',
              }}
            />
            <span
              style={{
                position: 'relative',
                display: 'inline-block',
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                backgroundColor: alert.color,
              }}
            />
          </span>

          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '24px',
              height: '24px',
              borderRadius: '0.45rem',
              background: 'rgba(0, 0, 0, 0.25)',
            }}
          >
            {renderCategoryIcon()}
          </div>

          <span
            style={{
              fontSize: '0.82rem',
              fontWeight: 700,
              fontFamily: 'var(--font-display)',
              color: alert.textColor,
              letterSpacing: '-0.01em',
            }}
          >
            {alert.title}
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          {/* Severity Badge */}
          <span
            style={{
              fontSize: '0.62rem',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '0.04em',
              padding: '0.15rem 0.45rem',
              borderRadius: '999px',
              background: alert.severity === 'severe' ? 'rgba(239, 68, 68, 0.35)' : 'rgba(249, 115, 22, 0.3)',
              border: `1px solid ${alert.borderColor}`,
              color: alert.textColor,
            }}
          >
            {alert.badge}
          </span>

          {/* Expand / Collapse Button */}
          <button
            type="button"
            onClick={() => setIsExpanded((prev) => !prev)}
            aria-label={isExpanded ? 'Recolher recomendações' : 'Ver recomendações'}
            style={{
              background: 'rgba(0, 0, 0, 0.2)',
              border: 'none',
              borderRadius: '0.35rem',
              padding: '0.2rem',
              color: alert.textColor,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              opacity: 0.85,
            }}
          >
            {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
        </div>
      </div>

      {/* Main Condition Headline */}
      <div
        style={{
          marginTop: '0.35rem',
          fontSize: '0.74rem',
          color: alert.textColor,
          opacity: 0.95,
          lineHeight: 1.38,
          fontWeight: 500,
        }}
      >
        {alert.headline}
      </div>

      {/* Dynamic Metric Detail Pill */}
      <div
        style={{
          marginTop: '0.4rem',
          display: 'inline-flex',
          alignItems: 'center',
          gap: '0.3rem',
          fontSize: '0.68rem',
          fontFamily: 'var(--font-mono)',
          padding: '0.2rem 0.5rem',
          borderRadius: '0.45rem',
          background: 'rgba(0, 0, 0, 0.28)',
          color: alert.textColor,
          border: '1px solid rgba(255, 255, 255, 0.08)',
        }}
      >
        <span>Dados detectados:</span>
        <strong style={{ fontWeight: 700 }}>{alert.metricDetails}</strong>
      </div>

      {/* Expandable Safety Recommendation */}
      {isExpanded && (
        <div
          style={{
            marginTop: '0.5rem',
            paddingTop: '0.45rem',
            borderTop: '1px solid rgba(255, 255, 255, 0.12)',
            fontSize: '0.7rem',
            lineHeight: 1.42,
            color: alert.textColor,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.35rem' }}>
            <span style={{ fontSize: '0.85rem' }}>💡</span>
            <div>
              <strong style={{ display: 'block', marginBottom: '0.1rem' }}>Recomendação de segurança:</strong>
              <span style={{ opacity: 0.92 }}>{alert.recommendation}</span>
            </div>
          </div>
        </div>
      )}

      {/* Bottom subtle touch hint when collapsed */}
      {!isExpanded && (
        <div
          onClick={() => setIsExpanded(true)}
          style={{
            marginTop: '0.35rem',
            fontSize: '0.65rem',
            opacity: 0.75,
            cursor: 'pointer',
            textAlign: 'right',
            color: alert.textColor,
          }}
        >
          Toque para ver recomendações de segurança →
        </div>
      )}
    </div>
  );
};
