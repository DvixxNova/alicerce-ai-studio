import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Save,
  Archive,
  ArchiveRestore,
  Trash2,
  Pin,
  Bell,
  BellOff,
  Clock,
  Calendar,
  Check,
  Tag,
  Plus,
  Palette,
  Bold,
  Italic,
  Heading2,
  List,
  ListTodo,
  Quote,
  Eye,
  Edit3,
  CheckSquare,
  Square,
  Sparkles,
} from 'lucide-react';
import { Note, NoteAccentColor } from '../types';
import {
  CATEGORY_MAP,
  NOTE_ACCENTS,
  NoteCategory,
} from './NotesView';

export interface NoteEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  note: Note | null; // null se for criação de nova nota
  onSave: (noteData: {
    title: string;
    content: string;
    category: string;
    color: NoteAccentColor;
    isPinned: boolean;
    isArchived: boolean;
    reminder?: string;
  }) => void;
  onArchiveToggle?: (noteId: string) => void;
  onDelete?: (noteId: string) => void;
  initialCategory?: string;
}

const PRESET_CATEGORIES: string[] = [
  'Trabalho',
  'Pessoal',
  'Ideias',
  'Metas',
  'Finanças',
  'Oração',
];

const ACCENT_KEYS: NoteAccentColor[] = ['neon', 'cosmic', 'ocean', 'gold', 'neutral'];

// Format a date string into ISO local format for datetime-local input (YYYY-MM-DDTHH:mm)
function toDatetimeLocalString(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  const year = date.getFullYear();
  const month = pad(date.getMonth() + 1);
  const day = pad(date.getDate());
  const hours = pad(date.getHours());
  const minutes = pad(date.getMinutes());
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

export const NoteEditorModal: React.FC<NoteEditorModalProps> = ({
  isOpen,
  onClose,
  note,
  onSave,
  onArchiveToggle,
  onDelete,
  initialCategory,
}) => {
  // Form State
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<string>('Trabalho');
  const [isCustomTagInputOpen, setIsCustomTagInputOpen] = useState(false);
  const [customTagInput, setCustomTagInput] = useState('');
  const [color, setColor] = useState<NoteAccentColor>('neon');
  const [isPinned, setIsPinned] = useState(false);
  const [isArchived, setIsArchived] = useState(false);

  // Reminder / Alarm State
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderValue, setReminderValue] = useState('');

  // Rich Text Editor Tab (Write vs. Preview)
  const [activeTab, setActiveTab] = useState<'write' | 'preview'>('write');

  // Textarea Ref for text selection insertions
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Synchronize state when modal opens or note changes
  useEffect(() => {
    if (isOpen) {
      if (note) {
        setTitle(note.title || '');
        setContent(note.content || '');
        setCategory(note.category || 'Trabalho');
        setColor((note.color as NoteAccentColor) || 'neon');
        setIsPinned(Boolean(note.isPinned));
        setIsArchived(Boolean(note.isArchived));

        if (note.reminder) {
          setReminderEnabled(true);
          try {
            const d = new Date(note.reminder);
            if (!isNaN(d.getTime())) {
              setReminderValue(toDatetimeLocalString(d));
            } else {
              setReminderValue(note.reminder);
            }
          } catch {
            setReminderValue(note.reminder);
          }
        } else {
          setReminderEnabled(false);
          setReminderValue('');
        }
      } else {
        // Creating new note
        setTitle('');
        setContent('');
        setCategory(
          initialCategory && initialCategory !== 'Todas' ? initialCategory : 'Trabalho'
        );
        setColor('neon');
        setIsPinned(false);
        setIsArchived(false);
        setReminderEnabled(false);
        // Default reminder to tomorrow at 09:00
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(9, 0, 0, 0);
        setReminderValue(toDatetimeLocalString(tomorrow));
      }
      setIsCustomTagInputOpen(false);
      setCustomTagInput('');
      setActiveTab('write');
    }
  }, [isOpen, note, initialCategory]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Insert markdown/checklist syntax helper at cursor or wrap selection
  const insertSyntax = (prefix: string, suffix: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);

    const replacement = `${prefix}${selectedText || (prefix === '[ ] ' ? 'Tarefa pendente' : '')}${suffix}`;
    const newContent =
      content.substring(0, start) + replacement + content.substring(end);

    setContent(newContent);

    // Re-focus and restore cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(
        start + prefix.length,
        start + prefix.length + (selectedText.length || (prefix === '[ ] ' ? 15 : 0))
      );
    }, 10);
  };

  // Form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !content.trim()) {
      return;
    }

    onSave({
      title: title.trim() || 'Sem título',
      content: content.trim(),
      category: category.trim() || 'Geral',
      color,
      isPinned,
      isArchived,
      reminder: reminderEnabled && reminderValue ? reminderValue : undefined,
    });
  };

  // Quick reminder shortcuts
  const applyReminderPreset = (preset: 'today_afternoon' | 'today_evening' | 'tomorrow_morning' | 'next_week') => {
    const now = new Date();
    const target = new Date();

    if (preset === 'today_afternoon') {
      target.setHours(15, 0, 0, 0);
      if (target.getTime() <= now.getTime()) {
        target.setDate(target.getDate() + 1);
      }
    } else if (preset === 'today_evening') {
      target.setHours(20, 0, 0, 0);
      if (target.getTime() <= now.getTime()) {
        target.setDate(target.getDate() + 1);
      }
    } else if (preset === 'tomorrow_morning') {
      target.setDate(target.getDate() + 1);
      target.setHours(9, 0, 0, 0);
    } else if (preset === 'next_week') {
      // Days until next Monday
      const day = target.getDay();
      const diff = day === 0 ? 1 : 8 - day;
      target.setDate(target.getDate() + diff);
      target.setHours(9, 0, 0, 0);
    }

    setReminderEnabled(true);
    setReminderValue(toDatetimeLocalString(target));
  };

  // Human-readable format of reminder date
  const getReadableReminder = () => {
    if (!reminderValue) return null;
    try {
      const d = new Date(reminderValue);
      if (isNaN(d.getTime())) return reminderValue;
      return d.toLocaleString('pt-BR', {
        weekday: 'short',
        day: '2-digit',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return reminderValue;
    }
  };

  // Interactive toggle inside the live preview
  const handleTogglePreviewCheckbox = (lineIndex: number) => {
    const lines = content.split('\n');
    if (lineIndex < 0 || lineIndex >= lines.length) return;
    const line = lines[lineIndex];
    let nextLine = line;
    if (line.includes('[ ]')) {
      nextLine = line.replace('[ ]', '[x]');
    } else if (/\[[xX]\]/.test(line)) {
      nextLine = line.replace(/\[[xX]\]/, '[ ]');
    }
    lines[lineIndex] = nextLine;
    setContent(lines.join('\n'));
  };

  const currentAccent = NOTE_ACCENTS[color] || NOTE_ACCENTS.neon;

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.65)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        animation: 'fadeIn 0.2s ease-out',
      }}
    >
      <div
        className="note-modal-dialog"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '640px',
          maxHeight: '92vh',
          display: 'flex',
          flexDirection: 'column',
          backgroundColor: 'var(--panel)',
          borderRadius: '1.25rem',
          border: `1.5px solid ${color === 'neutral' ? 'var(--line)' : currentAccent.border}`,
          boxShadow: `0 24px 60px rgba(0, 0, 0, 0.45), 0 0 24px ${currentAccent.glow}`,
          overflow: 'hidden',
          animation: 'modalScaleIn 0.22s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {/* Barra superior de acento colorido */}
        {color !== 'neutral' && (
          <div
            style={{
              height: '4px',
              width: '100%',
              background: currentAccent.color,
            }}
          />
        )}

        {/* 1. TOPO DO MODAL */}
        <div
          style={{
            padding: '1.1rem 1.4rem',
            borderBottom: '1px solid var(--line)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'var(--panel-strong)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: 34,
                height: 34,
                borderRadius: '0.6rem',
                background: `linear-gradient(135deg, ${currentAccent.color}, var(--active2))`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fff',
                boxShadow: `0 4px 12px ${currentAccent.glow}`,
              }}
            >
              <Edit3 size={17} />
            </div>
            <div>
              <h2
                className="note-modal-title"
                style={{
                  margin: 0,
                  fontSize: '1.15rem',
                  fontWeight: 800,
                  fontFamily: 'var(--font-display)',
                  color: 'var(--ink)',
                  letterSpacing: '0.01em',
                }}
              >
                {note ? 'Editar Anotação' : 'Nova Anotação'}
              </h2>
              <span style={{ fontSize: '0.74rem', color: 'var(--ink-soft)' }}>
                {note ? 'Atualize os dados, tarefas e lembrete' : 'Crie listas, ideias e agende alertas'}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            {/* Botão Fixar no Topo rápido */}
            <button
              type="button"
              onClick={() => setIsPinned((prev) => !prev)}
              title={isPinned ? 'Desafixar nota do topo' : 'Fixar nota no topo'}
              style={{
                background: isPinned ? 'rgba(245, 158, 11, 0.18)' : 'transparent',
                border: isPinned ? '1px solid #F59E0B' : '1px solid var(--line)',
                color: isPinned ? '#F59E0B' : 'var(--ink-soft)',
                borderRadius: '0.55rem',
                padding: '0.42rem',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.15s ease',
              }}
            >
              <Pin size={15} style={{ fill: isPinned ? '#F59E0B' : 'none' }} />
            </button>

            {/* Fechar Modal */}
            <button
              type="button"
              onClick={onClose}
              title="Fechar (Esc)"
              style={{
                background: 'transparent',
                border: 'none',
                color: 'var(--ink-soft)',
                padding: '0.42rem',
                borderRadius: '0.55rem',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.15s ease',
              }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* 2. FORMULÁRIO COM SCROLL INTERNO */}
        <form
          onSubmit={handleSubmit}
          style={{
            flex: 1,
            overflowY: 'auto',
            padding: '1.35rem 1.4rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '1.2rem',
          }}
        >
          {/* Campo: Título da Nota */}
          <div>
            <label
              className="note-form-label"
              style={{
                display: 'block',
                fontSize: '0.75rem',
                fontWeight: 700,
                color: 'var(--ink-soft)',
                marginBottom: '0.4rem',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}
            >
              Título da Nota
            </label>
            <input
              type="text"
              className="note-form-input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Metas Semanais, Alinhamento de Projetos, Ideias..."
              autoFocus
              style={{
                width: '100%',
                padding: '0.75rem 0.95rem',
                borderRadius: '0.75rem',
                background: 'var(--panel-strong)',
                border: '1px solid var(--line)',
                color: 'var(--ink)',
                fontSize: '0.95rem',
                fontWeight: 600,
                outline: 'none',
                boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.1)',
                transition: 'border-color 0.15s ease, box-shadow 0.15s ease',
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = currentAccent.color;
                e.currentTarget.style.boxShadow = `0 0 0 3px ${currentAccent.glow}`;
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = 'var(--line)';
                e.currentTarget.style.boxShadow = 'inset 0 1px 3px rgba(0,0,0,0.1)';
              }}
            />
          </div>

          {/* Campo: Seleção de Categoria & Tag Personalizada */}
          <div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '0.4rem',
              }}
            >
              <label
                className="note-form-label"
                style={{
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  color: 'var(--ink-soft)',
                  textTransform: 'uppercase',
                  letterSpacing: '0.04em',
                }}
              >
                Categoria / Tag
              </label>

              {!isCustomTagInputOpen && (
                <button
                  type="button"
                  onClick={() => setIsCustomTagInputOpen(true)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--active)',
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                  }}
                >
                  <Plus size={13} />
                  <span>+ Tag Personalizada</span>
                </button>
              )}
            </div>

            {/* Pílulas de Categoria Pré-definidas */}
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '0.4rem',
              }}
            >
              {PRESET_CATEGORIES.map((cat) => {
                const isSelected = category.toLowerCase() === cat.toLowerCase();
                const config = CATEGORY_MAP[cat];
                const Icon = config ? config.icon : Tag;

                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      setCategory(cat);
                      setIsCustomTagInputOpen(false);
                    }}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                      padding: '0.38rem 0.75rem',
                      borderRadius: '9999px',
                      fontSize: '0.78rem',
                      fontWeight: isSelected ? 700 : 500,
                      cursor: 'pointer',
                      border: isSelected
                        ? `1.5px solid ${config ? config.color : 'var(--active)'}`
                        : '1px solid var(--line)',
                      background: isSelected
                        ? config
                          ? config.color
                          : 'var(--active)'
                        : 'var(--panel-strong)',
                      color: isSelected ? '#FFFFFF' : 'var(--ink)',
                      boxShadow: isSelected
                        ? `0 3px 12px ${config ? config.color + '44' : 'var(--active-glow)'}`
                        : 'none',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    <Icon size={13} />
                    <span>{cat}</span>
                  </button>
                );
              })}

              {/* Se a categoria atual for personalizada (não preset) */}
              {!PRESET_CATEGORIES.some((c) => c.toLowerCase() === category.toLowerCase()) && category && (
                <div
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    padding: '0.38rem 0.75rem',
                    borderRadius: '9999px',
                    fontSize: '0.78rem',
                    fontWeight: 700,
                    border: `1.5px solid ${currentAccent.color}`,
                    background: currentAccent.color,
                    color: '#FFFFFF',
                    boxShadow: `0 3px 12px ${currentAccent.glow}`,
                  }}
                >
                  <Tag size={13} />
                  <span>{category}</span>
                  <X
                    size={13}
                    style={{ cursor: 'pointer', marginLeft: '0.2rem' }}
                    onClick={() => setCategory('Trabalho')}
                  />
                </div>
              )}
            </div>

            {/* Input para Tag Personalizada */}
            {isCustomTagInputOpen && (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  marginTop: '0.55rem',
                }}
              >
                <div style={{ position: 'relative', flex: 1 }}>
                  <Tag
                    size={14}
                    style={{
                      position: 'absolute',
                      left: '0.65rem',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      color: 'var(--ink-soft)',
                    }}
                  />
                  <input
                    type="text"
                    value={customTagInput}
                    onChange={(e) => setCustomTagInput(e.target.value)}
                    placeholder="Nome da tag (ex: Faculdade, Saúde, Livros)..."
                    autoFocus
                    style={{
                      width: '100%',
                      padding: '0.45rem 0.75rem 0.45rem 2.2rem',
                      borderRadius: '0.65rem',
                      background: 'var(--panel-strong)',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.82rem',
                      outline: 'none',
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (customTagInput.trim()) {
                          setCategory(customTagInput.trim());
                          setIsCustomTagInputOpen(false);
                          setCustomTagInput('');
                        }
                      }
                    }}
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (customTagInput.trim()) {
                      setCategory(customTagInput.trim());
                      setIsCustomTagInputOpen(false);
                      setCustomTagInput('');
                    }
                  }}
                  style={{
                    padding: '0.45rem 0.85rem',
                    borderRadius: '0.65rem',
                    background: 'linear-gradient(135deg, var(--active), var(--active2))',
                    border: 'none',
                    color: '#fff',
                    fontSize: '0.78rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                  }}
                >
                  Adicionar
                </button>

                <button
                  type="button"
                  onClick={() => setIsCustomTagInputOpen(false)}
                  style={{
                    padding: '0.45rem',
                    borderRadius: '0.65rem',
                    background: 'transparent',
                    border: '1px solid var(--line)',
                    color: 'var(--ink-soft)',
                    cursor: 'pointer',
                  }}
                >
                  <X size={14} />
                </button>
              </div>
            )}
          </div>

          {/* Campo: Escolha de Cor Temática do Card */}
          <div>
            <label
              className="note-form-label"
              style={{
                display: 'block',
                fontSize: '0.75rem',
                fontWeight: 700,
                color: 'var(--ink-soft)',
                marginBottom: '0.4rem',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}
            >
              Cor Temática do Card
            </label>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                flexWrap: 'wrap',
              }}
            >
              {ACCENT_KEYS.map((key) => {
                const cfg = NOTE_ACCENTS[key];
                const isSelected = color === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setColor(key)}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.45rem',
                      padding: '0.42rem 0.75rem',
                      borderRadius: '0.75rem',
                      background: isSelected ? 'var(--panel-strong)' : 'transparent',
                      border: isSelected
                        ? `2px solid ${cfg.color === 'var(--ink-soft)' ? 'var(--ink)' : cfg.color}`
                        : '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.78rem',
                      fontWeight: isSelected ? 700 : 500,
                      cursor: 'pointer',
                      boxShadow: isSelected ? `0 0 14px ${cfg.glow}` : 'none',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    <span
                      style={{
                        width: 14,
                        height: 14,
                        borderRadius: '50%',
                        backgroundColor: key === 'neutral' ? 'var(--line)' : cfg.color,
                        boxShadow: isSelected ? `0 0 8px ${cfg.color}` : 'none',
                      }}
                    />
                    <span>{cfg.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Campo: Recurso de Lembrete / Alarme */}
          <div
            style={{
              background: reminderEnabled ? 'rgba(14, 165, 233, 0.08)' : 'var(--panel-strong)',
              border: `1px solid ${reminderEnabled ? '#0EA5E9' : 'var(--line)'}`,
              borderRadius: '0.85rem',
              padding: '0.85rem 1rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.65rem',
              transition: 'all 0.2s ease',
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: '0.45rem',
                    background: reminderEnabled ? '#0EA5E9' : 'rgba(128,128,128,0.15)',
                    color: reminderEnabled ? '#FFFFFF' : 'var(--ink-soft)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.18s ease',
                  }}
                >
                  <Bell size={15} />
                </div>
                <div>
                  <div style={{ fontSize: '0.84rem', fontWeight: 700, color: 'var(--ink)' }}>
                    Lembrete / Alarme da Nota
                  </div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--ink-soft)' }}>
                    {reminderEnabled && reminderValue
                      ? `Ativo: ${getReadableReminder()}`
                      : 'Receba alertas no dia e horário programados'}
                  </div>
                </div>
              </div>

              {/* Toggle switch do Lembrete */}
              <button
                type="button"
                onClick={() => setReminderEnabled((prev) => !prev)}
                style={{
                  background: reminderEnabled ? '#0EA5E9' : 'var(--line)',
                  border: 'none',
                  borderRadius: '9999px',
                  width: '42px',
                  height: '24px',
                  position: 'relative',
                  cursor: 'pointer',
                  padding: '2px',
                  transition: 'background 0.2s ease',
                }}
              >
                <div
                  style={{
                    width: '20px',
                    height: '20px',
                    borderRadius: '50%',
                    background: '#FFFFFF',
                    transform: reminderEnabled ? 'translateX(18px)' : 'translateX(0)',
                    transition: 'transform 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
                  }}
                />
              </button>
            </div>

            {/* Painel expandido do lembrete */}
            {reminderEnabled && (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.65rem',
                  paddingTop: '0.4rem',
                  borderTop: '1px dashed var(--line)',
                  animation: 'fadeIn 0.2s ease',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                  <div style={{ position: 'relative', flex: 1, minWidth: '220px' }}>
                    <Calendar
                      size={14}
                      style={{
                        position: 'absolute',
                        left: '0.65rem',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        color: '#0EA5E9',
                        pointerEvents: 'none',
                      }}
                    />
                    <input
                      type="datetime-local"
                      value={reminderValue}
                      onChange={(e) => setReminderValue(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '0.48rem 0.65rem 0.48rem 2.2rem',
                        borderRadius: '0.65rem',
                        background: 'var(--panel)',
                        border: '1px solid var(--line)',
                        color: 'var(--ink)',
                        fontSize: '0.82rem',
                        fontFamily: 'inherit',
                        outline: 'none',
                      }}
                    />
                  </div>

                  {reminderValue && (
                    <button
                      type="button"
                      onClick={() => setReminderValue('')}
                      style={{
                        background: 'transparent',
                        border: '1px solid var(--line)',
                        color: 'var(--ink-soft)',
                        fontSize: '0.72rem',
                        padding: '0.45rem 0.65rem',
                        borderRadius: '0.65rem',
                        cursor: 'pointer',
                      }}
                    >
                      Limpar Data
                    </button>
                  )}
                </div>

                {/* Atalhos Rápidos de Agendamento */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: '0.68rem', color: 'var(--ink-soft)', fontWeight: 600 }}>
                    Atalhos:
                  </span>
                  <button
                    type="button"
                    onClick={() => applyReminderPreset('today_afternoon')}
                    style={{
                      background: 'rgba(128,128,128,0.1)',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.68rem',
                      fontWeight: 600,
                      padding: '0.2rem 0.5rem',
                      borderRadius: '9999px',
                      cursor: 'pointer',
                    }}
                  >
                    Hoje 15h
                  </button>
                  <button
                    type="button"
                    onClick={() => applyReminderPreset('today_evening')}
                    style={{
                      background: 'rgba(128,128,128,0.1)',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.68rem',
                      fontWeight: 600,
                      padding: '0.2rem 0.5rem',
                      borderRadius: '9999px',
                      cursor: 'pointer',
                    }}
                  >
                    Hoje 20h
                  </button>
                  <button
                    type="button"
                    onClick={() => applyReminderPreset('tomorrow_morning')}
                    style={{
                      background: 'rgba(128,128,128,0.1)',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.68rem',
                      fontWeight: 600,
                      padding: '0.2rem 0.5rem',
                      borderRadius: '9999px',
                      cursor: 'pointer',
                    }}
                  >
                    Amanhã 09h
                  </button>
                  <button
                    type="button"
                    onClick={() => applyReminderPreset('next_week')}
                    style={{
                      background: 'rgba(128,128,128,0.1)',
                      border: '1px solid var(--line)',
                      color: 'var(--ink)',
                      fontSize: '0.68rem',
                      fontWeight: 600,
                      padding: '0.2rem 0.5rem',
                      borderRadius: '9999px',
                      cursor: 'pointer',
                    }}
                  >
                    Segunda 09h
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Campo: Área de Texto Rica com Toolbar & Abas de Pré-visualização */}
          <div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '0.4rem',
              }}
            >
              <label
                style={{
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  color: 'var(--ink-soft)',
                  textTransform: 'uppercase',
                  letterSpacing: '0.04em',
                }}
              >
                Conteúdo da Nota (Markdown & Checklists)
              </label>

              {/* Alternador Escrever / Pré-visualizar */}
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  background: 'var(--panel-strong)',
                  border: '1px solid var(--line)',
                  borderRadius: '9999px',
                  padding: '0.15rem',
                }}
              >
                <button
                  type="button"
                  onClick={() => setActiveTab('write')}
                  style={{
                    padding: '0.22rem 0.65rem',
                    borderRadius: '9999px',
                    border: 'none',
                    background: activeTab === 'write' ? currentAccent.color : 'transparent',
                    color: activeTab === 'write' ? '#FFFFFF' : 'var(--ink-soft)',
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                  }}
                >
                  <Edit3 size={11} />
                  <span>Editor</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('preview')}
                  style={{
                    padding: '0.22rem 0.65rem',
                    borderRadius: '9999px',
                    border: 'none',
                    background: activeTab === 'preview' ? currentAccent.color : 'transparent',
                    color: activeTab === 'preview' ? '#FFFFFF' : 'var(--ink-soft)',
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                  }}
                >
                  <Eye size={11} />
                  <span>Prévia</span>
                </button>
              </div>
            </div>

            {/* Barra de Ferramentas / Formatação Rápida */}
            {activeTab === 'write' && (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.25rem',
                  padding: '0.4rem 0.6rem',
                  background: 'var(--panel-strong)',
                  border: '1px solid var(--line)',
                  borderBottom: 'none',
                  borderTopLeftRadius: '0.75rem',
                  borderTopRightRadius: '0.75rem',
                  overflowX: 'auto',
                }}
              >
                <button
                  type="button"
                  onClick={() => insertSyntax('**', '**')}
                  title="Negrito (**texto**)"
                  style={{
                    padding: '0.3rem 0.45rem',
                    borderRadius: '0.4rem',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--ink)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <Bold size={14} />
                </button>

                <button
                  type="button"
                  onClick={() => insertSyntax('*', '*')}
                  title="Itálico (*texto*)"
                  style={{
                    padding: '0.3rem 0.45rem',
                    borderRadius: '0.4rem',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--ink)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <Italic size={14} />
                </button>

                <button
                  type="button"
                  onClick={() => insertSyntax('### ')}
                  title="Subtítulo (### Título)"
                  style={{
                    padding: '0.3rem 0.45rem',
                    borderRadius: '0.4rem',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--ink)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <Heading2 size={14} />
                </button>

                <div style={{ width: '1px', height: '16px', background: 'var(--line)', margin: '0 0.2rem' }} />

                {/* Botão Checklist [ ] */}
                <button
                  type="button"
                  onClick={() => {
                    const prefix = content.length > 0 && !content.endsWith('\n') ? '\n' : '';
                    insertSyntax(`${prefix}[ ] `);
                  }}
                  title="Inserir Item com Checkbox ([ ] Tarefa)"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                    padding: '0.25rem 0.55rem',
                    borderRadius: '0.4rem',
                    background: 'rgba(16, 185, 129, 0.12)',
                    border: '1px solid rgba(16, 185, 129, 0.25)',
                    color: '#10B981',
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                  }}
                >
                  <CheckSquare size={13} />
                  <span>Checklist [ ]</span>
                </button>

                {/* Botão Marcador Tópico • */}
                <button
                  type="button"
                  onClick={() => {
                    const prefix = content.length > 0 && !content.endsWith('\n') ? '\n' : '';
                    insertSyntax(`${prefix}• `);
                  }}
                  title="Inserir Tópico com Marcador (• Item)"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                    padding: '0.25rem 0.55rem',
                    borderRadius: '0.4rem',
                    background: 'rgba(128,128,128,0.1)',
                    border: '1px solid var(--line)',
                    color: 'var(--ink)',
                    fontSize: '0.72rem',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <List size={13} />
                  <span>Marcador •</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const prefix = content.length > 0 && !content.endsWith('\n') ? '\n' : '';
                    insertSyntax(`${prefix}> `);
                  }}
                  title="Citação (> Citação)"
                  style={{
                    padding: '0.3rem 0.45rem',
                    borderRadius: '0.4rem',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--ink)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <Quote size={14} />
                </button>
              </div>
            )}

            {/* Visualização de Edição (Textarea) */}
            {activeTab === 'write' ? (
              <textarea
                ref={textareaRef}
                className="note-form-input"
                rows={8}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Escreva suas ideias, detalhes ou listas de tarefas...&#10;&#10;Exemplos:&#10;[ ] Alinhar requisitos da funcionalidade&#10;[x] Enviar relatório para o time&#10;• Reunião de alinhamento na quinta-feira"
                style={{
                  width: '100%',
                  padding: '0.85rem',
                  borderTopLeftRadius: 0,
                  borderTopRightRadius: 0,
                  borderBottomLeftRadius: '0.75rem',
                  borderBottomRightRadius: '0.75rem',
                  background: 'var(--panel)',
                  border: '1px solid var(--line)',
                  color: 'var(--ink)',
                  fontSize: '0.88rem',
                  lineHeight: 1.6,
                  resize: 'vertical',
                  outline: 'none',
                  fontFamily: 'inherit',
                  boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.1)',
                }}
              />
            ) : (
              /* Visualização Prévia Formatada e Interativa */
              <div
                style={{
                  minHeight: '190px',
                  maxHeight: '260px',
                  overflowY: 'auto',
                  padding: '0.9rem',
                  borderRadius: '0.75rem',
                  background: 'var(--panel-strong)',
                  border: '1px solid var(--line)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.5rem',
                }}
              >
                {!content.trim() ? (
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      height: '100%',
                      minHeight: 120,
                      color: 'var(--ink-soft)',
                      fontSize: '0.82rem',
                    }}
                  >
                    Nenhum conteúdo para pré-visualizar ainda.
                  </div>
                ) : (
                  content.split('\n').map((line, idx) => {
                    const trimmed = line.trim();

                    // Checkbox não concluído
                    if (trimmed.startsWith('[ ]')) {
                      const text = trimmed.replace('[ ]', '').trim();
                      return (
                        <div
                          key={idx}
                          onClick={() => handleTogglePreviewCheckbox(idx)}
                          style={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0.45rem',
                            cursor: 'pointer',
                            padding: '0.15rem 0',
                          }}
                        >
                          <Square
                            size={16}
                            style={{
                              color: 'var(--ink-soft)',
                              flexShrink: 0,
                              marginTop: '0.18rem',
                            }}
                          />
                          <span style={{ fontSize: '0.86rem', color: 'var(--ink)', lineHeight: 1.4 }}>
                            {text}
                          </span>
                        </div>
                      );
                    }

                    // Checkbox concluído
                    if (/^\[[xX]\]/.test(trimmed)) {
                      const text = trimmed.replace(/^\[[xX]\]/, '').trim();
                      return (
                        <div
                          key={idx}
                          onClick={() => handleTogglePreviewCheckbox(idx)}
                          style={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0.45rem',
                            cursor: 'pointer',
                            padding: '0.15rem 0',
                          }}
                        >
                          <CheckSquare
                            size={16}
                            style={{
                              color: '#10B981',
                              flexShrink: 0,
                              marginTop: '0.18rem',
                            }}
                          />
                          <span
                            style={{
                              fontSize: '0.86rem',
                              color: 'var(--ink-soft)',
                              textDecoration: 'line-through',
                              lineHeight: 1.4,
                            }}
                          >
                            {text}
                          </span>
                        </div>
                      );
                    }

                    // Cabeçalho Markdown (###)
                    if (trimmed.startsWith('###')) {
                      return (
                        <h4
                          key={idx}
                          style={{
                            margin: '0.35rem 0 0.15rem 0',
                            fontSize: '0.98rem',
                            fontWeight: 800,
                            color: currentAccent.color,
                          }}
                        >
                          {trimmed.replace(/^###\s*/, '')}
                        </h4>
                      );
                    }

                    // Marcador de tópico (• ou -)
                    if (trimmed.startsWith('•') || trimmed.startsWith('-')) {
                      return (
                        <div
                          key={idx}
                          style={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '0.4rem',
                            padding: '0.1rem 0',
                          }}
                        >
                          <span style={{ color: currentAccent.color, fontWeight: 800 }}>•</span>
                          <span style={{ fontSize: '0.86rem', color: 'var(--ink)' }}>
                            {trimmed.replace(/^[•-]\s*/, '')}
                          </span>
                        </div>
                      );
                    }

                    // Citação (>)
                    if (trimmed.startsWith('>')) {
                      return (
                        <div
                          key={idx}
                          style={{
                            borderLeft: `3px solid ${currentAccent.color}`,
                            paddingLeft: '0.65rem',
                            color: 'var(--ink-soft)',
                            fontStyle: 'italic',
                            fontSize: '0.84rem',
                          }}
                        >
                          {trimmed.replace(/^>\s*/, '')}
                        </div>
                      );
                    }

                    // Linha normal vazia ou parágrafo
                    if (!trimmed) {
                      return <div key={idx} style={{ height: '0.4rem' }} />;
                    }

                    return (
                      <p
                        key={idx}
                        style={{
                          margin: 0,
                          fontSize: '0.86rem',
                          color: 'var(--ink)',
                          lineHeight: 1.5,
                        }}
                      >
                        {trimmed}
                      </p>
                    );
                  })
                )}
              </div>
            )}
          </div>
        </form>

        {/* 3. RODAPÉ DE AÇÕES DO MODAL */}
        <div
          style={{
            padding: '1.1rem 1.4rem',
            borderTop: '1px solid var(--line)',
            background: 'var(--panel-strong)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '0.75rem',
            flexWrap: 'wrap',
          }}
        >
          {/* Lado Esquerdo: Ações Secundárias (Arquivar / Desarquivar & Excluir) */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            {note && onArchiveToggle && (
              <button
                type="button"
                onClick={() => {
                  onArchiveToggle(note.id);
                  onClose();
                }}
                title={note.isArchived ? 'Restaurar do Arquivo' : 'Arquivar esta nota'}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  padding: '0.55rem 0.85rem',
                  borderRadius: '9999px',
                  background: note.isArchived ? 'rgba(16, 185, 129, 0.12)' : 'rgba(128,128,128,0.1)',
                  border: '1px solid var(--line)',
                  color: note.isArchived ? '#10B981' : 'var(--ink)',
                  fontSize: '0.78rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
              >
                {note.isArchived ? <ArchiveRestore size={14} /> : <Archive size={14} />}
                <span>{note.isArchived ? 'Desarquivar' : 'Arquivar'}</span>
              </button>
            )}

            {note && onDelete && (
              <button
                type="button"
                onClick={() => {
                  onDelete(note.id);
                  onClose();
                }}
                title="Excluir nota permanentemente"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  padding: '0.55rem 0.85rem',
                  borderRadius: '9999px',
                  background: 'rgba(239, 68, 68, 0.08)',
                  border: '1px solid rgba(239, 68, 68, 0.2)',
                  color: 'var(--red)',
                  fontSize: '0.78rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
              >
                <Trash2 size={14} />
                <span>Excluir</span>
              </button>
            )}
          </div>

          {/* Lado Direito: Cancelar & Salvar Nota */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <button
              type="button"
              onClick={onClose}
              style={{
                padding: '0.6rem 1.2rem',
                borderRadius: '9999px',
                background: 'transparent',
                border: '1px solid var(--line)',
                color: 'var(--ink)',
                fontSize: '0.82rem',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
            >
              Cancelar
            </button>

            <button
              type="button"
              onClick={handleSubmit}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.45rem',
                padding: '0.62rem 1.45rem',
                borderRadius: '9999px',
                background: `linear-gradient(135deg, ${currentAccent.color}, var(--active2))`,
                border: 'none',
                color: '#FFFFFF',
                fontSize: '0.84rem',
                fontWeight: 700,
                cursor: 'pointer',
                boxShadow: `0 4px 18px ${currentAccent.glow}`,
                transition: 'all 0.18s ease',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-1px)')}
              onMouseLeave={(e) => (e.currentTarget.style.transform = 'translateY(0)')}
            >
              <Save size={15} />
              <span>{note ? 'Salvar Alterações' : 'Salvar Nota'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
