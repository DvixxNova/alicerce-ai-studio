import React, { useState, useMemo } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Pin,
  Calendar,
  Sparkles,
  Clock,
  CheckSquare,
  Square,
  Edit3,
  Copy,
  Trash2,
  List,
  Tag,
  Check,
} from 'lucide-react';
import { Note } from '../types';
import { getTagPill, formatNoteDate } from './NotesView';

interface NotesCalendarViewProps {
  notes: Note[];
  onOpenNote: (note: Note) => void;
  onCreateNoteAtDate: (dateIso: string) => void;
  onTogglePin: (id: string, e?: React.MouseEvent) => void;
  onDeleteNote: (id: string, e?: React.MouseEvent) => void;
  onCopyNote: (note: Note, e?: React.MouseEvent) => void;
  onToggleChecklistLine?: (noteId: string, lineIndex: number, e?: React.MouseEvent) => void;
  onBackToList: () => void;
}

const MONTH_NAMES_PT = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
];

const WEEKDAY_NAMES_PT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const CATEGORY_COLORS: Record<string, string> = {
  trabalho: '#3B82F6',
  pessoal: '#8B5CF6',
  ideias: '#F59E0B',
  metas: '#10B981',
  finanças: '#EC4899',
  financas: '#EC4899',
  oração: '#F43F5E',
  oracao: '#F43F5E',
  planejamento: '#EAB308',
  produto: '#14B8A6',
  design: '#06B6D4',
  reunião: '#F97316',
  reuniao: '#F97316',
};

export function getNoteIsoDate(note: Note): string {
  if (note.date && /^\d{4}-\d{2}-\d{2}/.test(note.date)) {
    return note.date.slice(0, 10);
  }
  if (note.reminder && /^\d{4}-\d{2}-\d{2}/.test(note.reminder)) {
    return note.reminder.slice(0, 10);
  }
  if (note.updatedAt && /^\d{4}-\d{2}-\d{2}/.test(note.updatedAt)) {
    return note.updatedAt.slice(0, 10);
  }
  return new Date().toISOString().slice(0, 10);
}

export const NotesCalendarView: React.FC<NotesCalendarViewProps> = ({
  notes,
  onOpenNote,
  onCreateNoteAtDate,
  onTogglePin,
  onDeleteNote,
  onCopyNote,
  onToggleChecklistLine,
  onBackToList,
}) => {
  const today = useMemo(() => new Date(), []);
  const todayIso = useMemo(() => today.toISOString().slice(0, 10), [today]);

  // Current viewed month and year
  const [currentYear, setCurrentYear] = useState<number>(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState<number>(today.getMonth()); // 0-11

  // Selected date ISO (default to today)
  const [selectedDateIso, setSelectedDateIso] = useState<string>(todayIso);

  // Category filter on calendar
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');

  // Copy feedback state
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Handle month navigation
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  const handleGoToToday = () => {
    setCurrentYear(today.getFullYear());
    setCurrentMonth(today.getMonth());
    setSelectedDateIso(todayIso);
  };

  // Group notes by ISO date
  const notesByDate = useMemo(() => {
    const map = new Map<string, Note[]>();
    notes
      .filter((n) => !n.isArchived)
      .forEach((note) => {
        if (
          selectedCategory !== 'Todas' &&
          (note.category || '').toLowerCase() !== selectedCategory.toLowerCase()
        ) {
          return;
        }
        const dateIso = getNoteIsoDate(note);
        if (!map.has(dateIso)) {
          map.set(dateIso, []);
        }
        map.get(dateIso)!.push(note);
      });
    return map;
  }, [notes, selectedCategory]);

  // Calendar cells for current viewed month
  const calendarDays = useMemo(() => {
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);

    const daysInMonth = lastDayOfMonth.getDate();
    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 is Sunday

    const prevMonthLastDay = new Date(currentYear, currentMonth, 0).getDate();

    const days: Array<{
      dateIso: string;
      dayNumber: number;
      isCurrentMonth: boolean;
      isToday: boolean;
      isSelected: boolean;
      notes: Note[];
    }> = [];

    // Previous month padding days
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      const d = prevMonthLastDay - i;
      const prevDate = new Date(currentYear, currentMonth - 1, d);
      const iso = prevDate.toISOString().slice(0, 10);
      days.push({
        dateIso: iso,
        dayNumber: d,
        isCurrentMonth: false,
        isToday: iso === todayIso,
        isSelected: iso === selectedDateIso,
        notes: notesByDate.get(iso) || [],
      });
    }

    // Current month days
    for (let d = 1; d <= daysInMonth; d++) {
      const currentDate = new Date(currentYear, currentMonth, d);
      const iso = currentDate.toISOString().slice(0, 10);
      days.push({
        dateIso: iso,
        dayNumber: d,
        isCurrentMonth: true,
        isToday: iso === todayIso,
        isSelected: iso === selectedDateIso,
        notes: notesByDate.get(iso) || [],
      });
    }

    // Next month padding days to complete 35 or 42 grid cells
    const remaining = (7 - (days.length % 7)) % 7;
    for (let d = 1; d <= remaining; d++) {
      const nextDate = new Date(currentYear, currentMonth + 1, d);
      const iso = nextDate.toISOString().slice(0, 10);
      days.push({
        dateIso: iso,
        dayNumber: d,
        isCurrentMonth: false,
        isToday: iso === todayIso,
        isSelected: iso === selectedDateIso,
        notes: notesByDate.get(iso) || [],
      });
    }

    return days;
  }, [currentYear, currentMonth, todayIso, selectedDateIso, notesByDate]);

  // Notes on the currently selected date
  const selectedDateNotes = useMemo(() => {
    return notesByDate.get(selectedDateIso) || [];
  }, [notesByDate, selectedDateIso]);

  // Total notes count in this month
  const totalNotesInMonth = useMemo(() => {
    const prefix = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}`;
    let count = 0;
    notesByDate.forEach((list, dateKey) => {
      if (dateKey.startsWith(prefix)) {
        count += list.length;
      }
    });
    return count;
  }, [notesByDate, currentYear, currentMonth]);

  // Format selected date into nice Portuguese text
  const formattedSelectedDate = useMemo(() => {
    try {
      const [y, m, d] = selectedDateIso.split('-').map(Number);
      const dateObj = new Date(y, m - 1, d);
      const dayOfWeek = WEEKDAY_NAMES_PT[dateObj.getDay()];
      const monthName = MONTH_NAMES_PT[dateObj.getMonth()];
      return `${dayOfWeek}, ${d} de ${monthName} de ${y}`;
    } catch {
      return selectedDateIso;
    }
  }, [selectedDateIso]);

  const handleCopy = (note: Note, e?: React.MouseEvent) => {
    e?.stopPropagation();
    onCopyNote(note, e);
    setCopiedId(note.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full flex flex-col gap-5">
      {/* 1. Header do Calendário com Navegação */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#E5E0D5] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 text-teal-700 flex items-center justify-center shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-[#0F172A] tracking-tight">
                  {MONTH_NAMES_PT[currentMonth]} {currentYear}
                </h2>
                <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-teal-100/80 text-teal-800">
                  {totalNotesInMonth} {totalNotesInMonth === 1 ? 'nota' : 'notas'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Clique em qualquer dia para ver e criar anotações nessa data
              </p>
            </div>
          </div>

          {/* Controles de Navegação */}
          <div className="flex items-center gap-1.5 self-start sm:self-auto">
            <button
              type="button"
              onClick={handleGoToToday}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              Hoje
            </button>
            <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200">
              <button
                type="button"
                onClick={handlePrevMonth}
                title="Mês anterior"
                className="p-1.5 rounded-md hover:bg-white text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleNextMonth}
                title="Próximo mês"
                className="p-1.5 rounded-md hover:bg-white text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Filtros de Categoria */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 mb-4 border-b border-slate-100">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1 flex items-center gap-1">
            <Tag className="w-3 h-3" /> Filtro:
          </span>
          {['Todas', 'Trabalho', 'Pessoal', 'Ideias', 'Metas', 'Finanças', 'Oração'].map((cat) => {
            const isSelected = selectedCategory.toLowerCase() === cat.toLowerCase();
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`text-xs px-2.5 py-1 rounded-full font-medium transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-teal-700 text-white font-semibold shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* 2. Grid Semanal e Dias do Mês */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-2">
          {WEEKDAY_NAMES_PT.map((dayName, idx) => (
            <div
              key={dayName}
              className={`text-center py-1 text-xs font-bold uppercase tracking-wider ${
                idx === 0 || idx === 6 ? 'text-amber-700/80' : 'text-slate-400'
              }`}
            >
              {dayName}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {calendarDays.map((cell) => {
            const noteCount = cell.notes.length;
            const isSelected = cell.isSelected;
            const isToday = cell.isToday;

            return (
              <button
                key={cell.dateIso}
                type="button"
                onClick={() => setSelectedDateIso(cell.dateIso)}
                className={`relative min-h-[64px] sm:min-h-[78px] p-1.5 sm:p-2 rounded-xl text-left transition-all cursor-pointer flex flex-col justify-between border ${
                  isSelected
                    ? 'bg-teal-50 border-teal-500 shadow-sm ring-2 ring-teal-500/20'
                    : cell.isCurrentMonth
                    ? 'bg-white hover:bg-slate-50/80 border-slate-200'
                    : 'bg-slate-50/50 hover:bg-slate-100/50 border-slate-100 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span
                    className={`inline-flex items-center justify-center w-6 h-6 text-xs font-bold rounded-full ${
                      isToday
                        ? 'bg-teal-600 text-white shadow-xs'
                        : isSelected
                        ? 'text-teal-900 font-extrabold'
                        : cell.isCurrentMonth
                        ? 'text-slate-700'
                        : 'text-slate-400'
                    }`}
                  >
                    {cell.dayNumber}
                  </span>

                  {noteCount > 0 && (
                    <span
                      className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded-full ${
                        isSelected
                          ? 'bg-teal-600 text-white'
                          : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}
                    >
                      {noteCount}
                    </span>
                  )}
                </div>

                {/* Prévia das Notas / Indicadores visuais de categoria */}
                <div className="w-full mt-1 flex flex-col gap-0.5 overflow-hidden">
                  {cell.notes.slice(0, 2).map((n) => {
                    const cat = (n.category || 'geral').toLowerCase();
                    const dotColor = CATEGORY_COLORS[cat] || '#00897B';

                    return (
                      <div
                        key={n.id}
                        className="truncate text-[10px] px-1 py-0.5 rounded bg-slate-100/90 text-slate-700 flex items-center gap-1 leading-tight"
                        title={n.title}
                      >
                        <span
                          className="w-1.5 h-1.5 rounded-full shrink-0"
                          style={{ backgroundColor: dotColor }}
                        />
                        <span className="truncate">{n.title || 'Sem título'}</span>
                      </div>
                    );
                  })}
                  {noteCount > 2 && (
                    <span className="text-[9px] text-slate-400 font-medium pl-1">
                      +{noteCount - 2} mais
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Painel do Dia Selecionado */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-[#E5E0D5] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 mb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-teal-700 mb-0.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span>Data Selecionada</span>
              {selectedDateIso === todayIso && (
                <span className="bg-teal-100 text-teal-800 text-[10px] px-2 py-0.2 rounded-full font-bold">
                  Hoje
                </span>
              )}
            </div>
            <h3 className="text-lg sm:text-xl font-extrabold text-[#0F172A] capitalize">
              {formattedSelectedDate}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {selectedDateNotes.length}{' '}
              {selectedDateNotes.length === 1 ? 'anotação encontrada' : 'anotações encontradas'}{' '}
              neste dia
            </p>
          </div>

          <button
            type="button"
            onClick={() => onCreateNoteAtDate(selectedDateIso)}
            className="inline-flex items-center justify-center gap-1.5 bg-[#00897B] hover:bg-[#00796B] text-white font-medium px-4 py-2 rounded-xl text-sm transition-all shadow-xs cursor-pointer active:scale-95 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Nova nota nesta data</span>
          </button>
        </div>

        {/* Lista de Notas do Dia Selecionado */}
        {selectedDateNotes.length > 0 ? (
          <div className="flex flex-col gap-3">
            {selectedDateNotes.map((note) => {
              const lines = (note.content || '').split('\n');
              const hasChecklist = lines.some((l) => /\[[ xX]\]/.test(l));
              const tagPillClass = getTagPill(note.category || 'planejamento');
              const formattedDate = formatNoteDate(note.updatedAt || note.date || '');
              const isCopied = copiedId === note.id;

              return (
                <article
                  key={note.id}
                  onClick={() => onOpenNote(note)}
                  className="bg-[#FBF9F4] rounded-xl p-4 border border-[#E8E2D6] hover:border-teal-500/40 transition-all cursor-pointer group relative"
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2">
                      {note.isPinned && (
                        <Pin className="w-3.5 h-3.5 fill-teal-600 text-teal-600 shrink-0" />
                      )}
                      <h4 className="font-bold text-[#0F172A] text-sm sm:text-base group-hover:text-teal-900 transition-colors">
                        {note.title || 'Sem título'}
                      </h4>
                    </div>

                    {/* Ações Rápidas */}
                    <div
                      className="flex items-center gap-1 shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={(e) => onTogglePin(note.id, e)}
                        title={note.isPinned ? 'Desafixar nota' : 'Fixar nota'}
                        className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                          note.isPinned
                            ? 'text-teal-600 hover:text-teal-700'
                            : 'text-slate-400 hover:text-slate-600'
                        }`}
                      >
                        <Pin
                          className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-teal-600' : ''}`}
                        />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleCopy(note, e)}
                        title="Copiar conteúdo"
                        className="p-1.5 rounded-md text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                      >
                        {isCopied ? (
                          <Check className="w-3.5 h-3.5 text-teal-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => onOpenNote(note)}
                        title="Editar anotação"
                        className="p-1.5 rounded-md text-slate-400 hover:text-teal-700 transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => onDeleteNote(note.id, e)}
                        title="Excluir nota"
                        className="p-1.5 rounded-md text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Conteúdo da Nota */}
                  <div className="text-[#475569] text-xs sm:text-sm leading-relaxed mb-3">
                    {hasChecklist ? (
                      <div className="flex flex-col gap-1 py-0.5">
                        {lines.map((line, idx) => {
                          const isCheck = /\[[ xX]\]/.test(line);
                          if (!isCheck) return <p key={idx} className="m-0">{line}</p>;
                          const isDone = /\[[xX]\]/.test(line);
                          const text = line.replace(/\[[ xX]\]/, '').trim();
                          return (
                            <div
                              key={idx}
                              onClick={(e) => {
                                if (onToggleChecklistLine) {
                                  onToggleChecklistLine(note.id, idx, e);
                                }
                              }}
                              className="flex items-start gap-1.5 hover:text-slate-900 transition-colors cursor-pointer"
                            >
                              <span className="mt-0.5 shrink-0 text-slate-400 hover:text-teal-600">
                                {isDone ? (
                                  <CheckSquare className="w-3.5 h-3.5 text-teal-600" />
                                ) : (
                                  <Square className="w-3.5 h-3.5" />
                                )}
                              </span>
                              <span
                                className={isDone ? 'line-through text-slate-400' : 'text-slate-700'}
                              >
                                {text}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="m-0 whitespace-pre-wrap line-clamp-3">{note.content}</p>
                    )}
                  </div>

                  {/* Rodapé do Card */}
                  <div className="flex items-center text-xs text-[#64748B] pt-2 border-t border-slate-200/60">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{formattedDate}</span>
                    </span>
                    <span className="mx-2">•</span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium capitalize ${tagPillClass}`}
                    >
                      {note.category || 'geral'}
                    </span>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="py-10 text-center flex flex-col items-center justify-center gap-3 bg-slate-50/70 rounded-xl border border-dashed border-slate-200">
            <div className="w-12 h-12 rounded-full bg-teal-50 border border-teal-200 text-teal-600 flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-700">
                Nenhuma anotação nesta data
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                Que tal registrar uma nova ideia, tarefa ou compromisso para {formattedSelectedDate}?
              </p>
            </div>
            <button
              type="button"
              onClick={() => onCreateNoteAtDate(selectedDateIso)}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-700 hover:text-teal-800 bg-teal-50 hover:bg-teal-100 px-3.5 py-2 rounded-lg transition-colors cursor-pointer border border-teal-200"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Criar anotação agora</span>
            </button>
          </div>
        )}
      </div>

      {/* 4. Botão Voltar para Lista */}
      <div className="flex justify-center pt-1">
        <button
          type="button"
          onClick={onBackToList}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200 shadow-xs transition-all cursor-pointer"
        >
          <List className="w-4 h-4 text-teal-700" />
          <span>Voltar para Lista de Notas</span>
        </button>
      </div>
    </div>
  );
};
