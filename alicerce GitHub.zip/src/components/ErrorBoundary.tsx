import React, { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public override state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  private handleReset = () => {
    try {
      this.setState({ hasError: false, error: null });
      window.location.reload();
    } catch {
      window.location.href = '/';
    }
  };

  private handleClearAndReset = () => {
    try {
      localStorage.clear();
      window.location.reload();
    } catch {
      window.location.href = '/';
    }
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full flex items-center justify-center p-4 bg-[#0A0E27] text-white">
          <div className="max-w-md w-full bg-[#111836] border border-red-500/30 rounded-2xl p-6 shadow-2xl text-center flex flex-col items-center">
            <div className="w-14 h-14 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-4 text-red-400">
              <AlertTriangle size={28} />
            </div>
            
            <h2 className="text-xl font-bold text-white mb-2">Ops! Ocorreu um erro temporário</h2>
            <p className="text-sm text-slate-400 mb-6 leading-relaxed">
              O aplicativo encontrou uma falha na renderização. Você pode tentar recarregar ou restaurar as configurações padrão.
            </p>

            {this.state.error?.message && (
              <div className="w-full bg-[#070A1E] border border-slate-800 rounded-lg p-3 text-xs text-red-300 font-mono mb-6 text-left break-all max-h-28 overflow-y-auto">
                {this.state.error.message}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 w-full">
              <button
                type="button"
                onClick={this.handleReset}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-teal-600 hover:bg-teal-500 text-white rounded-xl font-semibold text-sm transition-all cursor-pointer"
              >
                <RotateCcw size={16} />
                <span>Recarregar Página</span>
              </button>
              
              <button
                type="button"
                onClick={this.handleClearAndReset}
                className="flex-1 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-semibold text-sm transition-all cursor-pointer"
              >
                Limpar Cache e Abrir
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
