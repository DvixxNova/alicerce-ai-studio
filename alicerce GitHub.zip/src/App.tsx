import React, { useState, useEffect } from 'react';
import {
  DEFAULT_INVESTMENTS,
  DEFAULT_NOTES,
  DEFAULT_PRODUCTIVE_TASKS,
  DEFAULT_TRANSACTIONS,
  NAV_TABS,
  getDefaultWorkouts,
  getGreeting,
} from './utils/constants';
import {
  Investment,
  Note,
  ProductiveTask,
  TabId,
  ThemeMode,
  Transaction,
  UserProfile,
  WeatherState,
  Workout,
} from './types';
import { BellIcon, SettingsGearIcon } from './components/Icons';
import { LogIn, Smartphone, Mic, Radio, Cloud } from 'lucide-react';
import { InicioView } from './components/InicioView';
import { FinancasView } from './components/FinancasView';
import { TreinoView } from './components/TreinoView';
import { NotesView } from './components/NotesView';
import { DicasView } from './components/DicasView';
import { AiGroundingView } from './components/AiGroundingView';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { SettingsModal } from './components/SettingsModal';
import { LoginModal } from './components/LoginModal';
import { IPhoneDownloadModal } from './components/IPhoneDownloadModal';
import {
  auth,
  testFirestoreConnection,
  loadUserDataFromFirestore,
  saveUserDataToFirestore,
} from './firebase';
import { onAuthStateChanged } from 'firebase/auth';

const STORAGE_KEY = 'alicerce_data';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabId>('inicio');
  const [name, setName] = useState<string>('');
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: '',
    email: '',
    mainGoal: 'Hipertrofia & Rendimento Físico',
    avatarUrl: '',
  });
  const [theme, setTheme] = useState<ThemeMode>('dark');
  const [systemTheme, setSystemTheme] = useState<'light' | 'dark'>('dark');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isIPhoneOpen, setIsIPhoneOpen] = useState(false);
  const [isVoiceAssistantOpen, setIsVoiceAssistantOpen] = useState(false);
  const [isFirestoreSyncing, setIsFirestoreSyncing] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [workouts, setWorkouts] = useState<Workout[]>(() => getDefaultWorkouts());
  const [notes, setNotes] = useState<Note[]>(() => DEFAULT_NOTES);
  const [weather, setWeather] = useState<WeatherState>({
    city: '',
    data: null,
    loading: false,
    error: null,
    recent: [],
  });
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [productiveTasks, setProductiveTasks] = useState<ProductiveTask[]>(
    DEFAULT_PRODUCTIVE_TASKS
  );
  const [isLoaded, setIsLoaded] = useState(false);

  // System theme detection
  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: light)');
      setSystemTheme(mediaQuery.matches ? 'light' : 'dark');
      const handler = (e: MediaQueryListEvent) => {
        setSystemTheme(e.matches ? 'light' : 'dark');
      };
      mediaQuery.addEventListener('change', handler);
      return () => mediaQuery.removeEventListener('change', handler);
    }
  }, []);

  const effectiveTheme:
    | 'light'
    | 'dark'
    | 'cyberpunk'
    | 'cosmic'
    | 'ocean'
    | 'luxury' = theme === 'system' ? systemTheme : theme;

  // Apply effective theme to document
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', effectiveTheme);
      let bg = '#0A0E27';
      let color = '#F3F5FF';

      if (effectiveTheme === 'light') {
        bg = '#F8FAFC';
        color = '#0F172A';
      } else if (effectiveTheme === 'luxury') {
        bg = '#FAF8F5';
        color = '#1C1917';
      } else if (effectiveTheme === 'cyberpunk') {
        bg = '#050505';
        color = '#F0FFF4';
      } else if (effectiveTheme === 'cosmic') {
        bg = '#090414';
        color = '#FAF5FF';
      } else if (effectiveTheme === 'ocean') {
        bg = '#040D1A';
        color = '#ECFEFF';
      }

      document.body.style.backgroundColor = bg;
      document.body.style.color = color;
    }
  }, [effectiveTheme]);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.transactions) && parsed.transactions.length > 0) {
          setTransactions(parsed.transactions);
        } else {
          setTransactions(DEFAULT_TRANSACTIONS);
        }
        if (Array.isArray(parsed.workouts) && parsed.workouts.length > 0) {
          setWorkouts(parsed.workouts);
        } else {
          setWorkouts(getDefaultWorkouts());
        }
        if (Array.isArray(parsed.notes) && parsed.notes.length > 0) {
          const hasImageNotes = parsed.notes.some((n: any) => n.id?.startsWith('note-cn-'));
          if (hasImageNotes) {
            setNotes(parsed.notes);
          } else {
            setNotes(DEFAULT_NOTES);
          }
        } else {
          setNotes(DEFAULT_NOTES);
        }
        if (parsed.weather) setWeather(parsed.weather);
        if (Array.isArray(parsed.investments) && parsed.investments.length > 0) {
          const hasRealData = parsed.investments.some(
            (i: any) => i.institution || i.id === 'inv-nubank'
          );
          if (hasRealData) {
            setInvestments(parsed.investments);
          } else {
            setInvestments(DEFAULT_INVESTMENTS);
          }
        } else {
          setInvestments(DEFAULT_INVESTMENTS);
        }
        if (Array.isArray(parsed.productiveTasks)) {
          setProductiveTasks(parsed.productiveTasks);
        }
        if (typeof parsed.name === 'string') setName(parsed.name);
        if (parsed.userProfile) {
          setUserProfile(parsed.userProfile);
          if (parsed.userProfile.name) setName(parsed.userProfile.name);
        } else if (parsed.name) {
          setUserProfile((prev) => ({ ...prev, name: parsed.name }));
        }
        if (parsed.theme) setTheme(parsed.theme);
      } else {
        setTransactions(DEFAULT_TRANSACTIONS);
        setInvestments(DEFAULT_INVESTMENTS);
      }
    } catch {
      // Ignore parse error
    }
    setIsLoaded(true);
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({
            transactions,
            workouts,
            notes,
            weather,
            name: userProfile.name || name,
            userProfile,
            theme,
            investments,
            productiveTasks,
          })
        );
      } catch {
        // Storage might be full or blocked
      }
    }
  }, [
    isLoaded,
    transactions,
    workouts,
    notes,
    weather,
    name,
    userProfile,
    theme,
    investments,
    productiveTasks,
  ]);

  // Test Firestore connection on boot
  useEffect(() => {
    testFirestoreConnection();
  }, []);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const cleanName = user.displayName || user.email?.split('@')[0] || 'Usuário';
        setUserProfile((prev) => ({
          ...prev,
          name: prev.name || cleanName,
          email: user.email || '',
          avatarUrl: user.photoURL || prev.avatarUrl || '',
          isLoggedIn: true,
          customStatus: 'Sincronizado via Google & Firestore',
        }));
        if (!name) setName(cleanName);

        // Fetch user data from Firestore
        try {
          setIsFirestoreSyncing(true);
          const cloudData = await loadUserDataFromFirestore(user.uid);
          if (cloudData) {
            if (cloudData.transactions && cloudData.transactions.length > 0) {
              setTransactions(cloudData.transactions);
            }
            if (cloudData.investments && cloudData.investments.length > 0) {
              setInvestments(cloudData.investments);
            }
            if (cloudData.workouts && cloudData.workouts.length > 0) {
              setWorkouts(cloudData.workouts);
            }
            if (cloudData.notes && cloudData.notes.length > 0) {
              setNotes(cloudData.notes);
            }
            if (cloudData.productiveTasks && cloudData.productiveTasks.length > 0) {
              setProductiveTasks(cloudData.productiveTasks);
            }
            if (cloudData.userProfile) {
              setUserProfile(cloudData.userProfile);
              if (cloudData.userProfile.name) setName(cloudData.userProfile.name);
            }
            if (cloudData.theme) {
              setTheme(cloudData.theme as ThemeMode);
            }
          }
        } catch (err) {
          console.warn('Could not load from Firestore:', err);
        } finally {
          setIsFirestoreSyncing(false);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Automatically sync state to Firestore when user is logged in
  useEffect(() => {
    if (!isLoaded || !auth.currentUser) return;

    const timer = setTimeout(async () => {
      try {
        setIsFirestoreSyncing(true);
        await saveUserDataToFirestore(auth.currentUser!.uid, {
          userProfile,
          theme,
          transactions,
          investments,
          workouts,
          notes,
          productiveTasks,
        });
      } catch (err) {
        console.warn('Auto-save to Firestore notice:', err);
      } finally {
        setIsFirestoreSyncing(false);
      }
    }, 1500);

    return () => clearTimeout(timer);
  }, [
    isLoaded,
    userProfile,
    theme,
    transactions,
    investments,
    workouts,
    notes,
    productiveTasks,
  ]);

  const handleSaveProfile = (updatedProfile: UserProfile) => {
    setUserProfile(updatedProfile);
    setName(updatedProfile.name);
  };

  const handleLoginSuccess = (profile: UserProfile) => {
    setUserProfile(profile);
    setName(profile.name);
  };

  const handleLogout = () => {
    setUserProfile({
      name: '',
      email: '',
      mainGoal: 'Hipertrofia & Rendimento Físico',
      avatarUrl: '',
      avatarEmoji: '',
      customStatus: '',
      isLoggedIn: false,
    });
    setName('');
  };

  const handleUpdateName = (newName: string) => {
    setName(newName);
    setUserProfile((prev) => ({ ...prev, name: newName }));
  };

  const activeTabConfig =
    NAV_TABS.find((t) => t.id === currentTab) || NAV_TABS[0];
  const displayName = userProfile.name || name;

  return (
    <div
      className={`alicerce-app theme-${effectiveTheme}`}
      style={
        {
          '--active': activeTabConfig.c1,
          '--active2': activeTabConfig.c2,
          '--active-glow': activeTabConfig.glow,
        } as React.CSSProperties
      }
    >
      <style>{`
        .alicerce-app {
          --font-display: 'Space Grotesk', sans-serif;
          --font-body: 'Inter', sans-serif;
          --font-mono: 'Space Grotesk', sans-serif;
          --green: #22C55E;
          --red: #F43F5E;
          font-family: var(--font-body);
          width: 100%;
          max-width: 460px;
          margin: 0 auto;
          padding: 1rem 0.85rem 6.2rem;
          min-height: 100vh;
          box-sizing: border-box;
          position: relative;
          overflow: hidden;
          transition: background-color 0.25s ease, color 0.25s ease;
        }
        .alicerce-app * { box-sizing: border-box; }

        /* Dark Theme Variables */
        .alicerce-app.theme-dark {
          --bg: #0A0E27;
          --panel: rgba(255,255,255,0.055);
          --panel-strong: rgba(255,255,255,0.09);
          --ink: #F3F5FF;
          --ink-soft: #99A2C7;
          --line: rgba(255,255,255,0.14);
          --input-bg: rgba(255,255,255,0.07);
          --option-bg: #12173A;
          --nav-bg: rgba(14, 18, 48, 0.9);
          --card-shadow: 0 14px 40px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.06);
          --settings-panel-bg: #0F1433;
          --settings-card-bg: rgba(255, 255, 255, 0.045);
          --settings-border: rgba(255, 255, 255, 0.12);
          --settings-border-hover: rgba(255, 255, 255, 0.25);
          --settings-input-bg: rgba(255, 255, 255, 0.07);
          --settings-header-bg: rgba(15, 20, 51, 0.95);
          --settings-label-color: #CBD5E1;
          --settings-active-card: rgba(99, 102, 241, 0.14);
          --settings-glow: rgba(99, 102, 241, 0.22);
          --settings-focus-glow: rgba(99, 102, 241, 0.25);
          background:
            radial-gradient(620px circle at 12% -6%, rgba(139,92,246,0.45), transparent 60%),
            radial-gradient(620px circle at 92% 8%, rgba(59,130,246,0.4), transparent 58%),
            radial-gradient(520px circle at 50% 105%, rgba(236,72,153,0.25), transparent 62%),
            var(--bg);
          color: var(--ink);
        }

        /* Light Theme Variables */
        .alicerce-app.theme-light {
          --bg: #F8FAFC;
          --panel: rgba(255, 255, 255, 0.88);
          --panel-strong: #FFFFFF;
          --ink: #0F172A;
          --ink-soft: #475569;
          --green: #15803D;
          --green-invest: #16A34A;
          --red: #E11D48;
          --line: #E2E8F0;
          --input-bg: #FFFFFF;
          --option-bg: #FFFFFF;
          --nav-bg: rgba(255, 255, 255, 0.94);
          --card-shadow: 0 4px 20px rgba(15, 23, 42, 0.05), 0 1px 3px rgba(15, 23, 42, 0.04);
          --settings-panel-bg: #FFFFFF;
          --settings-card-bg: #F8FAFC;
          --settings-border: #E2E8F0;
          --settings-border-hover: #CBD5E1;
          --settings-input-bg: #FFFFFF;
          --settings-header-bg: rgba(255, 255, 255, 0.96);
          --settings-label-color: #334155;
          --settings-active-card: rgba(99, 102, 241, 0.08);
          --settings-glow: rgba(99, 102, 241, 0.15);
          --settings-focus-glow: rgba(99, 102, 241, 0.2);
          background:
            radial-gradient(620px circle at 12% -6%, rgba(199,210,254,0.55), transparent 60%),
            radial-gradient(620px circle at 92% 8%, rgba(186,230,253,0.5), transparent 58%),
            radial-gradient(520px circle at 50% 105%, rgba(251,207,232,0.35), transparent 62%),
            var(--bg);
          color: var(--ink);
        }

        /* ⚡ Cyberpunk Theme (Verde Neon & Preto) */
        .alicerce-app.theme-cyberpunk {
          --bg: #050505;
          --panel: rgba(10, 15, 12, 0.92);
          --panel-strong: #0A0F0C;
          --ink: #FFFFFF;
          --ink-soft: #00FF66;
          --green: #00FF66;
          --green-invest: #00FF66;
          --red: #FF3366;
          --line: rgba(0, 255, 102, 0.35);
          --input-bg: #0D1510;
          --option-bg: #080E0B;
          --nav-bg: rgba(6, 11, 8, 0.95);
          --card-shadow: 0 10px 30px rgba(0, 0, 0, 0.88), 0 0 16px rgba(0, 255, 102, 0.22), inset 0 1px 0 rgba(0, 255, 102, 0.2);
          --settings-panel-bg: #070D0A;
          --settings-card-bg: rgba(0, 255, 102, 0.04);
          --settings-border: rgba(0, 255, 102, 0.22);
          --settings-border-hover: rgba(0, 255, 102, 0.5);
          --settings-input-bg: #0D1510;
          --settings-header-bg: rgba(7, 13, 10, 0.97);
          --settings-label-color: #86EFAC;
          --settings-active-card: rgba(0, 255, 102, 0.14);
          --settings-glow: rgba(0, 255, 102, 0.35);
          --settings-focus-glow: rgba(0, 255, 102, 0.4);
          background:
            radial-gradient(620px circle at 12% -6%, rgba(0, 255, 102, 0.18), transparent 60%),
            radial-gradient(620px circle at 92% 8%, rgba(16, 185, 129, 0.16), transparent 58%),
            radial-gradient(520px circle at 50% 105%, rgba(0, 255, 102, 0.12), transparent 62%),
            var(--bg);
          color: var(--ink);
        }

        /* 🌌 Cosmic Violet Theme (Roxo Cósmico) */
        .alicerce-app.theme-cosmic {
          --bg: #090414;
          --panel: rgba(168, 85, 247, 0.05);
          --panel-strong: #150A28;
          --ink: #FAF5FF;
          --ink-soft: #D8B4FE;
          --green: #34D399;
          --green-invest: #34D399;
          --red: #F43F5E;
          --line: rgba(168, 85, 247, 0.26);
          --input-bg: #1C0E36;
          --option-bg: #120724;
          --nav-bg: rgba(12, 5, 25, 0.95);
          --card-shadow: 0 14px 40px rgba(0, 0, 0, 0.75), 0 0 18px rgba(168, 85, 247, 0.16), inset 0 1px 0 rgba(168, 85, 247, 0.22);
          --settings-panel-bg: #110724;
          --settings-card-bg: rgba(168, 85, 247, 0.055);
          --settings-border: rgba(168, 85, 247, 0.24);
          --settings-border-hover: rgba(168, 85, 247, 0.55);
          --settings-input-bg: #1C0E36;
          --settings-header-bg: rgba(17, 7, 36, 0.97);
          --settings-label-color: #E9D5FF;
          --settings-active-card: rgba(168, 85, 247, 0.16);
          --settings-glow: rgba(168, 85, 247, 0.35);
          --settings-focus-glow: rgba(168, 85, 247, 0.4);
          background:
            radial-gradient(620px circle at 12% -6%, rgba(168, 85, 247, 0.38), transparent 60%),
            radial-gradient(620px circle at 92% 8%, rgba(236, 72, 153, 0.28), transparent 58%),
            radial-gradient(520px circle at 50% 105%, rgba(147, 51, 234, 0.25), transparent 62%),
            var(--bg);
          color: var(--ink);
        }

        /* 🌊 Ocean Deep Theme (Azul Oceano) */
        .alicerce-app.theme-ocean {
          --bg: #040D1A;
          --panel: rgba(6, 182, 212, 0.05);
          --panel-strong: #0A1C33;
          --ink: #ECFEFF;
          --ink-soft: #A5F3FC;
          --green: #2DD4BF;
          --green-invest: #2DD4BF;
          --red: #FB7185;
          --line: rgba(6, 182, 212, 0.24);
          --input-bg: #0D2442;
          --option-bg: #061426;
          --nav-bg: rgba(4, 14, 28, 0.95);
          --card-shadow: 0 14px 40px rgba(0, 0, 0, 0.75), 0 0 16px rgba(6, 182, 212, 0.16), inset 0 1px 0 rgba(6, 182, 212, 0.2);
          --settings-panel-bg: #07172C;
          --settings-card-bg: rgba(6, 182, 212, 0.05);
          --settings-border: rgba(6, 182, 212, 0.24);
          --settings-border-hover: rgba(6, 182, 212, 0.5);
          --settings-input-bg: #0D2442;
          --settings-header-bg: rgba(7, 23, 44, 0.97);
          --settings-label-color: #BAE6FD;
          --settings-active-card: rgba(6, 182, 212, 0.16);
          --settings-glow: rgba(6, 182, 212, 0.35);
          --settings-focus-glow: rgba(6, 182, 212, 0.4);
          background:
            radial-gradient(620px circle at 12% -6%, rgba(6, 182, 212, 0.34), transparent 60%),
            radial-gradient(620px circle at 92% 8%, rgba(59, 130, 246, 0.3), transparent 58%),
            radial-gradient(520px circle at 50% 105%, rgba(14, 165, 233, 0.22), transparent 62%),
            var(--bg);
          color: var(--ink);
        }

        /* 👑 Luxury Light Theme (Ouro & Marfim) */
        .alicerce-app.theme-luxury {
          --bg: #FAF8F5;
          --panel: rgba(255, 255, 255, 0.94);
          --panel-strong: #FFFFFF;
          --ink: #1C1917;
          --ink-soft: #78716C;
          --green: #15803D;
          --green-invest: #16A34A;
          --red: #BE123C;
          --line: rgba(180, 83, 9, 0.18);
          --input-bg: #FFFFFF;
          --option-bg: #FFFFFF;
          --nav-bg: rgba(250, 248, 245, 0.96);
          --card-shadow: 0 10px 30px rgba(120, 53, 15, 0.08), 0 1px 3px rgba(120, 53, 15, 0.05);
          --settings-panel-bg: #FFFFFF;
          --settings-card-bg: #FDFBF7;
          --settings-border: rgba(180, 83, 9, 0.18);
          --settings-border-hover: rgba(180, 83, 9, 0.38);
          --settings-input-bg: #FFFFFF;
          --settings-header-bg: rgba(255, 255, 255, 0.97);
          --settings-label-color: #78350F;
          --settings-active-card: rgba(217, 119, 6, 0.12);
          --settings-glow: rgba(217, 119, 6, 0.24);
          --settings-focus-glow: rgba(217, 119, 6, 0.3);
          background:
            radial-gradient(620px circle at 12% -6%, rgba(254, 243, 199, 0.72), transparent 60%),
            radial-gradient(620px circle at 92% 8%, rgba(253, 230, 138, 0.52), transparent 58%),
            radial-gradient(520px circle at 50% 105%, rgba(251, 191, 36, 0.25), transparent 62%),
            var(--bg);
          color: var(--ink);
        }

        .alicerce-app::before, .alicerce-app::after {
          content: ''; position: absolute; border-radius: 50%; filter: blur(6px); pointer-events: none; z-index: 0;
        }
        .alicerce-app::before {
          width: 260px; height: 260px; top: -70px; left: -70px;
          background: radial-gradient(circle, rgba(139,92,246,0.55), transparent 70%);
          animation: floatA 13s ease-in-out infinite;
        }
        .alicerce-app::after {
          width: 220px; height: 220px; bottom: -50px; right: -50px;
          background: radial-gradient(circle, rgba(56,189,248,0.5), transparent 70%);
          animation: floatB 15s ease-in-out infinite;
        }
        .theme-light::before, .theme-light::after { opacity: 0.35; }
        .theme-cyberpunk::before {
          background: radial-gradient(circle, rgba(0, 255, 102, 0.35), transparent 70%);
          opacity: 0.8;
        }
        .theme-cyberpunk::after {
          background: radial-gradient(circle, rgba(16, 185, 129, 0.3), transparent 70%);
          opacity: 0.8;
        }
        .theme-cosmic::before {
          background: radial-gradient(circle, rgba(168, 85, 247, 0.45), transparent 70%);
          opacity: 0.85;
        }
        .theme-cosmic::after {
          background: radial-gradient(circle, rgba(236, 72, 153, 0.35), transparent 70%);
          opacity: 0.85;
        }
        .theme-ocean::before {
          background: radial-gradient(circle, rgba(6, 182, 212, 0.45), transparent 70%);
          opacity: 0.85;
        }
        .theme-ocean::after {
          background: radial-gradient(circle, rgba(59, 130, 246, 0.35), transparent 70%);
          opacity: 0.85;
        }
        .theme-luxury::before {
          background: radial-gradient(circle, rgba(253, 230, 138, 0.5), transparent 70%);
          opacity: 0.45;
        }
        .theme-luxury::after {
          background: radial-gradient(circle, rgba(251, 191, 36, 0.35), transparent 70%);
          opacity: 0.45;
        }
        @keyframes floatA { 0%, 100% { transform: translate(0,0); } 50% { transform: translate(26px, 34px); } }
        @keyframes floatB { 0%, 100% { transform: translate(0,0); } 50% { transform: translate(-22px, -30px); } }
        .header-row, .content-card { position: relative; z-index: 1; }

        /* 📝 Tema Notas Limpo (Fiel à imagem) */
        .content-card.notas-view-card {
          background: #FBF9F4 !important;
          border-color: #E8E2D6 !important;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03) !important;
          padding: 0.5rem !important;
        }

        /* 🏋️ Tema Treino Limpo (Fiel à imagem) */
        .content-card.treino-view-card {
          background: #F8F9FD !important;
          border-color: #E2E8F0 !important;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03) !important;
          padding: 0.5rem !important;
        }

        /* 📝 Integração de Notas: Tema Verde Neon & Preto (Cyberpunk) */
        .alicerce-app.theme-cyberpunk .note-card-item {
          background: rgba(10, 15, 12, 0.94) !important;
          border-color: rgba(0, 255, 102, 0.38) !important;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.88), 0 0 16px rgba(0, 255, 102, 0.22) !important;
        }
        .alicerce-app.theme-cyberpunk .note-card-item:hover {
          border-color: #00FF66 !important;
          box-shadow: 0 14px 38px rgba(0, 0, 0, 0.95), 0 0 22px rgba(0, 255, 102, 0.38) !important;
        }
        .alicerce-app.theme-cyberpunk .note-card-item.note-accent-neon,
        .alicerce-app.theme-cyberpunk .note-card-item.is-pinned {
          border-color: #00FF66 !important;
          box-shadow: 0 12px 34px rgba(0, 0, 0, 0.92), 0 0 20px rgba(0, 255, 102, 0.3) !important;
        }
        .alicerce-app.theme-cyberpunk .note-card-title {
          color: #FFFFFF !important;
        }
        .alicerce-app.theme-cyberpunk .note-card-desc,
        .alicerce-app.theme-cyberpunk .note-checklist-text {
          color: #FFFFFF !important;
        }
        .alicerce-app.theme-cyberpunk .note-card-meta {
          color: #00FF66 !important;
        }
        .alicerce-app.theme-cyberpunk .note-neon-accent {
          color: #00FF66 !important;
        }
        .alicerce-app.theme-cyberpunk .note-stat-card {
          background: rgba(10, 15, 12, 0.92) !important;
          border-color: rgba(0, 255, 102, 0.3) !important;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.8), 0 0 14px rgba(0, 255, 102, 0.16) !important;
        }
        .alicerce-app.theme-cyberpunk .note-stat-value {
          color: #FFFFFF !important;
        }
        .alicerce-app.theme-cyberpunk .note-stat-label {
          color: #00FF66 !important;
        }
        .alicerce-app.theme-cyberpunk .note-search-input {
          background: rgba(10, 15, 12, 0.95) !important;
          border-color: rgba(0, 255, 102, 0.35) !important;
          color: #FFFFFF !important;
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.8), 0 0 12px rgba(0, 255, 102, 0.12) !important;
        }
        .alicerce-app.theme-cyberpunk .note-search-input:focus {
          border-color: #00FF66 !important;
          box-shadow: 0 0 0 3px rgba(0, 255, 102, 0.25), 0 0 18px rgba(0, 255, 102, 0.35) !important;
        }
        .alicerce-app.theme-cyberpunk .note-modal-dialog {
          background: #0A0F0C !important;
          border-color: #00FF66 !important;
          box-shadow: 0 24px 60px rgba(0, 0, 0, 0.95), 0 0 32px rgba(0, 255, 102, 0.32) !important;
        }
        .alicerce-app.theme-cyberpunk .note-modal-title {
          color: #FFFFFF !important;
        }
        .alicerce-app.theme-cyberpunk .note-form-label {
          color: #00FF66 !important;
        }
        .alicerce-app.theme-cyberpunk .note-form-input {
          background: #0D1510 !important;
          border-color: rgba(0, 255, 102, 0.35) !important;
          color: #FFFFFF !important;
        }

        /* 📝 Integração de Notas: Modo Claro (Light Mode) */
        .alicerce-app.theme-light .note-card-item {
          background: rgba(255, 255, 255, 0.88) !important;
          border-color: #E2E8F0 !important;
          box-shadow: 0 4px 18px rgba(15, 23, 42, 0.05), 0 1px 3px rgba(15, 23, 42, 0.04) !important;
        }
        .alicerce-app.theme-light .note-card-item:hover {
          border-color: #CBD5E1 !important;
          box-shadow: 0 8px 26px rgba(15, 23, 42, 0.09) !important;
        }
        .alicerce-app.theme-light .note-card-item.note-accent-neutral {
          border-color: #E2E8F0 !important;
        }
        .alicerce-app.theme-light .note-card-title {
          color: #0F172A !important; /* Slate-900 para contraste total */
        }
        .alicerce-app.theme-light .note-card-desc,
        .alicerce-app.theme-light .note-checklist-text {
          color: #1E293B !important; /* Slate-800 */
        }
        .alicerce-app.theme-light .note-card-meta,
        .alicerce-app.theme-light .note-stat-label,
        .alicerce-app.theme-light .note-form-label {
          color: #475569 !important; /* Slate-600 para descrições */
        }
        .alicerce-app.theme-light .note-stat-card {
          background: rgba(255, 255, 255, 0.88) !important;
          border-color: #E2E8F0 !important;
          box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04) !important;
        }
        .alicerce-app.theme-light .note-stat-value {
          color: #0F172A !important; /* Slate-900 */
        }
        .alicerce-app.theme-light .note-search-input {
          background: rgba(255, 255, 255, 0.95) !important;
          border-color: #E2E8F0 !important;
          color: #0F172A !important;
          box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04) !important;
        }
        .alicerce-app.theme-light .note-search-input::placeholder {
          color: #94A3B8 !important; /* Slate-400 */
        }
        .alicerce-app.theme-light .note-search-input:focus {
          border-color: #059669 !important;
          box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.15) !important;
        }
        .alicerce-app.theme-light .note-modal-dialog {
          background: rgba(255, 255, 255, 0.97) !important;
          border-color: #E2E8F0 !important;
          box-shadow: 0 24px 60px rgba(15, 23, 42, 0.14) !important;
        }
        .alicerce-app.theme-light .note-modal-title {
          color: #0F172A !important; /* Slate-900 */
        }
        .alicerce-app.theme-light .note-form-input {
          background: #FFFFFF !important;
          border-color: #E2E8F0 !important;
          color: #0F172A !important;
        }

        @media (min-width: 480px) { .header-row { align-items: center; } }
        @media (min-width: 640px) {
          .alicerce-app { max-width: 700px; padding: 1.75rem 1.75rem 6.8rem; }
          .content-card { padding: 1.6rem 1.7rem; }
          .brand { font-size: 1.8rem; }
          .section-title { font-size: 1.15rem; }
          .notes-grid, .list-grid, .accordion-grid { display: grid !important; grid-template-columns: 1fr 1fr; gap: 0.65rem; }
          .overview-grid { grid-template-columns: repeat(4, 1fr); }
          .qa-btn .ic-wrap { width: 50px; height: 50px; }
          .hero-card .v { font-size: 2.2rem; }
          .bottom-nav { max-width: 480px; bottom: 1.25rem; }
        }
        @media (min-width: 960px) {
          .alicerce-app { max-width: 960px; padding: 2rem 2rem 7.2rem; }
          .content-card { padding: 1.9rem 2.1rem; min-height: 460px; }
          .notes-grid, .list-grid, .accordion-grid { grid-template-columns: 1fr 1fr 1fr; }
          .bottom-nav { max-width: 540px; bottom: 1.5rem; }
        }
        @media (min-width: 1280px) { .alicerce-app { max-width: 1080px; } }
        @media (max-width: 380px) {
          .brand { font-size: 1.25rem; }
          .nav-item .lbl { font-size: 0.52rem; }
          .qa-btn .ic-wrap { width: 40px; height: 40px; }
          .hero-card .v { font-size: 1.65rem; }
          .quick-actions .ic-wrap { width: 38px; height: 38px; }
          .quick-actions .lbl { font-size: 0.56rem; }
        }

        .alicerce-app button { font-family: var(--font-body); cursor: pointer; color: inherit; text-align: inherit; }
        .alicerce-app input, .alicerce-app select, .alicerce-app textarea {
          font-family: var(--font-body);
          background: var(--input-bg);
          border: 1px solid var(--line);
          border-radius: 0.6rem;
          padding: 0.55rem 0.65rem;
          font-size: 0.85rem;
          color: var(--ink);
          width: 100%;
        }
        .alicerce-app input::placeholder, .alicerce-app textarea::placeholder { color: var(--ink-soft); }
        .alicerce-app select option { background: var(--option-bg); color: var(--ink); }
        .alicerce-app input:focus, .alicerce-app select:focus, .alicerce-app textarea:focus {
          outline: 2px solid var(--active); outline-offset: 1px; border-color: var(--active);
        }

        .header-row { display: flex; justify-content: space-between; align-items: flex-start; gap: 0.6rem; }
        .greet { font-family: var(--font-body); font-size: 0.78rem; color: var(--ink-soft); }
        .brand { font-family: var(--font-display); font-weight: 700; font-size: 1.55rem; line-height: 1.15; color: var(--ink); }

        /* Botão para Baixar no Celular (Android & iOS) */
        .mobile-download-btn,
        .iphone-download-trigger {
          display: flex;
          align-items: center;
          gap: 0.35rem;
          padding: 0.38rem 0.72rem;
          border-radius: 9999px;
          background: linear-gradient(135deg, rgba(56, 189, 248, 0.16), rgba(139, 92, 246, 0.16));
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: var(--active, #38BDF8);
          font-family: var(--font-body);
          font-size: 0.72rem;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.22s ease;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
          white-space: nowrap;
        }
        .mobile-download-btn:hover,
        .iphone-download-trigger:hover {
          background: linear-gradient(135deg, rgba(56, 189, 248, 0.26), rgba(139, 92, 246, 0.26));
          border-color: var(--active, #38BDF8);
          transform: translateY(-1px);
          box-shadow: 0 4px 14px var(--active-glow, rgba(56, 189, 248, 0.3));
        }
        .mobile-download-btn:active,
        .iphone-download-trigger:active {
          transform: translateY(0);
        }

        /* Botão Painel de Login / Usuário */
        .login-trigger-btn {
          display: flex;
          align-items: center;
          gap: 0.28rem;
          padding: 0.35rem 0.62rem;
          border-radius: 9999px;
          background: var(--panel-strong);
          border: 1px solid var(--line);
          color: var(--ink);
          font-family: var(--font-body);
          font-size: 0.72rem;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .login-trigger-btn.logged-in {
          width: 33px;
          height: 33px;
          padding: 0;
          justify-content: center;
          border-color: var(--active);
          background: var(--panel-strong);
          box-shadow: 0 0 10px var(--active-glow);
        }
        .login-trigger-btn:hover {
          border-color: var(--active);
          background: var(--panel);
          transform: translateY(-1px);
        }

        /* Minimalist, discrete outline settings trigger button */
        .settings-trigger-btn {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: transparent;
          border: 1px solid var(--line);
          color: var(--ink-soft);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s ease;
          flex-shrink: 0;
        }
        .settings-trigger-btn:hover {
          color: var(--ink);
          border-color: var(--active);
          background: var(--panel-strong);
          transform: rotate(20deg);
        }

        .bell-btn {
          width: 36px; height: 36px; border-radius: 50%; background: var(--panel); border: 1px solid var(--line);
          display: flex; align-items: center; justify-content: center; color: var(--ink); flex-shrink: 0;
          box-shadow: 0 4px 14px rgba(0,0,0,0.18);
        }
        .today { font-family: var(--font-mono); font-size: 0.62rem; color: var(--ink-soft); text-transform: capitalize; margin-top: 0.15rem; }

        .content-card {
          background: var(--panel); border: 1px solid var(--line); border-radius: 1.3rem;
          padding: 1rem; min-height: 380px; margin-top: 1rem;
          backdrop-filter: blur(22px); -webkit-backdrop-filter: blur(22px);
          box-shadow: var(--card-shadow);
        }
        .fade-in { animation: fadeInUp 0.4s ease; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .section-title { font-family: var(--font-display); font-size: 1.05rem; font-weight: 700; margin: 0 0 0.8rem; color: var(--ink); }
        .empty { color: var(--ink-soft); font-size: 0.82rem; font-style: italic; padding: 0.5rem 0; }

        .bottom-nav {
          position: fixed;
          bottom: calc(0.9rem + env(safe-area-inset-bottom, 0px));
          left: 50%;
          transform: translateX(-50%);
          width: calc(100% - 1.5rem);
          max-width: 440px;
          z-index: 850;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 0.15rem;
          background: var(--nav-bg);
          border: 1px solid var(--line);
          border-radius: 9999px;
          padding: 0.42rem 0.55rem;
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          box-shadow: 0 16px 36px rgba(0,0,0,0.42), 0 2px 10px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.12);
          transition: max-width 0.25s ease, bottom 0.25s ease, background 0.25s ease, border-color 0.25s ease;
        }
        .theme-light .bottom-nav,
        .theme-luxury .bottom-nav {
          box-shadow: 0 14px 34px rgba(15, 23, 42, 0.14), 0 2px 8px rgba(15, 23, 42, 0.06), inset 0 1px 0 rgba(255, 255, 255, 0.85);
        }
        .nav-item {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.24rem;
          background: none;
          border: none;
          color: var(--ink-soft);
          padding: 0.3rem 0.1rem;
          border-radius: 9999px;
          transition: all 0.18s ease;
          -webkit-tap-highlight-color: transparent;
        }
        .nav-item:hover { color: var(--ink); }
        .nav-item .ic-wrap { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.18s ease; }
        .nav-item.nav-center .ic-wrap {
          width: 38px; height: 38px;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.12);
        }
        .nav-item.active { color: #fff; }
        .nav-item.active .ic-wrap { background: linear-gradient(135deg, var(--active), var(--active2)); box-shadow: 0 6px 16px var(--active-glow); animation: navPulse 2.4s ease-in-out infinite; }
        .nav-item.nav-center.active .ic-wrap { border-color: transparent; box-shadow: 0 6px 20px var(--active-glow); }
        @keyframes navPulse { 0%, 100% { box-shadow: 0 6px 16px var(--active-glow); } 50% { box-shadow: 0 8px 26px var(--active-glow); } }
        .nav-item .lbl { font-family: var(--font-mono); font-size: 0.58rem; text-transform: uppercase; letter-spacing: 0.03em; }
        .theme-light .nav-item.active .lbl,
        .theme-luxury .nav-item.active .lbl {
          color: var(--active);
          font-weight: 700;
        }

        .hero-card {
          position: relative; overflow: hidden; border-radius: 1.1rem; padding: 1rem 1.1rem;
          background: linear-gradient(135deg, var(--active), var(--active2));
          box-shadow: 0 12px 30px var(--active-glow); margin-bottom: 0.9rem; color: #fff;
        }
        .hero-card .l { font-family: var(--font-body); font-size: 0.72rem; opacity: 0.85; }
        .hero-card .v { font-family: var(--font-mono); font-size: 1.9rem; font-weight: 700; margin-top: 0.15rem; }
        .hero-card .trend { display: inline-flex; align-items: center; gap: 0.2rem; font-size: 0.7rem; margin-top: 0.4rem; background: rgba(255,255,255,0.2); padding: 0.15rem 0.5rem; border-radius: 1rem; }
        .hero-card .deco { position: absolute; right: -12px; top: 14px; opacity: 0.35; transform: rotate(12deg); }
        .hero-card::before {
          content: ''; position: absolute; top: 0; left: -60%; width: 45%; height: 100%;
          background: linear-gradient(120deg, transparent, rgba(255,255,255,0.28), transparent);
          transform: skewX(-20deg); animation: shine 5.5s ease-in-out infinite;
        }
        @keyframes shine { 0% { left: -60%; } 45% { left: 130%; } 100% { left: 130%; } }

        .financas-top { display: flex; flex-direction: column; }
        @media (min-width: 720px) {
          .financas-top { flex-direction: row; align-items: stretch; gap: 0.7rem; }
          .financas-top .hero-card { flex: 1.3; margin-bottom: 0; }
          .financas-top .stat-row { flex: 1; grid-template-columns: 1fr; margin-bottom: 0; }
        }

        .quick-actions { display: grid; grid-template-columns: repeat(5, 1fr); gap: 0.35rem; margin-bottom: 1rem; }
        .qa-btn { display: flex; flex-direction: column; align-items: center; gap: 0.35rem; background: none; border: none; color: var(--ink-soft); }
        .qa-btn .ic-wrap { width: 46px; height: 46px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; box-shadow: 0 6px 16px rgba(0,0,0,0.35); transition: transform 0.12s ease; }
        .qa-btn:hover .ic-wrap { transform: translateY(-2px); }
        .qa-btn .lbl { font-size: 0.62rem; }

        .stat-row { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin-bottom: 0.9rem; }
        .stat-sm { border: 1px solid var(--line); border-radius: 0.7rem; padding: 0.6rem 0.7rem; background: var(--panel-strong); }
        .stat-sm .l { font-family: var(--font-mono); font-size: 0.58rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--ink-soft); }
        .stat-sm .v { font-family: var(--font-mono); font-size: 1.05rem; font-weight: 700; }

        .breakdown-row { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.55rem; }
        .breakdown-row .ic { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; flex-shrink: 0; }
        .breakdown-row .info { flex: 1; min-width: 0; }
        .breakdown-row .name { font-size: 0.76rem; font-weight: 600; display: flex; justify-content: space-between; }
        .breakdown-bar { height: 5px; border-radius: 3px; background: rgba(255,255,255,0.1); margin-top: 0.25rem; overflow: hidden; }
        .breakdown-bar > div { height: 100%; border-radius: 3px; }

        .section-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.6rem; }
        .link-btn { background: none; border: none; color: var(--active); font-size: 0.72rem; font-weight: 600; display: flex; align-items: center; gap: 0.15rem; }
        .hi-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.9rem; gap: 0.5rem; }

        .overview-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.55rem; margin-bottom: 0.9rem; }
        .overview-card {
          text-align: left; border: 1px solid var(--line); border-radius: 0.9rem; padding: 0.7rem;
          background: var(--panel-strong); display: flex; flex-direction: column; gap: 0.4rem;
          transition: transform 0.15s ease, border-color 0.15s ease;
        }
        .overview-card:hover { transform: translateY(-2px); border-color: rgba(255,255,255,0.3); }
        .overview-card .ic-wrap { width: 34px; height: 34px; border-radius: 0.6rem; display: flex; align-items: center; justify-content: center; color: #fff; }
        .ov-label { font-family: var(--font-mono); font-size: 0.6rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--ink-soft); }
        .ov-value { font-family: var(--font-display); font-weight: 700; font-size: 1rem; color: var(--ink); }

        .quote-card { display: flex; align-items: flex-start; gap: 0.5rem; border: 1px solid var(--line); border-radius: 0.9rem; padding: 0.8rem 0.9rem; background: linear-gradient(135deg, rgba(34,211,238,0.14), rgba(139,92,246,0.1)); color: var(--ink); margin-bottom: 1rem; }
        .quote-card p { margin: 0; font-family: var(--font-display); font-style: italic; font-size: 0.86rem; line-height: 1.5; }

        .tip-card { border: 1px solid var(--line); border-left: 3px solid var(--tip-color, var(--active)); border-radius: 0.8rem; padding: 0.75rem 0.85rem; background: var(--panel-strong); }
        .tip-head { display: flex; align-items: center; gap: 0.4rem; font-family: var(--font-mono); font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.04em; color: var(--ink-soft); margin-bottom: 0.4rem; }
        .tip-card p { margin: 0; font-size: 0.83rem; line-height: 1.5; color: var(--ink); }

        .clock-card {
          display: flex; align-items: center; gap: 0.9rem; border: 1px solid var(--line); border-radius: 1rem;
          padding: 0.9rem 1rem; background: var(--panel-strong); margin-bottom: 0.9rem;
        }
        .clock-left { flex: 1; }
        .clock-time { font-family: var(--font-mono); font-size: 1.9rem; font-weight: 700; color: var(--ink); line-height: 1; }
        .clock-date { font-size: 0.78rem; text-transform: capitalize; color: var(--ink); margin-top: 0.35rem; font-weight: 600; }
        .clock-date-sub { font-family: var(--font-mono); font-size: 0.65rem; text-transform: capitalize; color: var(--ink-soft); margin-top: 0.1rem; }
        .clock-divider { width: 1px; align-self: stretch; background: var(--line); }
        .clock-right { display: flex; flex-direction: column; align-items: center; gap: 0.15rem; background: none; border: none; color: var(--ink); min-width: 64px; }
        .clock-right-cta { color: var(--ink-soft); font-size: 0.68rem; gap: 0.3rem; }
        .clock-temp { font-family: var(--font-mono); font-weight: 700; font-size: 1.1rem; color: var(--ink); }
        .clock-city { font-size: 0.6rem; color: var(--ink-soft); max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .streak-badge {
          display: inline-flex; align-items: center; gap: 0.25rem; font-family: var(--font-mono); font-size: 0.65rem;
          background: linear-gradient(135deg, #EC4899, #F97316); color: #fff; padding: 0.25rem 0.55rem; border-radius: 1rem;
          box-shadow: 0 4px 12px rgba(236,72,153,0.4);
        }

        .sparkline-card { border: 1px solid var(--line); border-radius: 0.8rem; padding: 0.7rem 0.8rem; background: var(--panel-strong); margin-bottom: 0.9rem; }
        .sparkline-head { font-family: var(--font-mono); font-size: 0.62rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--ink-soft); margin-bottom: 0.5rem; }
        .sparkline-row { display: flex; justify-content: space-between; align-items: flex-end; gap: 0.35rem; height: 68px; }
        .spark-col { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 0.3rem; }
        .spark-bar-wrap { height: 44px; display: flex; align-items: flex-end; }
        .spark-bar { width: 10px; border-radius: 4px; transition: height 0.3s ease; }
        .spark-lbl { font-family: var(--font-mono); font-size: 0.56rem; color: var(--ink-soft); }

        .form-block { border: 1px solid var(--line); border-radius: 0.8rem; padding: 0.7rem; margin-bottom: 0.9rem; background: var(--panel-strong); }
        .field-row { display: flex; gap: 0.4rem; margin-bottom: 0.4rem; }
        .field-row > * { flex: 1; }
        .btn-add {
          width: 100%; border: none; border-radius: 0.6rem; padding: 0.6rem; color: #fff;
          font-weight: 700; font-size: 0.85rem; display: flex; align-items: center; justify-content: center; gap: 0.35rem;
          background: linear-gradient(135deg, var(--active), var(--active2));
          box-shadow: 0 8px 20px var(--active-glow); transition: transform 0.12s ease;
        }
        .btn-add:hover { transform: translateY(-1px); }

        .list-item { display: flex; align-items: center; gap: 0.6rem; padding: 0.55rem; border: 1px solid var(--line); border-radius: 0.75rem; margin-bottom: 0.45rem; background: var(--panel-strong); }
        .li-icon { width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; flex-shrink: 0; }
        .li-main { min-width: 0; flex: 1; }
        .li-title { font-weight: 600; font-size: 0.83rem; color: #fff; }
        .li-sub { font-family: var(--font-mono); font-size: 0.63rem; color: var(--ink-soft); margin-top: 0.1rem; }
        .li-right { text-align: right; flex-shrink: 0; }
        .li-val { font-family: var(--font-mono); font-weight: 700; font-size: 0.85rem; white-space: nowrap; }
        .li-date { font-family: var(--font-mono); font-size: 0.6rem; color: var(--ink-soft); margin-top: 0.1rem; }
        .icon-btn { background: rgba(255,255,255,0.08); border: none; color: var(--ink-soft); padding: 0.35rem; display: flex; border-radius: 0.5rem; }
        .icon-btn:hover { color: #fff; background: var(--active); }

        .week-row { display: flex; justify-content: space-between; margin: 0.6rem 0 1.1rem; }
        .week-day { display: flex; flex-direction: column; align-items: center; gap: 0.3rem; }
        .week-day .lbl { font-family: var(--font-mono); font-size: 0.58rem; color: var(--ink-soft); }
        .week-dot { width: 28px; height: 28px; border-radius: 50%; border: 2px solid var(--line); display: flex; align-items: center; justify-content: center; }
        .week-dot.done { background: linear-gradient(135deg, var(--active), var(--active2)); border-color: transparent; box-shadow: 0 4px 12px var(--active-glow); }
        .week-dot.today { border-color: #fff; }

        .notes-grid, .list-grid, .accordion-grid { display: flex; flex-direction: column; gap: 0.55rem; }
        .note-card { border: 1px solid var(--line); border-radius: 0.8rem; padding: 0.65rem; background: var(--panel-strong); border-top: 3px solid var(--active); }
        .note-card input { font-family: var(--font-display); font-weight: 700; font-size: 0.92rem; border: none; background: none; padding: 0.1rem 0; margin-bottom: 0.3rem; color: #fff; }
        .note-card input:focus { outline: none; border-bottom: 1px solid var(--active); }
        .note-card textarea { border: none; background: none; padding: 0.1rem 0; font-size: 0.8rem; resize: vertical; min-height: 55px; }
        .note-card textarea:focus { outline: none; }
        .note-foot { display: flex; justify-content: space-between; align-items: center; margin-top: 0.3rem; }
        .note-foot .ts { font-family: var(--font-mono); font-size: 0.58rem; color: var(--ink-soft); }
        .note-cat-row { display: flex; gap: 0.3rem; margin-bottom: 0.5rem; flex-wrap: wrap; }
        .note-cat-btn { display: flex; align-items: center; gap: 0.25rem; font-size: 0.62rem; font-weight: 600; padding: 0.25rem 0.5rem; border-radius: 1rem; border: 1px solid var(--line); background: none; color: var(--ink-soft); }
        .note-cat-btn.active { color: #fff; }
        .note-reminder-row { display: flex; align-items: center; gap: 0.4rem; margin: 0.4rem 0; color: var(--ink-soft); }
        .note-reminder-row input { font-size: 0.72rem; padding: 0.35rem 0.5rem; }

        .view-toggle { display: flex; gap: 0.3rem; background: var(--panel-strong); border: 1px solid var(--line); border-radius: 0.7rem; padding: 0.25rem; margin-bottom: 0.8rem; }
        .view-toggle-btn { flex: 1; display: flex; align-items: center; justify-content: center; gap: 0.3rem; border: none; background: none; padding: 0.45rem; border-radius: 0.5rem; font-size: 0.72rem; font-weight: 600; color: var(--ink-soft); }
        .view-toggle-btn.active { background: linear-gradient(135deg, var(--active), var(--active2)); color: #fff; }

        .agenda-nav { display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.7rem; }
        .agenda-nav .icon-btn { background: var(--panel-strong); border: 1px solid var(--line); }
        .agenda-nav-label { text-align: center; }
        .agenda-nav-day { font-family: var(--font-display); font-weight: 700; font-size: 0.95rem; color: #fff; text-transform: capitalize; }
        .agenda-nav-date { font-family: var(--font-mono); font-size: 0.65rem; color: var(--ink-soft); text-transform: capitalize; }

        .cal-weekday-row { display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; margin-bottom: 0.35rem; }
        .cal-weekday-row span { font-family: var(--font-mono); font-size: 0.6rem; color: var(--ink-soft); }
        .cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 0.25rem; }
        .cal-cell { aspect-ratio: 1; border: 1px solid var(--line); border-radius: 0.5rem; background: var(--panel-strong); display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.15rem; color: #fff; font-size: 0.72rem; }
        .cal-cell-empty { border: none; background: none; }
        .cal-today { border-color: var(--active); box-shadow: 0 0 0 1px var(--active); }
        .cal-daynum { font-family: var(--font-mono); }
        .cal-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--active); }

        .prod-card { border: 1px solid var(--line); border-radius: 0.9rem; padding: 0.8rem 0.9rem; background: var(--panel-strong); margin-bottom: 0.9rem; }
        .prod-head { display: flex; justify-content: space-between; align-items: center; font-family: var(--font-mono); font-size: 0.68rem; color: var(--ink-soft); text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 0.5rem; }
        .prod-pct { color: #FDE047; font-weight: 700; }
        .prod-list { display: flex; flex-direction: column; gap: 0.4rem; margin-top: 0.7rem; }
        .prod-item { display: flex; align-items: center; gap: 0.5rem; }
        .prod-check { width: 22px; height: 22px; border-radius: 50%; border: 2px solid var(--line); background: none; flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
        .prod-check.done { background: linear-gradient(135deg,#F59E0B,#FDE047); border-color: transparent; }
        .prod-text { flex: 1; font-size: 0.82rem; color: #fff; }
        .prod-text.done { color: var(--ink-soft); text-decoration: line-through; }
        .habit-of-day { display: flex; align-items: flex-start; gap: 0.4rem; font-size: 0.8rem; line-height: 1.5; color: #E7EAFB; margin: 0; }

        .accordion-item { border: 1px solid var(--line); border-radius: 0.8rem; overflow: hidden; background: var(--panel-strong); }
        .accordion-head { width: 100%; display: flex; justify-content: space-between; align-items: center; padding: 0.65rem 0.8rem; background: none; border: none; text-align: left; }
        .accordion-head .t { font-family: var(--font-display); font-weight: 700; font-size: 0.86rem; }
        .accordion-body { padding: 0 0.9rem 0.8rem 0.9rem; }
        .accordion-body ul { margin: 0; padding-left: 1.1rem; color: #D6DCF5; }
        .accordion-body li { font-size: 0.78rem; margin-bottom: 0.4rem; line-height: 1.45; }

        .weather-search { display: flex; gap: 0.4rem; margin-bottom: 0.7rem; }
        .weather-search input { flex: 1; min-width: 0; }
        .chip-row { display: flex; flex-wrap: wrap; gap: 0.35rem; margin-bottom: 0.8rem; }
        .chip { background: var(--panel-strong); border: 1px solid var(--line); color: var(--ink-soft); font-size: 0.68rem; padding: 0.3rem 0.65rem; border-radius: 1rem; }
        .chip:hover { color: #fff; border-color: var(--active); }
        .weather-card { border: 1px solid var(--line); border-radius: 1rem; padding: 1.1rem; text-align: center; margin-bottom: 0.8rem; transition: background 0.4s ease; }
        .weather-city { font-family: var(--font-display); font-size: 1.05rem; font-weight: 700; color: #fff; }
        .weather-icon-anim { display: inline-block; margin: 0.3rem 0; animation: iconFloat 3s ease-in-out infinite; }
        @keyframes iconFloat { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
        @keyframes alertBeaconPing { 0% { transform: scale(1); opacity: 0.8; } 75%, 100% { transform: scale(2.4); opacity: 0; } }
        .weather-card-has-alert { position: relative; transition: all 0.4s ease; }
        .weather-temp { font-family: var(--font-mono); font-size: 2.7rem; font-weight: 700; margin: 0.1rem 0; color: #fff; }
        .weather-chips { display: flex; justify-content: center; flex-wrap: wrap; gap: 0.4rem; margin-top: 0.7rem; }
        .w-chip { display: flex; align-items: center; gap: 0.3rem; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.14); color: #E7EAFB; font-family: var(--font-mono); font-size: 0.65rem; padding: 0.3rem 0.55rem; border-radius: 1rem; }
        .weather-meta { display: flex; justify-content: center; gap: 1rem; font-family: var(--font-mono); font-size: 0.72rem; color: var(--ink-soft); margin-top: 0.6rem; }
        .sun-row { display: flex; justify-content: center; gap: 1.2rem; margin-top: 0.6rem; font-family: var(--font-mono); font-size: 0.68rem; color: var(--ink-soft); }
        .sun-row span { display: flex; align-items: center; gap: 0.3rem; }
        .hours-scroll { display: flex; gap: 0.5rem; overflow-x: auto; padding-bottom: 0.3rem; margin-bottom: 0.9rem; scrollbar-width: none; }
        .hours-scroll::-webkit-scrollbar { display: none; }
        .hour-card { flex: 0 0 auto; display: flex; flex-direction: column; align-items: center; gap: 0.3rem; background: var(--panel-strong); border: 1px solid var(--line); border-radius: 0.8rem; padding: 0.55rem 0.7rem; min-width: 58px; }
        .hour-lbl { font-family: var(--font-mono); font-size: 0.6rem; color: var(--ink-soft); }
        .hour-temp { font-family: var(--font-mono); font-size: 0.75rem; font-weight: 700; color: #fff; }
        .days-list { display: flex; flex-direction: column; gap: 0.4rem; }
        .day-row { display: flex; align-items: center; gap: 0.7rem; background: var(--panel-strong); border: 1px solid var(--line); border-radius: 0.7rem; padding: 0.5rem 0.75rem; }
        .day-name { flex: 1; font-size: 0.78rem; color: var(--ink); font-weight: 600; }
        .day-minmax { font-family: var(--font-mono); font-size: 0.75rem; color: var(--ink-soft); }
        .day-minmax b { color: var(--ink); }
        .spin { animation: alicerce-spin 1s linear infinite; }
        @keyframes alicerce-spin { to { transform: rotate(360deg); } }
      `}</style>

      {/* Header */}
      <div className="header-row">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
          <img
            src="/icon-192.png"
            alt="Alicerce"
            style={{
              width: '44px',
              height: '44px',
              borderRadius: '12px',
              boxShadow: '0 4px 14px rgba(14, 165, 233, 0.28), 0 1px 3px rgba(0, 0, 0, 0.2)',
              flexShrink: 0,
              objectFit: 'cover',
            }}
            referrerPolicy="no-referrer"
          />
          <div>
            <div className="greet" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              <span>{getGreeting()}</span>
              {displayName ? <span>, {displayName}</span> : null}
              <span style={{ fontSize: '1rem', lineHeight: 1 }}>{userProfile.avatarEmoji || '👋'}</span>
            </div>
            <div className="brand">
              {displayName ? 'Seu painel' : 'Bem-vindo ao Alicerce'}
            </div>
            <div className="today">
              {new Date().toLocaleDateString('pt-BR', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
              })}
            </div>
          </div>
        </div>

        {/* Top-right actions: Voice button, Mobile download link, Login trigger, settings gear & bell */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {/* Botão Conversa por Voz (Gemini Live API) */}
          <button
            id="voice-assistant-trigger-btn"
            type="button"
            className="mobile-download-btn"
            onClick={() => setIsVoiceAssistantOpen(true)}
            title="Conversar por Voz em Tempo Real (Live API · gemini-3.8-live)"
            aria-label="Abrir Alicerce Voz"
            style={{
              background: 'linear-gradient(135deg, rgba(2, 132, 199, 0.22), rgba(6, 182, 212, 0.22))',
              borderColor: 'rgba(56, 189, 248, 0.5)',
              color: '#38BDF8',
            }}
          >
            <Mic size={13} />
            <span>Alicerce Voz</span>
          </button>

          {/* Link / Botão para Baixar no Celular */}
          <button
            id="mobile-download-btn"
            type="button"
            className="mobile-download-btn"
            onClick={() => setIsIPhoneOpen(true)}
            title="Baixar ou Instalar no Celular (Android & iOS)"
            aria-label="Baixar no Celular"
          >
            <Smartphone size={13} />
            <span>Baixar no Celular</span>
          </button>

          {/* Botão Painel de Login */}
          <button
            id="login-trigger-btn"
            type="button"
            className={`login-trigger-btn ${userProfile.isLoggedIn ? 'logged-in' : ''}`}
            onClick={() => setIsLoginOpen(true)}
            title={userProfile.isLoggedIn ? `Conectado como ${userProfile.name} (Ver Painel)` : 'Entrar / Criar Conta'}
            aria-label="Painel de Login"
          >
            {userProfile.isLoggedIn ? (
              <span style={{ fontSize: '1rem', lineHeight: 1 }}>{userProfile.avatarEmoji || '👑'}</span>
            ) : (
              <>
                <LogIn size={13} />
                <span>Entrar</span>
              </>
            )}
          </button>

          <button
            id="settings-trigger-btn"
            type="button"
            className="settings-trigger-btn"
            onClick={() => setIsSettingsOpen(true)}
            title="Configurações e Perfil"
            aria-label="Abrir Configurações"
          >
            <SettingsGearIcon size={16} />
          </button>
          <div className="bell-btn" title="Notificações">
            <BellIcon size={18} />
          </div>
        </div>
      </div>

      {/* Active Tab Content Card */}
      <main
        className={`content-card fade-in ${currentTab === 'notas' ? 'notas-view-card' : ''} ${currentTab === 'treino' ? 'treino-view-card' : ''}`}
        key={currentTab}
      >
        {currentTab === 'inicio' && (
          <InicioView
            transactions={transactions}
            workouts={workouts}
            setWorkouts={setWorkouts}
            notes={notes}
            investments={investments}
            setTab={setCurrentTab}
            name={displayName}
            setName={handleUpdateName}
            weather={weather}
            setWeather={setWeather}
            userProfile={userProfile}
            onOpenLogin={() => setIsLoginOpen(true)}
            onOpenIPhoneDownload={() => setIsIPhoneOpen(true)}
            onOpenVoiceAssistant={() => setIsVoiceAssistantOpen(true)}
          />
        )}
        {currentTab === 'financas' && (
          <FinancasView
            transactions={transactions}
            setTransactions={setTransactions}
            investments={investments}
            setInvestments={setInvestments}
            userProfile={userProfile}
            onUpdateProfile={handleSaveProfile}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        )}
        {currentTab === 'notas' && (
          <NotesView notes={notes} setNotes={setNotes} />
        )}
        {currentTab === 'treino' && (
          <TreinoView
            workouts={workouts}
            setWorkouts={setWorkouts}
            userName={displayName}
          />
        )}
        {currentTab === 'dicas' && (
          <DicasView
            productiveTasks={productiveTasks}
            setProductiveTasks={setProductiveTasks}
          />
        )}
        {currentTab === 'radar' && <AiGroundingView />}
      </main>

      {/* Floating Alicerce Voz Trigger */}
      <button
        type="button"
        onClick={() => setIsVoiceAssistantOpen(true)}
        title="Conversar com Alicerce Voz (Gemini Live)"
        aria-label="Conversar por voz"
        style={{
          position: 'fixed',
          bottom: 'calc(4.8rem + env(safe-area-inset-bottom, 0px))',
          right: '1.2rem',
          zIndex: 800,
          width: '48px',
          height: '48px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #0284C7, #06B6D4)',
          border: '2px solid rgba(255, 255, 255, 0.25)',
          color: '#FFFFFF',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 8px 24px rgba(2, 132, 199, 0.55), 0 0 16px rgba(6, 182, 212, 0.4)',
          cursor: 'pointer',
          transition: 'transform 0.2s ease',
        }}
      >
        <Mic size={22} />
      </button>

      {/* Voice Assistant Modal (Live API · gemini-3.8-live) */}
      <VoiceAssistantModal
        isOpen={isVoiceAssistantOpen}
        onClose={() => setIsVoiceAssistantOpen(false)}
        userName={displayName}
      />

      {/* Bottom Floating Navigation */}
      <nav className="bottom-nav" aria-label="Navegação Principal">
        {NAV_TABS.map((tab) => {
          const IconComponent = tab.icon;
          const isActive = currentTab === tab.id;
          const isCenter = tab.id === 'inicio';
          return (
            <button
              key={tab.id}
              type="button"
              className={`nav-item ${isActive ? 'active' : ''} ${isCenter ? 'nav-center' : ''}`}
              onClick={() => setCurrentTab(tab.id)}
            >
              <span className="ic-wrap">
                <IconComponent size={isCenter ? 19 : 17} />
              </span>
              <span className="lbl">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Settings Modal / Drawer */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        userProfile={userProfile}
        onSaveProfile={handleSaveProfile}
        theme={theme}
        onSelectTheme={(newTheme) => setTheme(newTheme)}
        onOpenIPhoneDownload={() => {
          setIsSettingsOpen(false);
          setIsIPhoneOpen(true);
        }}
        onOpenLogin={() => {
          setIsSettingsOpen(false);
          setIsLoginOpen(true);
        }}
      />

      {/* Painel de Login Descontraído */}
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        userProfile={userProfile}
        onLoginSuccess={handleLoginSuccess}
        onLogout={handleLogout}
      />

      {/* Modal de Download / Instalação no iPhone */}
      <IPhoneDownloadModal
        isOpen={isIPhoneOpen}
        onClose={() => setIsIPhoneOpen(false)}
      />
    </div>
  );
}
