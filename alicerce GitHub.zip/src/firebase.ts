import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  collection,
  getDocs,
  getDocFromServer,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { Transaction, Investment, Workout, Note, ProductiveTask, UserProfile, AlicerceStorageData } from './types';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Test connection on boot
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline. Local storage fallback will be used.');
    } else {
      // Permission denied or other expected errors on unauthenticated test doc are acceptable
      console.info('Firestore initialized.');
    }
    return false;
  }
}

// Structured error handling per firebase-integration skill
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Google Sign-In helper
export async function signInWithGoogle(): Promise<User> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error('Error signing in with Google:', error);
    throw error;
  }
}

// Google Sign-Out helper
export async function signOutUser(): Promise<void> {
  await firebaseSignOut(auth);
}

// Sanitize string to fit within safe bounds
function sanitizeId(id: string): string {
  return id.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 100);
}

// Load full user data from Firestore
export async function loadUserDataFromFirestore(userId: string): Promise<Partial<AlicerceStorageData> | null> {
  const path = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userDocRef);

    if (!userSnap.exists()) {
      return null;
    }

    const userData = userSnap.data();

    // Fetch subcollections
    const txSnap = await getDocs(collection(db, 'users', userId, 'transactions'));
    const transactions: Transaction[] = [];
    txSnap.forEach((d) => transactions.push(d.data() as Transaction));

    const invSnap = await getDocs(collection(db, 'users', userId, 'investments'));
    const investments: Investment[] = [];
    invSnap.forEach((d) => investments.push(d.data() as Investment));

    const woSnap = await getDocs(collection(db, 'users', userId, 'workouts'));
    const workouts: Workout[] = [];
    woSnap.forEach((d) => workouts.push(d.data() as Workout));

    const notesSnap = await getDocs(collection(db, 'users', userId, 'notes'));
    const notes: Note[] = [];
    notesSnap.forEach((d) => notes.push(d.data() as Note));

    const tasksSnap = await getDocs(collection(db, 'users', userId, 'tasks'));
    const productiveTasks: ProductiveTask[] = [];
    tasksSnap.forEach((d) => productiveTasks.push(d.data() as ProductiveTask));

    const profile: UserProfile = {
      name: userData.name || '',
      email: userData.email || '',
      mainGoal: userData.mainGoal || 'Hipertrofia & Rendimento Físico',
      avatarUrl: userData.avatarUrl || '',
      avatarEmoji: userData.avatarEmoji || '👑',
      customStatus: userData.customStatus || 'Conectado via Google',
      isLoggedIn: true,
      totalFinancialGoal: userData.totalFinancialGoal || undefined,
    };

    return {
      userProfile: profile,
      name: profile.name,
      theme: userData.theme || 'dark',
      transactions: transactions.length > 0 ? transactions : undefined,
      investments: investments.length > 0 ? investments : undefined,
      workouts: workouts.length > 0 ? workouts : undefined,
      notes: notes.length > 0 ? notes : undefined,
      productiveTasks: productiveTasks.length > 0 ? productiveTasks : undefined,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

// Save complete user state to Firestore
export async function saveUserDataToFirestore(
  userId: string,
  data: {
    userProfile: UserProfile;
    theme?: string;
    transactions: Transaction[];
    investments: Investment[];
    workouts: Workout[];
    notes: Note[];
    productiveTasks: ProductiveTask[];
  }
): Promise<void> {
  const path = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    await setDoc(
      userDocRef,
      {
        userId,
        name: (data.userProfile.name || 'Usuário').slice(0, 100),
        email: (data.userProfile.email || '').slice(0, 150),
        mainGoal: (data.userProfile.mainGoal || '').slice(0, 150),
        avatarUrl: (data.userProfile.avatarUrl || '').slice(0, 500),
        avatarEmoji: (data.userProfile.avatarEmoji || '👑').slice(0, 10),
        customStatus: (data.userProfile.customStatus || '').slice(0, 100),
        theme: (data.theme || 'dark').slice(0, 30),
        totalFinancialGoal: data.userProfile.totalFinancialGoal || 0,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    // Save subcollections in batches
    const batch = writeBatch(db);

    // Transactions (up to latest 50)
    for (const tx of data.transactions.slice(0, 50)) {
      const cleanId = sanitizeId(tx.id || Math.random().toString(36).slice(2));
      const ref = doc(db, 'users', userId, 'transactions', cleanId);
      batch.set(
        ref,
        {
          id: cleanId,
          userId,
          desc: (tx.desc || 'Transação').slice(0, 200),
          value: Number(tx.value) || 0,
          type: tx.type === 'saida' ? 'saida' : 'entrada',
          category: (tx.category || 'Outros').slice(0, 60),
          date: (tx.date || new Date().toISOString().slice(0, 10)).slice(0, 20),
          status: tx.status === 'pendente' ? 'pendente' : 'pago',
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }

    // Investments (up to latest 50)
    for (const inv of data.investments.slice(0, 50)) {
      const cleanId = sanitizeId(inv.id || Math.random().toString(36).slice(2));
      const ref = doc(db, 'users', userId, 'investments', cleanId);
      batch.set(
        ref,
        {
          id: cleanId,
          userId,
          name: (inv.name || 'Ativo').slice(0, 120),
          type: (inv.type || 'Renda Fixa').slice(0, 60),
          institution: (inv.institution || 'Outra').slice(0, 80),
          value: Number(inv.value) || 0,
          yieldRate: (inv.yieldRate || '').slice(0, 60),
          liquidity: (inv.liquidity || '').slice(0, 60),
          date: (inv.date || new Date().toISOString().slice(0, 10)).slice(0, 20),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }

    // Workouts (up to latest 30)
    for (const wo of data.workouts.slice(0, 30)) {
      const cleanId = sanitizeId(wo.id || Math.random().toString(36).slice(2));
      const ref = doc(db, 'users', userId, 'workouts', cleanId);
      batch.set(
        ref,
        {
          id: cleanId,
          userId,
          name: (wo.name || 'Treino').slice(0, 120),
          date: (wo.date || new Date().toISOString().slice(0, 10)).slice(0, 20),
          durationMinutes: Number(wo.durationMinutes) || 0,
          focus: (wo.focus || '').slice(0, 100),
          loadNote: (wo.loadNote || '').slice(0, 250),
          totalVolumeKg: Number(wo.totalVolumeKg) || 0,
          isRestDay: Boolean(wo.isRestDay),
          dayOfWeek: (wo.dayOfWeek || '').slice(0, 20),
          category: (wo.category || 'Geral').slice(0, 60),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }

    // Notes (up to latest 40)
    for (const note of data.notes.slice(0, 40)) {
      const cleanId = sanitizeId(note.id || Math.random().toString(36).slice(2));
      const ref = doc(db, 'users', userId, 'notes', cleanId);
      batch.set(
        ref,
        {
          id: cleanId,
          userId,
          title: (note.title || 'Nota').slice(0, 150),
          content: (note.content || '').slice(0, 5000),
          category: (note.category || 'Pessoal').slice(0, 50),
          reminder: (note.reminder || '').slice(0, 50),
          date: (note.date || '').slice(0, 20),
          isPinned: Boolean(note.isPinned),
          isArchived: Boolean(note.isArchived),
          isCollapsed: Boolean(note.isCollapsed),
          color: (note.color || 'neutral').slice(0, 30),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }

    // Tasks (up to 20)
    for (const task of data.productiveTasks.slice(0, 20)) {
      const cleanId = sanitizeId(task.id || Math.random().toString(36).slice(2));
      const ref = doc(db, 'users', userId, 'tasks', cleanId);
      batch.set(
        ref,
        {
          id: cleanId,
          userId,
          text: (task.text || 'Tarefa').slice(0, 200),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
