import { jsPDF } from 'jspdf';
import { Transaction, Investment } from '../types';
import { fmtBRL } from './constants';

const MONTH_NAMES = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
];

const MONTH_SHORT = [
  'Jan',
  'Fev',
  'Mar',
  'Abr',
  'Mai',
  'Jun',
  'Jul',
  'Ago',
  'Set',
  'Out',
  'Nov',
  'Dez',
];

export interface MonthSummaryItem {
  key: string; // YYYY-MM
  label: string;
  shortLabel: string;
  entradas: number;
  saidas: number;
  saldo: number;
  savingsRate: number;
  txCount: number;
}

export const computeMonthlySummary = (transactions: Transaction[]): MonthSummaryItem[] => {
  const map = new Map<string, { entradas: number; saidas: number; count: number }>();

  transactions.forEach((tx) => {
    const ym = tx.date && tx.date.length >= 7 ? tx.date.slice(0, 7) : 'Sem Data';
    const current = map.get(ym) || { entradas: 0, saidas: 0, count: 0 };

    if (tx.type === 'entrada') {
      current.entradas += Number(tx.value) || 0;
    } else if (tx.type === 'saida') {
      current.saidas += Number(tx.value) || 0;
    }
    current.count += 1;
    map.set(ym, current);
  });

  const list: MonthSummaryItem[] = [];

  map.forEach((data, ym) => {
    if (ym === 'Sem Data') {
      list.push({
        key: ym,
        label: 'Sem Data Definida',
        shortLabel: 'S/D',
        entradas: data.entradas,
        saidas: data.saidas,
        saldo: data.entradas - data.saidas,
        savingsRate:
          data.entradas > 0
            ? Math.round(((data.entradas - data.saidas) / data.entradas) * 100)
            : 0,
        txCount: data.count,
      });
      return;
    }

    const parts = ym.split('-');
    const year = parseInt(parts[0], 10);
    const monthIdx = parseInt(parts[1], 10) - 1;
    const monthName = MONTH_NAMES[monthIdx] || parts[1];
    const shortName = MONTH_SHORT[monthIdx] || parts[1];

    const saldo = data.entradas - data.saidas;
    const savingsRate =
      data.entradas > 0 ? Math.round((saldo / data.entradas) * 100) : 0;

    list.push({
      key: ym,
      label: `${monthName} ${year}`,
      shortLabel: `${shortName}/${String(year).slice(2)}`,
      entradas: data.entradas,
      saidas: data.saidas,
      saldo,
      savingsRate,
      txCount: data.count,
    });
  });

  list.sort((a, b) => b.key.localeCompare(a.key));
  return list;
};

export const generateFinancialPDF = (
  transactions: Transaction[],
  investments: Investment[] = []
): boolean => {
  try {
    const monthlyData = computeMonthlySummary(transactions);

    let totalEntradas = 0;
    let totalSaidas = 0;

    transactions.forEach((tx) => {
      const val = Number(tx.value) || 0;
      if (tx.type === 'entrada') totalEntradas += val;
      if (tx.type === 'saida') totalSaidas += val;
    });

    const saldoGeral = totalEntradas - totalSaidas;
    const taxaGeral =
      totalEntradas > 0 ? Math.round((saldoGeral / totalEntradas) * 100) : 0;

    const totalInvestido = investments.reduce(
      (acc, curr) => acc + (Number(curr.value) || 0),
      0
    );

    // Group expenses by category
    const catMap = new Map<string, { total: number; count: number }>();
    transactions.forEach((tx) => {
      if (tx.type === 'saida') {
        const cat = tx.category || 'Outros';
        const current = catMap.get(cat) || { total: 0, count: 0 };
        current.total += Number(tx.value) || 0;
        current.count += 1;
        catMap.set(cat, current);
      }
    });

    const categoryExpenses = Array.from(catMap.entries()).map(([cat, data]) => ({
      category: cat,
      total: data.total,
      count: data.count,
      percent:
        totalSaidas > 0 ? Math.round((data.total / totalSaidas) * 100) : 0,
    }));
    categoryExpenses.sort((a, b) => b.total - a.total);

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = 210;
    const margin = 14;
    const contentWidth = pageWidth - margin * 2; // 182mm
    let yPos = 14;

    // 1. Header Banner
    doc.setFillColor(15, 23, 42); // Slate-900
    doc.roundedRect(margin, yPos, contentWidth, 24, 2, 2, 'F');

    // Top title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(15);
    doc.setTextColor(255, 255, 255);
    doc.text('BALANÇO FINANCEIRO - ALICERCE', margin + 6, yPos + 10);

    // Subtitle
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(203, 213, 225); // Slate-300
    doc.text(
      'Relatório Consolidado Multimeses • Gestão & Produtividade Pessoal',
      margin + 6,
      yPos + 17
    );

    // Issue date & time on the right
    const nowStr = new Date().toLocaleDateString('pt-BR');
    const timeStr = new Date().toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(`Emissão: ${nowStr} às ${timeStr}`, pageWidth - margin - 6, yPos + 10, {
      align: 'right',
    });
    doc.text(
      `${monthlyData.length} meses • ${transactions.length} lançamentos`,
      pageWidth - margin - 6,
      yPos + 17,
      { align: 'right' }
    );

    yPos += 30;

    // 2. Executive Summary Cards (4 Boxes)
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text('1. RESUMO EXECUTIVO CONSOLIDADO', margin, yPos);
    yPos += 4;

    const cardWidth = (contentWidth - 9) / 4;
    const cardHeight = 22;

    // Box 1: Receitas
    doc.setFillColor(240, 253, 244); // Green 50
    doc.setDrawColor(187, 247, 208); // Green 200
    doc.roundedRect(margin, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(22, 101, 52);
    doc.text('TOTAL RECEITAS', margin + 4, yPos + 6);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(21, 128, 61);
    doc.text(fmtBRL(totalEntradas), margin + 4, yPos + 13);
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Entradas acumuladas', margin + 4, yPos + 18);

    // Box 2: Despesas
    const b2X = margin + cardWidth + 3;
    doc.setFillColor(254, 242, 242); // Red 50
    doc.setDrawColor(254, 202, 202); // Red 200
    doc.roundedRect(b2X, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(153, 27, 27);
    doc.text('TOTAL DESPESAS', b2X + 4, yPos + 6);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(185, 28, 28);
    doc.text(fmtBRL(totalSaidas), b2X + 4, yPos + 13);
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Saídas acumuladas', b2X + 4, yPos + 18);

    // Box 3: Saldo Líquido
    const b3X = b2X + cardWidth + 3;
    const isPositive = saldoGeral >= 0;
    doc.setFillColor(isPositive ? 238 : 255, isPositive ? 242 : 241, isPositive ? 255 : 242);
    doc.setDrawColor(isPositive ? 199 : 254, isPositive ? 210 : 202, isPositive ? 254 : 202);
    doc.roundedRect(b3X, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(isPositive ? 30 : 153, isPositive ? 64 : 27, isPositive ? 175 : 27);
    doc.text('SALDO LÍQUIDO', b3X + 4, yPos + 6);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(isPositive ? 37 : 185, isPositive ? 99 : 28, isPositive ? 235 : 28);
    doc.text(fmtBRL(saldoGeral), b3X + 4, yPos + 13);
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(isPositive ? 'Superávit acumulado' : 'Déficit acumulado', b3X + 4, yPos + 18);

    // Box 4: Taxa de Economia
    const b4X = b3X + cardWidth + 3;
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(b4X, yPos, cardWidth, cardHeight, 1.5, 1.5, 'FD');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    doc.text('TAXA DE ECONOMIA', b4X + 4, yPos + 6);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text(`${taxaGeral}%`, b4X + 4, yPos + 13);
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(`Patrimônio: ${fmtBRL(totalInvestido)}`, b4X + 4, yPos + 18);

    yPos += cardHeight + 8;

    // 3. Tabela Comparativa Mês a Mês
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text('2. COMPARATIVO DETALHADO MÊS A MÊS', margin, yPos);
    yPos += 4;

    const colW = {
      mes: 38,
      rec: 32,
      des: 32,
      sal: 34,
      tax: 22,
      sit: 24,
    };

    // Table Header Row
    doc.setFillColor(30, 41, 59); // Slate-800
    doc.rect(margin, yPos, contentWidth, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(255, 255, 255);

    let xCursor = margin + 3;
    doc.text('MÊS / ANO', xCursor, yPos + 4.8);

    xCursor += colW.mes;
    doc.text('RECEITAS', xCursor + colW.rec - 6, yPos + 4.8, { align: 'right' });

    xCursor += colW.rec;
    doc.text('DESPESAS', xCursor + colW.des - 6, yPos + 4.8, { align: 'right' });

    xCursor += colW.des;
    doc.text('SALDO LÍQUIDO', xCursor + colW.sal - 6, yPos + 4.8, { align: 'right' });

    xCursor += colW.sal;
    doc.text('TX. ECON.', xCursor + colW.tax / 2, yPos + 4.8, { align: 'center' });

    xCursor += colW.tax;
    doc.text('SITUAÇÃO', xCursor + colW.sit / 2, yPos + 4.8, { align: 'center' });

    yPos += 7;

    // Table Rows
    monthlyData.forEach((m, idx) => {
      if (yPos > 265) {
        doc.addPage();
        yPos = 16;
      }

      const isEven = idx % 2 === 0;
      doc.setFillColor(isEven ? 255 : 248, isEven ? 255 : 250, isEven ? 255 : 252);
      doc.rect(margin, yPos, contentWidth, 6.5, 'F');

      doc.setDrawColor(241, 245, 249);
      doc.line(margin, yPos + 6.5, margin + contentWidth, yPos + 6.5);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(30, 41, 59);

      let rowX = margin + 3;
      doc.text(m.label, rowX, yPos + 4.5);

      rowX += colW.mes;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(21, 128, 61); // Green
      doc.text(fmtBRL(m.entradas), rowX + colW.rec - 6, yPos + 4.5, { align: 'right' });

      rowX += colW.rec;
      doc.setTextColor(185, 28, 28); // Red
      doc.text(fmtBRL(m.saidas), rowX + colW.des - 6, yPos + 4.5, { align: 'right' });

      rowX += colW.des;
      const mPos = m.saldo >= 0;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(mPos ? 21 : 185, mPos ? 128 : 28, mPos ? 61 : 28);
      doc.text(fmtBRL(m.saldo), rowX + colW.sal - 6, yPos + 4.5, { align: 'right' });

      rowX += colW.sal;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text(`${m.savingsRate}%`, rowX + colW.tax / 2, yPos + 4.5, { align: 'center' });

      rowX += colW.tax;
      const sitLabel = mPos ? 'Superávit' : 'Déficit';
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(mPos ? 22 : 153, mPos ? 101 : 27, mPos ? 52 : 27);
      doc.text(sitLabel, rowX + colW.sit / 2, yPos + 4.5, { align: 'center' });

      yPos += 6.5;
    });

    // Total Row at bottom of table
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, yPos, contentWidth, 7, 'F');
    doc.setDrawColor(203, 213, 225);
    doc.line(margin, yPos, margin + contentWidth, yPos);
    doc.line(margin, yPos + 7, margin + contentWidth, yPos + 7);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(15, 23, 42);

    let totX = margin + 3;
    doc.text('TOTAL CONSOLIDADO', totX, yPos + 4.8);

    totX += colW.mes;
    doc.setTextColor(21, 128, 61);
    doc.text(fmtBRL(totalEntradas), totX + colW.rec - 6, yPos + 4.8, { align: 'right' });

    totX += colW.rec;
    doc.setTextColor(185, 28, 28);
    doc.text(fmtBRL(totalSaidas), totX + colW.des - 6, yPos + 4.8, { align: 'right' });

    totX += colW.des;
    const totPos = saldoGeral >= 0;
    doc.setTextColor(totPos ? 21 : 185, totPos ? 128 : 28, totPos ? 61 : 28);
    doc.text(fmtBRL(saldoGeral), totX + colW.sal - 6, yPos + 4.8, { align: 'right' });

    totX += colW.sal;
    doc.setTextColor(15, 23, 42);
    doc.text(`${taxaGeral}%`, totX + colW.tax / 2, yPos + 4.8, { align: 'center' });

    totX += colW.tax;
    doc.setTextColor(totPos ? 22 : 153, totPos ? 101 : 27, totPos ? 52 : 27);
    doc.text(totPos ? 'Superávit' : 'Déficit', totX + colW.sit / 2, yPos + 4.8, {
      align: 'center',
    });

    yPos += 13;

    // 4. Detalhamento por Categoria
    if (yPos > 230) {
      doc.addPage();
      yPos = 16;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text('3. MAIORES GASTOS POR CATEGORIA (PERÍODO ACUMULADO)', margin, yPos);
    yPos += 4;

    const catColW = {
      cat: 64,
      cnt: 30,
      val: 48,
      pct: 40,
    };

    doc.setFillColor(30, 41, 59);
    doc.rect(margin, yPos, contentWidth, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(255, 255, 255);

    let cX = margin + 3;
    doc.text('CATEGORIA', cX, yPos + 4.8);
    cX += catColW.cat;
    doc.text('LANÇAMENTOS', cX + catColW.cnt / 2, yPos + 4.8, { align: 'center' });
    cX += catColW.cnt;
    doc.text('TOTAL GASTO', cX + catColW.val - 6, yPos + 4.8, { align: 'right' });
    cX += catColW.val;
    doc.text('% DO TOTAL', cX + catColW.pct / 2, yPos + 4.8, { align: 'center' });

    yPos += 7;

    categoryExpenses.slice(0, 8).forEach((catItem, idx) => {
      if (yPos > 265) {
        doc.addPage();
        yPos = 16;
      }

      const isEven = idx % 2 === 0;
      doc.setFillColor(isEven ? 255 : 248, isEven ? 255 : 250, isEven ? 255 : 252);
      doc.rect(margin, yPos, contentWidth, 6.5, 'F');

      doc.setDrawColor(241, 245, 249);
      doc.line(margin, yPos + 6.5, margin + contentWidth, yPos + 6.5);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(30, 41, 59);

      let rowCatX = margin + 3;
      doc.text(catItem.category, rowCatX, yPos + 4.5);

      rowCatX += catColW.cat;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(`${catItem.count} itens`, rowCatX + catColW.cnt / 2, yPos + 4.5, {
        align: 'center',
      });

      rowCatX += catColW.cnt;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(185, 28, 28);
      doc.text(fmtBRL(catItem.total), rowCatX + catColW.val - 6, yPos + 4.5, {
        align: 'right',
      });

      rowCatX += catColW.val;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text(`${catItem.percent}%`, rowCatX + catColW.pct / 2, yPos + 4.5, {
        align: 'center',
      });

      yPos += 6.5;
    });

    // 5. Page Numbering & Footer
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setDrawColor(226, 232, 240);
      doc.line(margin, 285, pageWidth - margin, 285);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(148, 163, 184);
      doc.text(
        'Alicerce • Gestão Financeira & Produtividade Pessoal • Relatório Gerado Automaticamente',
        margin,
        290
      );
      doc.text(`Página ${i} de ${totalPages}`, pageWidth - margin, 290, {
        align: 'right',
      });
    }

    // Download file
    const fileName = `balanco-financeiro-alicerce-${new Date().toISOString().slice(0, 10)}.pdf`;
    doc.save(fileName);
    return true;
  } catch (err) {
    console.error('Erro ao gerar PDF:', err);
    return false;
  }
};
