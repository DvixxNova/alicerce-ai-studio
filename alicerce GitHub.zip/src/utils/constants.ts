import React from 'react';
import {
  SparklesIcon,
  WalletIcon,
  DumbbellIcon,
  FileTextIcon,
  LightbulbIcon,
  CloudSunIcon,
  HomeIcon,
  UtensilsIcon,
  CarIcon,
  GamepadIcon,
  HeartPulseIcon,
  GraduationCapIcon,
  BanknoteIcon,
  MoreHorizontalIcon,
  UserIcon,
  BriefcaseIcon,
  HeartIcon,
  SunIcon,
  CloudIcon,
  CloudFogIcon,
  CloudRainIcon,
  CloudSnowIcon,
  CloudLightningIcon,
  TargetIcon,
} from '../components/Icons';
import { Investment, Note, ProductiveTask, TabId, Transaction, Workout } from '../types';

export const genId = (): string => Math.random().toString(36).slice(2, 9);

export const fmtBRL = (val: number): string =>
  (Number.isFinite(val) ? val : 0).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

export const getTodayISO = (): string => new Date().toISOString().slice(0, 10);

export const fmtDayMonth = (isoDate: string): string =>
  new Date(isoDate + 'T00:00:00').toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
  });

export function calcStreak(workouts: Workout[]): number {
  if (!workouts || workouts.length === 0) return 12; // Baseline consistency requested
  const dates = new Set(workouts.map((w) => w.date));
  let streak = 0;
  const d = new Date();
  const todayIso = d.toISOString().slice(0, 10);

  // If today is not yet done, check streak counting backwards from yesterday
  if (!dates.has(todayIso)) {
    d.setDate(d.getDate() - 1);
  }

  while (true) {
    const iso = d.toISOString().slice(0, 10);
    if (dates.has(iso)) {
      streak++;
      d.setDate(d.getDate() - 1);
    } else {
      break;
    }
  }
  return streak > 0 ? streak : 12;
}

export function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 6 || h >= 19) return 'Boa noite';
  if (h < 12) return 'Bom dia';
  return 'Boa tarde';
}

export function getDayOfYearIndex(mod: number): number {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const diff = now.getTime() - start.getTime();
  return Math.floor(diff / 86400000) % mod;
}

export const FINANCE_CATEGORIES: Record<
  string,
  { icon: React.FC<{ size?: number; color?: string }>; color: string }
> = {
  Moradia: { icon: HomeIcon, color: '#8B5CF6' },
  Alimentação: { icon: UtensilsIcon, color: '#F97316' },
  Transporte: { icon: CarIcon, color: '#3B82F6' },
  Lazer: { icon: GamepadIcon, color: '#EC4899' },
  Saúde: { icon: HeartPulseIcon, color: '#EF4444' },
  Educação: { icon: GraduationCapIcon, color: '#06B6D4' },
  Salário: { icon: BanknoteIcon, color: '#22C55E' },
  Outros: { icon: MoreHorizontalIcon, color: '#64748B' },
};

export const FINANCE_CATEGORY_NAMES = Object.keys(FINANCE_CATEGORIES);

export const WEEKDAYS_SHORT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export const DEFAULT_PRODUCTIVE_TASKS: ProductiveTask[] = [
  { id: 'p1', text: 'Beber água ao longo do dia', doneDates: [] },
  { id: 'p2', text: 'Revisar os gastos do dia', doneDates: [] },
  { id: 'p3', text: '30 minutos de atividade física', doneDates: [] },
  { id: 'p4', text: 'Definir as 3 prioridades de amanhã', doneDates: [] },
];

export const INVESTMENT_TYPES = [
  'Renda Fixa',
  'Fundos Imobiliários',
  'Cripto',
  'Ações',
  'Tesouro Direto',
  'Fundos',
  'Outro',
];

export const INVESTMENT_INSTITUTIONS = [
  'Nubank',
  'XP Investimentos',
  'Banco Inter',
  'Binance',
  'BTG Pactual',
  'C6 Bank',
  'Itaú',
  'Bradesco',
  'Outra',
];

export const INSTITUTION_BADGES: Record<
  string,
  { bg: string; text: string; border: string }
> = {
  Nubank: {
    bg: 'rgba(130, 10, 209, 0.18)',
    text: '#C084FC',
    border: 'rgba(130, 10, 209, 0.4)',
  },
  'XP Investimentos': {
    bg: 'rgba(245, 158, 11, 0.18)',
    text: '#FBBF24',
    border: 'rgba(245, 158, 11, 0.4)',
  },
  'Banco Inter': {
    bg: 'rgba(249, 115, 22, 0.18)',
    text: '#FB923C',
    border: 'rgba(249, 115, 22, 0.4)',
  },
  Binance: {
    bg: 'rgba(234, 179, 8, 0.18)',
    text: '#FDE047',
    border: 'rgba(234, 179, 8, 0.4)',
  },
};

export const DEFAULT_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1',
    desc: 'Salário Mensal',
    value: 5800,
    type: 'entrada',
    category: 'Salário',
    date: getTodayISO(),
    status: 'pago',
  },
  {
    id: 'tx-2',
    desc: 'Aluguel do Apartamento',
    value: 1650,
    type: 'saida',
    category: 'Moradia',
    date: getTodayISO(),
    status: 'pago',
  },
  {
    id: 'tx-3',
    desc: 'Supermercado Mensal',
    value: 840,
    type: 'saida',
    category: 'Alimentação',
    date: getTodayISO(),
    status: 'pago',
  },
  {
    id: 'tx-4',
    desc: 'Combustível / Transporte',
    value: 290,
    type: 'saida',
    category: 'Transporte',
    date: getTodayISO(),
    status: 'pago',
  },
  {
    id: 'tx-5',
    desc: 'Cursos & Educação',
    value: 220,
    type: 'saida',
    category: 'Educação',
    date: getTodayISO(),
    status: 'pago',
  },
  {
    id: 'tx-6',
    desc: 'Jantar com Família',
    value: 160,
    type: 'saida',
    category: 'Lazer',
    date: getTodayISO(),
    status: 'pendente',
  },
];

export const DEFAULT_INVESTMENTS: Investment[] = [
  {
    id: 'inv-nubank',
    institution: 'Nubank',
    name: 'Caixinha',
    type: 'Renda Fixa',
    value: 12500,
    yieldRate: '+100% CDI',
    liquidity: 'Diária (D+0)',
    date: getTodayISO(),
  },
  {
    id: 'inv-xp',
    institution: 'XP Investimentos',
    name: 'CDB Sofisa',
    type: 'Renda Fixa',
    value: 30000,
    yieldRate: '+12,5% a.a.',
    liquidity: 'Venc. 2027',
    date: getTodayISO(),
  },
  {
    id: 'inv-inter',
    institution: 'Banco Inter',
    name: 'MXRF11',
    type: 'Fundos Imobiliários',
    value: 8400,
    yieldRate: '+0,85% /mês',
    liquidity: 'D+2',
    date: getTodayISO(),
  },
  {
    id: 'inv-binance',
    institution: 'Binance',
    name: 'Bitcoin',
    type: 'Cripto',
    value: 5000,
    yieldRate: '+24,1%',
    liquidity: 'Imediata',
    date: getTodayISO(),
  },
];

export const NOTE_CATEGORIES: Record<
  string,
  { icon: React.FC<{ size?: number; color?: string }>; color: string }
> = {
  Trabalho: { icon: BriefcaseIcon, color: '#3B82F6' },
  Pessoal: { icon: UserIcon, color: '#8B5CF6' },
  Ideias: { icon: LightbulbIcon, color: '#F59E0B' },
  Metas: { icon: TargetIcon, color: '#10B981' },
  Finanças: { icon: WalletIcon, color: '#EC4899' },
  Oração: { icon: HeartIcon, color: '#F43F5E' },
};

export const NOTE_CATEGORY_NAMES = Object.keys(NOTE_CATEGORIES);

export const DEFAULT_NOTES: Note[] = [
  {
    id: 'note-1',
    title: 'Metas do Trimestre & Foco',
    content: '[x] Manter constância nos treinos 4x na semana com sobrecarga progressiva\n[ ] Aportar 20% da receita líquida em renda fixa e FIIs\n[x] Concluir leitura diária de 20 minutos de desenvolvimento\n[ ] Iniciar rotina de mobilidade articular matinal',
    category: 'Metas',
    date: getTodayISO(),
    updatedAt: new Date().toISOString(),
    isPinned: true,
    isArchived: false,
    isCollapsed: false,
    color: 'neon',
  },
  {
    id: 'note-2',
    title: 'Ideias para o Alicerce Hub',
    content: '[x] Novo layout de Bloco de Notas em Grade e Lista\n[x] Tags coloridas e filtros dinâmicos rápidos\n[x] Cards colapsáveis com pré-visualização\n[ ] Sincronização inteligente de lembretes\n• Explorar micro-interações táteis e feedback sonoro',
    category: 'Ideias',
    date: getTodayISO(),
    updatedAt: new Date().toISOString(),
    isPinned: true,
    isArchived: false,
    isCollapsed: false,
    color: 'cosmic',
  },
  {
    id: 'note-3',
    title: 'Alinhamento Semanal de Projetos',
    content: 'Revisar entregáveis da sprint técnica, validar backlog prioritário e agendar feedback de alinhamento estratégico na quinta-feira com os líderes.',
    category: 'Trabalho',
    date: getTodayISO(),
    updatedAt: new Date().toISOString(),
    isPinned: false,
    isArchived: false,
    isCollapsed: false,
    color: 'ocean',
  },
  {
    id: 'note-4',
    title: 'Revisão Orçamentária & Aportes',
    content: '[x] Conferir fechamento das faturas de cartão\n[ ] Checar rendimentos no CDI e dividendos de FIIs\n[ ] Transferir aporte para a reserva de oportunidade',
    category: 'Finanças',
    date: getTodayISO(),
    updatedAt: new Date().toISOString(),
    isPinned: false,
    isArchived: false,
    isCollapsed: false,
    color: 'gold',
  },
  {
    id: 'note-5',
    title: 'Rotina Matinal de Alta Performance',
    content: 'Hidratação (500ml de água mineral), 10 minutos de alongamento dinâmico, respiração controlada diafragmática e café sem açúcar.',
    category: 'Pessoal',
    date: getTodayISO(),
    updatedAt: new Date().toISOString(),
    isPinned: false,
    isArchived: false,
    isCollapsed: false,
    color: 'neutral',
  },
];

export interface NavTabConfig {
  id: TabId;
  label: string;
  icon: React.FC<{ size?: number; color?: string }>;
  c1: string;
  c2: string;
  glow: string;
}

export const NAV_TABS: NavTabConfig[] = [
  {
    id: 'financas',
    label: 'Finanças',
    icon: WalletIcon,
    c1: '#3B82F6',
    c2: '#06B6D4',
    glow: 'rgba(59,130,246,0.55)',
  },
  {
    id: 'treino',
    label: 'Treino',
    icon: DumbbellIcon,
    c1: '#EC4899',
    c2: '#F97316',
    glow: 'rgba(236,72,153,0.5)',
  },
  {
    id: 'inicio',
    label: 'Início',
    icon: SparklesIcon,
    c1: '#22D3EE',
    c2: '#8B5CF6',
    glow: 'rgba(34,211,238,0.5)',
  },
  {
    id: 'notas',
    label: 'Notas',
    icon: FileTextIcon,
    c1: '#8B5CF6',
    c2: '#6366F1',
    glow: 'rgba(139,92,246,0.5)',
  },
  {
    id: 'dicas',
    label: 'Dicas',
    icon: LightbulbIcon,
    c1: '#F59E0B',
    c2: '#FDE047',
    glow: 'rgba(245,158,11,0.5)',
  },
];

export interface PhraseItem {
  id: string;
  text: string;
  type: 'motivacional' | 'versiculo';
  authorOrRef: string;
}

export const DAILY_PHRASES: PhraseItem[] = [
  {
    id: 'biblical_salmos_28_7',
    text: 'O Senhor é a minha força e o meu escudo.',
    type: 'versiculo',
    authorOrRef: 'Salmos 28:7',
  },
  {
    id: 'v1',
    text: 'O Senhor é o meu pastor; nada me faltará.',
    type: 'versiculo',
    authorOrRef: 'Salmos 23:1',
  },
  {
    id: 'm1',
    text: 'Pequenos passos diários constroem grandes conquistas.',
    type: 'motivacional',
    authorOrRef: 'Constância',
  },
  {
    id: 'v2',
    text: 'Tudo posso naquele que me fortalece.',
    type: 'versiculo',
    authorOrRef: 'Filipenses 4:13',
  },
  {
    id: 'm2',
    text: 'Disciplina é escolher entre o que você quer agora e o que mais deseja.',
    type: 'motivacional',
    authorOrRef: 'Foco',
  },
  {
    id: 'v3',
    text: 'Consagre ao Senhor tudo o que você faz, e seus planos serão bem-sucedidos.',
    type: 'versiculo',
    authorOrRef: 'Provérbios 16:3',
  },
  {
    id: 'm3',
    text: 'Cuide do seu dinheiro hoje para ter mais liberdade e paz amanhã.',
    type: 'motivacional',
    authorOrRef: 'Finanças',
  },
  {
    id: 'v4',
    text: 'Seja forte e corajoso! Não se apavore, pois o Senhor está com você.',
    type: 'versiculo',
    authorOrRef: 'Josué 1:9',
  },
  {
    id: 'm4',
    text: 'Progresso supera perfeição em qualquer jornada.',
    type: 'motivacional',
    authorOrRef: 'Evolução',
  },
  {
    id: 'v5',
    text: 'O coração em paz dá vida e saúde ao corpo.',
    type: 'versiculo',
    authorOrRef: 'Provérbios 14:30',
  },
  {
    id: 'm5',
    text: 'O corpo alcança o que a mente decide perseverar.',
    type: 'motivacional',
    authorOrRef: 'Saúde',
  },
  {
    id: 'v6',
    text: 'Os que esperam no Senhor renovam as suas forças.',
    type: 'versiculo',
    authorOrRef: 'Isaías 40:31',
  },
  {
    id: 'm6',
    text: 'Organize hoje o que o seu futuro eu vai se orgulhar de ter começado.',
    type: 'motivacional',
    authorOrRef: 'Propósito',
  },
  {
    id: 'v7',
    text: 'O plano bem elaborado leva certamente à fartura.',
    type: 'versiculo',
    authorOrRef: 'Provérbios 21:5',
  },
  {
    id: 'm7',
    text: 'Foco na rota — os resultados consistentes são pura consequência.',
    type: 'motivacional',
    authorOrRef: 'Dedicação',
  },
  {
    id: 'v8',
    text: 'Lâmpada para os meus pés é a tua palavra, e luz para o meu caminho.',
    type: 'versiculo',
    authorOrRef: 'Salmos 119:105',
  },
  {
    id: 'm8',
    text: 'A melhor hora para agir foi ontem; a segunda melhor é agora.',
    type: 'motivacional',
    authorOrRef: 'Atitude',
  },
];

export const INSPIRATIONAL_QUOTES = [
  'Pequenos passos todos os dias constroem grandes resultados.',
  'Disciplina é escolher entre o que você quer agora e o que você quer mais.',
  'Cuide do seu dinheiro hoje para ter mais liberdade amanhã.',
  'Seu corpo ouve tudo que sua mente diz — seja gentil e constante.',
  'Progresso, não perfeição.',
  'Cada real guardado é um passo rumo à sua liberdade financeira.',
  'O único treino ruim é aquele que não aconteceu.',
  'Organize hoje o que o seu eu do futuro vai agradecer.',
  'Foco no processo — os resultados são consequência.',
  'Você não precisa ser perfeito, só precisa ser constante.',
  'Um orçamento é só um plano para gastar seu dinheiro com intenção.',
  'Descanso também é parte do treino.',
  'A melhor hora para começar foi ontem. A segunda melhor é agora.',
  'Metas pequenas e diárias vencem grandes intenções esquecidas.',
];

export function getDailyQuote(): string {
  return INSPIRATIONAL_QUOTES[getDayOfYearIndex(INSPIRATIONAL_QUOTES.length)];
}

export interface TipSection {
  id: string;
  title: string;
  color: string;
  tips: string[];
}

export const TIPS_SECTIONS: TipSection[] = [
  {
    id: 'orcamento',
    title: 'Orçamento pessoal',
    color: '#F59E0B',
    tips: [
      'Regra 50/30/20: 50% para necessidades, 30% para desejos e 20% para poupança ou dívidas.',
      'Anote todo gasto, até os pequenos, por 30 dias seguidos para enxergar seus padrões reais.',
      'Mantenha uma reserva de emergência de 3 a 6 meses das suas despesas fixas.',
      'Automatize uma transferência para a poupança logo no dia em que o salário cai.',
    ],
  },
  {
    id: 'habitos',
    title: 'Hábitos financeiros',
    color: '#38BDF8',
    tips: [
      'Espere 24 horas antes de compras por impulso acima de um valor que você definir.',
      'Revise assinaturas e serviços recorrentes a cada três meses e corte o que não usa.',
      'Negocie contas fixas, como internet e plano de celular, pelo menos uma vez por ano.',
      'Use lista de compras no mercado para evitar gastos supérfluos.',
    ],
  },
  {
    id: 'bemestar',
    title: 'Bem-estar e rotina',
    color: '#EC4899',
    tips: [
      'Durma e acorde em horários regulares, mesmo nos fins de semana.',
      'Reserve de 20 a 30 minutos de atividade física por dia, nem que seja uma caminhada.',
      'Beba água ao longo do dia, em vez de esperar sentir sede.',
      'Faça pausas curtas a cada 60 ou 90 minutos de trabalho concentrado.',
    ],
  },
  {
    id: 'produtividade',
    title: 'Produtividade e vida pessoal',
    color: '#8B5CF6',
    tips: [
      'Defina 3 prioridades no início de cada dia, não 10.',
      'Separe um horário fixo por semana só para organizar finanças e tarefas.',
      'Pratique dizer não a compromissos que não são realmente prioridade.',
      'Revise suas metas do mês e ajuste o que não está funcionando.',
    ],
  },
];

export function getDailyTip(): { text: string; color: string; cat: string } {
  const all = TIPS_SECTIONS.flatMap((sec) =>
    sec.tips.map((t) => ({ text: t, color: sec.color, cat: sec.title }))
  );
  return all[getDayOfYearIndex(all.length)];
}

export function getWeatherConditionInfo(code: number): {
  label: string;
  Icon: React.FC<{ size?: number; color?: string; className?: string }>;
  color: string;
  g1: string;
  g2: string;
} {
  if (code === 0) {
    return {
      label: 'Céu limpo',
      Icon: SunIcon,
      color: '#FBBF24',
      g1: 'rgba(250,204,21,0.28)',
      g2: 'rgba(249,115,22,0.12)',
    };
  }
  if ([1, 2, 3].includes(code)) {
    return {
      label: 'Parcialmente nublado',
      Icon: CloudIcon,
      color: '#CBD5E1',
      g1: 'rgba(148,163,184,0.28)',
      g2: 'rgba(100,116,139,0.12)',
    };
  }
  if ([45, 48].includes(code)) {
    return {
      label: 'Névoa',
      Icon: CloudFogIcon,
      color: '#94A3B8',
      g1: 'rgba(148,163,184,0.22)',
      g2: 'rgba(100,116,139,0.1)',
    };
  }
  if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(code)) {
    return {
      label: 'Chuva',
      Icon: CloudRainIcon,
      color: '#38BDF8',
      g1: 'rgba(56,189,248,0.3)',
      g2: 'rgba(37,99,235,0.14)',
    };
  }
  if ([71, 73, 75, 85, 86].includes(code)) {
    return {
      label: 'Neve',
      Icon: CloudSnowIcon,
      color: '#E0F2FE',
      g1: 'rgba(224,242,254,0.32)',
      g2: 'rgba(186,230,253,0.12)',
    };
  }
  if ([95, 96, 99].includes(code)) {
    return {
      label: 'Trovoada',
      Icon: CloudLightningIcon,
      color: '#A78BFA',
      g1: 'rgba(139,92,246,0.32)',
      g2: 'rgba(79,70,229,0.14)',
    };
  }
  return {
    label: 'Tempo estável',
    Icon: CloudIcon,
    color: '#CBD5E1',
    g1: 'rgba(148,163,184,0.22)',
    g2: 'rgba(100,116,139,0.1)',
  };
}

export const NIGHT_WEATHER_STYLE = {
  g1: 'rgba(99,102,241,0.28)',
  g2: 'rgba(30,27,75,0.35)',
  color: '#C7D2FE',
};

export interface WorkoutExerciseItem {
  name: string;
  setsReps: string;
  suggestedWeight?: string;
}

export interface WorkoutProgramOption {
  id: string;
  title: string;
  category: 'academia' | 'casa';
  duration: string;
  durationEstimate: string;
  focus: string;
  durationMinutes: number;
  exercisesCount: number;
  exercises: WorkoutExerciseItem[];
}

export const WORKOUT_PROGRAM_INFO = {
  currentProgram: 'Divisão ABC & Funcional',
  targetDaysWeekly: 5,
};

export const WORKOUT_OPTIONS: WorkoutProgramOption[] = [
  // --- ACADEMIA (Hipertrofia & Aparelhos) ---
  {
    id: 'A_ACADEMIA',
    title: 'Treino A - Peito, Ombro e Tríceps',
    category: 'academia',
    duration: '50 min',
    durationEstimate: '50 min',
    focus: 'Empurrar (Push)',
    durationMinutes: 50,
    exercisesCount: 6,
    exercises: [
      { name: 'Supino Reto com Barra', setsReps: '4 séries x 8-10 reps', suggestedWeight: '60kg' },
      { name: 'Supino Inclinado com Halteres', setsReps: '3 séries x 10-12 reps', suggestedWeight: '22kg' },
      { name: 'Crucifixo / Crossover na Polia', setsReps: '3 séries x 12 reps', suggestedWeight: '15kg' },
      { name: 'Desenvolvimento Militar Halteres', setsReps: '4 séries x 8-10 reps', suggestedWeight: '18kg' },
      { name: 'Elevação Lateral com Halteres', setsReps: '4 séries x 12-15 reps', suggestedWeight: '10kg' },
      { name: 'Tríceps Corda na Polia', setsReps: '4 séries x 10-12 reps', suggestedWeight: '25kg' },
    ],
  },
  {
    id: 'B_ACADEMIA',
    title: 'Treino B - Costas, Bíceps e Trapézio',
    category: 'academia',
    duration: '55 min',
    durationEstimate: '55 min',
    focus: 'Puxar (Pull)',
    durationMinutes: 55,
    exercisesCount: 6,
    exercises: [
      { name: 'Puxada Alta Aberta no Pulley', setsReps: '4 séries x 8-10 reps', suggestedWeight: '55kg' },
      { name: 'Remada Curvada com Barra', setsReps: '4 séries x 8-10 reps', suggestedWeight: '50kg' },
      { name: 'Remada Baixa no Triângulo', setsReps: '3 séries x 10-12 reps', suggestedWeight: '45kg' },
      { name: 'Rosca Direta Barra W', setsReps: '3 séries x 10-12 reps', suggestedWeight: '24kg' },
      { name: 'Rosca Martelo com Halteres', setsReps: '3 séries x 12 reps', suggestedWeight: '14kg' },
      { name: 'Encolhimento com Halteres', setsReps: '4 séries x 12-15 reps', suggestedWeight: '26kg' },
    ],
  },
  {
    id: 'C_ACADEMIA',
    title: 'Treino C - Pernas Completas e Abdômen',
    category: 'academia',
    duration: '60 min',
    durationEstimate: '60 min',
    focus: 'Membros Inferiores & Core',
    durationMinutes: 60,
    exercisesCount: 7,
    exercises: [
      { name: 'Agachamento Livre com Barra', setsReps: '4 séries x 8-10 reps', suggestedWeight: '70kg' },
      { name: 'Leg Press 45° Articulado', setsReps: '4 séries x 10-12 reps', suggestedWeight: '160kg' },
      { name: 'Cadeira Extensora', setsReps: '3 séries x 12-15 reps', suggestedWeight: '45kg' },
      { name: 'Mesa Flexora Posterior', setsReps: '4 séries x 10-12 reps', suggestedWeight: '40kg' },
      { name: 'Panturrilha em Pé no Degrau', setsReps: '4 séries x 15-20 reps', suggestedWeight: 'P.C.' },
      { name: 'Prancha Abdominal Isométrica', setsReps: '3 séries x 45 seg' },
      { name: 'Abdominal Infra na Paralela', setsReps: '3 séries x 15 reps' },
    ],
  },
  {
    id: 'CARDIO_ACADEMIA',
    title: 'Cardio & Mobilidade Regenerativa',
    category: 'academia',
    duration: '30 min',
    durationEstimate: '30 min',
    focus: 'Recuperação Ativa',
    durationMinutes: 30,
    exercisesCount: 3,
    exercises: [
      { name: 'Esteira HIIT / Inclinação Moderada', setsReps: '20 min contínuos' },
      { name: 'Mobilidade Articular de Quadril e Torácica', setsReps: '5 min fluxo dinâmico' },
      { name: 'Alongamento Miofascial e Descompressão', setsReps: '5 min' },
    ],
  },

  // --- EM CASA (Calistenia, Bodyweight & Funcional) ---
  {
    id: 'A_CASA',
    title: 'Treino A - Corpo Inteiro & Core (Full Body)',
    category: 'casa',
    duration: '40 min',
    durationEstimate: '40 min',
    focus: 'Funcional & Peso do Corpo',
    durationMinutes: 40,
    exercisesCount: 6,
    exercises: [
      { name: 'Flexões de Braço no Solo (Push-ups)', setsReps: '4 séries x 12-15 reps' },
      { name: 'Agachamento Livre (Air Squats)', setsReps: '4 séries x 20 reps' },
      { name: 'Afundo Alternado com Pausa (Lunges)', setsReps: '3 séries x 12 reps cada perna' },
      { name: 'Prancha Abdominal Isométrica', setsReps: '3 séries x 60 seg' },
      { name: 'Superman Lombar no Chão', setsReps: '3 séries x 15 reps' },
      { name: 'Polichinelos de Alta Intensidade', setsReps: '3 séries x 45 seg' },
    ],
  },
  {
    id: 'B_CASA',
    title: 'Treino B - Membros Superiores e Cardio',
    category: 'casa',
    duration: '35 min',
    durationEstimate: '35 min',
    focus: 'Resistência & Queima Calórica',
    durationMinutes: 35,
    exercisesCount: 6,
    exercises: [
      { name: 'Flexão Diamante ou Inclinada no Apoio', setsReps: '3 séries x 10-12 reps' },
      { name: 'Mergulho no Banco / Cadeira (Dips)', setsReps: '3 séries x 12-15 reps' },
      { name: 'Mountain Climbers (Escaladores)', setsReps: '4 séries x 45 seg' },
      { name: 'Elevação Lateral com Carga Leve/Garrafas', setsReps: '3 séries x 15-20 reps' },
      { name: 'Remada Invertida na Mesa / Toalha', setsReps: '4 séries x 10-12 reps' },
      { name: 'Corrida Estacionária com Joelhos Altos', setsReps: '3 séries x 45 seg' },
    ],
  },
  {
    id: 'C_CASA',
    title: 'Treino C - Pernas, Glúteos & Abdômen',
    category: 'casa',
    duration: '40 min',
    durationEstimate: '40 min',
    focus: 'Inferiores & Estabilidade',
    durationMinutes: 40,
    exercisesCount: 6,
    exercises: [
      { name: 'Agachamento Búlgaro no Sofá/Cadeira', setsReps: '3 séries x 10 reps cada perna' },
      { name: 'Elevação Pélvica de Quadril (Glute Bridge)', setsReps: '4 séries x 15-20 reps' },
      { name: 'Panturrilha Unilateral no Degrau', setsReps: '4 séries x 20 reps cada pé' },
      { name: 'Prancha Lateral com Apoio de Cotovelo', setsReps: '3 séries x 35 seg cada lado' },
      { name: 'Abdominal Bicicleta Cruzado', setsReps: '3 séries x 20 reps' },
      { name: 'Alongamento Dinâmico de Isquiotibiais', setsReps: '5 min desaquecimento' },
    ],
  },
];

export function calculateExerciseVolume(setsReps?: string, weightStr?: string): number {
  if (!weightStr) return 0;
  // Parse weight: e.g. "60kg", "22kg", "2.5kg"
  const weightMatch = weightStr.match(/(\d+(?:[.,]\d+)?)/);
  if (!weightMatch) return 0;
  const weight = parseFloat(weightMatch[1].replace(',', '.'));
  if (isNaN(weight) || weight <= 0) return 0;

  let sets = 3;
  let reps = 10;
  if (setsReps) {
    const setsMatch = setsReps.match(/(\d+)\s*(?:séries?|sets?|x)/i);
    if (setsMatch) {
      sets = parseInt(setsMatch[1], 10) || 3;
    }
    const repsMatch =
      setsReps.match(/x\s*(\d+)(?:-(\d+))?/i) ||
      setsReps.match(/(\d+)(?:-(\d+))?\s*reps?/i);
    if (repsMatch) {
      const minReps = parseInt(repsMatch[1], 10);
      const maxReps = repsMatch[2] ? parseInt(repsMatch[2], 10) : minReps;
      reps = Math.round((minReps + maxReps) / 2);
    }
  }
  return Math.round(sets * reps * weight);
}

export function calculateProgramTotalVolume(program: WorkoutProgramOption): number {
  let total = 0;
  if (Array.isArray(program.exercises)) {
    for (const ex of program.exercises) {
      total += calculateExerciseVolume(ex.setsReps, ex.suggestedWeight);
    }
  }
  if (total > 0) return total;
  if (program.category === 'casa') return 2400;
  return program.durationMinutes ? program.durationMinutes * 120 : 6000;
}

export function getWorkoutTotalVolume(
  workout: Workout,
  programs: WorkoutProgramOption[] = WORKOUT_OPTIONS
): number {
  if (workout.isRestDay) return 0;
  if (typeof workout.totalVolumeKg === 'number' && workout.totalVolumeKg > 0) {
    return workout.totalVolumeKg;
  }

  // Parse loadNote if present: e.g. "Supino: 60kg | Leg Press: 160kg"
  if (workout.loadNote) {
    let parsedSum = 0;
    const items = workout.loadNote.split('|');
    for (const item of items) {
      const weightMatch = item.match(/(\d+(?:[.,]\d+)?)\s*kg/i);
      const repsMatch = item.match(/(\d+)\s*reps?/i);
      if (weightMatch) {
        const weight = parseFloat(weightMatch[1].replace(',', '.'));
        const reps = repsMatch ? parseInt(repsMatch[1], 10) : 10;
        parsedSum += Math.round(3 * reps * weight);
      }
    }
    if (parsedSum > 0) return parsedSum;
  }

  // Match by name against available workout options
  const matched = programs.find((p) =>
    workout.name.toLowerCase().includes(p.title.toLowerCase()) ||
    p.title.toLowerCase().includes(workout.name.toLowerCase())
  );
  if (matched) {
    return calculateProgramTotalVolume(matched);
  }

  // Default estimate based on workout duration
  const mins = workout.durationMinutes || 45;
  return mins * 130;
}

export function fmtVolumeKg(volume: number): string {
  if (!volume || volume <= 0) return '0 kg';
  return `${volume.toLocaleString('pt-BR')} kg`;
}

export function getDefaultWorkouts(): Workout[] {
  const getOffsetDate = (daysAgo: number) => {
    const d = new Date();
    d.setDate(d.getDate() - daysAgo);
    return d.toISOString().slice(0, 10);
  };

  return [
    {
      id: 'w-hist-1',
      name: 'Treino C - Pernas Completas e Abdômen',
      date: getOffsetDate(1), // Ontem
      durationMinutes: 60,
      focus: 'Membros Inferiores & Core',
      loadNote: 'Agachamento: 70kg | Leg Press: 160kg | Extensora: 45kg',
      totalVolumeKg: 8420,
      isRestDay: false,
    },
    {
      id: 'w-hist-2',
      name: 'Treino B - Costas, Bíceps e Trapézio',
      date: getOffsetDate(2), // 2 dias atrás
      durationMinutes: 55,
      focus: 'Puxar (Pull)',
      loadNote: 'Puxada Alta: 55kg | Remada Curvada: 50kg | Rosca W: 24kg',
      totalVolumeKg: 6850,
      isRestDay: false,
    },
    {
      id: 'w-hist-3',
      name: 'Treino A - Peito, Ombro e Tríceps',
      date: getOffsetDate(4), // 4 dias atrás
      durationMinutes: 50,
      focus: 'Empurrar (Push)',
      loadNote: 'Supino Reto: 60kg | Inclinado: 22kg | Tríceps Corda: 25kg',
      totalVolumeKg: 6280,
      isRestDay: false,
    },
    {
      id: 'w-hist-4',
      name: 'Treino C - Pernas Completas e Abdômen',
      date: getOffsetDate(5), // 5 dias atrás
      durationMinutes: 55,
      focus: 'Membros Inferiores & Core',
      loadNote: 'Agachamento: 70kg | Mesa Flexora: 40kg | Leg Press: 150kg',
      totalVolumeKg: 7950,
      isRestDay: false,
    },
    {
      id: 'w-hist-5',
      name: 'Treino B - Costas, Bíceps e Trapézio',
      date: getOffsetDate(6), // 6 dias atrás
      durationMinutes: 50,
      focus: 'Puxar (Pull)',
      loadNote: 'Puxada Aberta: 50kg | Remada Baixa: 45kg | Rosca Martelo: 14kg',
      totalVolumeKg: 6540,
      isRestDay: false,
    },
  ];
}


