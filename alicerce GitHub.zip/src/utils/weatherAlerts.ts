import { WeatherData } from '../types';

export type AlertSeverity = 'warning' | 'severe';
export type AlertCategory = 'heat' | 'rain' | 'storm' | 'wind' | 'cold' | 'dry';

export interface WeatherAlert {
  id: string;
  category: AlertCategory;
  severity: AlertSeverity;
  title: string;
  badge: string;
  headline: string;
  metricDetails: string;
  recommendation: string;
  color: string;
  textColor: string;
  bgColor: string;
  borderColor: string;
  glowColor: string;
}

/**
 * Dynamically evaluates fetched weather data to detect severe weather conditions:
 * - Heat waves / extreme high temperatures
 * - Heavy torrential rain / thunderstorms / hail
 * - High winds / gale-force gusts
 * - Extreme freezing cold
 * - Critical air dryness / low humidity
 */
export function detectWeatherAlert(data: WeatherData | null): WeatherAlert | null {
  if (!data || !data.current) return null;

  const current = data.current;
  const temp = current.temperature_2m;
  const apparentTemp = current.apparent_temperature;
  const code = current.weather_code;
  const wind = current.wind_speed_10m;
  const humidity = current.relative_humidity_2m;
  const dailyMax = data.daily?.temperature_2m_max?.[0] ?? temp;

  // 1. Tempestade Severa / Trovoadas com raios ou granizo (Codes 95, 96, 99)
  if ([95, 96, 99].includes(code)) {
    return {
      id: 'storm-severe',
      category: 'storm',
      severity: 'severe',
      title: 'Alerta de Tempestade Severa',
      badge: 'Severo · Trovoadas',
      headline: 'Risco iminente de raios, rajadas intensas de vento e granizo.',
      metricDetails: `Condição de trovoada ativa (cód. ${code}) com ventos de ${Math.round(wind)} km/h.`,
      recommendation: 'Procure abrigo seguro imediatamente, evite áreas abertas e desconecte aparelhos da tomada.',
      color: '#A855F7',
      textColor: '#FAF5FF',
      bgColor: 'rgba(168, 85, 247, 0.22)',
      borderColor: 'rgba(168, 85, 247, 0.55)',
      glowColor: 'rgba(168, 85, 247, 0.4)',
    };
  }

  // 2. Chuva Forte / Torrencial (Code 65 = Chuva forte, Code 82 = Pancada violenta de chuva)
  // Ou chuva contínua (63) combinada com vento forte ou saturação de umidade
  if ([65, 82].includes(code) || ([63, 81].includes(code) && (humidity >= 85 || wind >= 30))) {
    const isViolent = code === 82 || (code === 65 && wind >= 25);
    return {
      id: 'heavy-rain',
      category: 'rain',
      severity: isViolent ? 'severe' : 'warning',
      title: isViolent ? 'Alerta de Chuva Torrencial' : 'Alerta de Chuva Forte',
      badge: isViolent ? 'Severo · Chuva Intensa' : 'Atenção · Chuva Volumosa',
      headline: 'Precipitação volumosa em andamento com alto acúmulo de água.',
      metricDetails: `Precipitação forte (cód. ${code}), umidade em ${humidity}% e ventos de ${Math.round(wind)} km/h.`,
      recommendation: 'Atenção a pontos de alagamento, reduza a velocidade nas pistas e evite trafegar por ruas inundadas.',
      color: '#0284C7',
      textColor: '#F0F9FF',
      bgColor: 'rgba(2, 132, 199, 0.22)',
      borderColor: 'rgba(56, 189, 248, 0.55)',
      glowColor: 'rgba(56, 189, 248, 0.4)',
    };
  }

  // 3. Onda de Calor / Calor Extremo (Heat Wave)
  // Gatilhos: temperatura >= 34°C, ou sensação térmica >= 38°C, ou máxima diária >= 36°C com temp >= 32°C
  if (temp >= 34 || apparentTemp >= 38 || (dailyMax >= 36 && temp >= 31)) {
    const isExtreme = temp >= 38 || apparentTemp >= 41;
    return {
      id: 'heat-wave',
      category: 'heat',
      severity: isExtreme ? 'severe' : 'warning',
      title: isExtreme ? 'Alerta de Calor Extremo' : 'Alerta de Onda de Calor',
      badge: isExtreme ? 'Severo · Calor Extremo' : 'Atenção · Onda de Calor',
      headline: isExtreme
        ? 'Temperaturas críticas que podem causar estresse térmico severo.'
        : 'Condições de forte calor acima da média sazonal.',
      metricDetails: `Temperatura de ${Math.round(temp)}°C com sensação térmica de ${Math.round(apparentTemp)}°C (Máx ${Math.round(dailyMax)}°C).`,
      recommendation: 'Beba bastante água, evite exposição solar direta entre 10h e 16h e permaneça em locais ventilados.',
      color: '#F97316',
      textColor: '#FFF7ED',
      bgColor: isExtreme ? 'rgba(239, 68, 68, 0.25)' : 'rgba(249, 115, 22, 0.22)',
      borderColor: isExtreme ? 'rgba(239, 68, 68, 0.6)' : 'rgba(249, 115, 22, 0.5)',
      glowColor: isExtreme ? 'rgba(239, 68, 68, 0.45)' : 'rgba(249, 115, 22, 0.35)',
    };
  }

  // 4. Vendaval / Ventos Fortes
  if (wind >= 45) {
    const isGale = wind >= 60;
    return {
      id: 'high-winds',
      category: 'wind',
      severity: isGale ? 'severe' : 'warning',
      title: isGale ? 'Alerta de Vendaval Severo' : 'Alerta de Ventos Fortes',
      badge: isGale ? 'Severo · Vendaval' : 'Atenção · Rajadas de Vento',
      headline: 'Rajadas intensas de vento com risco de quedas de galhos e objetos.',
      metricDetails: `Velocidade do vento registrada em ${Math.round(wind)} km/h.`,
      recommendation: 'Não estacione veículos sob árvores ou placas, e recolha itens soltos em varandas e quintais.',
      color: '#EAB308',
      textColor: '#FEFCE8',
      bgColor: 'rgba(234, 179, 8, 0.22)',
      borderColor: 'rgba(234, 179, 8, 0.55)',
      glowColor: 'rgba(234, 179, 8, 0.35)',
    };
  }

  // 5. Frio Extremo / Queda Brusca de Temperatura (<= 5°C or apparent <= 3°C)
  if (temp <= 5 || apparentTemp <= 3) {
    const isFreezing = temp <= 2 || apparentTemp <= 0;
    return {
      id: 'extreme-cold',
      category: 'cold',
      severity: isFreezing ? 'severe' : 'warning',
      title: isFreezing ? 'Alerta de Frio Extremo / Geada' : 'Alerta de Baixas Temperaturas',
      badge: isFreezing ? 'Severo · Frio Extremo' : 'Atenção · Frio Intenso',
      headline: 'Temperaturas rigorosas com risco de hipotermia e geada.',
      metricDetails: `Temperatura de ${Math.round(temp)}°C com sensação de ${Math.round(apparentTemp)}°C.`,
      recommendation: 'Vista-se em camadas térmicas, proteja extremidades e abrigue animais domésticos.',
      color: '#38BDF8',
      textColor: '#F0F9FF',
      bgColor: 'rgba(56, 189, 248, 0.22)',
      borderColor: 'rgba(56, 189, 248, 0.55)',
      glowColor: 'rgba(56, 189, 248, 0.35)',
    };
  }

  // 6. Umidade Crítica do Ar (<= 20% com calor)
  if (humidity <= 20 && temp >= 26) {
    return {
      id: 'low-humidity',
      category: 'dry',
      severity: humidity <= 14 ? 'severe' : 'warning',
      title: 'Alerta de Baixa Umidade do Ar',
      badge: 'Atenção · Umidade Crítica',
      headline: 'Ar muito seco trazendo desconforto respiratório e risco de incêndios.',
      metricDetails: `Umidade relativa em apenas ${humidity}% com temperatura de ${Math.round(temp)}°C.`,
      recommendation: 'Hidrate-se com frequência, lave narinas com soro fisiológico e evite queimadas ou exercícios ao sol.',
      color: '#F59E0B',
      textColor: '#FFFBEB',
      bgColor: 'rgba(245, 158, 11, 0.22)',
      borderColor: 'rgba(245, 158, 11, 0.55)',
      glowColor: 'rgba(245, 158, 11, 0.35)',
    };
  }

  return null;
}

/**
 * Pre-configured simulated scenarios for testing and demonstration
 */
export const SIMULATED_WEATHER_SCENARIOS: Record<string, { label: string; icon: string; data: WeatherData }> = {
  heat_wave: {
    label: 'Onda de Calor (38°C)',
    icon: '🔥',
    data: {
      name: 'Cuiabá',
      admin1: 'Mato Grosso',
      current: {
        temperature_2m: 38.4,
        apparent_temperature: 42.6,
        relative_humidity_2m: 28,
        weather_code: 0,
        wind_speed_10m: 14.5,
      },
      daily: {
        temperature_2m_max: [39.5, 38.8, 38.2, 37.5, 36.9],
        temperature_2m_min: [25.1, 24.8, 25.0, 24.5, 24.2],
        weather_code: [0, 1, 1, 0, 1],
        sunrise: [new Date().toISOString()],
        sunset: [new Date().toISOString()],
      },
      hourly: {
        time: Array.from({ length: 12 }, (_, i) => new Date(Date.now() + i * 3600000).toISOString()),
        temperature_2m: [35, 36, 38, 38.4, 38.0, 36.5, 34.0, 32.1, 30.2, 29.0, 28.1, 27.5],
        weather_code: [0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0],
      },
    },
  },
  heavy_rain: {
    label: 'Chuva Forte (Belém)',
    icon: '🌧️',
    data: {
      name: 'Belém',
      admin1: 'Pará',
      current: {
        temperature_2m: 26.2,
        apparent_temperature: 29.8,
        relative_humidity_2m: 94,
        weather_code: 65, // Heavy Rain
        wind_speed_10m: 28.5,
      },
      daily: {
        temperature_2m_max: [28.0, 27.5, 29.0, 28.5, 29.2],
        temperature_2m_min: [23.1, 22.8, 23.0, 23.5, 23.2],
        weather_code: [65, 82, 63, 80, 61],
        sunrise: [new Date().toISOString()],
        sunset: [new Date().toISOString()],
      },
      hourly: {
        time: Array.from({ length: 12 }, (_, i) => new Date(Date.now() + i * 3600000).toISOString()),
        temperature_2m: [26.2, 25.8, 25.4, 25.0, 25.2, 25.5, 26.0, 26.1, 25.9, 25.5, 25.2, 25.0],
        weather_code: [65, 65, 82, 65, 63, 61, 80, 80, 61, 61, 3, 3],
      },
    },
  },
  severe_storm: {
    label: 'Tempestade com Raios',
    icon: '⚡',
    data: {
      name: 'Campinas',
      admin1: 'São Paulo',
      current: {
        temperature_2m: 23.5,
        apparent_temperature: 24.8,
        relative_humidity_2m: 91,
        weather_code: 95, // Thunderstorm
        wind_speed_10m: 48.0,
      },
      daily: {
        temperature_2m_max: [25.0, 26.0, 27.0, 28.0, 26.5],
        temperature_2m_min: [18.2, 19.0, 18.5, 19.2, 18.0],
        weather_code: [95, 80, 61, 2, 1],
        sunrise: [new Date().toISOString()],
        sunset: [new Date().toISOString()],
      },
      hourly: {
        time: Array.from({ length: 12 }, (_, i) => new Date(Date.now() + i * 3600000).toISOString()),
        temperature_2m: [23.5, 22.8, 22.0, 21.5, 21.0, 21.2, 21.5, 22.0, 22.2, 22.5, 22.0, 21.8],
        weather_code: [95, 95, 96, 82, 65, 61, 80, 3, 2, 1, 0, 0],
      },
    },
  },
  gale_winds: {
    label: 'Vendaval (58 km/h)',
    icon: '💨',
    data: {
      name: 'Rio Grande',
      admin1: 'Rio Grande do Sul',
      current: {
        temperature_2m: 17.5,
        apparent_temperature: 15.0,
        relative_humidity_2m: 76,
        weather_code: 3,
        wind_speed_10m: 58.2,
      },
      daily: {
        temperature_2m_max: [19.0, 20.0, 21.0, 20.5, 19.5],
        temperature_2m_min: [13.0, 14.0, 13.5, 14.2, 13.8],
        weather_code: [3, 2, 1, 1, 0],
        sunrise: [new Date().toISOString()],
        sunset: [new Date().toISOString()],
      },
      hourly: {
        time: Array.from({ length: 12 }, (_, i) => new Date(Date.now() + i * 3600000).toISOString()),
        temperature_2m: [17.5, 17.0, 16.5, 16.0, 15.8, 15.5, 15.2, 15.0, 14.8, 14.5, 14.2, 14.0],
        weather_code: [3, 3, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0],
      },
    },
  },
};
