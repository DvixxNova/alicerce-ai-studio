export type TabId = 'inicio' | 'financas' | 'notas' | 'treino' | 'dicas' | 'radar';

export interface Transaction {
  id: string;
  desc: string;
  value: number;
  type: 'entrada' | 'saida';
  category: string;
  date: string; // YYYY-MM-DD
  status?: 'pago' | 'pendente';
}

export interface Investment {
  id: string;
  name: string;
  type: string;
  institution?: string;
  value: number;
  yieldRate?: string;
  liquidity?: string;
  date: string; // YYYY-MM-DD
}

export interface Workout {
  id: string;
  name: string;
  date: string; // YYYY-MM-DD
  durationMinutes?: number;
  focus?: string;
  loadNote?: string;
  totalVolumeKg?: number; // Volume total de carga acumulado em kg
  isRestDay?: boolean;
  dayOfWeek?: string;
  category?: string;
  exercises?: {
    id: string;
    name: string;
    sets: number;
    reps: number;
    weight: string;
    isDone?: boolean;
  }[];
}

export type NoteAccentColor = 'neon' | 'cosmic' | 'ocean' | 'gold' | 'neutral';

export interface Note {
  id: string;
  title: string;
  content: string;
  category: 'Pessoal' | 'Trabalho' | 'Ideias' | 'Metas' | 'Finanças' | 'Oração' | string;
  reminder?: string;
  date?: string; // YYYY-MM-DD
  updatedAt: string;
  isPinned?: boolean;
  isArchived?: boolean;
  isCollapsed?: boolean;
  color?: NoteAccentColor | string;
}

export interface ProductiveTask {
  id: string;
  text: string;
  doneDates?: string[];
}

export interface WeatherData {
  name: string;
  admin1?: string;
  current: {
    temperature_2m: number;
    apparent_temperature: number;
    relative_humidity_2m: number;
    weather_code: number;
    wind_speed_10m: number;
  };
  daily: {
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    weather_code: number[];
    sunrise: string[];
    sunset: string[];
  };
  hourly: {
    time: string[];
    temperature_2m: number[];
    weather_code: number[];
  };
}

export interface WeatherState {
  city: string;
  data: WeatherData | null;
  loading: boolean;
  error: string | null;
  recent: string[];
}

export type ThemeMode =
  | 'light'
  | 'dark'
  | 'cyberpunk'
  | 'cosmic'
  | 'ocean'
  | 'luxury'
  | 'system';

export interface UserProfile {
  name: string;
  email: string;
  mainGoal: string;
  avatarUrl: string;
  avatarEmoji?: string;
  customStatus?: string;
  isLoggedIn?: boolean;
  totalFinancialGoal?: number; // Meta Financeira Total (R$)
}

export interface AlicerceStorageData {
  transactions: Transaction[];
  workouts: Workout[];
  notes: Note[];
  weather: WeatherState;
  name: string;
  userProfile?: UserProfile;
  theme?: ThemeMode;
  investments: Investment[];
  productiveTasks: ProductiveTask[];
}
