import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Shared Gemini client with telemetry header per skill guidelines
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    time: new Date().toISOString(),
  });
});

// Google Search Grounding with gemini-3.5-flash
app.post('/api/search-grounding', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Prompt é obrigatório.' });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction:
          'Você é o analista de inteligência do Alicerce. Forneça respostas atualizadas, estruturadas e confiáveis com base em dados em tempo real da internet sobre economia, finanças pessoais, Selic, inflação, investimentos, musculação, nutrição e produtividade. Use Markdown legível.',
      },
    });

    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const searchQueries = response.candidates?.[0]?.groundingMetadata?.webSearchQueries || [];

    return res.json({
      text: response.text || '',
      groundingChunks: chunks,
      searchQueries,
    });
  } catch (error) {
    console.error('Error in /api/search-grounding:', error);
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Falha ao processar pesquisa com Google Search.',
    });
  }
});

// Google Maps Grounding with gemini-3.5-flash
app.post('/api/maps-grounding', async (req, res) => {
  try {
    const { prompt, lat, lng } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Prompt é obrigatório.' });
    }

    const hasCoords = typeof lat === 'number' && typeof lng === 'number' && !isNaN(lat) && !isNaN(lng);

    const config: any = {
      tools: [{ googleMaps: {} }],
      systemInstruction:
        'Você é o guia local do Alicerce. Recomende com precisão academias, pistas de corrida, centros esportivos, parques ao ar livre, clínicas de fisioterapia e restaurantes saudáveis utilizando os dados do Google Maps. Destaque diferenciais de cada local de forma clara e amigável.',
    };

    if (hasCoords) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: {
            latitude: lat,
            longitude: lng,
          },
        },
      };
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config,
    });

    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    return res.json({
      text: response.text || '',
      groundingChunks: chunks,
    });
  } catch (error) {
    console.error('Error in /api/maps-grounding:', error);
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Falha ao buscar locais no Google Maps.',
    });
  }
});

// WebSocket Server for Gemini Live API Voice Conversations (gemini-3.8-live)
const wss = new WebSocketServer({ server, path: '/live-ws' });

wss.on('connection', async (clientWs: WebSocket) => {
  console.log('Client connected to Live Voice WebSocket');

  let session: any = null;
  let isClosed = false;

  try {
    session = await ai.live.connect({
      model: 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' },
          },
        },
        systemInstruction:
          'Você é o Alicerce Voz, o coach pessoal por voz do aplicativo Alicerce. Você conversa em tempo real com o usuário em português brasileiro. Seja conciso, ágil, enérgico, acolhedor e focado em apoiar a disciplina diária em finanças, treinos físicos, hábitos e produtividade. Responda em no máximo 2 ou 3 frases claras.',
      },
      callbacks: {
        onmessage: (message: LiveServerMessage) => {
          if (isClosed || clientWs.readyState !== WebSocket.OPEN) return;

          // Model audio chunk
          const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (audio) {
            clientWs.send(JSON.stringify({ type: 'audio', audio }));
          }

          // User interrupted the model
          if (message.serverContent?.interrupted) {
            clientWs.send(JSON.stringify({ type: 'interrupted' }));
          }

          // Turn completion
          if (message.serverContent?.turnComplete) {
            clientWs.send(JSON.stringify({ type: 'turnComplete' }));
          }
        },
        onclose: () => {
          console.log('Live API session closed');
          if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'closed' }));
          }
        },
        onerror: (err) => {
          console.error('Live API error:', err);
          if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'error', error: String(err) }));
          }
        },
      },
    });

    if (clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(JSON.stringify({ type: 'connected', message: 'Conectado ao Gemini Live' }));
    }
  } catch (err) {
    console.error('Failed to initiate Gemini Live session:', err);
    if (clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(
        JSON.stringify({
          type: 'error',
          error: err instanceof Error ? err.message : 'Falha ao conectar com o Gemini Live API.',
        })
      );
      clientWs.close();
    }
    return;
  }

  // Handle audio or commands from client
  clientWs.on('message', (raw) => {
    if (!session || isClosed) return;
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.audio) {
        session.sendRealtimeInput({
          audio: {
            data: msg.audio,
            mimeType: 'audio/pcm;rate=16000',
          },
        });
      } else if (msg.text) {
        session.sendRealtimeInput({
          text: msg.text,
        });
      }
    } catch (err) {
      console.error('Error handling WebSocket message from client:', err);
    }
  });

  clientWs.on('close', () => {
    isClosed = true;
    if (session) {
      try {
        session.close();
      } catch {
        // Ignore close error
      }
      session = null;
    }
    console.log('Client disconnected from Live Voice WebSocket');
  });

  clientWs.on('error', (err) => {
    console.error('Client WebSocket error:', err);
  });
});

// Vite middleware in dev, static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`Alicerce full-stack server running on http://0.0.0.0:${port}`);
  });
}

startServer();
